<?php

include('labdd.php');
date_default_timezone_set('Asia/Dhaka');

$where = array();

if (!empty($_POST['salesinvoice_patientid'])) {
    $patientid = mysqli_real_escape_string($conn, trim($_POST['salesinvoice_patientid']));
    $where[] = "si.salesinvoice_patientid LIKE '".$patientid."%'";
}


if (!empty($_POST['salesinvoice_id'])) {
    $salesinvoice_id = mysqli_real_escape_string($conn, trim($_POST['salesinvoice_id']));
    $where[] = "si.salesinvoice_id LIKE '".$salesinvoice_id."%'";
}

if (!empty($_POST['salesinvoice_patient'])) {
    $patient = mysqli_real_escape_string($conn, trim($_POST['salesinvoice_patient']));
    $where[] = "si.salesinvoice_patient LIKE '%".$patient."%'";
}

$whereSql = "";
if(count($where) > 0){
    $whereSql = "WHERE ".implode(" AND ", $where);
}

header("Content-Type: text/html; charset=utf-8");
ob_start();

function renderTableHeader($title){
    echo "<h3 align='center'>$title</h3>
    <table border='1' width='100%' cellspacing='0' cellpadding='5'>
    <tr bgcolor='#cccccc'>
        <th>SL</th>
        <th>Inv No</th>
        <th>P.ID</th>
        <th>Patient</th>
        <th>Ward</th>
        <th>Date</th>
        <th>Item</th>
        <th>Qty</th>
        <th>Total</th>
    </tr>";
}

renderTableHeader("Sales Item Report");

$sql = "
SELECT
    si.salesinvoice_id,
    si.salesinvoice_patientid,
    si.salesinvoice_patient,
    si.ward,
    sid.auto_number,
    sid.salesinvoicedetails_date,
    sid.salesinvoicedetails_item AS item,
    sid.salesinvoicedetails_qty AS qty,
    sid.salesinvoicedetails_total AS total
FROM salesinvoicedetails sid
INNER JOIN salesinvoice si
    ON si.salesinvoice_id = sid.salesinvoice_id
$whereSql
ORDER BY
    si.salesinvoice_id ASC,
    sid.auto_number ASC
";
$result = mysqli_query($conn,$sql);

$totalSales = 0;
$sl = 1;

while($row = mysqli_fetch_assoc($result)){

    $totalSales += $row['total'];

    echo "<tr>
        <td>".$sl."</td>
         <td>".$row['salesinvoice_id']."</td>
        <td>".$row['salesinvoice_patientid']."</td>
        <td>".$row['salesinvoice_patient']."</td>
        <td>".$row['ward']."</td>
        <td>".$row['salesinvoicedetails_date']."</td>
        <td>".$row['item']."</td>
        <td>".$row['qty']."</td>
        <td align='right'>".number_format($row['total'],2)."</td>
    </tr>";

    $sl++;
}

echo "<tr bgcolor='#EEEEEE'>
        <td colspan='8' align='right'><strong>Total Sales</strong></td>
        <td align='right'><strong>".number_format($totalSales,2)."</strong></td>
      </tr>";

echo "</table>";



// --- RETURN REPORT ---
// --- RETURN REPORT ---
renderTableHeader("Return Item Report");

$sql2 = "
SELECT  
    si.salesinvoice_id, 
    si.salesinvoice_patientid, 
    si.salesinvoice_patient, 
    si.ward, 
    sid.salesinvoicereturndetails_item AS item, 
    SUM(sid.salesinvoicereturndetails_qty) AS qty, 
    SUM(sid.salesinvoicereturndetails_total) AS total, 
    DATE(sid.salesinvoicereturndetails_date) AS date 
FROM salesinvoicereturndetails sid 
JOIN salesinvoice si 
    ON si.salesinvoice_id = sid.salesinvoice_id 
$whereSql
GROUP BY 
    si.salesinvoice_id, 
    sid.salesinvoicereturndetails_item 
ORDER BY 
    si.salesinvoice_id ASC
";

$result2 = mysqli_query($conn, $sql2);

$totalReturn = 0;
$sl = 1;

while($row = mysqli_fetch_assoc($result2)) {

    $totalReturn += $row['total'];

    echo "<tr>
        <td>".$sl."</td>
        <td>".$row['salesinvoice_id']."</td>
        <td>".$row['salesinvoice_patientid']."</td>
        <td>".$row['salesinvoice_patient']."</td>
        <td>".$row['ward']."</td>
        <td>".$row['date']."</td>
        <td>".$row['item']."</td>
        <td>".$row['qty']."</td>
        <td align='right'>".number_format($row['total'],2)."</td>
    </tr>";

    $sl++;
}

echo "<tr bgcolor='#EEEEEE'>
        <td colspan='8' align='right'>
            <strong>Total Return</strong>
        </td>
        <td align='right'>
            <strong>".number_format($totalReturn,2)."</strong>
        </td>
      </tr>";

echo "</table>";

 
$net = $totalSales - $totalReturn;
echo "<h4 align='center'>Net Payable: <strong>" . number_format($net, 2) . " TK</strong></h4>";


ob_end_flush();
?>