<script language="JavaScript" type="text/javascript">
	
	var itemdata = <?php echo $itemdata;?>;
	var patientdata = <?php echo $patientdata;?>;
	var pcdata = <?php echo $pcdata;?>;
	//var cabin = <?php //echo $cabin;?>;
	$(document).ready(function($) {
		document.getElementsByName("hospitalinvoice_item[]")[0].focus();

		$( ".itemname" ).autocomplete({
			
			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				var hospitalinvoice_ratearray = document.getElementsByName("hospitalinvoice_rate[]");
				hospitalinvoice_ratearray[indexpos].value = ui.item.hospitalitem_price;
				
				var hospitalinvoice_qtyarray = document.getElementsByName("hospitalinvoice_qty[]");
				hospitalinvoice_qtyarray[indexpos].value = 1;
				
				var hospitalinvoice_pccomissionarray = document.getElementsByName("hospitalinvoice_pccomission[]");
				hospitalinvoice_pccomissionarray[indexpos].value = ui.item.hospitalitem_pccommission;
				
				var hospitalinvoice_categoryarray = document.getElementsByName("hospitalinvoice_category[]");
				hospitalinvoice_categoryarray[indexpos].value = ui.item.hospitalitem_category;
				
				var hospitalinvoice_unitarray = document.getElementsByName("hospitalinvoice_unit[]");
				hospitalinvoice_unitarray[indexpos].value = ui.item.hospitalitem_unit;
				
				var hospitalinvoice_refvaluearray = document.getElementsByName("hospitalinvoice_refvalue[]");
				hospitalinvoice_refvaluearray[indexpos].value = ui.item.hospitalitem_refvalue;
				
				calculaterowtotal(indexpos);
				calculate_pctotal();
				
				return false;
			}
		});
		
		
		$( "#hospitalinvoice_patientid" ).autocomplete({
			
			minLength: 1,
			source: patientdata,
			
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('hospitalinvoice_patient').value = ui.item.labelval;
				 document.getElementById('hospitalinvoice_age').value = ui.item.opregistration_age;
				 document.getElementById('hospitalinvoice_pc').value = ui.item.pcname;
				 document.getElementById('hospitalinvoice_lab_due').value = ui.item.due;
				 document.getElementById('advanced').value = ui.item.advanced;
				 document.getElementById('hospitalinvoice_cabin').value = ui.item.ward;
				 document.getElementById('hospitalinvoice_gender').value = ui.item.opregistration_gender;
				 document.getElementById('hospitalinvoice_mobile').value = ui.item.opregistration_mobile;
				 document.getElementById('hospitalinvoice_address').value = ui.item.opregistration_address;
				 document.getElementById('hospitalinvoice_admissiondate').value = ui.item.opregistration_date;
				
				return false;
			}
		});
		
		
		// pc search
		$( "#hospitalinvoice_pc" ).autocomplete({
			
			minLength: 1,
			source: pcdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('hospitalinvoice_pc').value = ui.item.labelval;
				 document.getElementById('hospitalinvoice_mpo').value = ui.item.mpo;
				
				return false;
			}
		});
		
		/*$( "#hospitalinvoice_patientid" ).autocomplete({
			
			minLength: 1,
			source: cabin,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('hospitalinvoice_ward').value = ui.item.labelval;
				
				return false;
			}
		});
		*/
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
	});
	function calculate_discountp(){
		var hospitalinvoice_discountparray = document.getElementsByName("hospitalinvoice_discountp[]");
		var hospitalinvoice_discarray = document.getElementsByName("hospitalinvoice_disc[]");
		var hospitalinvoice_ratearray = document.getElementsByName("hospitalinvoice_rate[]");
		var hospitalinvoice_qtyarray = document.getElementsByName("hospitalinvoice_qty[]");
		if(hospitalinvoice_discountparray.length>0){
			for(var p=0; p<hospitalinvoice_discountparray.length; p++){
				var hospitalinvoice_discountp = parseFloat(hospitalinvoice_discountparray[p].value);
				if(hospitalinvoice_discountp=='' || isNaN(hospitalinvoice_discountp)){hospitalinvoice_discountp = 0;}
				
				var hospitalinvoice_disc = parseFloat(hospitalinvoice_discarray[p].value);
				if(hospitalinvoice_disc=='' || isNaN(hospitalinvoice_disc)){hospitalinvoice_disc = 0;}
				if(hospitalinvoice_discountp>0){
					var hospitalinvoice_rate = parseFloat(hospitalinvoice_ratearray[p].value);
					if(hospitalinvoice_rate=='' || isNaN(hospitalinvoice_rate)){hospitalinvoice_rate = 0;}
					
					var hospitalinvoice_qty = hospitalinvoice_qtyarray[p].value;
					if(hospitalinvoice_qty=='' || isNaN(hospitalinvoice_qty)){hospitalinvoice_qty = 0;}
					
					var total = parseFloat(hospitalinvoice_rate*hospitalinvoice_qty);			
					var hospitalinvoice_disc = parseFloat(total*hospitalinvoice_discountp*0.01);
					
					hospitalinvoice_discarray[p].value = hospitalinvoice_disc.toFixed(2);
				}
				
				calculaterowtotal(p);
			}
		}
	}
	
	function calculaterowtotal(indexpos){
		if(indexpos=='all'){
			var hospitalinvoice_ratearray = document.getElementsByName("hospitalinvoice_rate[]");
			var hospitalinvoice_qtyarray = document.getElementsByName("hospitalinvoice_qty[]");
			var hospitalinvoice_discarray = document.getElementsByName("hospitalinvoice_disc[]");
			var hospitalinvoice_totalarray = document.getElementsByName("hospitalinvoice_total[]");
			
			if(hospitalinvoice_ratearray.length>0){
				for(var p=0; p<hospitalinvoice_ratearray.length; p++){
					var hospitalinvoice_rate = parseFloat(hospitalinvoice_ratearray[p].value);
					if(hospitalinvoice_rate=='' || isNaN(hospitalinvoice_rate)){hospitalinvoice_rate = 0;}
					
					var hospitalinvoice_qty = parseFloat(hospitalinvoice_qtyarray[p].value);
					if(hospitalinvoice_qty=='' || isNaN(hospitalinvoice_qty)){hospitalinvoice_qty = 0;}
					
					var total = parseFloat(hospitalinvoice_rate*hospitalinvoice_qty);
					
					var hospitalinvoice_disc = parseFloat(hospitalinvoice_discarray[p].value);
					if(hospitalinvoice_disc=='' || isNaN(hospitalinvoice_disc)){hospitalinvoice_disc = 0;}
					
					var total = parseFloat(total-hospitalinvoice_disc);
					
					hospitalinvoice_totalarray[p].value = total.toFixed(2);
				}
			}
			
		}
		else{
			var hospitalinvoice_ratearray = document.getElementsByName("hospitalinvoice_rate[]");
			var hospitalinvoice_rate = parseFloat(hospitalinvoice_ratearray[indexpos].value);
			if(hospitalinvoice_rate=='' || isNaN(hospitalinvoice_rate)){hospitalinvoice_rate = 0;}
			
			var hospitalinvoice_qtyarray = document.getElementsByName("hospitalinvoice_qty[]");
			var hospitalinvoice_qty = parseFloat(hospitalinvoice_qtyarray[indexpos].value);
			if(hospitalinvoice_qty=='' || isNaN(hospitalinvoice_qty)){hospitalinvoice_qty = 0;}
			
			var total = parseFloat(hospitalinvoice_rate*hospitalinvoice_qty);
			
			var hospitalinvoice_discarray = document.getElementsByName("hospitalinvoice_disc[]");
			var hospitalinvoice_disc = parseFloat(hospitalinvoice_discarray[indexpos].value);
			if(hospitalinvoice_disc=='' || isNaN(hospitalinvoice_disc)){hospitalinvoice_disc = 0;}
			
			var total = parseFloat(total-hospitalinvoice_disc);
			
			var hospitalinvoice_totalarray = document.getElementsByName("hospitalinvoice_total[]");
			hospitalinvoice_totalarray[indexpos].value = total.toFixed(2);
		}
		
		calculate_total();
	}
	
	function calculate_total(){
		var hospitalinvoice_lab_due = parseFloat(document.getElementById("hospitalinvoice_lab_due").value);
		if(hospitalinvoice_lab_due=='' || isNaN(hospitalinvoice_lab_due)){hospitalinvoice_lab_due = 0;}
		
		
		var hospitalinvoice_subtotal = 0;
		var hospitalinvoice_totalarray = document.getElementsByName("hospitalinvoice_total[]");
		if(hospitalinvoice_totalarray.length>0){
			for(var p=0; p<hospitalinvoice_totalarray.length; p++){
				var hospitalinvoice_total = parseFloat(hospitalinvoice_totalarray[p].value);
				if(hospitalinvoice_total=='' || isNaN(hospitalinvoice_total)){hospitalinvoice_total = 0;}
				hospitalinvoice_subtotal = parseFloat(hospitalinvoice_subtotal+hospitalinvoice_total);
			}
		}
		//subtotal calculation
		document.getElementById("hospitalinvoice_subtotal").value = (hospitalinvoice_subtotal).toFixed(2);
		
		var hospitalinvoice_totaldiscp = parseFloat(document.getElementById("hospitalinvoice_totaldiscp").value);
		if(hospitalinvoice_totaldiscp=='' || isNaN(hospitalinvoice_totaldiscp)){hospitalinvoice_totaldiscp = 0;}
		
		var hospitalinvoice_totaldisc = parseFloat(document.getElementById("hospitalinvoice_totaldisc").value);
		if(hospitalinvoice_totaldisc=='' || isNaN(hospitalinvoice_totaldisc)){hospitalinvoice_totaldisc = 0;}
		
		var hospitalinvoice_lab_due = parseFloat(document.getElementById("hospitalinvoice_lab_due").value);
		if(hospitalinvoice_lab_due=='' || isNaN(hospitalinvoice_lab_due)){hospitalinvoice_lab_due = 0;}
		
		var advanced = parseFloat(document.getElementById("advanced").value);
		if(advanced=='' || isNaN(advanced)){advanced = 0;}
		
		
		if(hospitalinvoice_totaldiscp>0){
			var hospitalinvoice_totaldisc = parseFloat(hospitalinvoice_subtotal*hospitalinvoice_totaldiscp*0.01);
			document.getElementById('hospitalinvoice_totaldisc').value= hospitalinvoice_totaldisc.toFixed(2);
		}
		
		var service = parseFloat((hospitalinvoice_subtotal)*0.20);
		document.getElementById('service').value=	service.toFixed(2);
		
		//var gross = parseFloat(hospitalinvoice_lab_due+hospitalinvoice_subtotal + service);
		//document.getElementById('gross').value=	gross.toFixed(2);
		
		var gross = parseFloat(hospitalinvoice_subtotal + service);
		document.getElementById('gross').value=	gross.toFixed(2);
		
		
		//var hospitalinvoice_subtotalafterdisc = parseFloat(hospitalinvoice_lab_due+hospitalinvoice_subtotal + service-hospitalinvoice_totaldisc-advanced);
		//document.getElementById('hospitalinvoice_subtotalafterdisc').value=	hospitalinvoice_subtotalafterdisc.toFixed(2);
		
		var hospitalinvoice_subtotalafterdisc = parseFloat(hospitalinvoice_subtotal +hospitalinvoice_lab_due + service-hospitalinvoice_totaldisc-advanced);
		document.getElementById('hospitalinvoice_subtotalafterdisc').value=	hospitalinvoice_subtotalafterdisc.toFixed(2);
			
		var hospitalinvoice_receiveamount = parseFloat(document.getElementById("hospitalinvoice_receiveamount").value);
		if(hospitalinvoice_receiveamount=='' || isNaN(hospitalinvoice_receiveamount)){hospitalinvoice_receiveamount = 0;}
		//advanced amount calculation
		
		var hospitalinvoice_due = parseFloat(hospitalinvoice_subtotalafterdisc-hospitalinvoice_receiveamount);
		document.getElementById('hospitalinvoice_due').value=hospitalinvoice_due.toFixed(2);		
		
	}
	
	function calculate_pctotal(){
		var hospitalinvoice_totalpccomission = 0;
		var hospitalinvoice_pccomissionarray = document.getElementsByName("hospitalinvoice_pccomission[]");
		if(hospitalinvoice_pccomissionarray.length>0){
			for(var p=0; p<hospitalinvoice_pccomissionarray.length; p++){
				var hospitalinvoice_pccomission = parseFloat(hospitalinvoice_pccomissionarray[p].value);
				if(hospitalinvoice_pccomission=='' || isNaN(hospitalinvoice_pccomission)){hospitalinvoice_pccomission = 0;}
				hospitalinvoice_totalpccomission = parseFloat(hospitalinvoice_totalpccomission+hospitalinvoice_pccomission);
			}
		}
		
		document.getElementById("hospitalinvoice_totalpccomission").value = hospitalinvoice_totalpccomission.toFixed(2);
		
	}
	
	function check_particular(){
		/*var particular_idlistarray = new Array();
		var particular_id = document.getElementsByName('particular_id[]');
		var particular_count = particular_id.length;
		var particular_priceid = document.getElementsByName('particular_price[]');
		var particular_qtyid = document.getElementsByName('particular_qty[]');
			
		var error_messageid = document.getElementById('errmsg_particular_id');
		error_messageid.innerHTML = '';
		
		for(i = 0; i < particular_count; i++) {
												
			if(particular_id[i].value=='' || particular_id[i].value==0){
				error_messageid.innerHTML = 'Missing Particular Name '+parseInt(i+1);
				particular_id[i].focus();
				returnvalue = false;
			}
			
			if(particular_idlistarray.length>0 && particular_idlistarray.indexOf(particular_id[i].value) != -1){
				error_messageid.innerHTML = 'Dupplicate Particular Name '+i;
				particular_id[i].focus();
				return false;
			}
			else{
				particular_idlistarray[i] = particular_id[i].value;
			}
			
			var particular_priceval = parseInt(particular_priceid[i].value);
			if(isNaN(particular_priceval) || particular_priceval==''){particular_priceval = 0;}
			if(particular_priceval==0){
				error_messageid.innerHTML = 'Missing Price '+Math.floor(i+1);
				particular_priceid[i].focus();
				return false;
			}
										
			var particular_qtyval = parseInt(particular_qtyid[i].value);
			if(isNaN(particular_qtyval) || particular_qtyval==''){particular_qtyval = 0;}							
			if(particular_qtyval==0){
				error_messageid.innerHTML = 'Missing QTY '+Math.floor(i+1);
				particular_qtyid.focus();
				return false;
			}
		}*/
		return true;
	}
	function addnew_particularrow(animate) {
		if(check_particular()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" style=\"BORDER-COLLAPSE: collapse; border:2px solid #FFF\" bgcolor=\"#77F7AA\" align=\"left\" width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"2\">"+
							'<tr>'+
								'<td align="right">Item Name</td>'+
								'<td> <input type="text" name="hospitalinvoice_item[]" value="" class="tdclass itemname"/></td>'+
								 '<input type="hidden" name="auto_number[]" value=""/>'+ 
								 '<input type="hidden" name="hospitalinvoice_category[]" value="" class="tdclass"  />'+
								'<input type="hidden" name="hospitalinvoice_unit[]" value="" class="tdclass"  />'+
								'<input type="hidden" name="hospitalinvoice_refvalue[]" value="" class="tdclass"  />'+
								'<td align="right">Rate</td>'+
								"<td> <input type=\"text\" name=\"hospitalinvoice_rate[]\"  id=\"hospitalinvoice_rate\" value=\"\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/></td>"+											 
								'<td align="right">Qty</td>'+
								"<td> <input type=\"text\" name=\"hospitalinvoice_qty[]\"   id=\"hospitalinvoice_qty\" value=\"\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/></td>"+
								'<td align="right">Disc%</td>'+
								'<td> <input type="text" name="hospitalinvoice_discountp[]" value="" class="tdclasssale" onKeyUp="calculate_discountp();"/></td>'+
								'<td align="right">Disc</td>'+
								"<td> <input type=\"text\" name=\"hospitalinvoice_disc[]\" value=\"\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\" /></td>"+
								'<td align="right">P.C</td>'+
								'<td> <input type="text" name="hospitalinvoice_pccomission[]" value="" class="tdclasssale" onKeyUp="calculate_pctotal();"  /></td>'+
								'<td align="right">Total</td>'+
								'<td> <input type="text" readonly name="hospitalinvoice_total[]"  id="hospitalinvoice_total" value="" class="tdclasssale"  /></td>'+												
								'<td>'+
								 "<input type=\"button\" value=\"Cancel\" onClick=\"deletethislistrow('particularlistrowno"+particular_rowcount+"');\" class=\"tdclasssale\"  />"+
								'</td>'+
							  '</tr>'+
						"</table>";
						
			var $newparticularlist = $("<li></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(200); 
			else 
			   $newparticularlist.show();   
			document.getElementsByName("hospitalinvoice_item[]")[parseInt(particular_rowcount-1)].focus();
			
			$( ".itemname" ).autocomplete({			
				minLength: 1,
				source: itemdata,
				focus: function( event, ui ) {
					//$( "#search_item_number" ).val( ui.item.labelval );
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					
					var hospitalinvoice_ratearray = document.getElementsByName("hospitalinvoice_rate[]");
					hospitalinvoice_ratearray[indexpos].value = ui.item.hospitalitem_price;
					
					var hospitalinvoice_qtyarray = document.getElementsByName("hospitalinvoice_qty[]");
					hospitalinvoice_qtyarray[indexpos].value = 1;
					
					var hospitalinvoice_pccomissionarray = document.getElementsByName("hospitalinvoice_pccomission[]");
					hospitalinvoice_pccomissionarray[indexpos].value = ui.item.hospitalitem_pccommission;
					
					var hospitalinvoice_categoryarray = document.getElementsByName("hospitalinvoice_category[]");
					hospitalinvoice_categoryarray[indexpos].value = ui.item.hospitalitem_category;
					
					var hospitalinvoice_unitarray = document.getElementsByName("hospitalinvoice_unit[]");
					hospitalinvoice_unitarray[indexpos].value = ui.item.hospitalitem_unit;
					
					var hospitalinvoice_refvaluearray = document.getElementsByName("hospitalinvoice_refvalue[]");
					hospitalinvoice_refvaluearray[indexpos].value = ui.item.hospitalitem_refvalue;
				
	
					calculaterowtotal(indexpos);
					calculate_pctotal();
					
					return false;
				}
			});						
		}
	}
	
	function deletethislistrow(tableidname){
		$("#"+tableidname).parent("li").slideUp(200, function() {
			$(this).remove();
			calculaterowtotal('all');
		});
	}

function funcSaveBill1()
{
	
	var varUserChoice; 
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet); 
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		document.frmsales.submit();
		//return true;
	}
}	
	
</script>