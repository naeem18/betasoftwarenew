<?php
session_start();
if(isset($_GET['idvalue'])){	
	
 	$idvalue = $_GET['idvalue'];
	if($idvalue>0){
		require('labdd.php');
		$user=$_SESSION['username'];
	 	$str2 = "update labinvoice set  `drcomissionpaid`='1'
						   where labinvoice_id = '$idvalue'";
		$userquery = mysqli_query($conn, $str2);
		
		if($userquery){			
			header("location:index.php?p=statementbydoctor&message=Approved-successfully");			
		}
		else{
			header("location:index.php?p=$returnpage&message=couldnotApproved");
		}
	}
	else{
		header("location:index.php?p=statementbydoctor&message=incorrect_id");
	}
}
?>