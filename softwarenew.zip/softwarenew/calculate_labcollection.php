<script language="JavaScript" type="text/javascript">
	
	var patientdata = <?php echo $patientdata;?>;
	$(document).ready(function($) {
		
		
		$( "#opregistration_id" ).autocomplete({
			
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
					document.getElementById('labcollection_name').value = ui.item.labelval;
					document.getElementById('labcollection_number').value = ui.item.opregistration_mobile;
					document.getElementById('opregistration_id').value = ui.item.opregistration_id;
					document.getElementById('opregistration_code').value = ui.item.opregistration_code;
					document.getElementById('opregistration_due').value = ui.item.lab_due;
					document.getElementById('labinvoice_totalpccomission').value = ui.item.labinvoice_totalpccomission;
					document.getElementById('labcollection_address').value = ui.item.opregistration_address;
					document.getElementById('labcollection_ward').value = ui.item.ward;
				
				return false;
			}
		});
		
	});
	
		
	function calculate_total(){
		
		var opregistration_due = parseFloat(document.getElementById("opregistration_due").value);
		if(opregistration_due=='' || isNaN(opregistration_due)){opregistration_due = 0;}
		
		var labinvoice_totalpccomission = parseFloat(document.getElementById("labinvoice_totalpccomission").value);
		if(labinvoice_totalpccomission=='' || isNaN(labinvoice_totalpccomission)){labinvoice_totalpccomission = 0;}
		
		var discount_amount = parseFloat(document.getElementById("discount_amount").value);
		if(discount_amount=='' || isNaN(discount_amount)){discount_amount = 0;}
			
		var collection_amount = parseFloat(document.getElementById("collection_amount").value);
		if(collection_amount=='' || isNaN(collection_amount)){collection_amount = '';}
		
		var adjustment = parseFloat(document.getElementById("adjustment").value);
		if(adjustment=='' || isNaN(adjustment)){adjustment = '';}
		
		var labinvoice_totalpccomission_update = parseFloat(labinvoice_totalpccomission - discount_amount);
		document.getElementById('labinvoice_totalpccomission_update').value=labinvoice_totalpccomission_update.toFixed(2);
		
		var total_balance = parseFloat(opregistration_due + adjustment - discount_amount - collection_amount);
		document.getElementById('total_balance').value=	total_balance.toFixed(2);
		
		}
		
		
function funcSaveBill1()
{
	
	var varUserChoice; 
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet); 
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		document.frmsales.submit();
		//return true;
	}
}				
	
</script>