<script type="text/javascript" language="javascript">
	function removetablerow3(idvalue){
		var conf = confirm("Do you sure want to delete this ID="+idvalue+" from this Table ");
		if(conf)
			window.location='delete_table_row3.php?idvalue='+idvalue;
		}
</script>

<?php
	date_default_timezone_set('Asia/Dhaka'); 
	$searchstr='';
	if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
	{
		$transactiondatefrom = $_REQUEST['ADate1'];
		$transactiondateto = $_REQUEST['ADate2'];
		
		$user = $_REQUEST['user'];
		$section = $_REQUEST['section'];
		$opregistration_id = $_REQUEST['opregistration_id'];
		$canteeninvoice_id = $_REQUEST['canteeninvoice_id'];
		if($user !=''){
			$searchstr .= " and user like '%$user%'";
		}
		elseif($opregistration_id !=''){
			$searchstr .= " and opregistration_id like '%$opregistration_id%'";
		}
		elseif($canteeninvoice_id !=''){
			$searchstr .= " and canteeninvoice_id like '%$canteeninvoice_id%'";
		}
		elseif($section !=''){
			$searchstr .= " and section like '%$section%'";
		}
	}
	else
	{
		$transactiondatefrom = date('Y-m-d', strtotime('-0 day'));
		$transactiondateto = date('Y-m-d');
	}
?>

<table width="100%" border="0" cellspacing="0" cellpadding="2">

  <tr>
    <td valign="top" align="center">
    	<form name="cbform1" method="post" action="index.php?p=canteeninvoicecollection">
            <table width="100%" border="1" align="center" cellpadding="4" cellspacing="1" bordercolor="#666666" style="border-collapse: collapse">
              <tbody>
                <tr bgcolor="#011E6A">
                  <td colspan="100%" bgcolor="#CCCCCC" align="center"><strong>Search Date wise</strong></td>
                </tr>           
                <tr bgcolor="#FFFFFF">
                    <td>Date From:</td>
                    <td>
                        <input name="ADate1" id="ADate1" style="border: 1px solid #001E6A" value="<?php echo $transactiondatefrom; ?>"  size="8"  readonly="readonly" onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
                    </td>
                    <td>Date To:</td>
                    <td>
                        <input name="ADate2" id="ADate2" style="border: 1px solid #001E6A" value="<?php echo $transactiondateto; ?>"  size="8"  readonly="readonly" onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate2')" style="cursor:pointer"/>
                    </td>
                    
                    <td>User</td>
            	    <td><input type="text" name="user" id="user" size="12" /></td>
                    
                     <td>ID</td>
            	     <td><input type="text" size="6" name="opregistration_id" id="opregistration_id" /></td>
            
            		<td>Inv.</td>
            	    <td><input type="text" size="6" name="canteeninvoice_id" id="canteeninvoice_id" /></td>
            		 <td>Section</td>
            	     <td><input type="text" size="6" name="section" id="section" /></td>
            
                    <td><input style="border: 1px solid #001E6A" type="submit" value="Search" name="Submit"></td>
                    <td>
                       <input name="print" type="button" id="print"  style="border: 1px solid #001E6A" value="Print" onClick="PrintElem('#printarea');" />
                    </td>
                </tr>
              </tbody>
            </table>
		</form>
      <script type="text/javascript">
        
            function PrintElem(elem)
            {
                var data = $(elem).html();
				
				var mywindow = window.open('', 'my div', 'height=600,width=450');
                mywindow.document.write('<html><head><title>Daily LAB Collection</title>');
                mywindow.document.write('<link rel="stylesheet" href="css/default.css" type="text/css" />');
                mywindow.document.write('</head><body >');
                mywindow.document.write(data);
                mywindow.document.write('</body></html>');
        
                mywindow.print();
               	//mywindow.close();
                return true;
            }        
        </script>
   	</td>
</tr>

	<tr>
    	<td align="center" id="printarea">
		<?php 
		$datetime1 = new DateTime($transactiondatefrom);
		$datetime2 = new DateTime($transactiondateto);
		$interval = $datetime1->diff($datetime2);
		$totaldays = $interval->format('%a');
		if($datetime1<$datetime2){
			$fromdate = $transactiondatefrom;
			$todate = $transactiondateto;
		}
		else{
			$fromdate = $transactiondateto;
			$todate = $transactiondatefrom;
		}
		?>
        <table width="100%" border="1" style="BORDER-COLLAPSE: collapse;font-size:12px;" cellspacing="1" cellpadding="4">
          <tr>
            <td colspan="19" bgcolor="#ccc" align="center" style="color:#03F; border:1px solid #03F;">
            	<strong><?php echo $hospitaldata_name;?></strong><br>
                <strong>Statement By Due Collection :: Date: <?php echo date('d.m.y',strtotime($fromdate));?></strong>
            </td>
          </tr>
            <tr bgcolor="#003399" style="color:#fff" align="center">
                <td><strong>SL No.</strong></td>
                <td><strong>Print</strong></td>
                <td><strong>Inv No.</strong></td>
                <td><strong>C.No.</strong></td>
                <td><strong>Date</strong></td>
                <td><strong>Section</strong></td>
                <td><strong>Name</strong></td>
                <td><strong>P.ID</strong></td>
                <td><strong>Cabin No.</strong></td>
                <td><strong>Inv. Amount</strong></td>
                <td><strong>Due Amount</strong></td>
                <td><strong>Collected Amount</strong></td>
                <td><strong>Discount</strong></td> 
                <td><strong>PC</strong></td> 
                <td><strong>MPO</strong></td> 
                <td><strong>Note/Dics By</strong></td> 
                <td><strong>User</strong></td>  
              </tr>
              
		<?php
		$totalsumlabinvoice_receiveamount='0.00';
		
		$s='';
		for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
			$sqllabinvoice = "select * from canteencollection where status!='Deleted' AND labcollection_date between '$newfromdate' and '$newtodate' $searchstr order by canteencollection_id asc";
	  		$labinvoicequery = mysqli_query($conn, $sqllabinvoice);
			if($labinvoicequery &&  mysqli_num_rows($labinvoicequery)>0){
			while ($labinvoicerow = mysqli_fetch_array($labinvoicequery)) {
					$canteencollection_id  = $labinvoicerow['canteencollection_id'];
					$canteeninvoice_id  = $labinvoicerow['canteeninvoice_id'];
					$opregistration_id = $labinvoicerow['opregistration_id'];
					$previous_due = $labinvoicerow['previous_due'];
					$due = $labinvoicerow['due'];
					$user = $labinvoicerow['user'];
                    $note = $labinvoicerow['note'];
                    $section = $labinvoicerow['section'];
                    $labcollection_ward = $labinvoicerow['labcollection_ward'];
					$labcollection_name = $labinvoicerow['labcollection_name'];
					$labinvoice_subtotalafterdisc = $labinvoicerow['labinvoice_subtotalafterdisc'];
					$labinvoice_pc = $labinvoicerow['labinvoice_pc'];
					$labinvoice_mpo = $labinvoicerow['labinvoice_mpo'];
					$collection_amount=	$labinvoicerow['collection_amount'];
					$discount_amount=	$labinvoicerow['discount_amount'];
					$labcollection_date=	$labinvoicerow['labcollection_date'];
					
			$action = "<a href=\"index.php?p=labcollectionedit&canteencollection_id=$canteencollection_id\">Edit</a> <a href=\"javascript:void(0)\" onclick=\"removetablerow3($canteencollection_id)\"></a>";
			$action1 = "<a href=\"index.php?p=labcollectionedit_indoor&canteencollection_id=$canteencollection_id\">Edit</a> <a href=\"javascript:void(0)\" onclick=\"removetablerow3($canteencollection_id)\"></a>";
			$action2 = "<a href=\"index.php?p=printdentalcollection&canteencollection_id=$canteencollection_id\" target=\"_blank\">Print</a>";
				
			$totalsumlabinvoice_receiveamount  = $totalsumlabinvoice_receiveamount + $collection_amount;
			?>
                <tr>
                    <td align="center"><?php echo $s = $s + 1; ?></td>
                    <td><?php echo $action2; ?></td>
                    <td><?php echo $canteeninvoice_id; ?></td>
                    <td><?php echo $canteencollection_id; ?></td>
                    <td><?php echo date('d.m.y',strtotime($newfromdate)); ?></td>
                    <td><?php echo $section; ?></td>
                    <td><?php echo $labcollection_name; ?></td>
                    <td><?php echo $opregistration_id; ?></td>
                    <td><?php echo $labcollection_ward; ?></td>
                    <td><?php echo $labinvoice_subtotalafterdisc; ?></td>
                    <td><?php echo $due; ?></td>
                    <td><?php echo $collection_amount; ?></td>
                    <td><?php echo $discount_amount; ?></td>
                    <td><?php echo $labinvoice_pc; ?></td>
                    <td><?php echo $labinvoice_mpo; ?></td>
                    <td><?php echo $note; ?></td>
                    <td><?php echo $user; ?></td>
                   
                 </tr>
                <?php
                }
			}
		}
		?>
        
    <tr align="left">
      <td colspan="11" align="right">Total :</td>
       <td><strong><?php echo number_format($totalsumlabinvoice_receiveamount, 2, '.', ''); ?></strong></td>
       <td colspan="6"></td>
      </tr>
    </table>
    </td>
</tr>
</table>