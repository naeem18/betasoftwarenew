<?php
session_start();
require('../labdd.php');

// Security check
if (!isset($_SESSION['auto_number']) || $_SESSION['company'] != 'betasoft25.0') {
    die(json_encode(['error' => 'Unauthorized access']));
}

$pagename = isset($_GET['p']) ? mysqli_real_escape_string($conn, $_GET['p']) : 'homepageac';
$pagename .= '.php';

// Security: Validate the requested file is within our directory
$realBase = realpath(__DIR__.'/..');
$realPath = realpath($realBase.'/'.$pagename);

if ($realPath === false || strpos($realPath, $realBase) !== 0 || !file_exists($realPath)) {
    die(json_encode(['error' => 'Invalid page request']));
}

ob_start();
include($realPath);
$content = ob_get_clean();

// Format title
$title = str_replace(['.php', '-', '_'], ' ', $pagename);
$title = trim($title);
if ($title == 'homepageac') {
    $title = 'Beta Hospital Management System';
}

echo json_encode([
    'success' => true,
    'title' => $title,
    'content' => $content
]);
?>