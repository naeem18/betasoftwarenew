<?php
 $sqlhd = "select * from hospitaldata order by hospitaldata_id desc";
	$hdquery = mysqli_query($conn, $sqlhd);
		if($hdquery && mysqli_num_rows($hdquery)>0){
		while ($hdrow = mysqli_fetch_array($hdquery))
		 {
			$hospitaldata_id = $hdrow['hospitaldata_id'];
			$hospitaldata_name = $hdrow['hospitaldata_name'];
			$hospitalname = $hdrow['hospitalname'];
			$hospitaldata_address1 = $hdrow['hospitaldata_address1'];
			$hospitaldata_address2 = $hdrow['hospitaldata_address2'];
			$name = 'betahospital';
			$rfshow = $hdrow['rfshow'];
			$namesize = $hdrow['namesize'];
			$pharmacyname = $hdrow['pharmacyname'];
			$pharmacy_address = $hdrow['pharmacy_address'];
			$hospitaldata_mobile = $hdrow['hospitaldata_mobile'];
			$hospitaldata_date = $hdrow['hospitaldata_date'];
			$hospitaldata_logo = $hdrow['hospitaldata_logo'];
			}
		}
?>