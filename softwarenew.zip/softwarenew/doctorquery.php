 <?php
 $sqllabitem = "select * from doctorentry order by doctor_id";
	$labitemquery = mysqli_query($conn, $sqllabitem);
		if($labitemquery && mysqli_num_rows($labitemquery)>0){
		 while ($labitemrow = mysqli_fetch_array($labitemquery))
		 {
			$doctor_id = $labitemrow['doctor_id'];
			$doctor_name = $labitemrow['doctor_name'];
			}
		}
	?>