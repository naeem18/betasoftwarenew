<?php
session_start();
if(isset($_GET['idvalue'])){	
	
	$idvalue = $_GET['idvalue'];
	if($idvalue>0){
		require('labdd.php');
		
		$str2 = "DELETE from emergencyinvoice where emergencyinvoice_id = '$idvalue'";
		$userquery = mysqli_query($conn, $str2);
		
		 $str = "DELETE from emergencyinvoicedetails where emergencyinvoice_id = '$idvalue'";
		$userquery = mysqli_query($conn, $str);
		
		 $str3 = "DELETE from dailytransection_lab where section='Emergency' AND labinvoice_id = '$idvalue'";
		$userquery = mysqli_query($conn, $str3);
		
		
		if($userquery){			
			header("location:index.php?p=emergencyreport&message=remove-successfully");			
		}
		else{
			header("location:index.php?p=emergencyreport&message=couldnotremove");
		}
	}
	else{
		header("location:index.php?p=emergencyreport&message=incorrect_id");
	}
}
?>
