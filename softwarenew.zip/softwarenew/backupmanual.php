<?php
// MySQL connection
include('labdd.php');
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Backup file name
$filename = "db_backup_" . date('Y-m-d_H-i') . ".sql";

// Set headers for download
header('Content-Type: application/sql');
header('Content-Disposition: attachment; filename=' . $filename);

// Open output
$output = fopen('php://output', 'w');

// Get all tables
$tables = [];
$result = mysqli_query($conn, "SHOW TABLES");
while ($row = mysqli_fetch_row($result)) {
    $tables[] = $row[0];
}

foreach ($tables as $table) {
    $res = mysqli_query($conn, "SELECT * FROM `$table`");
    $num_fields = mysqli_num_fields($res);

    // Table structure
    $row2 = mysqli_fetch_row(mysqli_query($conn, "SHOW CREATE TABLE `$table`"));
    fwrite($output, $row2[1] . ";\n\n");

    // Table data
    while ($row = mysqli_fetch_row($res)) {
        $vals = array_map(function($val) use ($conn){
            return isset($val) ? "'" . mysqli_real_escape_string($conn, $val) . "'" : "NULL";
        }, $row);
        fwrite($output, "INSERT INTO `$table` VALUES(" . implode(",", $vals) . ");\n");
    }
    fwrite($output, "\n\n");
}

fclose($output);
exit;
?>
