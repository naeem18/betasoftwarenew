<?php
//date_default_timezone_set('Asia/Dhaka'); 
$searchstr='';
if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
{
	$transactiondatefrom = $_REQUEST['ADate1'];
	$transactiondateto = $_REQUEST['ADate2'];
	
	$bloodbankid = $_REQUEST['bloodbankid'];
	$opregistration_mobile = $_REQUEST['opregistration_mobile'];
	$opregistration_name = $_REQUEST['opregistration_name'];
 	if($opregistration_name !=''){
		$searchstr .= " and opregistration_name like '%$opregistration_name%'";
	}
	elseif($bloodbankid !=''){
		$searchstr .= " and bloodbankid like '%$bloodbankid%'";
	}
	elseif($opregistration_mobile !=''){
		$searchstr .= " and opregistration_mobile like '%$opregistration_mobile%'";
	}
}
else
{
	$transactiondatefrom = date('Y-m-d', strtotime('-1 month'));
	$transactiondateto = date('Y-m-d');
}
?>


<table width="100%" border="0" cellspacing="0" cellpadding="2">
 
  <tr>
    <td valign="top" align="center">
    	<form name="cbform1" method="post" action="index.php?p=bloodbankreport">
            <table width="100%" border="0" align="center" cellpadding="4" cellspacing="0" bordercolor="#666666" style="border-collapse: collapse">
              <tbody>
                <tr bgcolor="#011E6A">
                  <td colspan="15" bgcolor="#CCCCCC" align="center"><strong>Search Date / Name Wise</strong></td>
                </tr>           
                <tr>
                    <td >Date From</td>
                    <td><input name="ADate1" id="ADate1" size="6" style="border: 1px solid #001E6A" value="<?php echo $transactiondatefrom; ?>" readonly onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
                    </td>
                    <td>Date To</td>
                    <td><input name="ADate2" id="ADate2" size="6" style="border: 1px solid #001E6A" value="<?php echo $transactiondateto; ?>" readonly onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate2')" style="cursor:pointer"/>
                   </td>
                    <td>Donar</td>
            	    <td><input type="text" size="16" name="opregistration_name" id="opregistration_name" /></td>
                     <td>By ID</td>
            	    <td><input type="text" size="10" name="bloodbankid" id="bloodbankid"/></td>
                    
                     <td>By Mobile</td>
            	    <td><input type="text" size="15" name="opregistration_mobile" id="opregistration_mobile"/></td>
                    
                      
                    <td><input  style="border: 1px solid #001E6A" type="submit" value="Search" name="Submit" />
                       <!-- <input name="resetbutton" type="reset" id="resetbutton"  style="border: 1px solid #001E6A" value="Reset" />-->
                    </td>
                    <td>
                       <input name="print" type="button" id="print"  style="border: 1px solid #001E6A" value="Print" onClick="PrintDiv();" />
                    </td>
                </tr>
              </tbody>
            </table>
		</form>
       
   	</td>
</tr>

	<td>
   
		<?php 
		$datetime1 = new DateTime($transactiondatefrom);
		$datetime2 = new DateTime($transactiondateto);
		$interval = $datetime1->diff($datetime2);
		$totaldays = $interval->format('%a');
		if($datetime1<$datetime2){
			$fromdate = $transactiondatefrom;
			$todate = $transactiondateto;
		}
		else{
			$fromdate = $transactiondateto;
			$todate = $transactiondatefrom;
		}
		?>
        
        <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1" cellspacing="0" cellpadding="2">
        <tbody>
         <tr>
            <td colspan="19" bgcolor="#f3f3f3" align="center" style="color:#000; border:1px solid #000;">
            	<strong><?php echo $hospitaldata_name;?></strong><br>
                <samp>Donar List :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></samp>
            </td>
          </tr>
             <tr bgcolor="#CCCCCC">
                 <td>SL No.</td>
                <td>Donated Date</td>
                 <td>Donar Name</td>              
                 <td>Blood Group</td>
               <td>Mobile</td>              
                <td>Adress</td>
                <td>User</td>
               </tr>
		<?php
			$s='';
		for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
			$sqlst = "select * from bloodbank where opregistration_date between 
			'$newfromdate' and '$newtodate' $searchstr order by bloodbankid asc";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery &&  mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery)) {
					$bloodbankid = $strow['bloodbankid'];
                    $opregistration_blood = $strow['opregistration_blood'];
                    $opregistration_mobile = $strow['opregistration_mobile'];
                    $opregistration_name = $strow['opregistration_name'];
                    $opregistration_address = $strow['opregistration_address'];
                    $opregistration_date = $strow['opregistration_date'];
                    $user = $strow['user'];
                   
					$action1 = "<a href=\"index.php?p=printadmissionform&bloodbankid=$bloodbankid\" target=\"_blank\">Print</a>";
					$action = "<a href=\"index.php?p=patientregedit&bloodbankid=$bloodbankid\">Update</a>";
					$action11 = "<a href=\"index.php?p=patientregcabin&bloodbankid=$bloodbankid\">Cabin Change</a>";
					$action3 = "<a href=\"index.php?p=iprelease&bloodbankid=$bloodbankid\">Discharge</a>";					
					$action2 = "<a href=\"index.php?p=statementbyinvoice&labinvoice_patientid=$bloodbankid\" target=\"_blank\">History</a>";					
				?>
				
               <tr>
                    <td><?php echo $s=$s+1; ?></td>
                    <td><?php echo $opregistration_date; ?></td>
                    <td><?php echo $opregistration_name; ?></td>
                    <td><?php echo $opregistration_blood; ?></td>
                    <td><?php echo $opregistration_mobile; ?></td>
                    <td><?php echo $opregistration_address; ?></td>
                    <td><?php echo $user; ?></td>
              	</tr>
                <?php
                	}
				}
			}
		?>
        	
           <tbody>
        </table>
        </td>
      
	<td align="center" id="divToPrint" style="display:none">
    
		<?php 
		$datetime1 = new DateTime($transactiondatefrom);
		$datetime2 = new DateTime($transactiondateto);
		$interval = $datetime1->diff($datetime2);
		$totaldays = $interval->format('%a');
		if($datetime1<$datetime2){
			$fromdate = $transactiondatefrom;
			$todate = $transactiondateto;
		}
		else{
			$fromdate = $transactiondateto;
			$todate = $transactiondatefrom;
		}
		?>
        
        <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1" cellspacing="0" cellpadding="2">
        <tbody>
         <tr>
            <td colspan="19" bgcolor="#f3f3f3" align="center" style="color:#000; border:1px solid #000;">
            	<strong><?php echo $hospitaldata_name;?></strong><br>
                <samp>Donar List :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></samp>
            </td>
          </tr>
             <tr bgcolor="#CCCCCC">
                 <td>SL No.</td>
                <td>Donated Date</td>
                 <td>Donar Name</td>              
                 <td>Blood Group</td>
               <td>Mobile</td>              
                <td>Adress</td>
                <td>User</td>
               </tr>
		<?php
			$s='';
		for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
			$sqlst = "select * from bloodbank where opregistration_date between 
			'$newfromdate' and '$newtodate' $searchstr order by bloodbankid asc";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery &&  mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery)) {
					$bloodbankid = $strow['bloodbankid'];
                    $opregistration_blood = $strow['opregistration_blood'];
                    $opregistration_mobile = $strow['opregistration_mobile'];
                    $opregistration_name = $strow['opregistration_name'];
                    $opregistration_address = $strow['opregistration_address'];
                    $opregistration_date = $strow['opregistration_date'];
                    $user = $strow['user'];
                   
					$action1 = "<a href=\"index.php?p=printadmissionform&bloodbankid=$bloodbankid\" target=\"_blank\">Print</a>";
					$action = "<a href=\"index.php?p=patientregedit&bloodbankid=$bloodbankid\">Update</a>";
					$action11 = "<a href=\"index.php?p=patientregcabin&bloodbankid=$bloodbankid\">Cabin Change</a>";
					$action3 = "<a href=\"index.php?p=iprelease&bloodbankid=$bloodbankid\">Discharge</a>";					
					$action2 = "<a href=\"index.php?p=statementbyinvoice&labinvoice_patientid=$bloodbankid\" target=\"_blank\">History</a>";					
				?>
				
               <tr>
                    <td><?php echo $s=$s+1; ?></td>
                    <td><?php echo $opregistration_date; ?></td>
                    <td><?php echo $opregistration_name; ?></td>
                    <td><?php echo $opregistration_blood; ?></td>
                    <td><?php echo $opregistration_mobile; ?></td>
                    <td><?php echo $opregistration_address; ?></td>
                    <td><?php echo $user; ?></td>
              	</tr>
                <?php
                	}
				}
			}
		?>
        	
           <tbody>
        </table>
        </td>
</table>