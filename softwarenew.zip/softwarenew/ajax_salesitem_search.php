<?php
require('labdd.php');

$term = mysqli_real_escape_string($conn, $_GET['term']);

$sql = "
SELECT
    salesitem_name,
    salesitem_stock,
    salesitem_price,
    expire
FROM salesitem
WHERE salesitem_name LIKE '$term%'
ORDER BY salesitem_name ASC
LIMIT 15000
";

$result = mysqli_query($conn, $sql);
?>

<table border="1" width="100%">
    <thead>
        <tr>
            <th>Name</th>
            <th>Stock</th>
            <th>Price</th>
            <th>Expire</th>
        </tr>
    </thead>
    <tbody>
        <?php while($row = mysqli_fetch_assoc($result)){ ?>
        <tr bgcolor="#fff">
            <td><?= $row['salesitem_name']; ?></td>
            <td><?= $row['salesitem_stock']; ?></td>
            <td><?= $row['salesitem_price']; ?></td>
            <td><?= $row['expire']; ?></td>
        </tr>
        <?php } ?>
    </tbody>
</table>