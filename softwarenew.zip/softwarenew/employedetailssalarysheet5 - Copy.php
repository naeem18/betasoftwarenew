<?php
//deepS
date_default_timezone_set('Asia/Dhaka');

$employee_name = isset($_REQUEST['employee_name']) ? trim($_REQUEST['employee_name']) : '';
$month = !empty($_REQUEST['month']) ? $_REQUEST['month'] : date('Y-m');
$year = !empty($_REQUEST['year']) ? $_REQUEST['year'] : date('Y');

// Calculate date range for the selected month
$fromdate = date('Y-m-01', strtotime($year . '-' . $month));
$todate = date('Y-m-t', strtotime($year . '-' . $month));
?>

<h2>Monthly Summary Report</h2>
<form method="post" action="">
    Employee: <input type="text" name="employee_name" value="<?php echo htmlspecialchars($employee_name); ?>">
    Month: 
    <select name="month">
        <?php
        $months = [
            '01' => 'January', '02' => 'February', '03' => 'March', '04' => 'April',
            '05' => 'May', '06' => 'June', '07' => 'July', '08' => 'August',
            '09' => 'September', '10' => 'October', '11' => 'November', '12' => 'December'
        ];
        foreach ($months as $key => $name) {
            $selected = ($key == $month) ? 'selected' : '';
            echo "<option value='$key' $selected>$name</option>";
        }
        ?>
    </select>
    Year: 
    <select name="year">
        <?php
        $currentYear = date('Y');
        for ($y = $currentYear - 2; $y <= $currentYear + 1; $y++) {
            $selected = ($y == $year) ? 'selected' : '';
            echo "<option value='$y' $selected>$y</option>";
        }
        ?>
    </select>
    <button type="submit">Generate Report</button>
</form>

<?php
// Get all employees for the summary
$sql_employees = "SELECT DISTINCT e.e_id, e.name, e.gross 
                  FROM employee e 
                  JOIN machine_data md ON e.e_id = md.e_id 
                  WHERE md.entry_date BETWEEN '$fromdate' AND '$todate'";
if(!empty($employee_name)) {
    $sql_employees .= " AND e.name LIKE '%".mysqli_real_escape_string($conn, $employee_name)."%'";
}
$sql_employees .= " ORDER BY e.name";

$result_employees = mysqli_query($conn, $sql_employees) or die("Employee query failed: ".mysqli_error($conn));

// Initialize totals
$grandTotalLate = 0;
$grandTotalDeduction = 0;
$grandTotalNet = 0;
$grandTotalWorkingDays = 0;
?>

<table border="1" cellspacing="0" cellpadding="5" width="100%" style="border-collapse: collapse; margin-top: 20px;">
<tr bgcolor="#0033FF" style="color:#fff;">
    <th rowspan="2">Employee</th>
    <th rowspan="2">Total Working Days</th>
    <th colspan="3">Late Summary</th>
    <th colspan="3">Salary Summary</th>
    <th rowspan="2">Status Summary</th>
</tr>
<tr bgcolor="#0033FF" style="color:#fff;">
    <th>Total Late (Min)</th>
    <th>Avg Late per Day</th>
    <th>Late Days</th>
    <th>Total Deduction</th>
    <th>Total Net Salary</th>
    <th>Gross Salary</th>
</tr>

<?php
while($employee = mysqli_fetch_assoc($result_employees)) {
    $e_id = $employee['e_id'];
    $name = $employee['name'];
    $gross = $employee['gross'];
    
    // Get attendance data for this employee for the month
    $sql_attendance = "SELECT md.* 
                       FROM machine_data md
                       WHERE md.e_id = '$e_id' 
                       AND md.entry_date BETWEEN '$fromdate' AND '$todate' 
                       AND md.in_out = 1
                       ORDER BY md.entry_date ASC, md.entry_time ASC";
    
    $result_attendance = mysqli_query($conn, $sql_attendance) or die("Attendance query failed: ".mysqli_error($conn));
    
    // Initialize employee totals
    $totalLate = 0;
    $totalDeduction = 0;
    $totalNet = 0;
    $workingDays = 0;
    $lateDays = 0;
    $statusSummary = [];
    
    while($row = mysqli_fetch_assoc($result_attendance)) {
        $entry_date = $row['entry_date'];
        $entry_time = strtotime($entry_date.' '.$row['entry_time']);
        if(!$entry_time) continue;
        
        // Get roster for this day
        $sqlRoster = "SELECT * FROM rostering 
                      WHERE e_id = '$e_id' 
                      AND fromdate <= '$entry_date' 
                      AND todate >= '$entry_date' 
                      ORDER BY fromtime ASC 
                      LIMIT 1";
        
        $rosterQ = mysqli_query($conn, $sqlRoster);
        $lateMinutes = 0;
        $deduction = 0;
        $netSalary = round($gross/30, 2);
        $status = "❌ No Roster Found";
        
        if(mysqli_num_rows($rosterQ) > 0) {
            $roster = mysqli_fetch_assoc($rosterQ);
            $rosterStart = strtotime($entry_date.' '.$roster['fromtime']);
            $rosterEnd = strtotime($entry_date.' '.$roster['totime']);
            
            // Handle overnight shifts
            if($rosterEnd <= $rosterStart) {
                $rosterEnd = strtotime('+1 day', $rosterEnd);
            }
            
            // Entry before roster start - consider on time
            if($entry_time < $rosterStart) {
                $status = "On Time";
            }
            // Grace period (15 minutes after roster start)
            else if($entry_time <= ($rosterStart + (15 * 60))) {
                $status = "On Time";
            }
            // Late but still within roster end time
            else if($entry_time <= $rosterEnd) {
                $graceEnd = $rosterStart + (15 * 60);
                $lateMinutes = floor(($entry_time - $graceEnd) / 60);
                $dailySalary = $gross / 30;
                $perMinuteRate = $dailySalary / (8 * 60);
                $deduction = round($lateMinutes * $perMinuteRate, 2);
                $netSalary = round($dailySalary - $deduction, 2);
                $status = "Late";
                $lateDays++;
            }
            // Outside roster
            else {
                $status = "Outside Roster";
                $netSalary = 0;
            }
        }
        
        $totalLate += $lateMinutes;
        $totalDeduction += $deduction;
        $totalNet += $netSalary;
        $workingDays++;
        
        // Track status summary
        if (!isset($statusSummary[$status])) {
            $statusSummary[$status] = 0;
        }
        $statusSummary[$status]++;
    }
    
    // Format status summary
    $statusText = "";
    foreach ($statusSummary as $status => $count) {
        $statusText .= "$status: $count days<br>";
    }
    
    // Calculate averages
    $avgLate = $workingDays > 0 ? round($totalLate / $workingDays, 2) : 0;
    
    // Add to grand totals
    $grandTotalLate += $totalLate;
    $grandTotalDeduction += $totalDeduction;
    $grandTotalNet += $totalNet;
    $grandTotalWorkingDays += $workingDays;
    
    // Display employee summary
    echo "<tr>
            <td>$name</td>
            <td align='center'>$workingDays</td>
            <td align='center'>$totalLate</td>
            <td align='center'>$avgLate</td>
            <td align='center'>$lateDays</td>
            <td align='right'>" . number_format($totalDeduction, 2) . "</td>
            <td align='right'>" . number_format($totalNet, 2) . "</td>
            <td align='right'>" . number_format($gross, 2) . "</td>
            <td>$statusText</td>
          </tr>";
}

// Display grand totals
$grandAvgLate = $grandTotalWorkingDays > 0 ? round($grandTotalLate / $grandTotalWorkingDays, 2) : 0;
echo "<tr bgcolor='#FFCC99'>
        <td align='right'><strong>Grand Totals</strong></td>
        <td align='center'><strong>$grandTotalWorkingDays</strong></td>
        <td align='center'><strong>$grandTotalLate</strong></td>
        <td align='center'><strong>$grandAvgLate</strong></td>
        <td align='center'>-</td>
        <td align='right'><strong>" . number_format($grandTotalDeduction, 2) . "</strong></td>
        <td align='right'><strong>" . number_format($grandTotalNet, 2) . "</strong></td>
        <td align='right'>-</td>
        <td>-</td>
      </tr>";
?>
</table>

<div style="margin-top: 20px;">
    <h3>Report Summary</h3>
    <p>Report Period: <?php echo date('F Y', strtotime($year . '-' . $month)); ?></p>
    <p>Total Employees: <?php echo mysqli_num_rows($result_employees); ?></p>
    <p>Total Working Days: <?php echo $grandTotalWorkingDays; ?></p>
    <p>Total Late Minutes: <?php echo $grandTotalLate; ?></p>
    <p>Total Deduction: ৳<?php echo number_format($grandTotalDeduction, 2); ?></p>
    <p>Total Net Salary: ৳<?php echo number_format($grandTotalNet, 2); ?></p>
</div>