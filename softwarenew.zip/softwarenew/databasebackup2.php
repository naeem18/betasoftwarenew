<button id="backupBtn">Download Backup</button>

<script>
document.getElementById('backupBtn').addEventListener('click', function(){
    // Auto click a hidden link to trigger PHP download
    var link = document.createElement('a');
    link.href = 'backupmanual.php';
    link.download = '';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
});
</script>
