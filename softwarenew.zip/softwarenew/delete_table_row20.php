<?php
session_start();
if(isset($_GET['idvalue'])){	
	$idvalue = $_GET['idvalue'];
	if($idvalue>0){
		require('labdd.php');
 		 $str2 = "DELETE from labinvoice_return where labinvoice_returnid = '$idvalue'";
		 $userquery = mysqli_query($conn, $str2);
		
		 $str = "DELETE from labinvoicedetails_return where labinvoice_returnid = '$idvalue'";
		 $userquery = mysqli_query($conn, $str);
		
		 $str3 = "DELETE from dailytransection_lab where section='L.Cash Return' AND labinvoice_id = '$idvalue'";
		 $userquery = mysqli_query($conn, $str3);
 		
		if($userquery){			
			header("location:index.php?p=statementbyinvoice_return&message=remove-successfully");			
		}
		else{
			header("location:index.php?p=$returnpage&message=couldnotremove");
		}
	}
	else{
		header("location:index.php?p=statementbyinvoice_return&message=incorrect_id");
	}
}
?>