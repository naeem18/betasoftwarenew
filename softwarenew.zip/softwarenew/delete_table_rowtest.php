<?php
session_start();
if(isset($_GET['idvalue'])){	

	$idvalue = $_GET['idvalue'];
	if($idvalue>0){
		require('labdd.php');
		
		$str2 = "UPDATE labinvoicedetails set `return` = 'Y'
							where auto_number = '$idvalue'";
		$userquery = mysqli_query($conn, $str2);
		
		if($userquery){			
			header("location:index.php?p=labinvoicereturn&message=remove-successfully");			
		}
		else{
			header("location:index.php?p=$returnpage&message=couldnotremove");
		}
	}
	else{
		header("location:index.php?p=labinvoicereturn&message=incorrect_id");
	}
}
?>