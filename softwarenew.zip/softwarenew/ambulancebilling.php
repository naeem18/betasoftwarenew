<article class="bottomcontent">
    <h3 style="background: #6F7BFB; color:#fff; text-align:center">Ambulance Billing</h3>
    <content>
<?php
$patientdata = '';
$sqlopregistration = "select * from opregistration order by opregistration_id asc";
$opregistrationquery = mysqli_query($conn, $sqlopregistration);
if($opregistrationquery && mysqli_num_rows($opregistrationquery)>0){
 	while ($opregistrationrow = mysqli_fetch_array($opregistrationquery))
	{
		$opregistration_id = $opregistrationrow['opregistration_id'];
		$opregistration_code = $opregistrationrow['opregistration_code'];
		$opregistration_name = $opregistrationrow['opregistration_name'];
		$ward = $opregistrationrow['ward'];
		$ambulance_due = $opregistrationrow['ambulance_due'];
		$advanced = $opregistrationrow['advanced'];
		$opregistration_mobile = $opregistrationrow['opregistration_mobile'];
		$opregistration_address = $opregistrationrow['opregistration_address'];
		$patientdata[] =array( 'labelval' => $opregistration_name,
							'label' => $opregistration_id,
							'opregistration_id'=>$opregistration_id,
							'opregistration_code'=>$opregistration_code,
							'ambulance_due'=>$ambulance_due,
							'advanced'=>$advanced,
							'ward'=>$ward,
							'opregistration_mobile'=>$opregistration_mobile,
							'opregistration_address'=>$opregistration_address
							);
		}
	}
$patientdata = json_encode($patientdata);
?>
<link rel="stylesheet" href="autocomplete/jquery-ui.css">
<script src="autocomplete/jquery-ui.min.js"></script>
  <script language="JavaScript" type="text/javascript">
   var patientdata = <?php echo $patientdata;?>;
	$(document).ready(function($) {
	
   	$( "#opregistration_id" ).autocomplete({
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				document.getElementById('name').value = ui.item.labelval;
				document.getElementById('mobile').value = ui.item.opregistration_mobile;
				document.getElementById('opregistration_id').value = ui.item.opregistration_id;
				document.getElementById('opregistration_code').value = ui.item.opregistration_code;
				document.getElementById('address').value = ui.item.opregistration_address;
				document.getElementById('pdue').value = ui.item.ambulance_due;
				//document.getElementById('labcollection_address').value = ui.item.opregistration_address;
				
				return false;
			}
		});
	});
		
     function calculate_total(){
		var charge = parseFloat(document.getElementById("charge").value);
		if(charge=='' || isNaN(charge)){charge = 0;}
		
		var received = parseFloat(document.getElementById("received").value);
		if(received=='' || isNaN(received)){received = '';}
		
		var pdue = parseFloat(document.getElementById("pdue").value);
		if(pdue=='' || isNaN(pdue)){pdue = '';}
		
		var due = parseFloat(charge+pdue - received);
		document.getElementById('due').value= due.toFixed(2);
		}
		</script>
        <?php
        if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
            echo "<p class=\"red12bold\">You have missing Something</p>";
        }
		 if(isset($_GET['message']) && $_GET['message']=='update-successfully'){
            echo "<p class=\"red12bold\">updated successfully</p>";
        }
        elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
            echo "<p class=\"red12bold\">Error occured! Could not insert.</p>";   
        }
        elseif(isset($_GET['message']) && $_GET['message']=='save-successfully'){
            echo "<p class=\"red12bold\">Information insert successfully. Click Print Button To Print or View Previous Bill <td align=\"center\" ><a onclick=\"PrintDiv();\"><input type=\"button\" name=\"user\" id=\"user\" required value=\"Print\" class=\"tdclass\"  /></a></td></p>";   
        }
        $ambulance_id = 0;
        $name = '';
        $mobile = '';
        $destination = '';
        $charge = '';
        $month = '';
        $description = '';
        ?>        
           
	<form action="save_ambulance.php" style="background:#FFF; padding:10px" name="frmcontact" onsubmit="return checkcontactform();" method="post" enctype="multipart/form-data">

	<table width="55%" align="center" border="1" style="BORDER-COLLAPSE: collapse;" bgcolor="#ccc" cellpadding="2">
         <input type="hidden" name="user" id="user" required value="<?php echo $_SESSION['fullname'];?>" class="tdclass"  />
         <input type="hidden" name="type" id="type" required value="Cash" class="tdclass" />
    <tr>
        <td align="right">Date/Month</td>
        <td><input type="text" name="month" id="month" value="<?php echo date("F Y");?>" class="tdclass3" /></td>
    </tr>
    
    <tr>
        <td align="right">Date</td>
        <td><input type="text" name="created_date" id="created_date" value="<?php echo date('Y-m-d');?>" class="tdclass3"  /></td>
    </tr>
    
    <tr>
        <td align="right"><strong>Patient Code</strong></td>
        <td><input type="hidden" name="opregistration_code" id="opregistration_code" class="tdclass3" />
            <input type="text" name="opregistration_id" id="opregistration_id" class="tdclass3" />
        </td>
   </tr>
   
    <tr>
    	<td align="right"><strong>Name</strong>*</td>
    	<td><input type="text" required name="name" id="name" value="<?php //echo $name ;?>" class="tdclass3" /></td>
    </tr>
    
    <tr>
        <td align="right">Address</td>
        <td><textarea type="text" name="address" id="address" class="textareadetailsr" /><?php //echo $address ;?></textarea></td>
    </tr>
    
    <tr>
        <td align="right">Mobile Number</td>
        <td><input type="text" name="mobile" id="mobile" class="tdclass3" /></td>
    </tr>
    
    <tr>
        <td align="right">Referer</td>
        <td><input type="text" name="referer" id="referer" value="<?php //echo $description ;?>" class="tdclass3" /></td>
    </tr>
    
    <tr>
        <td align="right">From Location*</td>
        <td><textarea type="text" required name="starting_location" id="starting_location" class="textareadetailsr" /></textarea></td>
    </tr>
    
    <tr>
        <td align="right">Destination*</td>
        <td><textarea name="destination" required id="destination" class="textareadetailsr"></textarea></td>
    </tr>
    
    <tr>
        <td align="right"><strong>Driver</strong></td>
        <td><input name="driver" id="driver"  class="tdclass3" /></td>
    </tr>
    
    <tr>
        <td align="right"><strong>Previous Due</strong></td>
        <td><input name="pdue" id="pdue" readonly value="" onKeyUp="calculate_total();" class="tdclass3" /></td>
    </tr>
    
    <tr>
        <td align="right"><strong>Charge*</strong></td>
        <td><input name="charge" id="charge" required value="<?php //echo $charge ;?>" onKeyUp="calculate_total();" class="tdclass3" /></td>
    </tr>
    
    <tr>
        <td align="right"><strong>Received*</strong></td>
        <td><input name="received" id="received" required value="<?php //echo $received ;?>" onKeyUp="calculate_total();" class="tdclass3" /></td>
    </tr>
    
     
    <tr>
        <td align="right"><strong>Current Due</strong></td>
        <td><input name="due" id="due" readonly value="<?php //echo $due ;?>" onKeyUp="calculate_total();" class="tdclass3" /></td>
    </tr>
     
    <tr>
        <td align="right">Due Holder</td>
        <td><textarea type="text" name="dueholder" id="dueholder" class="textareadetailsr" /><?php //echo $dueholder ;?></textarea></td>
    </tr>
    
    <tr>
        <td align="right">Note</td>
        <td><textarea type="text" name="description" id="description" class="textareadetailsr" /><?php //echo $description ;?></textarea></td>
    </tr>
    
    <tr>
        <td align="right"></td>
        <td>
        <input type="hidden" name="ambulance_id" id="ambulance_id" value="<?php echo $ambulance_id;?>">
        <input type="submit" value=" Save " name="submit_invoice" id="submit_invoice" class="tdclass" />
        <input type="reset" name="expense" id="expense" value="Cancel" class="tdclass"/>
        </td>
    </tr>
</table>
</form>
</content>
</article>

<div id="divToPrint" style="display:none;">
	<article class="bottomcontent" style="margin:0 auto">
   	  <?php
		  if(isset($_GET['ambulance_id'])){
          	$ambulance_id = $_GET['ambulance_id'];
            $labinvoicedetails_sql = "select * from ambulance where ambulance_id = $ambulance_id order by ambulance_id desc";
            $labinvoicedetailsquery = mysqli_query($conn, $labinvoicedetails_sql);
            if($labinvoicedetailsquery && mysqli_num_rows($labinvoicedetailsquery)>0){
               $i=0;
			    while($page_inforow = mysqli_fetch_array($labinvoicedetailsquery)){
                   $i++;
				    $ambulance_id = $page_inforow['ambulance_id'];
                    $name = $page_inforow['name'];
                    $mobile = $page_inforow['mobile'];
					$user = $page_inforow['user'];
                    $destination = $page_inforow['destination'];
                    $charge = $page_inforow['charge'];
                    $received = $page_inforow['received'];
                    $month = $page_inforow['month'];
                    $starting_location = $page_inforow['starting_location'];
                    $description = $page_inforow['description'];
                    $created_date = $page_inforow['created_date'];
		 	 ?>
             <?php if($heading=='Yes'){ ?> 
               <table width="450" align="center" style="border:1px solid #000;padding:0 10px; font-size:12px;" bgcolor="#FFF" cellpadding="0">
                <tr>
                    <td width="280">
                        <div style="font-size:14px"><strong><?php echo $hospitaldata_name;?></strong></div>
                        <div><?php echo $hospitaldata_address1;?></div>
                    </td>
                 </tr>
            </table>
            <?php }?>
            <table width="450" align="center" style="border:1px solid #000;font-size:12px; padding:0 10px;<?php if($heading=='Yes'){ ?> margin-top:2px<?php }?> <?php if($heading=='No'){ ?> margin-top:55px<?php }?>" bgcolor="#FFF" cellpadding="0">
                <tr>
                    <td width="280">
                        <div align="left">Inv No.<?php echo $ambulance_id;?></div>
                        <div align="left"><strong>Name</strong><?php echo $name;?></div>
                        <div align="left">Mobile<?php echo $mobile;?></div>
                    </td>
                    <td width="150">
                       <div align="left" style="font-size:14px"><strong>Ambulance Receipt</strong></div>
                       <div align="left">Voucher No.<?php echo $description;?></div>
                       <div align="left">Date<?php echo $created_date ;?></div>
                    </td>
                 </tr>
            </table>
            <table width="450" align="center" style="border:1px solid #000;font-size:12px; padding:0 10px;<?php if($heading=='Yes'){ ?> margin-top:2px<?php }?> <?php if($heading=='No'){ ?> margin-top:55px<?php }?>" bgcolor="#FFF" cellpadding="0">
                <tr>
                    <td width="450">
                        <div align="left">From: <?php echo $starting_location;?></div>
                        <div align="left">To: <?php  echo $destination ;?></div>
                    </td>
                 </tr>
            </table>     
            <table width="450" align="center" bgcolor="#FFF" style=" padding:0 0 40px;font-size:12px; border:1px #000 solid; border-top:none;">
                <tr>
                    <td style="text-align:center;">Paid Amount</td>
                    <td style=" text-align:center;"><?php echo $received;?></td>
                </tr>
            </table>
                   
         <table width="450" align="center" style="font-size:12px;">
        	<tr><td>Paid Inword <?php include ("convert_currency_to_words.php");
				echo covert_currency_to_words($received); ?></td></tr>
        </table>
        <table width="450" align="center" style=" font-size:12px; padding:12px 1px" bgcolor="#FFF" cellpadding="0">
            <tr>
                <td width="200">
                    <div>Prepared By<?php echo $user; ?></div>
                </td>
                <td width="250">
                    <div style="padding-bottom:20px" align="right"></div>
                    <div align="right">Authorised Sign</div>
                   </td>
             </tr>
        </table>
      <?php
      }}}
      ?>
</article>
</div>