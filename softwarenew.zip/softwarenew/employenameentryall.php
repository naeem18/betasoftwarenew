<table align="left" width="100%" border="1" style="BORDER-COLLAPSE: collapse;" cellspacing="1" cellpadding="3">
  <tr>
    <td colspan="100%" bgcolor="#0033FF" align="center" style="color:#fff; border:1px solid #03F;">
         <strong>In-Out Report </strong>
    </td>
  </tr>
  <?php
  // Get current month and year
  $currentMonth = date('m');
  $currentYear = date('Y');
  
  // Calculate total attendance days first
  $totalDaysQuery = mysqli_query($conn, "SELECT COUNT(DISTINCT entry_date) as total_days FROM machine_data WHERE in_out > 0");
  $totalDaysRow = mysqli_fetch_assoc($totalDaysQuery);
  $totalDays = $totalDaysRow['total_days'];
  
  // Calculate monthly attendance per employee
  $monthlyAttendance = array();
  $monthlyQuery = mysqli_query($conn, 
    "SELECT e.e_id, e.name, COUNT(DISTINCT DATE(m.entry_date)) as days_attended 
     FROM employee e 
     JOIN machine_data m ON e.e_id = m.e_id 
     WHERE m.in_out > 0 
     AND MONTH(m.entry_date) = '$currentMonth' 
     AND YEAR(m.entry_date) = '$currentYear'
     GROUP BY e.e_id");
  
  while($row = mysqli_fetch_assoc($monthlyQuery)) {
    $monthlyAttendance[$row['e_id']] = array(
      'name' => $row['name'],
      'days_attended' => $row['days_attended']
    );
  }
  ?>
  <tr>
    <td colspan="6" align="center" style="background-color:#f0f0f0; font-weight:bold;">
      Total Attendance Days: <?php echo $totalDays; ?> | 
      Current Month: <?php echo date('F Y'); ?>
    </td>
  </tr>
  <tr>
    <td colspan="6" align="right">
      <form method="get" action="">
        <input type="hidden" name="p" value="employenameentryall">
        Search by Name: <input type="text" name="search_name" value="<?php echo isset($_GET['search_name']) ? htmlspecialchars($_GET['search_name']) : ''; ?>">
        <input type="submit" value="Search">
        <?php if(isset($_GET['search_name']) && !empty($_GET['search_name'])): ?>
          <a href="index.php?p=employenameentryall" style="margin-left:10px;">Clear Search</a>
        <?php endif; ?>
      </form>
    </td>
  </tr>
  <tr bgcolor="#ccc" align="center">
    <td>SL No.</td>
    <td>EID</td>
    <td>Name</td>
    <td>In Time</td>
    <td>Out Time</td>
   </tr>
  <?php
  // Modify the query to include search filter
  $searchCondition = "";
  $s = 0;
  if(isset($_GET['search_name']) && !empty($_GET['search_name'])) {
    $searchName = mysqli_real_escape_string($conn, $_GET['search_name']);
    $searchCondition = " AND employee.name LIKE '%$searchName%'";
  }

  $mdObj = mysqli_query($conn, "SELECT * FROM machine_data, employee WHERE employee.e_id = machine_data.e_id AND machine_data.in_out>0 $searchCondition");
  $mdCount = mysqli_num_rows($mdObj);
  if($mdCount > 0){
    $attendanceData = $employeeDate = array();
    while($mdOneRow = mysqli_fetch_array($mdObj)){
      $employeeDate[$mdOneRow['e_id']][$mdOneRow['entry_date']] = $mdOneRow['name'];
      $attendanceData[$mdOneRow['entry_date']][] = array($mdOneRow['entry_date'], $mdOneRow['entry_time'], $mdOneRow['in_out']);
    }
    ksort($employeeDate);
    if(!empty($employeeDate)){
      foreach($employeeDate as $e_id => $dateInfo){      
        foreach($dateInfo as $date => $name){
          $inTime = $outTime = '';
          $empAttInfo = array();
          if(array_key_exists($date, $attendanceData)){$empAttInfo = $attendanceData[$date];}
          if(!empty($empAttInfo)){
            foreach($empAttInfo as $attOneRow){
              $entry_date = $attOneRow[0];
              $entry_time = $attOneRow[1];
              $in_out = $attOneRow[2];
              if($in_out == 1){
                $inTime = "$entry_date $entry_time";
              }
              elseif($in_out == 2){
                $outTime = "$entry_date $entry_time";
              }
            }
          }
          // Skip if we're searching and the name doesn't match
          if(isset($_GET['search_name']) && !empty($_GET['search_name']) && stripos($name, $_GET['search_name']) === false) {
            continue;
          }
          ?>
          <tr bgcolor="#fff" align="left">
            <td><?php echo $s = $s + 1; ?></td>
            <td><?php echo $e_id; ?></td>
            <td><?php echo $name; ?></td>
            <td><?php echo $inTime; ?></td>
            <td><?php echo $outTime; ?></td>
            <?php /*?><td align="center">
              <?php 
                if(isset($monthlyAttendance[$e_id])) {
                  echo $monthlyAttendance[$e_id]['days_attended'] . " days";
                } else {
                  echo "0 days";
                }
              ?>
            </td><?php */?>
          </tr>
        <?php
        }      
      }
    }
  } else {
    echo '<tr><td colspan="6" align="center">No records found'.(isset($_GET['search_name']) ? ' for "'.htmlspecialchars($_GET['search_name']).'"' : '').'</td></tr>';
  }
  ?>
</table>