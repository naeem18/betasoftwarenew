<script language="JavaScript" type="text/javascript">
	
	var itemdata = <?php echo $itemdata;?>;
	var patientdata = <?php echo $patientdata;?>;
	$(document).ready(function($) {
		document.getElementsByName("salesreturninvoice_item[]")[0].focus();

		$( ".itemname" ).autocomplete({
			
			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.saleselval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				document.getElementsByName("salesitem_id[]")[indexpos].value = ui.item.salesitem_id;
				document.getElementsByName("salesreturninvoice_purchase_rate[]")[indexpos].value = ui.item.salesitem_purchase_rate;
				document.getElementsByName("salesreturninvoice_rate[]")[indexpos].value = ui.item.salesitem_price;				
				document.getElementsByName("salesitem_pack[]")[indexpos].value =ui.item.salesitem_pack;
				document.getElementsByName("salesreturninvoice_qty[]")[indexpos].value = 1;					
				document.getElementsByName("salesreturninvoice_category[]")[indexpos].value = ui.item.salesitem_category;
				document.getElementsByName("salesreturninvoice_stock[]")[indexpos].value = ui.item.salesitem_stock;
				
				calculateCurrentRowTotal(indexpos);
				
				return false;
			}
		});
		
		
		$( "#salesreturninvoice_patient" ).autocomplete({
			
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.saleselval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 	document.getElementById('salesreturninvoice_patientid').value = ui.item.labelval;
				 	document.getElementById('salesreturninvoice_mobile').value = ui.item.opregistration_mobile;
				 	document.getElementById('salesreturninvoice_address').value = ui.item.opregistration_address;
				
				return false;
			}
		});
		
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
		$( ".sirow input.ccrt" ).keyup(function() {
			var index = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
			calculateCurrentRowTotal(index);
		});
	});
	
	function calculateCurrentRowTotal(index){
		var salesreturninvoice_rate = parseFloat(document.getElementsByName("salesreturninvoice_rate[]")[index].value);
		if(salesreturninvoice_rate=='' || isNaN(salesreturninvoice_rate)){salesreturninvoice_rate = 0.00;}
		
		var salesitem_pack = parseFloat(document.getElementsByName("salesitem_pack[]")[index].value);
		if(salesitem_pack=='' || isNaN(salesitem_pack)){salesitem_pack = 0.00;}
		
		var salesreturninvoice_pqty = parseFloat(document.getElementsByName("salesreturninvoice_pqty[]")[index].value);
		if(salesreturninvoice_pqty=='' || isNaN(salesreturninvoice_pqty)){salesreturninvoice_pqty = 0.00;}
		
		if(salesitem_pack==0 || salesreturninvoice_pqty==0){
			var salesreturninvoice_qty = parseFloat(document.getElementsByName("salesreturninvoice_qty[]")[index].value);
			if(salesreturninvoice_qty=='' || isNaN(salesreturninvoice_qty)){salesreturninvoice_qty = 0.00;}
		}
		else{
			var salesreturninvoice_qty = parseFloat(salesitem_pack*salesreturninvoice_pqty);
			if(salesreturninvoice_qty=='' || isNaN(salesreturninvoice_qty)){salesreturninvoice_qty = 0.00;}
			document.getElementsByName("salesreturninvoice_qty[]")[index].value = salesreturninvoice_qty.toFixed(2);
		}
		
		var qtyPrice = parseFloat(salesreturninvoice_rate*salesreturninvoice_qty);
		
		var salesreturninvoice_discountp = parseFloat(document.getElementsByName("salesreturninvoice_discountp[]")[index].value);
		if(salesreturninvoice_discountp=='' || isNaN(salesreturninvoice_discountp)){salesreturninvoice_discountp = 0.00;}
		if(salesreturninvoice_discountp==0){
			var salesreturninvoice_disc = parseFloat(document.getElementsByName("salesreturninvoice_disc[]")[index].value);
			if(salesreturninvoice_disc=='' || isNaN(salesreturninvoice_disc)){salesreturninvoice_disc = 0.00;}
		}
		else{
			var salesreturninvoice_disc = parseFloat(qtyPrice*salesreturninvoice_discountp*0.01);	
			document.getElementsByName("salesreturninvoice_disc[]")[index].value = salesreturninvoice_disc.toFixed(2);
		}
		
		document.getElementsByName("salesreturninvoice_total[]")[index].value = parseFloat(qtyPrice-salesreturninvoice_disc).toFixed(2);
		
		calculateGrandTotal();
	}
	
	function calculateGrandTotal(){
		var salesreturninvoice_totalarray = document.getElementsByName("salesreturninvoice_total[]");
		var salesreturninvoice_subtotal = 0.00;
		for(var r=0; r<salesreturninvoice_totalarray.length; r++){
			var salesreturninvoice_total = parseFloat(salesreturninvoice_totalarray[r].value);
			if(salesreturninvoice_total=='' || isNaN(salesreturninvoice_total)){salesreturninvoice_total = 0.00;}
			salesreturninvoice_subtotal = parseFloat(salesreturninvoice_subtotal+salesreturninvoice_total);
		}
		
		document.getElementById("salesreturninvoice_subtotal").value = salesreturninvoice_subtotal.toFixed(2);
		
		var salesreturninvoice_totaldiscp = parseFloat(document.getElementById("salesreturninvoice_totaldiscp").value);
		if(salesreturninvoice_totaldiscp=='' || isNaN(salesreturninvoice_totaldiscp)){salesreturninvoice_totaldiscp = 0;}
		if(salesreturninvoice_totaldiscp==0){
			var salesreturninvoice_totaldisc = parseFloat(document.getElementById("salesreturninvoice_totaldisc").value);
			if(salesreturninvoice_totaldisc=='' || isNaN(salesreturninvoice_totaldisc)){salesreturninvoice_totaldisc = 0;}
		}
		else{
			var salesreturninvoice_totaldisc = parseFloat(salesreturninvoice_subtotal*salesreturninvoice_totaldiscp*0.01);
			document.getElementById('salesreturninvoice_totaldisc').value= salesreturninvoice_totaldisc.toFixed(2);
		}
		
		var salesreturninvoice_subtotalafterdisc = parseFloat(salesreturninvoice_subtotal-salesreturninvoice_totaldisc);
		document.getElementById('salesreturninvoice_subtotalafterdisc').value= salesreturninvoice_subtotalafterdisc.toFixed(2);
			
		var salesreturninvoice_receiveamount = parseFloat(document.getElementById("salesreturninvoice_receiveamount").value);
		if(salesreturninvoice_receiveamount=='' || isNaN(salesreturninvoice_receiveamount)){salesreturninvoice_receiveamount = 0;}
		
		var salesreturninvoice_due = parseFloat(salesreturninvoice_subtotalafterdisc-salesreturninvoice_receiveamount);
		document.getElementById('salesreturninvoice_due').value=salesreturninvoice_due.toFixed(2);		
		
	}
	
	function check_blankrow(){
		var salesreturninvoice_itemArray = document.getElementsByName('salesreturninvoice_item[]');
		var salesreturninvoice_totalArray = document.getElementsByName('salesreturninvoice_total[]');
			
		var error_messageid = document.getElementById('errmsg_particular_id');
		error_messageid.innerHTML = '';
		
		for(r = 0; r < salesreturninvoice_itemArray.length; r++) {
												
			if(salesreturninvoice_itemArray[r].value==''){
				error_messageid.innerHTML = 'Missing item name '+parseInt(r+1);
				salesreturninvoice_itemArray[r].focus();
				return false;
			}
			
			if(salesreturninvoice_totalArray[r].value=='' || salesreturninvoice_totalArray[r].value==0){
				error_messageid.innerHTML = 'Missing item total '+parseInt(r+1);
				salesreturninvoice_totalArray[r].focus();
				return false;
			}
		}
		
		return true;
	}

	function addnew_particularrow(animate) {
		if(check_blankrow()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" align=\"center\" width=\"918\" cellpadding=\"1\">"+
							'<tbody><tr></tr><tr>'+
								'<td align="center" width=\"130\"> <input type="text" name="salesreturninvoice_item[]" value="" class="tdclass itemname"/>'+
								'<input type="hidden" name="salesitem_id[]" id="salesitem_id[]" value="" class="tdclass itemname"/>'+
								'<input type="hidden" name="salesreturninvoice_category[]" value="" class="tdclass"  /></td>'+
								'<td align="center" width=\"95\"> <input type="text" name="salesreturninvoice_stock[]" value=\"\" class="tdclasssale itemname"/></td>'+
								"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"salesreturninvoice_purchase_rate[]\"  value=\"\" class=\"tdclasssale\"/></td>"+											 
								"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"salesreturninvoice_rate[]\" value=\"\" class=\"tdclasssale numeric ccrt\"/></td>"+											 
								"<input type=\"hidden\" title=\"class\" name=\"salesitem_pack[]\" class=\"tdclasssale numeric ccrt\" >"+
								"<input type=\"hidden\" name=\"salesreturninvoice_pqty[]\" value=\"\" class=\"tdclasssale numeric ccrt\" />"+
								"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"salesreturninvoice_qty[]\" class=\"tdclasssale numeric ccrt\"/></td>"+
								'<td align="center" width=\"95\"><input type="text" name="salesreturninvoice_discountp[]" value="" class="tdclasssale numeric ccrt"/></td>'+
								"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"salesreturninvoice_disc[]\" value=\"\" class=\"tdclasssale numeric  ccrt\" /></td>"+
								'<td align="center" width=\"95\"><input type="text" readonly name="salesreturninvoice_total[]" value="" class="tdclasssale numeric ccrt"  /></td>'+												
								'<td>'+
								 "<input type=\"button\" value=\"X\" class=\"tdclasssales deletethislistrow\"  />"+
								'</td>'+
							  '</tr></tbody>'+
						"</table>";
						
			var $newparticularlist = $("<li class=\"sirow\"></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(300); 
			else 
			   $newparticularlist.show();   
			document.getElementsByName("salesreturninvoice_item[]")[parseInt(particular_rowcount-1)].focus();
			
			$( ".itemname" ).autocomplete({			
				minLength: 1,
				source: itemdata,
				focus: function( event, ui ) {
					//$( "#search_item_number" ).val( ui.item.saleselval );
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					document.getElementsByName("salesitem_id[]")[indexpos].value = ui.item.salesitem_id;
					document.getElementsByName("salesreturninvoice_purchase_rate[]")[indexpos].value = ui.item.salesitem_purchase_rate;
					document.getElementsByName("salesreturninvoice_rate[]")[indexpos].value = ui.item.salesitem_price;				
					document.getElementsByName("salesitem_pack[]")[indexpos].value =ui.item.salesitem_pack;
					document.getElementsByName("salesreturninvoice_qty[]")[indexpos].value = 1;					
					document.getElementsByName("salesreturninvoice_category[]")[indexpos].value = ui.item.salesitem_category;
					document.getElementsByName("salesreturninvoice_stock[]")[indexpos].value = ui.item.salesitem_stock;
					
					calculateCurrentRowTotal(indexpos);
					
					return false;
				}
			});						
		
			$( ".sirow input.ccrt" ).keyup(function() {
				var index = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				calculateCurrentRowTotal(index);
			});
			
			$( ".sirow input.deletethislistrow" ).click(function() {
				$(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').slideUp(500, function() {
					$(this).remove();
					calculateGrandTotal();
				});
			});
			
			$( ".numeric" ).keyup(function() {
				var price = $(this).val();
				var ValidChars = "-.0123456789";
				var IsNumber=true;
				var Char;
				var validint = '';
				for (var i = 0; i < price.length && IsNumber == true; i++){ 
					Char = price.charAt(i);
					if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
					else{
						validint = validint+Char;
					}
				}
				$(this).val(validint);
			});
		}
	}
</script>