<?php
// 🔹 Backup directory declare করুন
$backupDir = "G:/db_backup";

// MySQL details
include('labdd.php');

// Timestamp
$timestamp = date("Y-m-d_H-i");

// Backup file path
$backupFile = $backupDir . "/db_backup_" . $timestamp . ".sql";

// Run mysqldump
$command = "\"C:/xampp/mysql/bin/mysqldump.exe\" -h $dbHost -u $dbUser -p$dbPass $dbName > \"$backupFile\"";
system($command, $output);

// Delete old files (keep only 5 minutes)
$minutesToKeep = 5;
$files = glob($backupDir . '/*.sql');
$now = time();

foreach ($files as $file) {
    if (is_file($file)) {
        $fileAge = $now - filemtime($file);
        if ($fileAge > ($minutesToKeep * 60)) {
            unlink($file);
        }
    }
}

echo "Backup saved: $backupFile\n";
?>
