<?php
// index.php
function announceSerialNumber($number) {
    $words = [
        1 => 'one', 2 => 'two', 3 => 'three', 4 => 'four', 5 => 'five',
        6 => 'six', 7 => 'seven', 8 => 'eight', 9 => 'nine', 10 => 'ten'
    ];
    
    $word = isset($words[$number]) ? $words[$number] : $number;
    $text = "Serial number " . $word ." Please Come";
    
    echo "<h2>Now Serving: Serial Number " . htmlspecialchars($number) . "</h2>";
    
    // JavaScript solution that works with modern browser autoplay policies
    echo "
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var audio = new Audio('sounds/".$number.".mp3');
            audio.play().catch(e => {
                // Fallback to TTS if audio file fails
                var msg = new SpeechSynthesisUtterance('".$text."');
                window.speechSynthesis.speak(msg);
                console.log('Audio play failed, using TTS fallback');
            });
        });
    </script>
    ";
}

if (isset($_GET['next'])) {
    $nextNumber = (int)$_GET['next'];
    announceSerialNumber($nextNumber);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Appointment Announcer</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
        .serial-buttons { display: flex; gap: 10px; margin-top: 20px; }
        button { padding: 10px 20px; font-size: 18px; cursor: pointer; }
    </style>
</head>
<body>
    <h1>Serial Number Announcer</h1>
    
    <form method="GET" id="serialForm">
        <label for="serial">Enter Next Serial Number (1-10):</label>
        <input type="number" id="serial" name="next" min="1" max="10" required>
        <button type="submit">Call Next</button>
    </form>
    
    <div class="serial-buttons">
        <?php for($i = 1; $i <= 10; $i++): ?>
            <form method="GET" style="display:inline">
                <input type="hidden" name="next" value="<?= $i ?>">
                <button type="submit"><?= $i ?></button>
            </form>
        <?php endfor; ?>
    </div>
    
    <script>
        // Alternative solution if page reload is problematic
        document.getElementById('serialForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const number = document.getElementById('serial').value;
            playSerialSound(number);
        });
        
        function playSerialSound(number) {
            const audio = new Audio(`sounds/${number}.mp3`);
            audio.play().catch(e => {
                // TTS fallback
                const msg = new SpeechSynthesisUtterance(`Serial number ${number}`);
                window.speechSynthesis.speak(msg);
            });
            document.querySelector('h2').textContent = `Now Serving: Serial Number ${number}`;
        }
    </script>
</body>
</html>