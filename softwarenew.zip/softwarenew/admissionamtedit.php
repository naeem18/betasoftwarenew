<?php
$patientdata = '';
$sqlopregistration = "select * from opregistration where status!= 'Released' order by opregistration_id asc";
$opregistrationquery = mysqli_query($conn, $sqlopregistration);
if($opregistrationquery && mysqli_num_rows($opregistrationquery)>0){

	while ($opregistrationrow = mysqli_fetch_array($opregistrationquery))
	{
		$opregistration_id = $opregistrationrow['opregistration_id'];
		$opregistration_code = $opregistrationrow['opregistration_code'];
		$opregistration_name = $opregistrationrow['opregistration_name'];
		$ward = $opregistrationrow['ward'];
		$advanced = $opregistrationrow['advanced'];
		$opregistration_mobile = $opregistrationrow['opregistration_mobile'];
		$opregistration_address = $opregistrationrow['opregistration_address'];
		$patientdata[] =array( 'labelval' => $opregistration_name,
							'label' => $opregistration_id,
							'opregistration_id'=>$opregistration_id,
							'opregistration_code'=>$opregistration_code,
							'advanced'=>$advanced,
							'ward'=>$ward,
							'opregistration_mobile'=>$opregistration_mobile,
							'opregistration_address'=>$opregistration_address
							);
		}
	}
$patientdata = json_encode($patientdata);
?>

<link rel="stylesheet" href="autocomplete/jquery-ui.css">
<script src="autocomplete/jquery-ui.min.js"></script>
<script language="JavaScript" type="text/javascript">
	var patientdata = <?php echo $patientdata;?>;
	$(document).ready(function($) {
 		$( "#opregistration_id" ).autocomplete({
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				document.getElementById('labcollection_name').value = ui.item.labelval;
				document.getElementById('labcollection_number').value = ui.item.opregistration_mobile;
				document.getElementById('opregistration_id').value = ui.item.opregistration_id;
				document.getElementById('opregistration_code').value = ui.item.opregistration_code;
				document.getElementById('labcollection_ward').value = ui.item.ward;
				document.getElementById('advanced').value = ui.item.advanced;
				document.getElementById('labcollection_address').value = ui.item.opregistration_address;
 				return false;
			}
		});
		
			
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
		
	});
	
		
	function calculate_total(){
		
		/*var advanced = parseFloat(document.getElementById("advanced").value);
		if(advanced=='' || isNaN(advanced)){advanced = 0;}*/
		
		var collection_amount = parseFloat(document.getElementById("collection_amount").value);
		if(collection_amount=='' || isNaN(collection_amount)){collection_amount = '';}
		
		var adjustment_amount = parseFloat(document.getElementById("adjustment_amount").value);
		if(adjustment_amount=='' || isNaN(adjustment_amount)){adjustment_amount = '';}
		
		var total_balance = parseFloat( collection_amount+adjustment_amount);
		document.getElementById('total_balance').value=	total_balance.toFixed(2);
		
		}
		
		
		function funcSaveBill1()
	{
	var varUserChoice; 
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet); 
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		document.frmsales.submit();
		//return true;
	}
}		
</script>


<article class="bottomcontent">
    <h3 align="center">Admission Amount Update</h3>
    <content>
       <?php
        if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
            echo "<p class=\"red12bold\">You have missing Something</p>";
        }
        elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
            echo "<p class=\"red12bold\">Error occured! Could not insert.</p>";   
        }
        elseif(isset($_GET['message']) && $_GET['message']=='update-success'){
            echo "<p class=\"red12bold\">Information insert successfully. Click Print Button To Print or View Previous Bill <td width=\"30\" align=\"center\" >
			<a onclick=\"PrintDiv();\"><input type=\"button\" required value=\"Print\" class=\"tdclass\"  /></a></td></p>";   
        }
       
        $advanced_id = $_GET['advanced_id'];
        $sql = "select * from advanced where advanced_id = $advanced_id";
        $sqlquery = mysqli_query($conn, $sql);
        if($sqlquery){
            while($onerow = mysqli_fetch_array($sqlquery)){
            $advanced_id = $onerow['advanced_id'];
            $opregistration_id = $onerow['opregistration_id'];
            $opregistration_code = $onerow['opregistration_code'];
            $advanced = $onerow['advanced'];
            $ward = $onerow['ward'];
            $type = $onerow['type'];
            $mobile = $onerow['mobile'];
            $note = $onerow['note'];
            $advanced_date = $onerow['advanced_date'];
            $advanced_update = $onerow['advanced_update'];
            $name = $onerow['name'];
            $user = $onerow['user'];	
            }
        }            
       ?>
 
<form action="save_admissionamtedit.php" name="frmcontact" onsubmit="return checkcontactform();" onKeyDown="return disableEnterKey(event)" method="post" enctype="multipart/form-data">
<table width="500" align="center" border="0" bgcolor="#ccc" cellpadding="2">
   <tr>
  	<input type="hidden" name="user" id="user" required value="<?php echo $_SESSION['fullname'];?>" class="tdclass" />
    <td align="right"><strong>Patient ID/Code</strong></td>
    <td><input type="hidden" value="<?php echo $opregistration_code; ?>" required name="opregistration_code" id="opregistration_code" class="tdclass2" />
    	<input type="hidden" value="<?php echo $type; ?>" required name="type" id="type" class="tdclass2" />
    	<input type="text" readonly value="<?php echo $opregistration_id; ?>" required name="opregistration_id" id="opregistration_id" class="tdclass2" />
    </td>
   </tr>
   
   <tr>
    <td align="right">Patient Name </td>
    <td><input type="text" readonly value="<?php echo $name; ?>" name="labcollection_name" id="labcollection_name" required class="tdclass" /></td>
   </tr>
   
   <tr>
    <td align="right">Mobile </td>
    <td><input readonly type="text" value="<?php echo $mobile; ?>" name="labcollection_number" id="labcollection_number" class="tdclass" /></td>
   </tr>
   
   <tr>
   <td align="right">Ward </td>
  <td><input readonly type="text" name="labcollection_ward" value="<?php echo $ward; ?>" id="labcollection_ward" class="tdclass" /></td>
      <input type="hidden" name="labcollection_address" value="<?php echo $labcollection_address; ?>" id="labcollection_address" class="tdclass" />
 </tr>
   
   <tr>
    <td align="right">Date: </td>
    <td><input type="text" name="labcollection_date" readonly id="labcollection_date" value="<?php echo $advanced_date; ?>" class="tdclass"  /></td>
    	<input type="hidden" name="labcollection_update" id="labcollection_update"  value="<?php echo date('Y-m-d H:i:s');?>" class="tdclass2"  />
  </tr>
</table>

<table align="center" border="0" width="500" cellpadding="2"  bgcolor="#f2f2f2">
  <tr>
   <td align="right">Note </td>
    <td><textarea style="width:450px" type="text" name="note" id="note"/><?php echo $note; ?></textarea></td>
  </tr>
 </table>	
		
  <table  border="0" width="500" align="center" bgcolor="#e3e7ff" cellpadding="2">
  	
    <tr><td></td></tr>
    <tr>
     <td align="right" style="border-top:1px solid #999;">Current Balance : </td>
    	<td width="50" style="border-top:1px solid #999;"> 
        <input type="text" readonly name="advanced" id="advanced" class="tdclass"  onKeyUp="calculate_total();" /></td>
    </tr>
    
     <tr>
     <td align="right"><strong>Received Amount</strong>: </td>
    <td> <input type="text" readonly name="collection_amount" id="collection_amount" value="<?php echo $advanced; ?>" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
  	</tr>
    <tr>
     <td align="right"><strong>Adjustment Amount</strong>: </td>
    <td> <input type="text" required name="adjustment_amount" id="adjustment_amount" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
  	</tr>
    <tr>
     <td align="right">Current Amount: </td>
    <td> <input type="text" readonly name="total_balance" id="total_balance" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
  	</tr>
    
   
    <tr>
     <td align="right"></td>
	 <td>
        <input type="hidden" name="advanced_id" id="advanced_id" value="<?php echo $advanced_id;?>">
        <input type="submit"  value=" save " name="submit_invoice" id="submit_invoice" class="tdclass1" onClick="return funcSaveBill1()"  />
     </td>
  	</tr>
   
</table>
</form>         
      
  
</content>
</article>