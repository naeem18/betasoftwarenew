<script language="JavaScript" type="text/javascript">
var itemdata = <?php echo $itemdata;?>;
	$(document).ready(function($) {
		
		$( ".itemname" ).autocomplete({
			
			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				var purchaseinvoice_ratearray = document.getElementsByName("purchaseinvoice_rate[]");
				purchaseinvoice_ratearray[indexpos].value = ui.item.salesitem_price;
				
				var purchaseinvoice_qtyarray = document.getElementsByName("purchaseinvoice_qty[]");
				purchaseinvoice_qtyarray[indexpos].value = 1;
				
				var purchaseinvoice_pccomissionarray = document.getElementsByName("purchaseinvoice_pccomission[]");
				purchaseinvoice_pccomissionarray[indexpos].value = ui.item.salesitem_pccommission;
				
				var purchaseinvoice_categoryarray = document.getElementsByName("purchaseinvoice_category[]");
				purchaseinvoice_categoryarray[indexpos].value = ui.item.salesitem_category;
				
				calculaterowtotal(indexpos);
				calculate_pctotal();
				
				return false;
			}
		});
		
		
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
	});
	
	function calculate_discountp(){
		
		var purchaseinvoice_discountparray = document.getElementsByName("purchaseinvoice_discountp[]");
		var purchaseinvoice_discarray = document.getElementsByName("purchaseinvoice_disc[]");
		var purchaseinvoice_ratearray = document.getElementsByName("purchaseinvoice_rate[]");
		var purchaseinvoice_qtyarray = document.getElementsByName("purchaseinvoice_qty[]");
		
		if(purchaseinvoice_discountparray.length>0){
			for(var p=0; p<purchaseinvoice_discountparray.length; p++){
				var purchaseinvoice_discountp = parseFloat(purchaseinvoice_discountparray[p].value);
				if(purchaseinvoice_discountp=='' || isNaN(purchaseinvoice_discountp)){purchaseinvoice_discountp = 0;}
				
				var purchaseinvoice_disc = parseFloat(purchaseinvoice_discarray[p].value);
				if(purchaseinvoice_disc=='' || isNaN(purchaseinvoice_disc)){purchaseinvoice_disc = 0;}
				if(purchaseinvoice_discountp>0){
					var purchaseinvoice_rate = parseFloat(purchaseinvoice_ratearray[p].value);
					if(purchaseinvoice_rate=='' || isNaN(purchaseinvoice_rate)){purchaseinvoice_rate = 0;}
					
					var purchaseinvoice_qty = purchaseinvoice_qtyarray[p].value;
					if(purchaseinvoice_qty=='' || isNaN(purchaseinvoice_qty)){purchaseinvoice_qty = 0;}
					
					var total = parseFloat(purchaseinvoice_rate*purchaseinvoice_qty);			
					var purchaseinvoice_disc = parseFloat(total*purchaseinvoice_discountp*0.01);
					
					purchaseinvoice_discarray[p].value = purchaseinvoice_disc.toFixed(2);
				}
				
				calculaterowtotal(p);
			}
		}
	}
	
	function calculaterowtotal(indexpos){
		if(indexpos=='all'){
			var purchaseinvoice_ratearray = document.getElementsByName("purchaseinvoice_rate[]");
			var purchaseinvoice_qtyarray = document.getElementsByName("purchaseinvoice_qty[]");
			var purchaseinvoice_discarray = document.getElementsByName("purchaseinvoice_disc[]");
			var purchaseinvoice_totalarray = document.getElementsByName("purchaseinvoice_total[]");
			
			if(purchaseinvoice_ratearray.length>0){
				for(var p=0; p<purchaseinvoice_ratearray.length; p++){
					var purchaseinvoice_rate = parseFloat(purchaseinvoice_ratearray[p].value);
					if(purchaseinvoice_rate=='' || isNaN(purchaseinvoice_rate)){purchaseinvoice_rate = 0;}
					
					var purchaseinvoice_qty = parseFloat(purchaseinvoice_qtyarray[p].value);
					if(purchaseinvoice_qty=='' || isNaN(purchaseinvoice_qty)){purchaseinvoice_qty = 0;}
					
					var total = parseFloat(purchaseinvoice_rate*purchaseinvoice_qty);
					
					var purchaseinvoice_disc = parseFloat(purchaseinvoice_discarray[p].value);
					if(purchaseinvoice_disc=='' || isNaN(purchaseinvoice_disc)){purchaseinvoice_disc = 0;}
					
					var total = parseFloat(total-purchaseinvoice_disc);
					
					purchaseinvoice_totalarray[p].value = total.toFixed(2);
				}
			}
			
		}
		else{
			var purchaseinvoice_ratearray = document.getElementsByName("purchaseinvoice_rate[]");
			var purchaseinvoice_rate = parseFloat(purchaseinvoice_ratearray[indexpos].value);
			if(purchaseinvoice_rate=='' || isNaN(purchaseinvoice_rate)){purchaseinvoice_rate = 0;}
			
			var purchaseinvoice_qtyarray = document.getElementsByName("purchaseinvoice_qty[]");
			var purchaseinvoice_qty = parseFloat(purchaseinvoice_qtyarray[indexpos].value);
			if(purchaseinvoice_qty=='' || isNaN(purchaseinvoice_qty)){purchaseinvoice_qty = 0;}
			
			var total = parseFloat(purchaseinvoice_rate*purchaseinvoice_qty);
			
			var purchaseinvoice_discarray = document.getElementsByName("purchaseinvoice_disc[]");
			var purchaseinvoice_disc = parseFloat(purchaseinvoice_discarray[indexpos].value);
			if(purchaseinvoice_disc=='' || isNaN(purchaseinvoice_disc)){purchaseinvoice_disc = 0;}
			
			var total = parseFloat(total-purchaseinvoice_disc);
			
			var purchaseinvoice_totalarray = document.getElementsByName("purchaseinvoice_total[]");
			purchaseinvoice_totalarray[indexpos].value = total.toFixed(2);
		}
		
		calculate_total();
	}
	
	function calculate_total(){
		
		//subtotal calculation
		var purchaseinvoice_subtotal = document.getElementById("purchaseinvoice_subtotal").value;
		if(purchaseinvoice_subtotal=='' || isNaN(purchaseinvoice_subtotal)){purchaseinvoice_subtotal = 0;}
		
		var purchaseinvoice_totaldisc = parseFloat(document.getElementById("purchaseinvoice_totaldisc").value);
		if(purchaseinvoice_totaldisc=='' || isNaN(purchaseinvoice_totaldisc)){purchaseinvoice_totaldisc = 0;}
		
		var purchaseinvoice_finaldisc = parseFloat(document.getElementById("purchaseinvoice_finaldisc").value);
		if(purchaseinvoice_finaldisc=='' || isNaN(purchaseinvoice_finaldisc)){purchaseinvoice_finaldisc = 0;}
		
		var purchaseinvoice_subtotalafterdisc = parseFloat(purchaseinvoice_subtotal-purchaseinvoice_totaldisc-purchaseinvoice_finaldisc);
		document.getElementById('purchaseinvoice_subtotalafterdisc').value= purchaseinvoice_subtotalafterdisc.toFixed(2);
		
		var purchaseinvoice_receiveamount = parseFloat(document.getElementById("purchaseinvoice_receiveamount").value);
		if(purchaseinvoice_receiveamount=='' || isNaN(purchaseinvoice_receiveamount)){purchaseinvoice_receiveamount = 0;}		
		
		var purchaseinvoicepaid_amount = parseFloat(document.getElementById("purchaseinvoicepaid_amount").value);
		if(purchaseinvoicepaid_amount=='' || isNaN(purchaseinvoicepaid_amount)){purchaseinvoicepaid_amount = 0;}
		
		var purchaseinvoice_due = parseFloat(document.getElementById("purchaseinvoice_due").value);
		if(purchaseinvoice_due=='' || isNaN(purchaseinvoice_due)){purchaseinvoice_due = 0;}
		
		//var purchaseinvoice_due = parseFloat(purchaseinvoice_subtotalafterdisc - purchaseinvoice_receiveamount-purchaseinvoicepaid_amount);
		//document.getElementById('purchaseinvoice_due').value=purchaseinvoice_due.toFixed(2);			
	
	var purchaseinvoice_currentdue = parseFloat(purchaseinvoice_due - purchaseinvoicepaid_amount  - purchaseinvoice_finaldisc);
		document.getElementById('purchaseinvoice_currentdue').value=purchaseinvoice_currentdue.toFixed(2);
		
	}
	
	function calculate_pctotal(){
		var purchaseinvoice_totalpccomission = 0;
		var purchaseinvoice_pccomissionarray = document.getElementsByName("purchaseinvoice_pccomission[]");
		if(purchaseinvoice_pccomissionarray.length>0){
			for(var p=0; p<purchaseinvoice_pccomissionarray.length; p++){
				var purchaseinvoice_pccomission = parseFloat(purchaseinvoice_pccomissionarray[p].value);
				if(purchaseinvoice_pccomission=='' || isNaN(purchaseinvoice_pccomission)){purchaseinvoice_pccomission = 0;}
				purchaseinvoice_totalpccomission = parseFloat(purchaseinvoice_totalpccomission+purchaseinvoice_pccomission);
			}
		}
		
		document.getElementById("purchaseinvoice_totalpccomission").value = purchaseinvoice_totalpccomission;
		
	}
	
	function check_particular(){
		/*var particular_idlistarray = new Array();
		var particular_id = document.getElementsByName('particular_id[]');
		var particular_count = particular_id.length;
		var particular_priceid = document.getElementsByName('particular_price[]');
		var particular_qtyid = document.getElementsByName('particular_qty[]');
			
		var error_messageid = document.getElementById('errmsg_particular_id');
		error_messageid.innerHTML = '';
		
		for(i = 0; i < particular_count; i++) {
												
			if(particular_id[i].value=='' || particular_id[i].value==0){
				error_messageid.innerHTML = 'Missing Particular Name '+parseInt(i+1);
				particular_id[i].focus();
				returnvalue = false;
			}
			
			if(particular_idlistarray.length>0 && particular_idlistarray.indexOf(particular_id[i].value) != -1){
				error_messageid.innerHTML = 'Dupplicate Particular Name '+i;
				particular_id[i].focus();
				return false;
			}
			else{
				particular_idlistarray[i] = particular_id[i].value;
			}
			
			var particular_priceval = parseInt(particular_priceid[i].value);
			if(isNaN(particular_priceval) || particular_priceval==''){particular_priceval = 0;}
			if(particular_priceval==0){
				error_messageid.innerHTML = 'Missing Price '+Math.floor(i+1);
				particular_priceid[i].focus();
				return false;
			}
										
			var particular_qtyval = parseInt(particular_qtyid[i].value);
			if(isNaN(particular_qtyval) || particular_qtyval==''){particular_qtyval = 0;}							
			if(particular_qtyval==0){
				error_messageid.innerHTML = 'Missing QTY '+Math.floor(i+1);
				particular_qtyid.focus();
				return false;
			}
		}*/
		return true;
	}
	function addnew_particularrow(animate) {
		if(check_particular()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" align=\"left\" width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"4\">"+
							'<tr>'+
								'<td align="right">Item Name</td>'+
								'<td> <input type="text" name="purchaseinvoice_item[]" value="" class="tdclass itemname"/></td>'+
								'<input type="hidden" name="purchaseinvoice_category[]" value="" class="tdclass"  />'+
								'<td align="right">Rate</td>'+
								"<td> <input type=\"text\" name=\"purchaseinvoice_rate[]\"  id=\"purchaseinvoice_rate\" value=\"\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/></td>"+											 
								'<td align="right">Qty</td>'+
								"<td> <input type=\"text\" name=\"purchaseinvoice_qty[]\"   id=\"purchaseinvoice_qty\" value=\"\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/></td>"+
								'<td align="right">Disc%</td>'+
								'<td> <input type="text" name="purchaseinvoice_discountp[]" value="" class="tdclasssale" onKeyUp="calculate_discountp();"/></td>'+
								'<td align="right">Disc</td>'+
								"<td> <input type=\"text\" name=\"purchaseinvoice_disc[]\" value=\"\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\" /></td>"+
								'<td align="right">P.C</td>'+
								'<td> <input type="text" name="purchaseinvoice_pccomission[]" value="" class="tdclasssale" onKeyUp="calculate_pctotal();"  /></td>'+
								'<td align="right">Total</td>'+
								'<td> <input type="text" readonly name="purchaseinvoice_total[]"  id="purchaseinvoice_total" value="" class="tdclasssale"  /></td>'+												
								'<td>'+
								 "<input type=\"button\" value=\"Cancel\" onClick=\"deletethislistrow('particularlistrowno"+particular_rowcount+"');\" class=\"tdclasssale\"  />"+
								'</td>'+
							  '</tr>'+
						"</table>";
						
			var $newparticularlist = $("<li></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(200); 
			else 
			   $newparticularlist.show();   
			
			$( ".itemname" ).autocomplete({			
				minLength: 1,
				source: itemdata,
				focus: function( event, ui ) {
					//$( "#search_item_number" ).val( ui.item.labelval );
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					
					var purchaseinvoice_ratearray = document.getElementsByName("purchaseinvoice_rate[]");
					purchaseinvoice_ratearray[indexpos].value = ui.item.salesitem_price;
					
					var purchaseinvoice_qtyarray = document.getElementsByName("purchaseinvoice_qty[]");
					purchaseinvoice_qtyarray[indexpos].value = 1;
					
					var purchaseinvoice_pccomissionarray = document.getElementsByName("purchaseinvoice_pccomission[]");
					purchaseinvoice_pccomissionarray[indexpos].value = ui.item.salesitem_pccommission;
					
					var purchaseinvoice_categoryarray = document.getElementsByName("purchaseinvoice_category[]");
					purchaseinvoice_categoryarray[indexpos].value = ui.item.salesitem_category;
	
					calculaterowtotal(indexpos);
					calculate_pctotal();
					
					return false;
				}
			});						
		}
	}
	
	function deletethislistrow(tableidname){
		$("#"+tableidname).parent("li").slideUp(200, function() {
			$(this).remove();
			calculaterowtotal('all');
		});
	}
</script>