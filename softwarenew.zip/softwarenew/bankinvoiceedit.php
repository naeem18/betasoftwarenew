<?php

$patientdata = '';
$sqlbankaccounts = "select * from bankaccounts order by bankaccounts_id asc";
$bankaccountsquery = mysqli_query($conn, $sqlbankaccounts);
if($bankaccountsquery && mysqli_num_rows($bankaccountsquery)>0){

	while ($bankaccountsrow = mysqli_fetch_array($bankaccountsquery)){
		$bankaccounts_id = $bankaccountsrow['bankaccounts_id'];
		$bankaccounts_name = $bankaccountsrow['bankaccounts_name'];
		$current_balance = $bankaccountsrow['current_balance'];
		$bankaccounts_number = $bankaccountsrow['bankaccounts_number'];
		$bankaccounts_address = $bankaccountsrow['bankaccounts_address'];
		$patientdata[] =array( 'labelval' => $bankaccounts_id,
							'label' => $bankaccounts_name,
							'bankaccounts_id'=>$bankaccounts_id,
							'current_balance'=>$current_balance,
							'bankaccounts_number'=>$bankaccounts_number,
							'bankaccounts_address'=>$bankaccounts_address
							);
		}
	}
$patientdata = json_encode($patientdata);

?>

<link rel="stylesheet" href="autocomplete/jquery-ui.css">
<script src="autocomplete/jquery-ui.min.js"></script>

<script language="JavaScript" type="text/javascript">
/*function disableEnterKey(e)
{
		var evt = e || window.event; 
			var key = evt.keyCode;
			//alert (key);
			if(key == 13) // if enter key press
			{
				//alert ("Enter Key Press");
				return false;
			}

}*/
</script>	
<style type="text/css">
.ui-autocomplete { height:auto !important; max-height:300px; overflow:auto; background:#FFF; border:1px solid #CCC;	width:200px;}
.search_row{text-align:left;}
.ui-autocomplete li{ min-height:30px; border-bottom:1px dotted #CCC; padding:10px; text-align:left;}
</style>

<script language="JavaScript" type="text/javascript">
	
	//var patientdata = <?php //echo $patientdata;?>;
	$(document).ready(function($) {
			
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
	});
	
		
	function calculate_total(){
		
		//var current_balance = parseFloat(document.getElementById("current_balance").value);
//		if(current_balance=='' || isNaN(current_balance)){current_balance = 0;}
//			
//		var deposite_amount = parseFloat(document.getElementById("deposite_amount").value);
//		if(deposite_amount=='' || isNaN(deposite_amount)){deposite_amount = 0;}
//		
//		var total_balance = parseFloat(current_balance + deposite_amount);
//		document.getElementById('total_balance').value=	total_balance.toFixed(2);
		
		}
	
function funcSaveBill1()
{
	
	var varUserChoice; 
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet); 
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		document.frmsales.submit();
		//return true;
	}
}		
</script>

<article class="bottomcontent">
    <h4>Bank Deposit Update</h4>
   <content>
   
        <?php
        if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
            echo "<p class=\"red12bold\">You have missing Something</p>";
        }
        elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
            echo "<p class=\"red12bold\">Error occured! Could not insert.</p>";   
        }
        elseif(isset($_GET['message']) && $_GET['message']=='save-successfully'){
            echo "<p class=\"red12bold\">Information insert successfully. Click Print Button To Print or View Previous Bill <td width=\"30\" align=\"center\" >
			<a onclick=\"PrintDiv();\"><input type=\"button\" required value=\"Print\" class=\"tdclass\"  /></a></td></p>";   
        }
													
		$bankinvoice_id = $_GET['bankinvoice_id'];
            $sqlbankitem = "select * from bankinvoice where bankinvoice_id = $bankinvoice_id";
            $bankitemquery = mysqli_query($conn, $sqlbankitem);
            if($bankitemquery){
                while($bankitemrow = mysqli_fetch_array($bankitemquery)){
                    $bankinvoice_id = $bankitemrow['bankinvoice_id'];
                    $bankaccounts_id = $bankitemrow['bankaccounts_id'];
                    $bankinvoice_name = $bankitemrow['bankinvoice_name'];
                    $bankinvoice_number = $bankitemrow['bankinvoice_number'];
                    $bankinvoice_address = $bankitemrow['bankinvoice_address'];
					 $deposite_amount = $bankitemrow['deposite_amount'];
					 $current_balance = $bankitemrow['current_balance'];
					 $total_balance = $bankitemrow['total_balance'];
					 $user = $bankitemrow['user'];
					 $note = $bankitemrow['note'];
					 $bankinvoice_date = $bankitemrow['bankinvoice_date'];
				}
			}
       ?>          
<form action="save_bankinvoice.php" name="frmcontact" onsubmit="return checkcontactform();" onKeyDown="return disableEnterKey(event)" method="post" enctype="multipart/form-data">
                          
<table width="650" border="0" bgcolor="#89C5C5" cellpadding="1">
      
  <tr>
  	<input type="hidden" readonly name="bankaccounts_id" id="bankaccounts_id" value="<?php echo $bankaccounts_id;?>" class="tdclass2" />
    <input type="hidden" name="user" id="user" required value="<?php echo $_SESSION['fullname'];?>" class="tdclass"  />
    <td align="right" bgcolor="#0066FF">Bank Name</td>
    <td> <input type="text" name="bankinvoice_name" id="bankinvoice_name" value="<?php echo $bankinvoice_name;?>" required class="tdclass"  />
    <td align="right">Account No.</td>
    <td><input type="text" name="bankinvoice_number" id="bankinvoice_number" value="<?php echo $bankinvoice_number;?>" class="tdclass"  /></td>
    </tr>
  <td></td>
  <tr>
    <td align="right">Branch</td>
	<td> <textarea type="text" name="bankinvoice_address" id="bankinvoice_address"  class="tdclass" /><?php echo $bankinvoice_address;?></textarea></td>
 
    <td align="right">Date</td>
     <td><input type="text" name="bankinvoice_date" readonly id="bankinvoice_date" value="<?php echo date('Y-m-d h:i:s');?>" class="tdclass2"  /></td>
      
  </tr>
</table>

<table  border="0" width="650" bgcolor="#e3e7ff" cellpadding="2">
    <tr>
     <td>Note :<textarea style="width:400px" name="note" id="note"><?php echo $note;?></textarea></td>
    </tr>
 </table>  
	
  <table  border="0" width="650" bgcolor="#e3e7ff" cellpadding="2">
  	
    <tr><td></td></tr>
    <tr>
     <td align="right" style="border-top:1px solid #999;">Current Balance :</td>
    	<td width="50" style="border-top:1px solid #999;"> 
        <input  type="text" readonly name="current_balance" id="current_balance" value="<?php echo $current_balance;?>" class="tdclass"  onKeyUp="calculate_total();" /></td>
    </tr>
    
     <tr>
     <td align="right">Deposit Amount:</td>
    <td> <input type="text"  name="deposite_amount" id="deposite_amount" readonly value="<?php echo $deposite_amount;?>" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
  	</tr>
    
    <tr>
     <td align="right"><strong>Adjustment Amount</strong>:</td>
    <td> <input type="text"  name="adjustment" id="adjustment"  class="tdclass numeric" onKeyUp="calculate_total();" /></td>
  	</tr>
    
    <tr>
     <td align="right">Total Balance Amount:</td>
    <td> <input type="text" readonly name="total_balance" id="total_balance" value="<?php echo $total_balance;?>" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
  	</tr>
    
   
    <tr>
     <td align="right"></td>
	 <td>
         <input type="hidden" name="bankinvoice_id" id="bankinvoice_id" value="<?php echo $bankinvoice_id;?>">
       <input type="submit"  value=" save " name="submit_invoice" id="submit_invoice" class="tdclass1" onClick="return funcSaveBill1()" />
         
         <input type="reset" name="bank" id="bank" value="Cancel" class="tdclass1"/>
     </td>
  	</tr>
   
</table>
</form>         
          
</content>
</article>

