<?php
// Set default timezone
date_default_timezone_set('Asia/Dhaka');

// Initialize search parameters
$searchstr = '';
$employee_name = isset($_REQUEST['employee_name']) ? trim($_REQUEST['employee_name']) : '';

if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '') {
    $transactiondatefrom = $_REQUEST['ADate1'];
    $transactiondateto = $_REQUEST['ADate2'];    
} else {
    $transactiondatefrom = date('Y-m-d', strtotime('-0 day'));
    $transactiondateto = date('Y-m-d');
}

$datetime1 = new DateTime($transactiondatefrom);
$datetime2 = new DateTime($transactiondateto);
$interval = $datetime1->diff($datetime2);
$totaldays = $interval->format('%a');
if($datetime1 < $datetime2) {
    $fromdate = $transactiondatefrom;
    $todate = $transactiondateto;
} else {
    $fromdate = $transactiondateto;
    $todate = $transactiondatefrom;
}
?>

<table width="100%" border="0" cellspacing="0" cellpadding="2">
    <tr>
        <td valign="top" align="center">
            <form name="cbform1" method="post" action="index.php?p=employedetailssalarysheet2">
                <table width="100%" border="1" align="center" cellpadding="2" cellspacing="0" bordercolor="#666666" style="border-collapse: collapse">
                    <tbody>
                        <tr bgcolor="#011E6A">
                            <td colspan="12" bgcolor="#CCCCCC" align="center"><strong>Search Employee Salary Details</strong></td>
                        </tr>           
                        <tr>
                            <td>Employee Name:</td>
                            <td><input name="employee_name" id="employee_name" style="border: 1px solid #001E6A" 
                                   value="<?php echo htmlspecialchars($employee_name); ?>" size="15" onKeyDown="return disableEnterKey()" /></td>
                            <td>Date From:</td>
                            <td><input name="ADate1" id="ADate1" style="border: 1px solid #001E6A" 
                                   value="<?php echo $transactiondatefrom; ?>" size="10" readonly onKeyDown="return disableEnterKey()" />
                                <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
                            </td>
                            <td>Date To:</td>
                            <td><input name="ADate2" id="ADate2" style="border: 1px solid #001E6A" 
                                   value="<?php echo $transactiondateto; ?>" size="10" readonly onKeyDown="return disableEnterKey()" />
                                <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate2')" style="cursor:pointer"/>
                            </td>
                            <td><input style="border: 1px solid #001E6A" type="submit" value="Search" name="Submit" />
                                <input name="resetbutton" type="reset" id="resetbutton" style="border: 1px solid #001E6A" value="Reset" />
                            </td>
                            <td><input name="print" type="button" id="print" style="border: 1px solid #001E6A" value="Print" onClick="PrintDiv();" /></td>
                        </tr>
                    </tbody>
                </table>
            </form>
        </td>
    </tr>

    <tr>
        <td align="center">
            <?php
            // Define all shift patterns
            $shifts = [
                ['8:00AM-4:00PM', '08:00:00', '16:00:00'],
                ['9:00AM-5:00PM', '09:00:00', '17:00:00'],
                ['10:00AM-6:00PM', '10:00:00', '18:00:00'],
                ['11:00AM-7:00PM', '11:00:00', '19:00:00'],
                ['12:00PM-8:00PM', '12:00:00', '20:00:00'],
                ['1:00PM-9:00PM', '13:00:00', '21:00:00'],
                ['2:00PM-10:00PM', '14:00:00', '22:00:00'],
                ['3:00PM-11:00PM', '15:00:00', '23:00:00'],
                ['4:00PM-12:00AM', '16:00:00', '00:00:00'],
                ['5:00PM-1:00AM', '17:00:00', '01:00:00'],
                ['6:00PM-2:00AM', '18:00:00', '02:00:00'],
                ['7:00PM-3:00AM', '19:00:00', '03:00:00'],
                ['8:00PM-4:00AM', '20:00:00', '04:00:00'],
                ['9:00PM-5:00AM', '21:00:00', '05:00:00'],
                ['10:00PM-6:00AM', '22:00:00', '06:00:00'],
                ['11:00PM-7:00AM', '23:00:00', '07:00:00'],
                ['12:00AM-8:00AM', '00:00:00', '08:00:00']
            ];
            
            foreach ($shifts as $shift) {
                $shiftName = $shift[0];
                $shiftStart = $shift[1];
                $shiftEnd = $shift[2];
                
                // Calculate the check-in window (first hour of shift)
                $checkinStart = $shiftStart;
                $checkinEnd = date('H:59:59', strtotime($shiftStart));
                
                // For overnight shifts, we need to handle date changes
                if (strtotime($shiftEnd) < strtotime($shiftStart)) {
                    // Overnight shift - check-in is on previous calendar day
                    $checkinDate = date('Y-m-d', strtotime($fromdate.' -1 day'));
                } else {
                    $checkinDate = $fromdate;
                }
                
                $newfromdate = $checkinDate . ' ' . $checkinStart;
                $newtodate = $checkinDate . ' ' . $checkinEnd;
                
                // Build the base SQL query
                $sqlsalary = "SELECT md.* FROM machine_data md
                             JOIN employee e ON md.e_id = e.e_id
                             WHERE md.entry_time BETWEEN '$newfromdate' AND '$newtodate' 
                             AND md.in_out=1 ";
                
                // Add employee name filter if search term exists
                if (!empty($employee_name)) {
                    $sqlsalary .= " AND e.name LIKE '%".mysqli_real_escape_string($conn, $employee_name)."%'";
                }
                
                $sqlsalary .= " ORDER BY md.id ASC";
                
                $salaryquery = mysqli_query($conn, $sqlsalary);
                
                // Only show shift table if there are records or name search is active
                if (mysqli_num_rows($salaryquery) > 0 || !empty($employee_name)) {
            ?>
            
            <h3>Shift: <?php echo $shiftName; ?></h3>
            <table align="center" width="100%" border="1" style="BORDER-COLLAPSE: collapse;" cellspacing="1" cellpadding="3">
                <tr>
                    <td colspan="12" bgcolor="#0033FF" align="center" style="color:#fff; border:1px solid #03F;">
                        <strong>Details Salary Sheet</strong><br>
                        <strong>Shift: <?php echo $shiftName; ?> (Check-in between <?php echo $checkinStart; ?> and <?php echo $checkinEnd; ?>)</strong>
                        <?php if (!empty($employee_name)) echo "<br>Filtered by: ".htmlspecialchars($employee_name); ?>
                    </td>
                </tr>
                <tr bgcolor="#ccc" align="center">
                    <td>SL</td>
                    <td>ID</td>
                    <td>Name</td>
                    <td>Entry Date</td>
                    <td>In Time</td>
                    <td>Shift Start</td>
                    <td>Grace Period</td>
                    <td>Late (Minutes)</td>
                    <td>Salary Per Day</td>
                    <td>Per Minute Rate</td>
                    <td>Salary Deduct</td>
                    <td>Today's Salary</td>
                </tr>
                <?php
                $s = 0;
                $totalLate = 0;
                $totalDeductions = 0;
                $totalSalary = 0;
                
                while ($salaryrow = mysqli_fetch_array($salaryquery)) {
                    $s++;
                    $e_id = $salaryrow['e_id'];
                    $id = $salaryrow['id'];
                    $entry_time = $salaryrow['entry_time'];
                    $entry_date = $salaryrow['entry_date'];
                    $in_out = $salaryrow['in_out'];
                    
                    $sqlst = "SELECT name, gross FROM employee WHERE e_id='$e_id'";
                    $exec3 = mysqli_query($conn, $sqlst);
                    $onerow = mysqli_fetch_array($exec3);
                    $name = $onerow['name'];
                    $gross = $onerow['gross'];
                    
                    $colorcode = ($in_out == 1) ? 'bgcolor="#CBDBFA"' : 'bgcolor="#D3EEB7"';
                    
                    // Time calculation with all fixes
                    $actualTime = new DateTime($entry_time);
                    $shiftDate = $actualTime->format('Y-m-d');
                    $expectedTime = new DateTime($shiftDate . ' ' . $shiftStart);
                    
                    // Handle overnight shifts
                    if ($actualTime < $expectedTime && strtotime($shiftEnd) < strtotime($shiftStart)) {
                        $expectedTime->modify('-1 day');
                    }
                    
                    $graceEndTime = clone $expectedTime;
                    $graceEndTime->add(new DateInterval('PT15M'));
                    
                    // Calculate late minutes
                    $lateMinutes = 0;
                    if ($actualTime > $graceEndTime) {
                        $diff = $actualTime->diff($graceEndTime);
                        $lateMinutes = ($diff->days * 24 * 60) + ($diff->h * 60) + $diff->i;
                    }
                    
                    // Special case for early same-day check-ins
                    if ($actualTime < $expectedTime && $actualTime->format('Y-m-d') == $expectedTime->format('Y-m-d')) {
                        $lateMinutes = 0;
                    }
                    
                    $lateMinutes = max(0, $lateMinutes);
                    $lateMinutes = min($lateMinutes, 1440);
                    
                    // Calculate salary values
                    $dailySalary = $gross / 30;
                    $workMinutes = 8 * 60;
                    $perMinuteRate = $dailySalary / $workMinutes;
                    $deduction = round($perMinuteRate * $lateMinutes, 2);
                    $netSalary = round($dailySalary - $deduction, 2);
                    
                    $totalLate += $lateMinutes;
                    $totalDeductions += $deduction;
                    $totalSalary += $netSalary;
                ?>
                <tr <?php echo $colorcode; ?> align="center">
                    <td align="left"><?php echo $s; ?></td>
                    <td align="left"><?php echo $e_id; ?></td>
                    <td align="left"><?php echo $name; ?></td>
                    <td align="left"><?php echo $entry_date; ?></td>
                    <td><?php echo $actualTime->format('Y-m-d H:i:s'); ?></td>
                    <td><?php echo $expectedTime->format('Y-m-d H:i:s'); ?></td>
                    <td>15 minutes</td>
                    <td><?php echo $lateMinutes; ?></td>
                    <td><?php echo number_format($dailySalary, 2); ?></td>
                    <td><?php echo number_format($perMinuteRate, 4); ?></td>
                    <td><?php echo number_format($deduction, 2); ?></td>
                    <td><?php echo number_format($netSalary, 2); ?></td>
                </tr>
                <?php
                }
                
                if ($s == 0) {
                    echo '<tr><td colspan="11" align="center">No records found for this shift';
                    if (!empty($employee_name)) echo ' matching search criteria';
                    echo '</td></tr>';
                }
                ?>
                <tr bgcolor="#ffcc99" align="center">
                    <td colspan="7"><strong>Shift Totals</strong></td>
                    <td><strong><?php echo round($totalLate); ?> min</strong></td>
                    <td>-</td>
                    <td>-</td>
                    <td><strong><?php echo number_format($totalDeductions, 2); ?></strong></td>
                    <td><strong><?php echo number_format($totalSalary, 2); ?></strong></td>
                </tr>
            </table>
            <br><br>
            <?php
                } // End if records exist or name search active
            } // End foreach shift
            ?>
        </td>
    </tr>
</table>