<script language="JavaScript" type="text/javascript">
	
	
	function calculate_total(){
		
		var emergencyinvoice_due = parseFloat(document.getElementById("emergencyinvoice_due").value);
		if(emergencyinvoice_due=='' || isNaN(emergencyinvoice_due)){emergencyinvoice_due = 0;}
		
		
		var discount_amount = parseFloat(document.getElementById("discount_amount").value);
		if(discount_amount=='' || isNaN(discount_amount)){discount_amount = 0;}
			
		var Tcollection_amount = parseFloat(document.getElementById("Tcollection_amount").value);
		if(Tcollection_amount=='' || isNaN(Tcollection_amount)){Tcollection_amount = '';}
		
		//var emergencyinvoice_totalpccomission_update = parseFloat(emergencyinvoice_totalpccomission - discount_amount/2);
		//document.getElementById('emergencyinvoice_totalpccomission_update').value=emergencyinvoice_totalpccomission_update.toFixed(2);
		
			
		var total_balance = parseFloat(emergencyinvoice_due - discount_amount - Tcollection_amount);
		document.getElementById('total_balance').value=	total_balance.toFixed(2);
		
		}
	function funcSaveBill1()
{
	
	var varUserChoice; 
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet); 
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		document.frmsales.submit();
		//return true;
	}
}				

</script>