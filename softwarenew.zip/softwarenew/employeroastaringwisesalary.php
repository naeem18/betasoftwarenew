<?php
$searchstr='';
if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
{
	$transactiondatefrom = $_REQUEST['ADate1'];
	$transactiondateto = $_REQUEST['ADate2'];	
}
else
{
	$transactiondatefrom = date('Y-m-d', strtotime('-0 day'));
	$transactiondateto = date('Y-m-d');
}

	$datetime1 = new DateTime($transactiondatefrom);
	$datetime2 = new DateTime($transactiondateto);
	$interval = $datetime1->diff($datetime2);
	$totaldays = $interval->format('%a');
	if($datetime1<$datetime2){
		$fromdate = $transactiondatefrom;
		$todate = $transactiondateto;
	}
	else{
		$fromdate = $transactiondateto;
		$todate = $transactiondatefrom;
	}
?>

<table width="120%" border="0" cellspacing="0" cellpadding="2">
 <tr>
    <td valign="top" align="center">
    	<form name="cbform1" method="post" action="index.php?p=employeroastaringwisesalary">
            <table width="100%" border="1" align="center" cellpadding="2" cellspacing="0" bordercolor="#666666" style="border-collapse: collapse">
              <tbody>
                <tr bgcolor="#011E6A">
                  <td colspan="10" bgcolor="#CCCCCC" align="center"><strong>Search date wise</strong></td>
                </tr>           
                <tr>
                    <td>Date From:</td>
                    <td><input name="ADate1" id="ADate1" style="border: 1px solid #001E6A" value="<?php echo $transactiondatefrom; ?>"  size="10"  readonly="readonly" onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
                    </td>
                    <td>Date To:</td>
                    <td><input name="ADate2" id="ADate2" style="border: 1px solid #001E6A" value="<?php echo $transactiondateto; ?>"  size="10"  readonly="readonly" onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate2')" style="cursor:pointer"/>
                    </td>
                    
                      <td><input style="border: 1px solid #001E6A" type="submit" value="Search" name="Submit" />
                          <input name="resetbutton" type="reset" id="resetbutton" style="border: 1px solid #001E6A" value="Reset" />
                    </td>
                    <td><input name="print" type="button" id="print" style="border: 1px solid #001E6A" value="Print" onClick="PrintDiv();" /></td>
                </tr>
              </tbody>
            </table>
		</form>
   	</td>
</tr>

<tr>
<td align="center" >
 <table align="center" width="100%" border="1" style="BORDER-COLLAPSE: collapse;" cellspacing="1" cellpadding="3">
      <tr>
        <td colspan="100%" bgcolor="#0033FF" align="center" style="color:#fff; border:1px solid #03F;">
            <strong>Roasting wise salary</strong><br>
            <strong>8.00 to 4.00</strong>
        </td>
      </tr>
      <tr bgcolor="#ccc" align="center">
        <td>SL</td>
        <td>ID</td>
        <td>Name</td>
        <td>In Time</td>
        <!--<td>In(1)/Out(2)</td>-->
        <td>Salary Per Day</td>

        <td>Late</td>
        <td>Late</td>
        <td>Late Count(-15)</td>
        <td>Salary Deduct</td>
        <td>Today's Salary</td>
      </tr>
	  <?php
	    $s=0;
		$newfromdate = date('Y-m-d 08:00:00', strtotime($fromdate)+floor(86400));
		$newtodate = date('Y-m-d 08:59:59', strtotime($fromdate)+floor(86400));
     	$sqlsalesitem = "select * from machine_data where entry_time between '$newfromdate' AND '$newtodate' AND in_out=1 order by id asc";
	  	$salesitemquery = mysqli_query($conn, $sqlsalesitem);
			while ($salesitemrow = mysqli_fetch_array($salesitemquery))
				{
				$e_id = $salesitemrow['e_id'];
				$id = $salesitemrow['id'];
				$entry_time = $salesitemrow['entry_time'];
				$entry_date = $salesitemrow['entry_date'];
				$in_out = $salesitemrow['in_out'];
				
				$sqlst = "select name,gross from employee where e_id='$e_id'";
				$exec3 = mysqli_query($conn, $sqlst) or die ("Error in Query3".mysql_error());
				$onerow = mysqli_fetch_array($exec3);
					$name = $onerow['name'];
					$gross = $onerow['gross'];
				 
				if ($in_out == 1)
					{ $colorcode = 'bgcolor="#CBDBFA"';}
					else
					{ $colorcode = 'bgcolor="#D3EEB7"';}
				?>
				<tr <?php echo $colorcode; ?> align="center">
					<td align="left"><?php echo $s=$s+1; ?></td>
					<td align="left"><?php echo $e_id; ?></td>
                    <td align="left"><?php echo $name; ?></td>
					<td><?php echo $entry_date .'#'. $entry_time; ?></td>
					<?php /*?><td align="left"><?php echo $in_out; ?></td><?php */?>
                    <td align="left"><?php echo $gross/30; ?></td>

                    <td><?php echo $H=(date('H',strtotime($entry_time))-'08')*60; echo '+'; echo $S=date('i',strtotime($entry_time)); ?></td>
                    <td><?php echo $HS=$H + $S; ?></td>
                    <td><?php echo $LHS=($H + $S)-15; ?></td>
					<td><?php if($LHS>0){echo $lessT=($gross/30)/(9*60)*(($H + $S)-15);} ?></td>
					<td><?php if($LHS>0){echo $Total=($gross/30)-($gross/30)/(9*60)*(($H + $S)-15);}
							  if($LHS<=0){echo $Total=($gross/30);} ?></td>
                 </tr>
			<?Php
			}
  		?>
 </table>
 
 <table align="center" width="100%" border="1" style="BORDER-COLLAPSE: collapse;" cellspacing="1" cellpadding="3">
      <tr>
        <td colspan="10" bgcolor="#0033FF" align="center" style="color:#fff; border:1px solid #03F;">
            <strong><?php echo $hospitaldata_name; ?></strong><br>
            <strong>9.00 to 5.00</strong>
        </td>
      </tr>
      <tr bgcolor="#ccc" align="center">
        <td>SL</td>
        <td>ID</td>
        <td>Name</td>
        <td>In Time</td>
        <td>In(1)/Out(2)</td>
        <td>Salary Per Day</td>
      </tr>
	  <?php
	    $s=0;
		$newfromdate = date('Y-m-d 09:00:00', strtotime($fromdate)+floor(86400));
		$newtodate = date('Y-m-d 09:59:59', strtotime($fromdate)+floor(86400));
     	$sqlsalesitem = "select * from machine_data where entry_time between '$newfromdate' AND '$newtodate' AND in_out=1 order by id asc";
	  	$salesitemquery = mysqli_query($conn, $sqlsalesitem);
			while ($salesitemrow = mysqli_fetch_array($salesitemquery))
				{
				$e_id = $salesitemrow['e_id'];
				$id = $salesitemrow['id'];
				$entry_time = $salesitemrow['entry_time'];
				$entry_date = $salesitemrow['entry_date'];
				$in_out = $salesitemrow['in_out'];
				
				$sqlst = "select name,gross from employee where e_id='$e_id'";
				$exec3 = mysqli_query($conn, $sqlst) or die ("Error in Query3".mysql_error());
				$onerow = mysqli_fetch_array($exec3);
					$name = $onerow['name'];
					$gross = $onerow['gross'];

				if ($in_out == 1)
					{ $colorcode = 'bgcolor="#CBDBFA"';}
					else
					{ $colorcode = 'bgcolor="#D3EEB7"';}
				?>
				<tr <?php echo $colorcode; ?> align="center">
					<td align="left"><?php echo $s=$s+1; ?></td>
					<td align="left"><?php echo $e_id; ?></td>
                    <td align="left"><?php echo $name; ?></td>
					<td><?php echo $entry_date .'#'. $entry_time; ?></td>
					<td align="left"><?php echo $in_out; ?></td>
                    <td align="left"><?php echo $gross/30; ?></td>
                </tr>
			<?Php
			}
  		?>
 </table>
 
 <table align="center" width="100%" border="1" style="BORDER-COLLAPSE: collapse;" cellspacing="1" cellpadding="3">
      <tr>
        <td colspan="10" bgcolor="#0033FF" align="center" style="color:#fff; border:1px solid #03F;">
            <strong><?php echo $hospitaldata_name; ?></strong><br>
            <strong>10.00 to 6.00</strong>
        </td>
      </tr>
      <tr bgcolor="#ccc" align="center">
        <td>SL</td>
        <td>ID</td>
        <td>Name</td>
        <td>In Time</td>
        <td>In(1)/Out(2)</td>
        <td>Salary Per Day</td>
      </tr>
	  <?php
	  $s=0;
 			$newfromdate = date('Y-m-d 10:00:00', strtotime($fromdate)+floor(86400));
			$newtodate = date('Y-m-d 10:59:59', strtotime($fromdate)+floor(86400));
     	$sqlsalesitem = "select * from machine_data where entry_time between '$newfromdate' AND '$newtodate' AND in_out=1 order by id asc";
	  	$salesitemquery = mysqli_query($conn, $sqlsalesitem);
			while ($salesitemrow = mysqli_fetch_array($salesitemquery))
				{
				$e_id = $salesitemrow['e_id'];
				$id = $salesitemrow['id'];
				$entry_time = $salesitemrow['entry_time'];
				$entry_date = $salesitemrow['entry_date'];
				$in_out = $salesitemrow['in_out'];
				
				$sqlst = "select name,gross from employee where e_id='$e_id'";
				$exec3 = mysqli_query($conn, $sqlst) or die ("Error in Query3".mysql_error());
				$onerow = mysqli_fetch_array($exec3);
					$name = $onerow['name'];
					$gross = $onerow['gross'];
				 
				if ($in_out == 1)
					{ $colorcode = 'bgcolor="#CBDBFA"';}
					else
					{ $colorcode = 'bgcolor="#D3EEB7"';}
				?>
				<tr <?php echo $colorcode; ?> align="center">
					<td align="left"><?php echo $s=$s+1; ?></td>
					<td align="left"><?php echo $e_id; ?></td>
                    <td align="left"><?php echo $name; ?></td>
					<td><?php echo $entry_date .'#'. $entry_time; ?></td>
					<td align="left"><?php echo $in_out; ?></td>
                    <td align="left"><?php echo $gross/30; ?></td>
                </tr>
			<?Php
			}
  		?>
 </table>


 <table align="center" width="100%" border="1" style="BORDER-COLLAPSE: collapse;" cellspacing="1" cellpadding="3">
      <tr>
        <td colspan="10" bgcolor="#0033FF" align="center" style="color:#fff; border:1px solid #03F;">
            <strong><?php echo $hospitaldata_name; ?></strong><br>
            <strong>2.00PM/ 14.00PM to 0.00</strong>
        </td>
      </tr>
      <tr bgcolor="#ccc" align="center">
        <td>SL</td>
        <td>ID</td>
        <td>Name</td>
        <td>In Time</td>
        <td>In(1)/Out(2)</td>
        <td>Salary Per Day</td>
      </tr>
	  <?php
	  $s=0;
 			$newfromdate = date('Y-m-d 14:00:00', strtotime($fromdate)+floor(86400));
			$newtodate = date('Y-m-d 14:59:59', strtotime($fromdate)+floor(86400));
     	$sqlsalesitem = "select * from machine_data where entry_time between '$newfromdate' AND '$newtodate' AND in_out=1 order by id asc";
	  	$salesitemquery = mysqli_query($conn, $sqlsalesitem);
			while ($salesitemrow = mysqli_fetch_array($salesitemquery))
				{
				$e_id = $salesitemrow['e_id'];
				$id = $salesitemrow['id'];
				$entry_time = $salesitemrow['entry_time'];
				$entry_date = $salesitemrow['entry_date'];
				$in_out = $salesitemrow['in_out'];
				
				$sqlst = "select name,gross from employee where e_id='$e_id'";
				$exec3 = mysqli_query($conn, $sqlst) or die ("Error in Query3".mysql_error());
				$onerow = mysqli_fetch_array($exec3);
					$name = $onerow['name'];
					$gross = $onerow['gross'];
				 
				if ($in_out == 1)
					{ $colorcode = 'bgcolor="#CBDBFA"';}
					else
					{ $colorcode = 'bgcolor="#D3EEB7"';}
				?>
				<tr <?php echo $colorcode; ?> align="center">
					<td align="left"><?php echo $s=$s+1; ?></td>
					<td align="left"><?php echo $e_id; ?></td>
                    <td align="left"><?php echo $name; ?></td>
					<td><?php echo $entry_date .'#'. $entry_time; ?></td>
					<td align="left"><?php echo $in_out; ?></td>
                    <td align="left"><?php echo $gross/30; ?></td>
                </tr>
			<?Php
			}
  		?>
 </table>
 
 <table align="center" width="100%" border="1" style="BORDER-COLLAPSE: collapse;" cellspacing="1" cellpadding="3">
      <tr>
        <td colspan="10" bgcolor="#0033FF" align="center" style="color:#fff; border:1px solid #03F;">
            <strong><?php echo $hospitaldata_name; ?></strong><br>
            <strong>8.00PM/20PM to 0.00</strong>
        </td>
      </tr>
      <tr bgcolor="#ccc" align="center">
        <td>SL</td>
        <td>ID</td>
        <td>Name</td>
        <td>In Time</td>
        <td>In(1)/Out(2)</td>
        <td>Salary Per Day</td>
      </tr>
	  <?php
	  	$s=0;
		$newfromdate = date('Y-m-d 20:00:00', strtotime($fromdate)+floor(86400));
		$newtodate = date('Y-m-d 20:59:59', strtotime($fromdate)+floor(86400));
     	$sqlsalesitem = "select * from machine_data where entry_time between '$newfromdate' AND '$newtodate' AND in_out=1 order by id asc";
	  	$salesitemquery = mysqli_query($conn, $sqlsalesitem);
			while ($salesitemrow = mysqli_fetch_array($salesitemquery))
				{
				$e_id = $salesitemrow['e_id'];
				$id = $salesitemrow['id'];
				$entry_time = $salesitemrow['entry_time'];
				$entry_date = $salesitemrow['entry_date'];
				$in_out = $salesitemrow['in_out'];
				
				$sqlst = "select name,gross from employee where e_id='$e_id'";
				$exec3 = mysqli_query($conn, $sqlst) or die ("Error in Query3".mysql_error());
				$onerow = mysqli_fetch_array($exec3);
					$name = $onerow['name'];
					$gross = $onerow['gross'];
				 
				if ($in_out == 1)
					{ $colorcode = 'bgcolor="#CBDBFA"';}
					else
					{ $colorcode = 'bgcolor="#D3EEB7"';}
				?>
				<tr <?php echo $colorcode; ?> align="center">
					<td align="left"><?php echo $s=$s+1; ?></td>
					<td align="left"><?php echo $e_id; ?></td>
                    <td align="left"><?php echo $name; ?></td>
					<td><?php echo $entry_date .'#'. $entry_time; ?></td>
					<td align="left"><?php echo $in_out; ?></td>
                    <td align="left"><?php echo $gross/30; ?></td>
                </tr>
			<?Php
			}
  		?>
 </table>
 
 <table align="center" width="100%" border="1" style="BORDER-COLLAPSE: collapse;" cellspacing="1" cellpadding="3">
      <tr>
        <td colspan="10" bgcolor="#0033FF" align="center" style="color:#fff; border:1px solid #03F;">
            <strong><?php echo $hospitaldata_name; ?></strong><br>
            <strong>21.00 to 0.00</strong>
        </td>
      </tr>
      <tr bgcolor="#ccc" align="center">
        <td>SL</td>
        <td>ID</td>
        <td>Name</td>
        <td>In Time</td>
        <td>In(1)/Out(2)</td>
        <td>Salary Per Day</td>
      </tr>
	  <?php
	  $s=0;
 			$newfromdate = date('Y-m-d 21:00:00', strtotime($fromdate)+floor(86400));
			$newtodate = date('Y-m-d 21:59:59', strtotime($fromdate)+floor(86400));
     	$sqlsalesitem = "select * from machine_data where entry_time between '$newfromdate' AND '$newtodate' AND in_out=1 order by id asc";
	  	$salesitemquery = mysqli_query($conn, $sqlsalesitem);
			while ($salesitemrow = mysqli_fetch_array($salesitemquery))
				{
				$e_id = $salesitemrow['e_id'];
				$id = $salesitemrow['id'];
				$entry_time = $salesitemrow['entry_time'];
				$entry_date = $salesitemrow['entry_date'];
				$in_out = $salesitemrow['in_out'];
				
				$sqlst = "select name,gross from employee where e_id='$e_id'";
				$exec3 = mysqli_query($conn, $sqlst) or die ("Error in Query3".mysql_error());
				$onerow = mysqli_fetch_array($exec3);
					$name = $onerow['name'];
					$gross = $onerow['gross'];
				 
				if ($in_out == 1)
					{ $colorcode = 'bgcolor="#CBDBFA"';}
					else
					{ $colorcode = 'bgcolor="#D3EEB7"';}
				?>
				<tr <?php echo $colorcode; ?> align="center">
					<td align="left"><?php echo $s=$s+1; ?></td>
					<td align="left"><?php echo $e_id; ?></td>
                    <td align="left"><?php echo $name; ?></td>
					<td><?php echo $entry_date .'#'. $entry_time; ?></td>
					<td align="left"><?php echo $in_out; ?></td>
                    <td align="left"><?php echo $gross/30; ?></td>
                </tr>
			<?Php
			}
  		?>
 </table>
 
 <table align="center" width="100%" border="1" style="BORDER-COLLAPSE: collapse;" cellspacing="1" cellpadding="3">
      <tr>
        <td colspan="10" bgcolor="#0033FF" align="center" style="color:#fff; border:1px solid #03F;">
            <strong><?php echo $hospitaldata_name; ?></strong><br>
            <strong>10/22.00PM to 0.00</strong>
        </td>
      </tr>
      <tr bgcolor="#ccc" align="center">
        <td>SL</td>
        <td>ID</td>
        <td>Name</td>
        <td>In Time</td>
        <td>In(1)/Out(2)</td>
        <td>Salary Per Day</td>
      </tr>
	  <?php
	  $s=0;
 			$newfromdate = date('Y-m-d 22:00:00', strtotime($fromdate)+floor(86400));
			$newtodate = date('Y-m-d 22:59:59', strtotime($fromdate)+floor(86400));
     	$sqlsalesitem = "select * from machine_data where entry_time between '$newfromdate' AND '$newtodate' AND in_out=1 order by id asc";
	  	$salesitemquery = mysqli_query($conn, $sqlsalesitem);
			while ($salesitemrow = mysqli_fetch_array($salesitemquery))
				{
				$e_id = $salesitemrow['e_id'];
				$id = $salesitemrow['id'];
				$entry_time = $salesitemrow['entry_time'];
				$entry_date = $salesitemrow['entry_date'];
				$in_out = $salesitemrow['in_out'];
				
				$sqlst = "select name,gross from employee where e_id='$e_id'";
				$exec3 = mysqli_query($conn, $sqlst) or die ("Error in Query3".mysql_error());
				$onerow = mysqli_fetch_array($exec3);
					$name = $onerow['name'];
					$gross = $onerow['gross'];
				 
				if ($in_out == 1)
					{ $colorcode = 'bgcolor="#CBDBFA"';}
					else
					{ $colorcode = 'bgcolor="#D3EEB7"';}
				?>
				<tr <?php echo $colorcode; ?> align="center">
					<td align="left"><?php echo $s=$s+1; ?></td>
					<td align="left"><?php echo $e_id; ?></td>
                    <td align="left"><?php echo $name; ?></td>
					<td><?php echo $entry_date .'#'. $entry_time; ?></td>
					<td align="left"><?php echo $in_out; ?></td>
                    <td align="left"><?php echo $gross/30; ?></td>
                </tr>
			<?Php
			}
  		?>
 </table>
 
 </td>
 </tr> 
 </table>