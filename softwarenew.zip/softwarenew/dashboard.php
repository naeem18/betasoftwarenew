<?php
$searchstr='';
if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
{
	$transactiondatefrom = $_REQUEST['ADate1'];
	$transactiondateto = $_REQUEST['ADate2'];
}
else
{
	$transactiondatefrom = date('Y-m-d', strtotime('-0 day'));
	$transactiondateto = date('Y-m-d');
}
?>

<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td valign="top" align="center">
    	<form name="cbform1" method="post" action="index.php?p=dashboard">
            <table width="100%" border="1" align="center" cellpadding="4" cellspacing="0" bordercolor="#666666" style="border-collapse: collapse">
              <tbody>
                <tr bgcolor="#011E6A">
                  <td colspan="10" bgcolor="#CCCCCC" class="bodytext3"><strong>Search Date Wise</strong></td>
                </tr>
                <tr bgcolor="#FFFFFF">
                    <td>Date From:</td>
                    <td><input name="ADate1" id="ADate1" style="border: 1px solid #001E6A" value="<?php echo $transactiondatefrom; ?>" size="10" readonly onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
                    </td>
                    <td>Date To:</td>
                    <td><input name="ADate2" id="ADate2" style="border: 1px solid #001E6A" value="<?php echo $transactiondateto; ?>" size="10" readonly onKeyDown="return disableEnterKey()" />
                         <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate2')" style="cursor:pointer"/>
                    </td>
                    <td><input  style="border: 1px solid #001E6A" type="submit" value="Search" name="submit" /></td>
                    <td><input name="print" type="button" id="print" style="border: 1px solid #001E6A" value="Print" onClick="PrintDiv();" /></td>
                </tr>
              </tbody>
            </table>
		</form>
   		</td>
	</tr>

		<tr>
    	<td align="center">
		<?php
			$datetime1 = new DateTime($transactiondatefrom);
			$datetime2 = new DateTime($transactiondateto);
			$interval = $datetime1->diff($datetime2);
			$totaldays = $interval->format('%a');
			if($datetime1<$datetime2){
				$fromdate = $transactiondatefrom;
				$todate = $transactiondateto;
			}
			else{
				$fromdate = $transactiondateto;
				$todate = $transactiondatefrom;
			}
		 ?>
         <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1">
          <tr>
            <td colspan="19" bgcolor="#f2f2f2" align="center" style="color:#03F; border:1px solid #03F;">
            	<strong><?php echo $hospitaldata_name; ?></strong><br>
                <strong>Dashboard :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></strong>
            </td>
          </tr>
          </table>

          <table align="left" style="BORDER-COLLAPSE: collapse" width="100%" border="1" cellpadding="5" >
             
            <tr bgcolor="#F3F764">
                <td align="center">Section</td>
              	<td align="center">Qty</td>
              	<td align="center">Amount</td> 
            </tr>
 		<?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(number) as numbertotal, sum(appointmententry_amount) as appointmententry_amounttotal from appointmententry where (appointmententry_date between '$newfromdate' and '$newtodate') $searchstr  order by appointmententry_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$number1 = $strow['numbertotal'];
				$appointmententry_amount = $strow['appointmententry_amounttotal'];
 			?>
         <tr align="center">
           <td><strong>Appointment</strong> </td>
           <td><strong><?php echo $number1; ?></strong> </td>
           <td><strong><?php echo $appointmententry_amount; ?></strong> </td>
         </tr>
         <?php
             }
          }
     	?>
        
        <!--Admited-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(number) as numbertotal, sum(admissionfee) as admissionfeeT from opregistration where status='admitted' AND (opregistration_date between '$newfromdate' and '$newtodate') $searchstr order by opregistration_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$number2 = $strow['numbertotal'];
				$admissionfee = $strow['admissionfeeT'];
  			?>
         <tr align="center">
           <td><strong>Today's Admitted</strong> </td>
           <td><strong><?php echo $number2; ?></strong> </td>
           <td><strong><?php //echo $admissionfee; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
        <!--Admission Fees-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(labinvoice_receiveamount) as labinvoice_receiveamountT from dailytransection_lab where section='Admission Fee' and (dailytransection_lab_date between '$newfromdate' and '$newtodate') $searchstr order by dailytransection_lab_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$labinvoice_receiveamountAD = $strow['labinvoice_receiveamountT'];
  			?>
         <tr align="center">
           <td><strong>Admission Fees Received</strong> </td>
           <td><strong></strong> </td>
           <td><strong><?php echo $labinvoice_receiveamountAD; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
        <!--Total Admitted-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(number) as numbertotal, sum(admissionfee) as admissionfeeT from opregistration where status='admitted' order by opregistration_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$number3 = $strow['numbertotal'];
				$admissionfee = $strow['admissionfeeT'];
  			?>
         <tr align="center">
           <td><strong>Total Admitted</strong> </td>
           <td><strong><?php echo $number3; ?></strong> </td>
           <td><strong><?php //echo $admissionfee; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
        
        
        <!--Release-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(number) as numbertotal from opregistration where status='Released' AND (ip_releasedate between '$newfromdate' and '$newtodate') $searchstr order by ip_releasedate asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$number4 = $strow['numbertotal'];
  			?>
         <tr align="center">
           <td><strong>Released</strong> </td>
           <td><strong><?php echo $number4; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
       
       
       
        
        
         
         
        <!--Advanced-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(advanced) as advancedT from advanced where type='advanced' and (advanced_date between '$newfromdate' and '$newtodate') $searchstr order by advanced_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$advanced = $strow['advancedT'];
  			?>
         <tr align="center">
           <td><strong>Advanced Collection</strong> </td>
           <td><strong></strong> </td>
           <td><strong><?php echo $advanced; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
        
        
        <!--Emergency-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(emergencyinvoice_receiveamount) as emergencyinvoice_receiveamountT from emergencyinvoice where (emergencyinvoice_date between '$newfromdate' and '$newtodate') $searchstr order by emergencyinvoice_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$emergencyinvoice_receiveamount = $strow['emergencyinvoice_receiveamountT'];
  			?>
         <tr align="center">
           <td><strong>Emergency</strong> </td>
           <td><strong></strong> </td>
           <td><strong><?php echo $emergencyinvoice_receiveamount; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
        
        <!--Lab Cash-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(labinvoice_receiveamount) as labinvoice_receiveamountT from labinvoice where (labinvoice_date between '$newfromdate' and '$newtodate') $searchstr order by labinvoice_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$labinvoice_receiveamount = $strow['labinvoice_receiveamountT'];
  			?>
         <tr align="center">
           <td><strong>OutDoor Cash</strong> </td>
           <td><strong></strong></td>
           <td><strong><?php echo $labinvoice_receiveamount; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
        
        
        <!--Lab Collection-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(collection_amount) as collection_amountT from labcollection where (labcollection_date between '$newfromdate' and '$newtodate') $searchstr order by labcollection_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$collection_amount = $strow['collection_amountT'];
  			?>
         <tr align="center">
           <td><strong>OutDoor Due Collection</strong> </td>
           <td><strong></strong></td>
           <td><strong><?php echo $collection_amount; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
        
        
        <!--Hospital cash-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(hospitalinvoice_receiveamount) as hospitalinvoice_receiveamountT from hospitalinvoice where (hospitalinvoice_deliverydate between '$newfromdate' and '$newtodate') $searchstr order by hospitalinvoice_deliverydate asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 			 $hospitalinvoice_receiveamount = $strow['hospitalinvoice_receiveamountT'];
  			?>
         <tr align="center">
           <td><strong>Indoor Cash</strong> </td>
           <td><strong></strong> </td>
           <td><strong><?php echo $hospitalinvoice_receiveamount; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
        
        
         <!--Hospital collection-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(hospitalinvoicecollection_amount) as hospitalinvoicecollection_amountT from hospitalinvoicecollection where (hospitalinvoicecollection_date between '$newfromdate' and '$newtodate') $searchstr order by hospitalinvoicecollection_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 			 $hospitalinvoicecollection_amount = $strow['hospitalinvoicecollection_amountT'];
  			?>
         <tr align="center">
           <td><strong>Indoor Due Collection</strong> </td>
           <td><strong></strong> </td>
           <td><strong><?php echo $hospitalinvoicecollection_amount; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
        
       
          
       <!--icu/ccu-->
        
        <!--icu cash-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
 		    $sqlst = "select *, sum(hospitalinvoiceicu_receiveamount) as hospitalinvoiceicu_receiveamountT from hospitalinvoiceicu where (hospitalinvoiceicu_deliverydate between '$newfromdate' and '$newtodate') $searchstr order by hospitalinvoiceicu_deliverydate asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$hospitalinvoiceicu_receiveamount = $strow['hospitalinvoiceicu_receiveamountT'];
  			?>
         <tr align="center">
           <td><strong>ICU Cash</strong> </td>
           <td><strong></strong> </td>
           <td><strong><?php echo $hospitalinvoiceicu_receiveamount; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
         
         <!--icu collection-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(hospitalinvoiceicucollection_amount) as hospitalinvoiceicucollection_amountT from hospitalinvoiceicucollection where (hospitalinvoiceicucollection_date between '$newfromdate' and '$newtodate') $searchstr order by hospitalinvoiceicucollection_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 			 $hospitalinvoiceicucollection_amount = $strow['hospitalinvoiceicucollection_amountT'];
  			?>
         <tr align="center">
           <td><strong>ICU Due Collection</strong> </td>
           <td><strong></strong> </td>
           <td><strong><?php echo $hospitalinvoiceicucollection_amount; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
        
        
        <tr align="center" bgcolor="#EFEAEA">
           <td><strong>Total</strong> </td>
           <td><strong></strong> </td>
           <td><strong><?php echo $advanced+$emergencyinvoice_receiveamount+$labinvoice_receiveamount+$collection_amount+$hospitalinvoice_receiveamount+$hospitalinvoicecollection_amount+$hospitalinvoiceicu_receiveamount+$hospitalinvoiceicucollection_amount; ?></strong> </td>
        </tr>
          
        <!--Expense-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));

		    $sqlst = "select *, sum(expense_amount) as expense_amountT from expense where (expense_date between '$newfromdate' and '$newtodate') $searchstr order by expense_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$expense_amount = $strow['expense_amountT'];
  			?>
         <tr align="center">
           <td><strong>Expense Amount</strong> </td>
           <td><strong></strong> </td>
           <td><strong><?php echo $expense_amount; ?></strong> </td>
         </tr>
         <?php
             }
          }
     	?>
        
        <tr align="center" bgcolor="#f2f2f2">
           <td><strong>Cash In Hand</strong> </td>
           <td><strong></strong> </td>
           <td><strong><?php echo $labinvoice_receiveamountAD+$advanced+$emergencyinvoice_receiveamount+$labinvoice_receiveamount+$collection_amount+$hospitalinvoice_receiveamount+$hospitalinvoicecollection_amount+$hospitalinvoiceicu_receiveamount+$hospitalinvoiceicucollection_amount-$expense_amount; ?></strong> </td>
        </tr>
        
      </table>
     </td>
</tr>

 <td align="center" id="divToPrint" style="display:none">
 		<?php
			$datetime1 = new DateTime($transactiondatefrom);
			$datetime2 = new DateTime($transactiondateto);
			$interval = $datetime1->diff($datetime2);
			$totaldays = $interval->format('%a');
			if($datetime1<$datetime2){
				$fromdate = $transactiondatefrom;
				$todate = $transactiondateto;
			}
			else{
				$fromdate = $transactiondateto;
				$todate = $transactiondatefrom;
			}
		 ?>
         <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1">
          <tr>
            <td colspan="19" bgcolor="#f2f2f2" align="center" style="color:#03F; border:1px solid #03F;">
            	<strong><?php echo $hospitaldata_name; ?></strong><br>
                <strong>Dashboard :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></strong>
            </td>
          </tr>
          </table>

          <table align="left" style="BORDER-COLLAPSE: collapse" width="100%" border="1" cellpadding="5" >
             
            <tr bgcolor="#F3F764">
                <td align="center">Section</td>
              	<td align="center">Qty</td>
              	<td align="center">Amount</td> 
            </tr>
 		<?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(number) as numbertotal, sum(appointmententry_amount) as appointmententry_amounttotal from appointmententry where (appointmententry_date between '$newfromdate' and '$newtodate') $searchstr  order by appointmententry_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$number8 = $strow['numbertotal'];
				$appointmententry_amount = $strow['appointmententry_amounttotal'];
 			?>
         <tr align="center">
           <td><strong>Appointment</strong> </td>
           <td><strong><?php echo $number8; ?></strong> </td>
           <td><strong><?php echo $appointmententry_amount; ?></strong> </td>
         </tr>
         <?php
             }
          }
     	?>
        
        <!--Admited-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(number) as numbertotal, sum(admissionfee) as admissionfeeT from opregistration where status='admitted' AND (opregistration_date between '$newfromdate' and '$newtodate') $searchstr order by opregistration_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$number9 = $strow['numbertotal'];
				$admissionfee = $strow['admissionfeeT'];
  			?>
         <tr align="center">
           <td><strong>Today's Admitted</strong> </td>
           <td><strong><?php echo $number9; ?></strong> </td>
           <td><strong><?php //echo $admissionfee; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
        <!--Admission Fees-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(labinvoice_receiveamount) as labinvoice_receiveamountT from dailytransection_lab where section='Admission Fee' and (dailytransection_lab_date between '$newfromdate' and '$newtodate') $searchstr order by dailytransection_lab_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$labinvoice_receiveamountAD = $strow['labinvoice_receiveamountT'];
  			?>
         <tr align="center">

           <td><strong>Admission Fees Received</strong> </td>
           <td><strong></strong> </td>
           <td><strong><?php echo $labinvoice_receiveamountAD; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
        <!--Total Admited-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(number) as numbertotal, sum(admissionfee) as admissionfeeT from opregistration where status='admitted' order by opregistration_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$number10 = $strow['numbertotal'];
				$admissionfee = $strow['admissionfeeT'];
  			?>
         <tr align="center">
           <td><strong>Total Admitted</strong> </td>
           <td><strong><?php echo $number10; ?></strong> </td>
           <td><strong><?php //echo $admissionfee; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
        
        
        <!--Release-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(number) as numbertotal from opregistration where status='Released' AND (ip_releasedate between '$newfromdate' and '$newtodate') $searchstr order by ip_releasedate asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$number11 = $strow['numbertotal'];
  			?>
         <tr align="center">
           <td><strong>Released</strong> </td>
           <td><strong><?php echo $number11; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
       
       
       
        
        
         
         
        <!--Advanced-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(advanced) as advancedT from advanced where type='advanced' and (advanced_date between '$newfromdate' and '$newtodate') $searchstr order by advanced_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$advanced = $strow['advancedT'];
  			?>
         <tr align="center">
           <td><strong>Advanced Collection</strong> </td>
           <td><strong></strong> </td>
           <td><strong><?php echo $advanced; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
        
        
        <!--Emergency-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(emergencyinvoice_receiveamount) as emergencyinvoice_receiveamountT from emergencyinvoice where (emergencyinvoice_date between '$newfromdate' and '$newtodate') $searchstr order by emergencyinvoice_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$emergencyinvoice_receiveamount = $strow['emergencyinvoice_receiveamountT'];
  			?>
         <tr align="center">
           <td><strong>Emergency</strong> </td>
           <td><strong></strong> </td>
           <td><strong><?php echo $emergencyinvoice_receiveamount; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
        
        <!--Lab Cash-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(labinvoice_receiveamount) as labinvoice_receiveamountT from labinvoice where (labinvoice_date between '$newfromdate' and '$newtodate') $searchstr order by labinvoice_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$labinvoice_receiveamount = $strow['labinvoice_receiveamountT'];
  			?>
         <tr align="center">
           <td><strong>OutDoor Cash</strong> </td>
           <td><strong></strong></td>
           <td><strong><?php echo $labinvoice_receiveamount; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
        
        
        <!--Lab Collection-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(collection_amount) as collection_amountT from labcollection where (labcollection_date between '$newfromdate' and '$newtodate') $searchstr order by labcollection_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$collection_amount = $strow['collection_amountT'];
  			?>
         <tr align="center">
           <td><strong>OutDoor Due Collection</strong> </td>
           <td><strong></strong></td>
           <td><strong><?php echo $collection_amount; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
        
        
        <!--Hospital cash-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(hospitalinvoice_receiveamount) as hospitalinvoice_receiveamountT from hospitalinvoice where (hospitalinvoice_deliverydate between '$newfromdate' and '$newtodate') $searchstr order by hospitalinvoice_deliverydate asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$hospitalinvoice_receiveamount = $strow['hospitalinvoice_receiveamountT'];
  			?>
         <tr align="center">
           <td><strong>Indoor Cash</strong> </td>
           <td><strong></strong> </td>
           <td><strong><?php echo $hospitalinvoice_receiveamount; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
        
        
         <!--Hospital collection-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(hospitalinvoicecollection_amount) as hospitalinvoicecollection_amountT from hospitalinvoicecollection where (hospitalinvoicecollection_date between '$newfromdate' and '$newtodate') $searchstr order by hospitalinvoicecollection_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$hospitalinvoicecollection_amount = $strow['hospitalinvoicecollection_amountT'];
  			?>
         <tr align="center">
           <td><strong>Indoor Due Collection</strong> </td>
           <td><strong></strong> </td>
           <td><strong><?php echo $hospitalinvoicecollection_amount; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
        
       
          
       <!--icu/ccu-->
        
        <!--icu cash-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
 		    $sqlst = "select *, sum(hospitalinvoiceicu_receiveamount) as hospitalinvoiceicu_receiveamountT from hospitalinvoiceicu where (hospitalinvoiceicu_deliverydate between '$newfromdate' and '$newtodate') $searchstr order by hospitalinvoiceicu_deliverydate asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$hospitalinvoiceicu_receiveamount = $strow['hospitalinvoiceicu_receiveamountT'];
  			?>
         <tr align="center">
           <td><strong>ICU Cash</strong> </td>
           <td><strong></strong> </td>
           <td><strong><?php echo $hospitalinvoiceicu_receiveamount; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
         
         <!--icu collection-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
            
		    $sqlst = "select *, sum(hospitalinvoiceicucollection_amount) as hospitalinvoiceicucollection_amountT from hospitalinvoiceicucollection where (hospitalinvoiceicucollection_date between '$newfromdate' and '$newtodate') $searchstr order by hospitalinvoiceicucollection_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 			 $hospitalinvoiceicucollection_amount = $strow['hospitalinvoiceicucollection_amountT'];
  			?>
         <tr align="center">
           <td><strong>ICU Due Collection</strong> </td>
           <td><strong></strong> </td>
           <td><strong><?php echo $hospitalinvoiceicucollection_amount; ?></strong> </td>
          </tr>
         <?php
             }
          }
     	?>
        
        
        <tr align="center" bgcolor="#EFEAEA">
           <td><strong>Total</strong> </td>
           <td><strong></strong> </td>
           <td><strong><?php echo $labinvoice_receiveamountAD+$advanced+$emergencyinvoice_receiveamount+$labinvoice_receiveamount+$collection_amount+$hospitalinvoice_receiveamount+$hospitalinvoicecollection_amount+$hospitalinvoiceicu_receiveamount+$hospitalinvoiceicucollection_amount; ?></strong> </td>
        </tr>
          
        <!--Expense-->
        <?php
            $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));

		    $sqlst = "select *, sum(expense_amount) as expense_amountT from expense where (expense_date between '$newfromdate' and '$newtodate') $searchstr order by expense_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$expense_amount = $strow['expense_amountT'];
  			?>
         <tr align="center">
           <td><strong>Expense Amount</strong> </td>
           <td><strong></strong> </td>
           <td><strong><?php echo $expense_amount; ?></strong> </td>
         </tr>
         <?php
             }
          }
     	?>
        
        <tr align="center" bgcolor="#f2f2f2">
           <td><strong>Cash In Hand</strong> </td>
           <td><strong></strong> </td>
           <td><strong><?php echo $labinvoice_receiveamountAD+$advanced+$emergencyinvoice_receiveamount+$labinvoice_receiveamount+$collection_amount+$hospitalinvoice_receiveamount+$hospitalinvoicecollection_amount+$hospitalinvoiceicu_receiveamount+$hospitalinvoiceicucollection_amount-$expense_amount; ?></strong> </td>
        </tr>
        
      </table>
     </td>   
</table>

<article class="bottomcontent">
  <h3 align="center">SMS Panel(PC, MPO, DOCTOR)</h3>
       <?php
	   if(isset($_GET['message']) && $_GET['message']=='save-successfully'){
            echo "<p class=\"red12bold\">SMS Sent successfully </p>";
        }
      ?>
<form action="save_smsdeshboard.php" name="frm" onsubmit="return checkcontactform();" method="post" enctype="multipart/form-data">
  <table width="50%" align="center" border="1" style="BORDER-COLLAPSE: collapse;" bgcolor="#D6FEE1" cellpadding="2">
     <input type="hidden" name="user" id="user" required value="<?php echo $_SESSION['fullname'];?>" class="tdclass" />
    <tr>
        <td align="right">Number</td>
        <td><textarea name="number" id="number" class="textareadetailsr"><?php echo '01757827474';?></textarea></td>
        
    <tr>
        <td align="right">Particulars</td>
        <td><textarea name="writesmsname" id="writesmsname" class="textareadetailsr">ICU Hospital
</textarea>
        
        <textarea name="writesms" id="writesms" class="textareadetailsr"><?php
 			$s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
 		    $sqlst = "select *, sum(number) as numbertotal, sum(appointmententry_amount) as appointmententry_amounttotal from appointmententry where (appointmententry_date between '$newfromdate' and '$newtodate') $searchstr order by appointmententry_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
$number12 = $strow['numbertotal'];
$appointmententry_amount = $strow['appointmententry_amounttotal'];?>1. Appointment qty:<?php echo $number12;?>

<?php
}
}
?></textarea>
        <textarea name="writesms2" id="writesms2" class="textareadetailsr"><?php $s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
 		    $sqlst = "select *, sum(number) as numbertotal, sum(admissionfee) as admissionfeeT from opregistration where status='admitted' AND (opregistration_date between '$newfromdate' and '$newtodate') $searchstr order by opregistration_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {$number13 = $strow['numbertotal'];
$admissionfee = $strow['admissionfeeT'];?>2. Today's Admitted qty:<?php echo $number13;?>

<?php
}
}
?></textarea>
        <textarea name="writesms3" id="writesms3" class="textareadetailsr"><?php
 			$s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
 		   $sqlst = "select *, sum(number) as numbertotal, sum(admissionfee) as admissionfeeT from opregistration where status='admitted' order by opregistration_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$number14 = $strow['numbertotal'];
				$admissionfee = $strow['admissionfeeT'];?>3. Total Admitted:<?php echo $number14;?>

<?php
		}
	}
?></textarea>
         <textarea name="writesms4" id="writesms4" class="textareadetailsr"><?php
 			$s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
 		    $sqlst = "select *, sum(number) as numbertotal from opregistration where status='Released' AND (opregistration_date between '$newfromdate' and '$newtodate') $searchstr order by opregistration_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$number15 = $strow['numbertotal'];
  			?>4. Released qty:<?php echo $number15;?>
            
	<?php
		}
	}
?></textarea>
         <!--Adv Collection-->
        <textarea name="writesms5" id="writesms5" class="textareadetailsr"><?php
 			$s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
 		    $sqlst = "select *, sum(advanced) as advancedT from advanced where type='advanced' and (advanced_date between '$newfromdate' and '$newtodate') $searchstr order by advanced_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$advanced = $strow['advancedT'];
  			?>5. Adv Received:<?php echo $advanced;?>

<?php
}
}
?></textarea>
         <!--6.Emergency-->
        <textarea name="writesms6" id="writesms6" class="textareadetailsr"><?php
 			$s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
 		    $sqlst = "select *, sum(emergencyinvoice_receiveamount) as emergencyinvoice_receiveamountT from emergencyinvoice where (emergencyinvoice_date between '$newfromdate' and '$newtodate') $searchstr order by emergencyinvoice_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$emergencyinvoice_receiveamount = $strow['emergencyinvoice_receiveamountT'];
  			?>6. Emergency:<?php echo $emergencyinvoice_receiveamount;?>
            
<?php
}
}
?></textarea>        
         <!--7. Lab-->
        <textarea name="writesms7" id="writesms7" class="textareadetailsr"><?php
 			$s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
 		    $sqlst = "select *, sum(labinvoice_receiveamount) as labinvoice_receiveamountT from labinvoice where (labinvoice_date between '$newfromdate' and '$newtodate') $searchstr order by labinvoice_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$labinvoice_receiveamount = $strow['labinvoice_receiveamountT'];
  			?>7. OutDoor Cash:<?php echo $labinvoice_receiveamount;?>
            
<?php
}
}
?></textarea>
         <!--8.OutDoor Coll-->
        <textarea name="writesms8" id="writesms8" class="textareadetailsr"><?php
 			$s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
 		    $sqlst = "select *, sum(collection_amount) as collection_amountT from labcollection where (labcollection_date between '$newfromdate' and '$newtodate') $searchstr order by labcollection_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$collection_amount = $strow['collection_amountT'];
  			?>8. OutDoor Coll:<?php echo $collection_amount;?>
            
<?php
}
}
?></textarea>
         <!--9 indoor-->
        <textarea name="writesms9" id="writesms9" class="textareadetailsr"><?php
 			$s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
 		    $sqlst = "select *, sum(hospitalinvoice_receiveamount) as hospitalinvoice_receiveamountT from hospitalinvoice where (hospitalinvoice_deliverydate between '$newfromdate' and '$newtodate') $searchstr order by hospitalinvoice_deliverydate asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$hospitalinvoice_receiveamount = $strow['hospitalinvoice_receiveamountT'];
  			?>9. Indoor Cash:<?php echo $hospitalinvoice_receiveamount;?>
            
<?php
}
}
?></textarea>
         <!--10. indoor coll-->
        <textarea name="writesms10" id="writesms10" class="textareadetailsr"><?php
 			$s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
 		    $sqlst = "select *, sum(hospitalinvoicecollection_amount) as hospitalinvoicecollection_amountT from hospitalinvoicecollection where (hospitalinvoicecollection_date between '$newfromdate' and '$newtodate') $searchstr order by hospitalinvoicecollection_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$hospitalinvoicecollection_amount = $strow['hospitalinvoicecollection_amountT'];
  			?>10. Indoor Coll:<?php echo $hospitalinvoicecollection_amount;?>
            
<?php
}
}
?></textarea>
         <!--11 icu cash-->
        <textarea name="writesms14" id="writesms14" class="textareadetailsr"><?php
 			$s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
 		    $sqlst = "select *, sum(hospitalinvoiceicu_receiveamount) as hospitalinvoiceicu_receiveamountT from hospitalinvoiceicu where (hospitalinvoiceicu_deliverydate between '$newfromdate' and '$newtodate') $searchstr order by hospitalinvoiceicu_deliverydate asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$hospitalinvoiceicu_receiveamount = $strow['hospitalinvoiceicu_receiveamountT'];
  			?>11. ICU Cash:<?php echo $hospitalinvoiceicu_receiveamount;?>
            
<?php
}
}
?></textarea>
         <!--12. icu coll-->
        <textarea name="writesms15" id="writesms15" class="textareadetailsr"><?php
 			$s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
 		    $sqlst = "select *, sum(hospitalinvoiceicucollection_amount) as hospitalinvoiceicucollection_amountT from hospitalinvoiceicucollection where (hospitalinvoiceicucollection_date between '$newfromdate' and '$newtodate') $searchstr order by hospitalinvoiceicucollection_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$hospitalinvoiceicucollection_amount = $strow['hospitalinvoiceicucollection_amountT'];
  			?>12. icu Coll:<?php echo $hospitalinvoiceicucollection_amount;?>
            
<?php
}
}
?></textarea>
 <!--13. Total-->
        <textarea name="writesms11" id="writesms11" class="textareadetailsr">13. Total:<?php echo $labinvoice_receiveamountAD+$advanced+$emergencyinvoice_receiveamount+$labinvoice_receiveamount+$collection_amount+$hospitalinvoice_receiveamount+$hospitalinvoicecollection_amount+$hospitalinvoiceicu_receiveamount+$hospitalinvoiceicucollection_amount; ?>
        
</textarea>

         <br>
        <!--14. Expense-->
          <textarea name="writesms12" id="writesms12" class="textareadetailsr"><?php
 			$s='';
         	$newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate));
            $newtodate = date('Y-m-d 23:59:59', strtotime($todate));
 		    $sqlst = "select *, sum(expense_amount) as expense_amountT from expense where (expense_date between '$newfromdate' and '$newtodate') $searchstr order by expense_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
 				$expense_amount = $strow['expense_amountT'];
  			?>14. Expense:<?php echo $expense_amount;?>
            
<?php
}
}
?></textarea>
         <!--15. Cash in Hand-->
        <textarea name="writesms13" id="writesms13" class="textareadetailsr">15. Cash in Hand:<?php echo $labinvoice_receiveamountAD+$advanced+$emergencyinvoice_receiveamount+$labinvoice_receiveamount+$collection_amount+$hospitalinvoice_receiveamount+$hospitalinvoicecollection_amount+$hospitalinvoiceicu_receiveamount+$hospitalinvoiceicucollection_amount-$expense_amount;?>
		</textarea>
        </td>
     </tr>
    
   
    <tr>
    	<td align="right"></td>
        <td>
         <input type="hidden" name="smsid" id="smsid" value="<?php echo $smsid;?>">
         <input type="submit" value="Send SMS" name="submit_invoice" id="submit_invoice" class="tdclass" />
        </td>
    </tr>
</table>
</form>
</article>