<?php
$patientdata = '';
$sqlbankaccounts = "select * from bankaccounts order by bankaccounts_id asc";
$bankaccountsquery = mysqli_query($conn, $sqlbankaccounts);
if($bankaccountsquery && mysqli_num_rows($bankaccountsquery)>0){

	while ($bankaccountsrow = mysqli_fetch_array($bankaccountsquery)){
		$bankaccounts_id = $bankaccountsrow['bankaccounts_id'];
		$section = $bankaccountsrow['section'];
		$bankaccounts_name = $bankaccountsrow['bankaccounts_name'];
		$current_balance = $bankaccountsrow['current_balance'];
		$bankaccounts_number = $bankaccountsrow['bankaccounts_number'];
		$bankaccounts_address = $bankaccountsrow['bankaccounts_address'];
		$patientdata[] =array( 'labelval' => $bankaccounts_name,
							'label' => $bankaccounts_name.' ' .$bankaccounts_number,
							'bankaccounts_id'=>$bankaccounts_id,
							'section'=>$section,
							'current_balance'=>$current_balance,
							'bankaccounts_number'=>$bankaccounts_number,
							'bankaccounts_address'=>$bankaccounts_address
							);
		}
	}
$patientdata = json_encode($patientdata);

?>

<link rel="stylesheet" href="autocomplete/jquery-ui.css">
<script src="autocomplete/jquery-ui.min.js"></script>

<script language="JavaScript" type="text/javascript">
/*function disableEnterKey(e)
{
		var evt = e || window.event; 
			var key = evt.keyCode;
			//alert (key);
			if(key == 13) // if enter key press
			{
				//alert ("Enter Key Press");
				return false;
			}

}*/
</script>	
<style type="text/css">
.ui-autocomplete { height:auto !important; max-height:300px; overflow:auto; background:#FFF; border:1px solid #CCC;	width:200px;}
.search_row{text-align:left;}
.ui-autocomplete li{ min-height:30px; border-bottom:1px dotted #CCC; padding:10px; text-align:left;}
</style>

<?php include("calculate_bank.php");?>

<article class="bottomcontent">
    <h3><a href="#" title="Key Facts">Bank Deposit </a></h3>
   <content>
   
        <?php
        if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
            echo "<p class=\"red12bold\">You have missing Something</p>";
        }
        elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
            echo "<p class=\"red12bold\">Error occured! Could not insert.</p>";   
        }
        elseif(isset($_GET['message']) && $_GET['message']=='save-successfully'){
            echo "<p class=\"red12bold\">Information insert successfully. Click Print Button To Print or View Previous Bill <td width=\"30\" align=\"center\" >
			<a onclick=\"PrintDiv();\"><input type=\"button\" required value=\"Print\" class=\"tdclass\"  /></a></td></p>";   
        }
       ?>          
	<form action="save_bankinvoice.php" name="frmcontact" onsubmit="return checkcontactform();" onKeyDown="return disableEnterKey(event)" method="post" enctype="multipart/form-data">
                          
     <table width="650" border="0" bgcolor="#89C5C5" cellpadding="1">
        <tr>
            <input type="hidden" readonly name="bankaccounts_id" id="bankaccounts_id"  class="tdclass2"  />
            <input type="hidden" name="user" id="user" required value="<?php echo $_SESSION['fullname'];?>" class="tdclass"  />
            <td align="right"  bgcolor="#0066FF">Bank Name</td>
            <td><input type="text" name="bankinvoice_name" id="bankinvoice_name" required class="tdclass"  />
            
            <td align="right">Account No.</td>
            <td><input type="text" name="bankinvoice_number" id="bankinvoice_number"  class="tdclass"  /></td>
        </tr>
        <td></td>
        <tr>
            <td align="right">Branch</td>
            <td> <textarea type="text" name="bankinvoice_address" id="bankinvoice_address"  class="tdclass"  /></textarea></td>
            
            <td align="right">Date</td>
            <td><input type="text" name="bankinvoice_date" id="bankinvoice_date" value="<?php echo date('Y-m-d H:i:s');?>" class="tdclass2"  /></td>
        </tr>
    </table>

	<table  border="0" width="650" bgcolor="#e3e7ff" cellpadding="2">
    <tr>
     <td>Note :<textarea style="width:380px" name="note" id="note"></textarea></td>
     <td>Section :<input type="text" size="15" name="section" id="section"/></td>
    </tr>
    </table>
  
	
  <table  border="0" width="650" bgcolor="#e3e7ff" cellpadding="2">
    <tr><td></td></tr>
    <tr>
     	<td align="right" style="border-top:1px solid #999;">Current Balance :</td>
    	<td width="50" style="border-top:1px solid #999;"> 
        <input  type="text" readonly name="current_balance" id="current_balance" class="tdclass"  onKeyUp="calculate_total();" /></td>
    </tr>
    
     <tr>
         <td align="right"><strong>Deposit Amount</strong>:</td>
         <td> <input type="text"  name="deposite_amount" id="deposite_amount" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
  	</tr>
    
      <tr>
         <td align="right">Balance After Deposit:</td>
         <td> <input type="text" readonly name="total_balance" id="total_balance"  class="tdclass numeric" onKeyUp="calculate_total();" /></td>
  	 </tr>
    
    <tr>
     <td align="right">
        <input type="reset" name="bank" id="bank" value="Cancel" class="tdclass1"/>
     </td>
     <td>
         <input type="hidden" name="bankinvoice_id" id="bankinvoice_id" value="<?php echo $bankinvoice_id;?>">
         <input type="submit"  value=" save " name="submit_invoice" id="submit_invoice" class="tdclass1"  onClick="return funcSaveBill1()" />
     </td>
  	</tr>
</table>
</form>         
          
</content>
</article>

<div id="divToPrint" style="display:none;">
	<article class="bottomcontent" style="margin-left:<?php echo $printdata_name; ?>">
  		 <?php
		    $bankinvoice_id = $_GET['bankinvoice_id'];
            $sqlbankitem = "select * from bankinvoice where bankinvoice_id = $bankinvoice_id";
            $bankitemquery = mysqli_query($conn, $sqlbankitem);
            if($bankitemquery){
                while($bankitemrow = mysqli_fetch_array($bankitemquery)){
                    $bankinvoice_id = $bankitemrow['bankinvoice_id'];
                    $bankinvoice_name = $bankitemrow['bankinvoice_name'];
                    $bankinvoice_number = $bankitemrow['bankinvoice_number'];
                    $bankinvoice_address = $bankitemrow['bankinvoice_address'];
					$deposite_amount = $bankitemrow['deposite_amount'];
					$user = $bankitemrow['user'];
					$bankinvoice_date = $bankitemrow['bankinvoice_date'];
                ?>

              <table align="center" width="<?php echo $printdata_mobile; ?>"  style=" padding:0 5px; font-size:12px; "  bgcolor="#FFF" cellpadding="0">
                <tr>
                <td width="300" style="border-right:1px solid #666">
                    <div align="left" style="font-size:15px;"><strong><?php echo $hospitaldata_name;?></strong></div>
                    <div align="left"> <?php echo $hospitaldata_address1;?></div>
                    <?php /*?><div align="left"> <?php echo $hospitaldata_mobile;?></div><?php */?>
                </td>
                 <td width="140">
                    <div align="right" style="font-size:12px;"><strong><?php echo 'Contact';?></strong></div>
                    <div align="right"> <?php echo $hospitaldata_mobile;?></div>
                </td>
               </tr>
            </table>
                       
            <table align="center" width="<?php echo $printdata_mobile; ?>" style="border:1px solid #999;font-size:12px; border-bottom:none; padding:2px 8px 0 8px; margin-top:13px " bgcolor="#FFF" cellpadding="0">
                <tr>
                    <td width="300">
                         <div align="left"><strong>Bank Name: <?php echo $bankinvoice_name;?></strong> </div>
                         <div align="left"><strong>A/C Number : <?php echo $bankinvoice_number;?></strong></div>
                         <div align="left">Address : <?php echo $bankinvoice_address;?></div>
                     </td>
                    <td width="150">
                        <div align="right" style="font-size:14px"><strong>Deposite Receipt</strong></div>
                        <div align="right">Receipt No : <?php echo $bankinvoice_id;?></div>
                        <div align="right">Date : <?php  echo $bankinvoice_date;?></div>
                    </td>
                 </tr>
             </table>
           
             <table align="center" width="<?php echo $printdata_mobile; ?>" bgcolor="#FFF" style="padding:0 0 40px;font-size:12px; border:1px #999 solid; border-top:none; "cellspacing="0" cellpadding="0">
                  <tr height="20">
                    <td style="border:1px solid #999;text-align:center;"><strong>Bank Name</strong></td>
                    <td style="border:1px solid #999; text-align:center;"><strong>Deposited Amount</strong></td>
                  </tr>
                 
                  <tr>
                    <td style="text-align:center;"> <?php echo $bankinvoice_name;?></td>
                    <td style="text-align:center;"> <?php echo $deposite_amount;?></td>
                  </tr>
             </table>
                <?php
				}
			}
        ?>
        <table align="center" width="450" style="font-size:12px; font-style:italic">
        	<tr><td><?php include ("convert_currency_to_words.php");
			echo 'InWord:';	echo covert_currency_to_words($deposite_amount); ?></td></tr>
        </table>
                
        <table align="center" width="<?php echo $printdata_mobile; ?>" style=" font-size:12px; padding:5px 2px" bgcolor="#FFF" cellpadding="0">
            <tr>
                <td width="200">
                    <div style="padding-bottom:10px" align="right"></div>
                    <div align="right">Authorised Sign</div>
                </td>
            </tr>
         </table>    

    <table align="center" width="<?php echo $printdata_mobile; ?>" border="0">
      <tr>
        <td width="300" style=" font-size:10px">Software by: Betasofts.com (01757827474)</td>
      </tr>
    </table>
</article>
</div>