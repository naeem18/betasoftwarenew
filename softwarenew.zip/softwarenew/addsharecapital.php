<article class="bottomcontent">
    <h3 style="background:#77F7AA; text-align:center">Add Director/Share Capital</h3>
   	<content>
        <?php
        if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
            echo "<p class=\"red12bold\">You have missing Something</p>";
        }
		 if(isset($_GET['message']) && $_GET['message']=='update-successfully'){
            echo "<p class=\"red12bold\">updated successfully</p>";
        }
       
        elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
            echo "<p class=\"red12bold\">Error occured! Could not insert.</p>";   
        }
        elseif(isset($_GET['message']) && $_GET['message']=='save-successfully'){
            echo "<p class=\"red12bold\">Information insert successfully. </p>";   
        }
        
		$initialcapital_name = '';
		$initialcapital_head = '';
		$initialcapital_amount ='';
		$initialcapital_description = '';
		$mobile='';
 		$profitsharing='';
		$nid='';
		$nominee='';
					  		
	  if(isset($_GET['initialcapital_id'])){
            require('labdd.php');
            $initialcapital_id = $_GET['initialcapital_id'];
            $sqlst = "select * from initialcapital where initialcapital_id = $initialcapital_id";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery){
                while($strow = mysqli_fetch_array($stquery)){
                    $initialcapital_id = $strow['initialcapital_id'];
                    $initialcapital_name = $strow['initialcapital_name'];
                    $initialcapital_head = $strow['initialcapital_head'];
                    $initialcapital_amount = $strow['initialcapital_amount'];
					$user = $strow['user'];
					$nid = $strow['nid'];
					$mobile = $strow['mobile'];
					$nominee = $strow['nominee'];
					$profitsharing = $strow['profitsharing'];
					$initialcapital_description = $strow['initialcapital_description'];
					$initialcapital_date = $strow['initialcapital_date'];
                }
            }
        }         
       ?>        
           
<form action="save_sharecapital.php" style="background:#FFF; padding:10px" name="frmcontact" onsubmit="return checkcontactform();" method="post" enctype="multipart/form-data">

<table width="50%" align="center" border="1" style="BORDER-COLLAPSE: collapse; color:#fff" bgcolor="#31a8b3" cellpadding="2">
 <input type="hidden" name="user" id="user" required value="<?php echo $_SESSION['fullname'];?>" class="tdclass" />
    <tr>
        <td align="right">Date</td>
        <td><input type="text" name="initialcapital_date" id="initialcapital_date" value="<?php echo date('Y-m-d');?>" class="tdclass3" /></td>
    </tr>
    
    <tr>
    <td align="right"><label>Director Category*</label></td>
     <td>
        <select required id="initialcapital_head" name="initialcapital_head" >
            <?php
            $doyouknowarray = array('Share Holder', 'Director', 'Executive Director', 'Managing Director', 'Chairman', 'Founder', 'Founder & Chairman', 'Founder Member');
            foreach($doyouknowarray as $singleoption){
                $selected = '';
                if($section=="$singleoption"){$selected = ' selected="selected"';}
                echo "<option value=\"$singleoption\"$selected>$singleoption</option>";
            }
            ?>
        </select>
    </td>
    </tr>
   
    <tr>
        <td align="right">Director/Share Holder Name</td>
        <td><input type="text" name="initialcapital_name" required id="initialcapital_name" value="<?php echo $initialcapital_name ;?>" size="30"/></td>
    </tr>
    <tr>
        <td align="right">Picture</td>
        <td><input type="file" name="picture" id="picture" size="30"/></td>
    </tr>
    <tr>
        <td align="right">Mobile</td>
        <td><input type="text" name="mobile" required id="mobile" value="<?php echo $mobile ;?>" size="30"/></td>
    </tr>
    
    <tr>
        <td align="right">NID</td>
        <td><input type="text" name="nid" required id="nid" value="<?php echo $nid ;?>" size="30"/></td>
    </tr>
     <tr>
        <td align="right">Paid Amount</td>
        <td><input name="initialcapital_amount" required id="initialcapital_amount" value="<?php echo $initialcapital_amount ;?>" size="30"/></td>
    </tr>
     <tr>
        <td align="right">Profit Sharing %</td>
        <td><input name="profitsharing" required id="profitsharing" type="number" value="<?php echo $profitsharing ;?>" size="30"/></td>
    </tr>
    <tr>
        <td align="right">Nominee</td>
        <td><textarea type="text" name="nominee" id="nominee" class="textareadetailsr" /><?php echo $nominee ;?></textarea></td>
    </tr>
    
   
    <tr>
        <td align="right">Note</td>
        <td><textarea type="text" name="initialcapital_description" id="initialcapital_description" class="textareadetailsr" /><?php echo $initialcapital_description ;?></textarea></td>
	</tr>
    <tr>
    	<td align="right"></td>
        <td>
        <input type="hidden" name="initialcapital_id" id="initialcapital_id" value="<?php echo $initialcapital_id;?>">
        <input type="submit" value=" Save" name="submit_invoice" id="submit_invoice" class="tdclass" />
         </td>
    </tr>
</table>
</form>         
</content>
</article>