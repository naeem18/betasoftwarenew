<?php
date_default_timezone_set('Asia/Dhaka');
$selectname_list = '';
$itemdata = '';
$itemdataarray = array();
$sqllabitem = "select * from emergencyitem order by labitem_id asc";
$labitemquery = mysqli_query($conn, $sqllabitem);
if($labitemquery && mysqli_num_rows($labitemquery)>0){

	while ($labitemrow = mysqli_fetch_array($labitemquery)){
		$labitem_id = $labitemrow['labitem_id'];
		$labitem_name = $labitemrow['labitem_name'];
		$labitem_group = $labitemrow['labitem_group'];
		$labitem_unit = $labitemrow['labitem_unit'];
		$labitem_refvalue = $labitemrow['labitem_refvalue'];
		$labitem_price = $labitemrow['labitem_price'];
		$labitem_reagent = $labitemrow['labitem_reagent'];
		$labitem_pccommission = $labitemrow['labitem_pccommission'];
		$labitem_drcommission = $labitemrow['labitem_drcommission'];
		$labitem_tax = $labitemrow['labitem_tax'];

		$itemdataarray[$labitem_name] = "$labitem_id||$labitem_group||$labitem_unit||$labitem_refvalue||$labitem_price||$labitem_reagent||$labitem_pccommission||$labitem_drcommission||$labitem_tax";

		$itemdata[] =array( 'labelval' => $labitem_name,
							'label' => $labitem_name,
							'labitem_id'=>$labitem_id,
							'labitem_group'=>$labitem_group,
							'labitem_unit'=>$labitem_unit,
							'labitem_refvalue'=>$labitem_refvalue,
							'labitem_price'=>$labitem_price,
							'labitem_reagent'=>$labitem_reagent,
							'labitem_pccommission'=>$labitem_pccommission,
							'labitem_drcommission'=>$labitem_drcommission,
							'labitem_tax'=>$labitem_tax
							);
	}
}
$itemdataarray = json_encode($itemdataarray);
$itemdata = json_encode($itemdata);

$patientdata = '';
//$sqlopregistration = "select * from opregistration where section='OPD/Emergency' order by opregistration_id asc";
$sqlopregistration = "select * from opregistration order by opregistration_id asc";
$opregistrationquery = mysqli_query($conn, $sqlopregistration);
if($opregistrationquery && mysqli_num_rows($opregistrationquery)>0){

	while ($opregistrationrow = mysqli_fetch_array($opregistrationquery)){
		$opregistration_id = $opregistrationrow['opregistration_id'];
		$opregistration_name = $opregistrationrow['opregistration_name'];
		$opregistration_age = $opregistrationrow['opregistration_age'];
		//$emergency_due = $opregistrationrow['emergency_due'];
		$bar = $opregistrationrow['bar'];
		$opregistration_gender = $opregistrationrow['opregistration_gender'];
		$opregistration_mobile = $opregistrationrow['opregistration_mobile'];
		$opregistration_address = $opregistrationrow['opregistration_address'];
		$patientdata[] =array( 'labelval' => $opregistration_name,
							'label' => $bar .'#'. $opregistration_name .'#'.$opregistration_id,
							'opregistration_id'=>$opregistration_id,
							'bar'=>$bar,
							'opregistration_age'=>$opregistration_age,
 							'opregistration_gender'=>$opregistration_gender,
							'opregistration_mobile'=>$opregistration_mobile,
							'opregistration_address'=>$opregistration_address
							);
			}
		}
$patientdata = json_encode($patientdata);

$pcdata = '';
$sqlpc = "select * from doctorentry where doctor_category='pc' order by doctor_name asc";
$opregistrationquery1 = mysqli_query($conn, $sqlpc);
if($opregistrationquery1 && mysqli_num_rows($opregistrationquery1)>0){

	while ($opregistrationrow = mysqli_fetch_array($opregistrationquery1)){
		$doctor_id = $opregistrationrow['doctor_id'];
		$doctor_name = $opregistrationrow['doctor_name'];
		$mpo = $opregistrationrow['mpo'];
		$pcdata[] =array( 'labelval' => $doctor_name,
							'label' => $doctor_name,
							'doctor_name'=>$doctor_name,
							'mpo'=>$mpo
							);
		}
	}
$pcdata = json_encode($pcdata);

$drdata = '';
$sqldr = "select * from doctorentry where doctor_category='doctor' order by doctor_name asc";
$opregistrationquery2 = mysqli_query($conn, $sqldr);
if($opregistrationquery2 && mysqli_num_rows($opregistrationquery2)>0){

	while ($opregistrationrow = mysqli_fetch_array($opregistrationquery2)){
		$doctor_id = $opregistrationrow['doctor_id'];
		$doctor_name = $opregistrationrow['doctor_name'];
		$drdata[] =array( 'labelval' => $doctor_name,
							'label' => $doctor_name,
							'doctor_name'=>$doctor_name
							);
		}
	}
$drdata = json_encode($drdata);
?>

<link rel="stylesheet" href="autocomplete/jquery-ui.css">
<script src="autocomplete/jquery-ui.min.js"></script>

<script language="JavaScript" type="text/javascript">
function disableEnterKey(e)
{
	var evt = e || window.event; 
		var key = evt.keyCode;
		//alert (key);
		if(key == 13) // if enter key press
		{
			//alert ("Enter Key Press");
			return false;
		}

}
</script>	

<style type="text/css">
.ui-autocomplete { height:auto !important; max-height:300px; overflow:auto; background:#FFF; border:1px solid #CCC;	width:200px;}
.search_row{text-align:left;}
.ui-autocomplete li{ min-height:30px; border-bottom:1px dotted #CCC; padding:10px; text-align:left;}
</style>

<?php include("calculate-emergency.php");?>

<article class="bottomcontent">
   <h3>Emergency Invoice Entry</h3>
    <content>
	<?php
        if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
            echo "<p class=\"red12bold\">You have missing Something</p>";
        }
        elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
            echo "<p class=\"red12bold\">Error occured! Could not insert.</p>";   
        }
        elseif(isset($_GET['message']) && $_GET['message']=='save-successfully'){
            echo "<p class=\"red12bold\">Information insert successfully. Click Print Button To Print or View Previous Bill <td width=\"30\" align=\"center\" >
            <a onclick=\"PrintDiv();\"><input type=\"button\" required value=\"Print\" class=\"tdclass\"  /></a></td></p>";   
        }
    ?>          
<form action="save_emergencyinvoice.php" name="frmcontact" onsubmit="return checkcontactform();" onKeyDown="return disableEnterKey(event)" method="post" enctype="multipart/form-data">
 <table width="100%" border="0" id="bodycolor" style="color:#fff" cellpadding="1">
  <tr>
  	<input type="hidden" name="user" id="user" required value="<?php echo $_SESSION['fullname'];?>" class="tdclass" />
    <td align="right"><strong>Patient Name</strong>* </td>
    <td><input type="text" name="emergencyinvoice_patient" id="emergencyinvoice_patient"  size="12" required />
    <td align="right"><strong>Age</strong>* </td>
    <td><input type="text" name="emergencyinvoice_age" id="emergencyinvoice_age" required size="8" /></td>
   <!-- <td align="right">Gender * </td>
    <td><input type="text"  size="8" name="emergencyinvoice_gender" id="emergencyinvoice_gender" /></td>-->
    
       <td><label><strong>Gender</strong>*</label></td>
         <td>
            <select required id="emergencyinvoice_gender" title="class" name="emergencyinvoice_gender" >
               <?php
                $doyouknowarray = array('Female', 'Male', 'Others');
                foreach($doyouknowarray as $singleoption){
                    $selected = '';
                    if($section=="$singleoption"){$selected = ' selected="selected"';}
                    echo "<option value=\"$singleoption\"$selected>$singleoption</option>";
                	}
                ?>
            </select>
        </td>
    
     <td align="right"><strong>Doctor</strong> </td>
     <td><input type="text" size="23" placeholder="Search by Dr. Name" name="emergencyinvoice_doctor" id="emergencyinvoice_doctor"/></td>
    
   <td align="right"><strong>P.C</strong> </td>
   <td><input type="text" size="12" placeholder="search by PC" name="emergencyinvoice_pc" id="emergencyinvoice_pc"/></td>
    
  </tr>
  <td></td>
  <tr>
   	<td align="right">PID/Bar </td>
    <td><input type="text"  size="12" name="emergencyinvoice_patientid" id="emergencyinvoice_patientid"  autofocus/></td>
    	<input type="hidden" size="15" name="emergencyinvoice_patientcode" id="emergencyinvoice_patientcode" />
      
    <td align="right">Mobile </td>
    <td><input type="text"  size="8" name="emergencyinvoice_mobile" id="emergencyinvoice_mobile" /></td>
  	
    <td align="right">Address</td>
	<td><textarea type="text" name="emergencyinvoice_address" id="emergencyinvoice_address" style="width:70px; height:15px" /></textarea></td>   
    
     <!--<td align="right">Date </td>-->
     <input type="hidden" name="emergencyinvoice_date" size="12" readonly id="emergencyinvoice_date" value="<?php echo date('Y-m-d H:i:s');?>" />
      
     <td align="right">R.Delivery </td>
     <td><input type="text" name="emergencyinvoice_deliverydate" id="emergencyinvoice_deliverydate" value="<?php echo date('d-m-Y');?>" size="23"/></td>
    
    <td align="right">M.P.O </td>
    <td><input type="text" size="12" name="emergencyinvoice_mpo" id="emergencyinvoice_mpo" /></td>
  </tr>
</table>
<br />
<div id="errmsg_particular_id"></div>
<ul id="particularlist" class="ullistnone">
<li>
   <table width="<?php echo $printdata_address3;?>"  style="BORDER-COLLAPSE: collapse; border:2px solid #FFF;" bgcolor="#c0d2ff" cellpadding="4">
         
          <tr>
            <td align="right">Test Name</td>
            <td><input type="text" name="emergencyinvoice_item[]"  id="emergencyinvoice_item" required class="tdclass itemname emergencyinvoice_item" autocomplete="off" />
            	 <input type="hidden" name="labitem_id[]"  id="labitem_id" class="tdclass" />
            	 <input type="hidden" name="emergencyinvoice_category[]" class="tdclass" />
                 <input type="hidden" name="emergencyinvoice_unit[]" class="tdclass" />
                 <input type="hidden" name="emergencyinvoice_refvalue[]" class="tdclass" />
        	</td>
             <!--<td align="right">Stock</td>-->
            <input type="hidden" name="emergencyinvoice_reagent[]" id="emergencyinvoice_reagent" class="tdclasssale numeric" onKeyUp="calculaterowtotal('all');" />
            
            <td align="right">Rate</td>
            <td><input type="text" required name="emergencyinvoice_rate[]" id="emergencyinvoice_rate" class="tdclasssale numeric" onKeyUp="calculaterowtotal('all');" /></td>
           
             <!--<td align="right">Qty</td>-->
			 <input type="hidden" name="emergencyinvoice_qty[]" id="emergencyinvoice_qty" class="tdclasssale numeric" onKeyUp="calculaterowtotal('all');" />
         
            <td align="right">Disc%</td>
            <td><input type="text" name="emergencyinvoice_discountp[]" id="emergencyinvoice_discountp" class="tdclasssale numeric" onKeyUp="calculate_discountp();" /></td>
           
            <td align="right">Disc</td>
            <td><input type="text" name="emergencyinvoice_disc[]" id="emergencyinvoice_disc" class="tdclasssale numeric" onKeyUp="calculaterowtotal('all');" /></td>
          
            <td align="right">P.C</td>
            <td><input type="text" name="emergencyinvoice_pccomission[]" id="emergencyinvoice_pccomission" class="tdclasssale numeric" onKeyUp="calculate_pctotal();" /></td>
            <td align="right">Dr.</td>
            <td><input type="text" name="emergencyinvoice_drcomission[]" id="emergencyinvoice_drcomission" class="tdclasssale numeric" onKeyUp="calculate_drtotal();" /></td>
           
            <td align="right">Total</td>
            <td><input type="text" readonly name="emergencyinvoice_total[]" id="emergencyinvoice_total" class="tdclasssale" /></td>
            <td><input type="button" value="Add" onClick="addnew_particularrow(true)" class="tdclasssale" /></td>
          </tr>
     </table>
    </li>
   </ul>
  <br />
  
    <table border="0" width="<?php echo $printdata_address3;?>" cellpadding="2" bgcolor="#F3F3F3">
      <input name="bar" id="bar" type="hidden" value="<?php echo date('Ymdhis')?>"/>
      <tr>
        <td align="right">Note</td>
        <td><textarea type="text" name="emergencyinvoice_description" id="emergencyinvoice_description" class="tdclass" /></textarea></td>
        <td align="right">Dues Holder</td>
        <td><textarea type="text" name="emergencyinvoice_duesholder" id="emergencyinvoice_duesholder" class="tdclass" /></textarea></td>
        <td align="right">P.C Total</td>
        <td><input type="text" size="6" name="emergencyinvoice_totalpccomission" id="emergencyinvoice_totalpccomission"  onKeyUp="calculate_total();" /></td>
        <td><input type="text" size="6" name="emergencyinvoice_totalpccomission_percent" id="emergencyinvoice_totalpccomission_percent" onKeyUp="calculate_total();" /> %</td>
        <td align="right">Dr. Total</td>
        <td><input type="text" name="emergencyinvoice_totaldrcomission" id="emergencyinvoice_totaldrcomission" class="tdclass" onKeyUp="calculate_total();" /></td>
     </tr>
    </table>
	
  <table border="0" width="<?php echo $printdata_address3;?>" bgcolor="#e3e7ff" cellpadding="2">
     <tr>
         <td align="left" rowspan="10" colspan="4">
         <table width="100%" align="right">
             <tr>
             <td align="left">Cash Given By patient:</td>
             <td><input type="text"/></td>
             </tr>
             <tr>
              <td align="left">Cash Return To Patient:</td>
             <td><input type="text" />  </td>
             </tr>
            
         </table>
         </td>
    </tr>
    
    <tr>
     <td align="right" style="border-top:1px solid #999;"><strong>Previous Due</strong>:</td>
     <td width="50" style="border-top:1px solid #999;"> 
        <input type="text" readonly name="emergencyinvoice_previousdue" id="emergencyinvoice_previousdue" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
    </tr>
    
    <tr>
     <td align="right">Sub Total:</td>
     <td><input type="text" readonly name="emergencyinvoice_subtotal" id="emergencyinvoice_subtotal" class="tdclass" required /></td>
    </tr>
    <tr>
     <td align="right">Discount %:</td>
     <td><input type="text" name="emergencyinvoice_totaldiscp" id="emergencyinvoice_totaldiscp" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
  	</tr>
     <tr>
     <td align="right">Discount (General):</td>
     <td><input type="text" name="emergencyinvoice_totaldisc" id="emergencyinvoice_totaldisc" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
    </tr>
   
    <!--<tr>
     <td align="right">Discount (BOTH):</td>
    <td> <input type="text" name="emergencyinvoice_totaldisc2" id="emergencyinvoice_totaldisc2" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
    </tr>-->
     <tr>
     <td align="right"><strong>Receivable Amount</strong>:</td>
     <td><input type="text" readonly name="emergencyinvoice_subtotalafterdisc" id="emergencyinvoice_subtotalafterdisc" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
  	</tr>
    
    <tr>
     <td align="right">Received Amount:</td>
     <td><input type="text" name="emergencyinvoice_receiveamount" id="emergencyinvoice_receiveamount" class="tdclass numeric" step="0.01" min="0" oninput="preventNegative(this)" onKeyUp="calculate_total();" /></td>
  	</tr>
    
    <tr>
    <td align="right">Dues Amount:</td>
    <td><input type="readonly" name="emergencyinvoice_due" id="emergencyinvoice_due" class="tdclass" /></td>
		<span id="error_emergencyinvoice_due" style="color:#F00;"></span>
  	</tr>
    <tr>
     <td align="right"></td>
 	 <td>
         <input type="hidden" name="emergencyinvoice_id" id="emergencyinvoice_id" value="<?php echo $emergencyinvoice_id;?>">
         <input type="submit" value=" save " name="submit_invoice" id="submit_invoice" class="tdclass1" />
     </td>
  	</tr>
   
</table>
</form>         
          
</content>
</article>

<div id="divToPrint" style="display:none;">
<script type="text/javascript" language="javascript">
		function printBarcode(barCode, company_name, product_name, pricestr){
			var URL = 'barcodePrint.php?barCode='+barCode;
			var day = new Date();
			var id = day.getTime();
			var w = 500;
			var h = 400;
			var scrl = 1;
			var winl = (screen.width - w) / 2;
			var wint = (screen.height - h) / 2;
			winprops = 'height='+h+',width='+w+',top='+wint+',left='+winl+',scrollbars='+scrl+',toolbar=0,location=0,statusbar=0,menubar=0,resizable=0';
			eval("page" + id + " = window.open(URL, '" + id + "', winprops);");
		}
	</script>
	<article class="bottomcontent" style=" margin:0 auto; margin:0 auto">
  	<?php
		$emergencyinvoice_id = $_GET['emergencyinvoice_id'];
        $emergencyinvoice_sql = "select * from emergencyinvoice where emergencyinvoice_id = $emergencyinvoice_id order by emergencyinvoice_id asc";
        $emergencyinvoicequery = mysqli_query($conn, $emergencyinvoice_sql);
        if($emergencyinvoicequery && mysqli_num_rows($emergencyinvoicequery)>0 && ($emergencyinvoice_id<40000)){
            while ($onerow = mysqli_fetch_array($emergencyinvoicequery)){
               	$emergencyinvoice_id = $onerow['emergencyinvoice_id'];
                $emergencyinvoice_patientid = $onerow['emergencyinvoice_patientid'];
                $emergencyinvoice_patient = $onerow['emergencyinvoice_patient'];
                $emergencyinvoice_age = $onerow['emergencyinvoice_age'];
                $emergencyinvoice_gender = $onerow['emergencyinvoice_gender'];
                $emergencyinvoice_address = $onerow['emergencyinvoice_address'];
                $emergencyinvoice_doctor = $onerow['emergencyinvoice_doctor'];
                $emergencyinvoice_pc = $onerow['emergencyinvoice_pc'];
				$user = $onerow['user'];		
                $bar = $onerow['bar'];		
                $emergencyinvoice_totalpccomission = $onerow['emergencyinvoice_totalpccomission'];
                $emergencyinvoice_subtotal = $onerow['emergencyinvoice_subtotal'];
                $emergencyinvoice_totaldiscp = $onerow['emergencyinvoice_totaldiscp'];
                $emergencyinvoice_totaldisc = $onerow['emergencyinvoice_totaldisc'];
                $emergencyinvoice_subtotalafterdisc = $onerow['emergencyinvoice_subtotalafterdisc'];
                $emergencyinvoice_receiveamount = $onerow['emergencyinvoice_receiveamount'];
                $emergencyinvoice_due = $onerow['emergencyinvoice_due'];
                $emergencyinvoice_description = $onerow['emergencyinvoice_description'];
				$emergencyinvoice_mobile = $onerow['emergencyinvoice_mobile'];
                $emergencyinvoice_date=	$onerow['emergencyinvoice_date'];
				 $emergencyinvoice_deliverydate=	$onerow['emergencyinvoice_deliverydate'];
                ?>
               
              <?php if($heading=='Yes'){ ?>
              <table align="center" width="100%" style="border-bottom:1px dashed #999; padding:0 5px; font-size:13px;" bgcolor="#FFF" cellpadding="0">
                <tr>
                <?php
                   if($hospitaldata_logo!=''){
				 ?>
                 <td width="65">
                    <div align="left" style="font-size:15px;">
                    <img width="60" height="60" src="logo_images/<?php echo $hospitaldata_logo; ?>" /></div>
                   </td>
                <?php }?>
                <td width="320">
                    <div align="center" style="font-size:16px;"><b><?php echo $hospitaldata_name;?></b></div>
                    <div align="center"><?php echo $hospitaldata_address1;?></div>
                    <div align="center" style="font-size:13px;">Contact: <?php echo $hospitaldata_mobile;?></div>
                </td>
               </tr>
             </table>
             <?php } ?>
                       
            <table width="100%" align="center" style=" color:#000;border-bottom:1px dashed #999;
              <?php if($heading=='Yes'){ ?> margin-top:2px;<?php }?> <?php if($heading=='No'){ ?> margin-top:155px;<?php }?>" bgcolor="#FFF" cellpadding="0">
                    <tr>
                    <td width="300">
                        <div align="left">Patient ID : <?php if($emergencyinvoice_patientid==0){ echo date('mdHY'); }?> <?php if($emergencyinvoice_patientid>0){ echo $emergencyinvoice_patientid;}?></div>
                        <div align="left"><strong>Patient : <?php echo $emergencyinvoice_patient;?></strong> </div>
                        <div align="left">Gender & Age : <?php echo $emergencyinvoice_gender;?> / <?php echo $emergencyinvoice_age;?> Years</div>
                        <div align="left">Mobile : <?php echo $emergencyinvoice_mobile;?></div>
                    </td>
                    <td width="150">
                        <div align="right" style="font-size:17px"><strong>Emergency Invoice</strong></div>
                        <div align="right">Invoice No :<strong style="font-size:16px"><?php echo $emergencyinvoice_id;?></strong></div>
                        <div align="right"><?php  echo $emergencyinvoice_date;?></div>
                       </td>
                 </tr>
                 
                 <tr>
                    <td colspan="2" align="right">
                    <div align="right">
                    <!--<img alt="barcode" width="135" height="40"
                     src="barcode/barcode.php?codetype=Code39&size=40&text=<?php //echo date('1m5s');?>&print=true" />-->
                    	<?php 
							$barCode = $bar;
							require("barcodePrint.php");
						?>
                    </div>
                    </td>
                </tr> 
                
                 </table>
                         
             <table align="center" width="100%" style=" border-bottom:1px dashed #999;font-size:12px; padding:0 8px 5px 8px;" bgcolor="#FFF" cellpadding="0">
            <tr><td width="100%"><strong>Ref. by</strong>: <?php echo $emergencyinvoice_doctor;?></td></tr>
            </table>
             <table align="center" width="100%" bgcolor="#FFF" style="padding:0 0 40px;font-size:13px; border-bottom:1px dashed #999; "cellspacing="0" cellpadding="0">
                
                  <tr height="20">
                    <td style="border:1px solid #999; text-align:center;border-top:none;"><strong>SL</strong> </td>
                    <td style="border:1px solid #999;text-align:center;border-top:none;"><strong>Test Name</strong></td>
                    <td style="border:1px solid #999; text-align:center;border-top:none;">Rate</td>
                    <!-- <td style="border:1px solid #000; text-align:center;">Qty</td>-->
                   <!-- <td style="border:1px solid #999; text-align:center;">Disc(%)</td>-->
                    <td style="border:1px solid #999; text-align:center;border-top:none;">Disc</td>
                    <td style="border:1px solid #999; text-align:center;border-top:none;"><strong>Total</strong></td>
                  </tr>
                 
                <?php
                $emergencyinvoicedetails_sql = "select * from emergencyinvoicedetails where emergencyinvoice_id = $emergencyinvoice_id order by auto_number asc";
                $emergencyinvoicedetailsquery = mysqli_query($conn, $emergencyinvoicedetails_sql);
                if($emergencyinvoicedetailsquery && mysqli_num_rows($emergencyinvoicedetailsquery)>0){
                    $i=0;
                    while($page_inforow = mysqli_fetch_array($emergencyinvoicedetailsquery)){
                        $i++;
                        $auto_number = $page_inforow['auto_number'];
                        $emergencyinvoicedetails_item = $page_inforow['emergencyinvoicedetails_item'];
                        $emergencyinvoicedetails_rate = $page_inforow['emergencyinvoicedetails_rate'];
                        $emergencyinvoicedetails_qty = $page_inforow['emergencyinvoicedetails_qty'];
                        $emergencyinvoicedetails_discountp = $page_inforow['emergencyinvoicedetails_discountp'];
                        $emergencyinvoicedetails_disc = $page_inforow['emergencyinvoicedetails_disc'];
                        $emergencyinvoicedetails_total = $page_inforow['emergencyinvoicedetails_total'];
                        ?>
                        <tr>
                            <td style="text-align:center;"><?php echo $i;?></td>
                            <td style=" text-align:left; padding-left:3px" width="250"> <?php echo $emergencyinvoicedetails_item;?></td>
                            <td style=" text-align:center;"> <?php echo $emergencyinvoicedetails_rate;?></td>
                            <?php /*?> <td style="text-align:center;">  <?php echo $emergencyinvoicedetails_discountp;?></td><?php */?>
                            <td style="text-align:center;"> <?php  echo number_format($emergencyinvoicedetails_disc);?></td>
                            <td style="text-align:center;"> <?php echo $emergencyinvoicedetails_total;?></td>
                          </tr>
                 
                        <?php
                    }
                }
                ?>
               
            </table>
                    
       <table width="100%" align="center" style="  border-bottom:1px dashed #999;font-size:13px; font-weight:bold; font-style:italic">
        <tr><td>Note: <?php echo $emergencyinvoice_description; ?></td></tr>
        </table>
                   
            <table align="center" width="100%" style=" border-bottom:1px dashed #999;font-size:13px"  bgcolor="#FFFFFF" cellpadding="1">
                    
                        <tr>
                         <td align="right" style=" width:500px">Sub Total :</td>
                         <td width="30" style="border:none" > <?php echo $emergencyinvoice_subtotal;?></td>
                        </tr>
                      
                          <?php
						  if($emergencyinvoice_totaldisc>0)
                          echo "<tr>
                         <td align=\"right\">Discount :</td>
                        <td> $emergencyinvoice_totaldisc</td>
                        </tr>";
                        ?>
                         <tr>
                         <td align="right"><strong>Net Payable Amount</strong> :</td>
                        <td> <?php echo $emergencyinvoice_subtotalafterdisc;?></td>
                        </tr>
                        
                        <tr>
                         <td align="right" style="border-top: 1px solid #fff">Total paid Amount :</td>
                        <td><?php echo $emergencyinvoice_receiveamount;?></td>
                        </tr>
                        <?php if($emergencyinvoice_due>0)
                        echo "<tr>
                         <td align=\"right\"><strong>Due Amount :</strong></td>
                         <td> $emergencyinvoice_due</td>
                        </tr>";
                        ?>
                    </table>
                    
                <?php
				}
			}
        ?>
         <table width="100%" align="center" style="font-size:12px;">
        	<tr><td><?php include ("convert_currency_to_words.php");
 			echo 'InWord:';	echo covert_currency_to_words($emergencyinvoice_receiveamount); ?></td></tr>
        </table>
       
        
        <table align="center" width="100%" style="font-size:12px; padding:5px 2px" bgcolor="#FFF" cellpadding="0">
         <tr>
            <td width="350">
                <div align="left">Prepared By:<?php echo $user; ?>  
                <?php if($emergencyinvoice_due>0){
                  echo "<strong style=\"font-size:23px; padding:0 3px; box-shadow: 0 -1px 3px; margin-left:30px; width:150px\" >Due $emergencyinvoice_due</strong>";}
                  else{
                  echo "<strong style=\"font-size:23px;box-shadow: 0 -1px 3px; margin-left:30px; width:150px\" >Paid $emergencyinvoice_receiveamount</strong>";}
                   ?>
                </div>
            </td>
            <td width="200">
                <div style="padding-bottom:10px" align="right"></div>
                <div align="right">Authorised Sign</div>
            </td>
         </tr>
             
        </table>
        
      
    <table align="center" width="100%" border="0">
      <tr><td width="350" style="font-weight:500; font-size:11px;"><strong><?php echo $labroom_name; ?></strong></td>
         </tr>
    </table>

    <table align="center" width="100%" border="0">
    <tr>
        <td style=" font-size:10px">Software by: Betasofts.com</td>
      </tr></table>
   
</article>
</div>