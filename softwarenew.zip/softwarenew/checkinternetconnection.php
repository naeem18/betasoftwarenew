<?php
echo "Checking Net Connection: ";
$check = @fsockopen("www.google.com", 80); 
if ($check) {
    echo "Internet is working slow!";
    fclose($check);
} else {
    echo " No Internet Connection. Check your network!";
}
?>
