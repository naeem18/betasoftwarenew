<script language="JavaScript" type="text/javascript">
	
	var itemdataarray = '<?php echo $itemdataarray;?>';
	var itemdata = <?php echo $itemdata;?>;
	var patientdata = <?php echo $patientdata;?>;
	var itemarraydata = jQuery.parseJSON(itemdataarray);
	
	$(document).ready(function($) {
		document.getElementsByName("expiryplus_item[]")[0].focus();

		$( ".itemname" ).autocomplete({
			
			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.saleselval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				document.getElementsByName("salesitem_id[]")[indexpos].value = ui.item.salesitem_id;
				document.getElementsByName("expiryplus_purchase_rate[]")[indexpos].value = ui.item.salesitem_purchase_rate;
				document.getElementsByName("expiryplus_rate[]")[indexpos].value = ui.item.salesitem_price;				
				document.getElementsByName("salesitem_pack[]")[indexpos].value =ui.item.salesitem_pack;
				document.getElementsByName("expiryplus_qty[]")[indexpos].value = 1;					
				document.getElementsByName("expiryplus_category[]")[indexpos].value = ui.item.salesitem_category;
				document.getElementsByName("expiryplus_stock[]")[indexpos].value = ui.item.salesitem_stock;
				document.getElementsByName("expire[]")[indexpos].value = ui.item.expire;
				
				calculateCurrentRowTotal(indexpos);
				
				return false;
			}
		});
		
		
		$( "#expiryplus_patient" ).autocomplete({
			
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.saleselval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 	document.getElementById('expiryplus_patientid').value = ui.item.labelval;
				 	document.getElementById('expiryplus_patientcode').value = ui.item.company_code;
					//document.getElementById('expiryplus_previousdue').value = ui.item.company_due;
					document.getElementById('expiryplus_mobile').value = ui.item.company_mobile;
				 	document.getElementById('expiryplus_address').value = ui.item.company_address;
				
				return false;
			}
		});
		
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
		$( ".expiryplus_item" ).keypress(function(keyname) {
			if(keyname.which==13){
				var imei = $(this).val();
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				$.each(itemarraydata, function(key, value){
					var valuearray = value.split('||');
					if(key==imei){
						document.getElementsByName("salesitem_id[]")[indexpos].value = valuearray[0];
						//document.getElementsByName("expiryplus_item[]")[indexpos].value = valuearray[1];
						document.getElementsByName("expiryplus_category[]")[indexpos].value = valuearray[1];
						document.getElementsByName("expiryplus_stock[]")[indexpos].value = valuearray[2];
						document.getElementsByName("expiryplus_purchase_rate[]")[indexpos].value = valuearray[3];
						document.getElementsByName("expiryplus_rate[]")[indexpos].value = valuearray[4];
						document.getElementsByName("expiryplus_qty[]")[indexpos].value = 1;
						calculateCurrentRowTotal(indexpos);
						
						addnew_particularrow(true);
					}
				});
				return false;
			}
		});
		
		
		$( ".sirow input.ccrt" ).keyup(function() {
			var index = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
			calculateCurrentRowTotal(index);
		});
		
		
	});
	
	function calculateCurrentRowTotal(indexpos){
		//purchase 
		
		var expiryplus_purchase_rate = parseFloat(document.getElementsByName("expiryplus_purchase_rate[]")[indexpos].value);
		if(expiryplus_purchase_rate=='' || isNaN(expiryplus_purchase_rate)){expiryplus_purchase_rate = 0.00;}
		
		var expiryplus_rate = parseFloat(document.getElementsByName("expiryplus_rate[]")[indexpos].value);
		if(expiryplus_rate=='' || isNaN(expiryplus_rate)){expiryplus_rate = 0.00;}
		
		var salesitem_pack = parseFloat(document.getElementsByName("salesitem_pack[]")[indexpos].value);
		if(salesitem_pack=='' || isNaN(salesitem_pack)){salesitem_pack = 0.00;}
		
		var expiryplus_pqty = parseFloat(document.getElementsByName("expiryplus_pqty[]")[indexpos].value);
		if(expiryplus_pqty=='' || isNaN(expiryplus_pqty)){expiryplus_pqty = 0.00;}
		
		if(salesitem_pack==0 || expiryplus_pqty==0){
			var expiryplus_qty = parseFloat(document.getElementsByName("expiryplus_qty[]")[indexpos].value);
			if(expiryplus_qty=='' || isNaN(expiryplus_qty)){expiryplus_qty = 0.00;}
		}
		else{
			var expiryplus_qty = parseFloat(salesitem_pack*expiryplus_pqty);
			if(expiryplus_qty=='' || isNaN(expiryplus_qty)){expiryplus_qty = 0.00;}
			document.getElementsByName("expiryplus_qty[]")[indexpos].value = expiryplus_qty.toFixed(2);
		}
		
		var qtyPrice = parseFloat(expiryplus_rate*expiryplus_qty);
		// purchase calculate
		var qtypurchasePrice = parseFloat(expiryplus_purchase_rate*expiryplus_qty);
		
		var expiryplus_discountp = parseFloat(document.getElementsByName("expiryplus_discountp[]")[indexpos].value);
		if(expiryplus_discountp=='' || isNaN(expiryplus_discountp)){expiryplus_discountp = 0.00;}
		if(expiryplus_discountp==0){
			var expiryplus_disc = parseFloat(document.getElementsByName("expiryplus_disc[]")[indexpos].value);
			if(expiryplus_disc=='' || isNaN(expiryplus_disc)){expiryplus_disc = 0.00;}
		}
		else{
			var expiryplus_disc = parseFloat(qtyPrice*expiryplus_discountp*0.01);	
			document.getElementsByName("expiryplus_disc[]")[indexpos].value = expiryplus_disc.toFixed(2);
		}
		
		document.getElementsByName("expiryplus_total[]")[indexpos].value = parseFloat(qtyPrice-expiryplus_disc).toFixed(2);
		//purchase
		document.getElementsByName("purchaseinvoice_total[]")[indexpos].value = parseFloat(qtypurchasePrice).toFixed(2);
		
		
		calculateGrandTotal();
	}
	
	function calculateGrandTotal(){
		var expiryplus_totalarray = document.getElementsByName("expiryplus_total[]");
		var expiryplus_subtotal = 0.00;
		for(var r=0; r<expiryplus_totalarray.length; r++){
			var expiryplus_total = parseFloat(expiryplus_totalarray[r].value);
			if(expiryplus_total=='' || isNaN(expiryplus_total)){expiryplus_total = 0.00;}
			expiryplus_subtotal = parseFloat(expiryplus_subtotal+expiryplus_total);
		}
		document.getElementById("expiryplus_subtotal").value = expiryplus_subtotal.toFixed(2);
		
		
		var purchaseinvoice_totalarray = document.getElementsByName("purchaseinvoice_total[]");
		var expiryplus_purchasesubtotal = 0.00;
		for(var m=0; m<purchaseinvoice_totalarray.length; m++){
			var purchaseinvoice_total = parseFloat(purchaseinvoice_totalarray[m].value);
			if(purchaseinvoice_total=='' || isNaN(purchaseinvoice_total)){purchaseinvoice_total = 0.00;}
			expiryplus_purchasesubtotal = parseFloat(expiryplus_purchasesubtotal+purchaseinvoice_total);
		}
		document.getElementById("expiryplus_purchasesubtotal").value = expiryplus_purchasesubtotal.toFixed(2);
		
		
		// when sale price above 100 tk  then less 5% ....for general it should be off.
			var expiryplus_totaldisc = parseFloat(expiryplus_totaldisc);
			if(expiryplus_totaldisc=='' || isNaN(expiryplus_totaldisc)){expiryplus_totaldisc = 0;}
			
			if(expiryplus_subtotal>=100){
				var expiryplus_totaldisc = parseFloat(expiryplus_subtotal*5*0.01);
				//document.getElementById('expiryplus_totaldisc').value= expiryplus_totaldisc.toFixed(2);
			}
			document.getElementById('expiryplus_totaldisc').value= expiryplus_totaldisc.toFixed(2);
		// when sale price above 100 tk  then less 5%
		
		
		// prevoius due
		var expiryplus_previousdue = parseFloat(document.getElementById("expiryplus_previousdue").value);
		if(expiryplus_previousdue=='' || isNaN(expiryplus_previousdue)){expiryplus_previousdue = 0;}
		
		
		var expiryplus_subtotalafterdisc = parseFloat(expiryplus_subtotal-expiryplus_totaldisc);
		document.getElementById('expiryplus_subtotalafterdisc').value= expiryplus_subtotalafterdisc.toFixed(2);
			
		
			// for all 
		//var expiryplus_receiveamount = parseFloat(document.getElementById("expiryplus_receiveamount").value);
		//if(expiryplus_receiveamount=='' || isNaN(expiryplus_receiveamount)){expiryplus_receiveamount = 0;}
		
		// for Feni Diabetes temprary 
		var expiryplus_receiveamount = parseFloat( expiryplus_subtotalafterdisc);
		document.getElementById('expiryplus_receiveamount').value=expiryplus_receiveamount.toFixed(2);		
		
		
		var expiryplus_due = parseFloat( expiryplus_subtotalafterdisc-expiryplus_receiveamount);
		document.getElementById('expiryplus_due').value=expiryplus_due.toFixed(2);		
		
		
		var cashreceive = parseFloat(document.getElementById("cashreceive").value);
		if(cashreceive=='' || isNaN(cashreceive)){cashreceive = 0;}
		var cashreturn = parseFloat(cashreceive-expiryplus_receiveamount);
		document.getElementById('cashreturn').value=cashreturn.toFixed(2);		
			
	}
	
	function check_blankrow(){
		
		
		return true;
	}

	function addnew_particularrow(animate) {
		if(check_blankrow()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" align=\"center\" bgcolor=\"#ccc\" width=\"800\" cellpadding=\"1\">"+
							'<tbody><tr></tr><tr>'+
								'<td align="center" width=\"130\"> <input type="text" required name="expiryplus_item[]" class="tdclass itemname expiryplus_item"/>'+
								'<input type="hidden" name="salesitem_id[]" id="salesitem_id" class="tdclass itemname"/>'+
								'<input type="hidden" name="expiryplus_category[]"  class="tdclass"  /></td>'+
								"<td align=\"center\" width=\"70\"><input type=\"text\" value=\"1\" name=\"expiryplus_qty[]\" class=\"tdclasssale numeric ccrt\"/></td>"+
								'<td align="center" width=\"70\"> <input type="text" name="expiryplus_stock[]" value=\"\" class="tdclasssale itemname"/></td>'+
								"<td align=\"center\" width=\"70\"><input type=\"text\" readonly name=\"expiryplus_purchase_rate[]\" class=\"tdclasssale\"/></td>"+											 
								"<td align=\"center\" width=\"70\"><input type=\"text\" required name=\"expiryplus_rate[]\" value=\"\" class=\"tdclasssale numeric ccrt\"/></td>"+											 
								"<td align=\"center\" width=\"70\"><input type=\"text\" title=\"class\" name=\"salesitem_pack[]\" class=\"tdclasssale numeric ccrt\" ></td>"+
								"<td align=\"center\" width=\"70\"><input type=\"text\" name=\"expiryplus_pqty[]\" value=\"\" class=\"tdclasssale numeric ccrt\" /></td>"+
								
								'<input type="hidden" name="expiryplus_discountp[]" class="tdclasssale numeric ccrt"/>'+
								"<input type=\"hidden\" name=\"expiryplus_disc[]\"  class=\"tdclasssale numeric  ccrt\" />"+
								'<td align="center" width=\"70\"><input type="text" readonly name="expiryplus_total[]" class="tdclasssale numeric ccrt"  /></td>'+	
								'<td align="center" width=\"90\"><input type="text" readonly name="expire[]" size="8" class="ccrt"  /></td>'+												
								'<input type="hidden" required readonly name="purchaseinvoice_total[]" class="tdclasssale numeric ccrt"  />'+												
								'<td>'+
								 "<input type=\"button\" value=\"Del\" class=\"tdclasssales deletethislistrow\"  />"+
								'</td>'+
							  '</tr></tbody>'+
						"</table>";
						
			var $newparticularlist = $("<li class=\"sirow\"></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(300); 
			else 
			   $newparticularlist.show();   
			document.getElementsByName("expiryplus_item[]")[parseInt(particular_rowcount-1)].focus();
			
			$( ".itemname" ).autocomplete({			
				minLength: 1,
				source: itemdata,
				focus: function( event, ui ) {
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					document.getElementsByName("salesitem_id[]")[indexpos].value = ui.item.salesitem_id;
					document.getElementsByName("expiryplus_purchase_rate[]")[indexpos].value = ui.item.salesitem_purchase_rate;
					document.getElementsByName("expiryplus_rate[]")[indexpos].value = ui.item.salesitem_price;				
					document.getElementsByName("salesitem_pack[]")[indexpos].value =ui.item.salesitem_pack;
					document.getElementsByName("expiryplus_qty[]")[indexpos].value = 1;					
					document.getElementsByName("expiryplus_category[]")[indexpos].value = ui.item.salesitem_category;
					document.getElementsByName("expiryplus_stock[]")[indexpos].value = ui.item.salesitem_stock;
					
					calculateCurrentRowTotal(indexpos);
					
					return false;
				}
			});						
		
			$( ".sirow input.ccrt" ).keyup(function() {
				var index = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				calculateCurrentRowTotal(index);
			});
			
			$( ".sirow input.deletethislistrow" ).click(function() {
				$(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').slideUp(200, function() {
					$(this).remove();
					calculateGrandTotal();
				});
			});
			
			$( ".numeric" ).keyup(function() {
				var price = $(this).val();
				var ValidChars = "-.0123456789";
				var IsNumber=true;
				var Char;
				var validint = '';
				for (var i = 0; i < price.length && IsNumber == true; i++){ 
					Char = price.charAt(i);
					if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
					else{
						validint = validint+Char;
					}
				}
				$(this).val(validint);
			});
			
			$( ".expiryplus_item" ).keypress(function(keyname) {
				if(keyname.which==13){
					var imei = $(this).val();
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					
					$.each(itemarraydata, function(key, value){
						var valuearray = value.split('||');
						if(key==imei){
							document.getElementsByName("salesitem_id[]")[indexpos].value = valuearray[0];
							//document.getElementsByName("expiryplus_item[]")[indexpos].value = valuearray[1];
							document.getElementsByName("expiryplus_category[]")[indexpos].value = valuearray[1];
							document.getElementsByName("expiryplus_stock[]")[indexpos].value = valuearray[2];
							document.getElementsByName("expiryplus_purchase_rate[]")[indexpos].value = valuearray[3];
							document.getElementsByName("expiryplus_rate[]")[indexpos].value = valuearray[4];
							document.getElementsByName("expiryplus_qty[]")[indexpos].value = 1;
							
							calculateCurrentRowTotal(indexpos);
							addnew_particularrow(true);
						}
					});
					return false;
				}
			});
			
		}
	}
	
	/*function deletethislistrow(tableidname){
		$("#"+tableidname).parent("li").slideUp(200, function() {
			$(this).remove();
			calculateCurrentRowTotal('all');
		});
	}*/
</script>