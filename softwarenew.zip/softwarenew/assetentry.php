<article class="bottomcontent">
<header class="header_tittle">
    <h3 style="background:#77F7AA; text-align:center">Asset Entry</h3>
</header>
   <content>
     
        <?php
        if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
            echo "<p class=\"red12bold\">You have missing Something</p>";
        }
		 if(isset($_GET['message']) && $_GET['message']=='update-successfully'){
            echo "<p class=\"red12bold\">updated successfully</p>";
        }
       
        elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
            echo "<p class=\"red12bold\">Error occured! Could not insert.</p>";   
        }
        elseif(isset($_GET['message']) && $_GET['message']=='save-successfully'){
            echo "<p class=\"red12bold\">Information insert successfully. </p>";   
        }
           		
      ?>  
         		 <?php  
		  			$assetentry_id = 0;
                    $expense_mobile = '';
                    $assetentry_name = '';
                    $assetentry_amount = '';
                    $assetentry_description = '';
                    
        ?>        
           
<form action="save_assetentry.php" style="background:#FFF; padding:10px" name="frmcontact" onsubmit="return checkcontactform();" method="post" enctype="multipart/form-data">

<table width="50%" align="center" border="1" style="BORDER-COLLAPSE: collapse;" bgcolor="#D6FEE1" cellpadding="2">
 <input type="hidden" name="user" id="user" required value="<?php echo $_SESSION['fullname'];?>" class="tdclass"  />
 
        <tr>
            <td align="right">Date:&emsp;</td>
            <td><input type="text" name="assetentry_date" id="assetentry_date" value="<?php echo date('Y-m-d');?>" class="tdclass3"  /></td>
        </tr>
    
    <tr>
        <td align="right"><label>Asset Category</label></td>
         <td>
            <select required id="assetentry_head" title="class" name="assetentry_head" >
                <?php
                $doyouknowarray = array('Fixed', 'Current');
                foreach($doyouknowarray as $singleoption){
                    $selected = '';
                    if($section=="$singleoption"){$selected = ' selected="selected"';}
                    echo "<option value=\"$singleoption\"$selected>$singleoption</option>";
                }
                ?>
            </select>
        </td>
    </tr>
   
    <tr>
        <td align="right">Asset Name&emsp;</td>
        <td> <textarea name="assetentry_name" required  id="assetentry_name" value="" class="textareadetailsr"><?php //echo $assetentry_name ;?></textarea></td>
    </tr>
    <tr>
        <td align="right">Asset Price&emsp;</td>
        <td> <input name="assetentry_amount" required id="assetentry_amount" required value="<?php //echo $assetentry_amount ;?>" class="tdclass3" /></td>
    </tr>
    <tr>
        <td align="right">Note&emsp;</td>
        <td><textarea type="text" name="assetentry_description" id="assetentry_description" class="textareadetailsr" /><?php //echo $assetentry_description ;?></textarea></td>
	</tr>
    <tr>
    	<td align="right">&emsp;</td>
        <td>
        <input type="hidden" name="assetentry_id" id="assetentry_id" value="<?php echo $assetentry_id;?>">
        <input type="submit" value=" Save Asset" name="submit_invoice" id="submit_invoice" class="tdclass" />
        &emsp;
        <input type="button" name="assetentry" id="assetentry" value="Cancel" class="tdclass"/>
        </td>
    </tr>
</table>
</form>         

</content>
</article>