<article class="bottomcontent">
  <h3>Add New Category</h3>
    <content>
     <?php
        if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
        echo "<h2 class=\"red12bold\">You have missing Something</h2>";
        }
        elseif(isset($_GET['message']) && $_GET['message']=='duplicatecategory'){
        echo "<h2 class=\"red12bold\">This Item  already exists. Please try with different item .</h2>";   
        }
        elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
        echo "<h2 class=\"red12bold\">Error occured! Could not insert.</h2>";   
        }
        elseif(isset($_GET['message']) && $_GET['message']=='insert-successfully'){
        echo "<h4 style=\"color:#f00\">Item insert successfully</h4>";   
        }
        $auto_number = 0;
        $section = '';
        $category = '';
        $date = '';
        $sample='';
        $method='';
        $charge='';
        $orderby='';
    
    if(isset($_GET['auto_number'])){
        $auto_number = $_GET['auto_number'];
        $sqlcategory = "select * from category where auto_number = $auto_number";
        $categoryquery = mysqli_query($conn, $sqlcategory);
        if($categoryquery){
            while($categoryrow = mysqli_fetch_array($categoryquery)){
                $auto_number = $categoryrow['auto_number'];
                $section = $categoryrow['section'];
                $category = $categoryrow['category'];
                $date = $categoryrow['date'];
                $orderby = $categoryrow['orderby'];
                $sample = $categoryrow['sample'];
                $method = $categoryrow['method'];
                $charge = $categoryrow['charge'];
            }
        }
    }
?>        
<form action="save_category.php" category="frmcontact" onsubmit="return checkcontactform();" method="post" enctype="multipart/form-data">
     <table width="100%" border="0" cellspacing="0" bgcolor="f2f2f2" cellpadding="2">
         <tr>
            <td width="220">Select Section</td>
             <td>
                <select required id="section" name="section" >
                    <option value="<?php echo $section?>"><?php echo $section?></option>
                    <?php
                    $doyouknowarray = array('Emergency', 'Lab Item Section', 'Lab Item Group', 'Report Name', 
					'Hospital', 'Ward(room)', 'income head', 'Medicine Group', 'Scissor', 'Bank', 'Complain', 
					'Diagnosis', 'Medicine Eating Rules', 'Store Item Category');
                    foreach($doyouknowarray as $singleoption){
                        $selected = '';
                        if($section=="$singleoption"){$selected = ' selected="selected"';}
                        echo "<option value=\"$singleoption\"$selected>$singleoption</option>";
                    }
                    ?>
                </select>
            </td>
        </tr>
        
        <tr>
            <td>Name*</td>
            <td><input type="text" required name="category" id="category" value="<?php echo $category;?>" class="textfieldcssmem" /></td>
            
            <td>Sample</td>
            <td><input type="hidden" name="sample" id="sample" class="textfieldcssmem" value="<?php echo $sample;?>"/></td>
            
            <td>Method/Description/Subtitle</td>
            <td><input type="hidden" name="method" id="method" class="textfieldcssmem" value="<?php echo $method;?>"/>
            </td>
        </tr>
         
         <tr>
            <td>Charge(For Ward)</td>
            <td><input type="text" name="charge" id="charge" value="<?php echo $charge;?>" class="textfieldcssmem" />
            </td>
        </tr>
         <tr>
            <td width="220">Order</td>
            <td><input type="text" name="orderby" id="orderby" value="<?php echo $orderby;?>" class="textfieldcssmem" />
            </td>
        </tr>
         <tr>
            <td>Date</td>
            <td><input type="text" name="date" id="date" value="<?php echo date('Y-m-d');?>" class="textfieldcssmem" /></td>
        </tr>
        
        <tr>
            <td>PC Comission</td>
            <td><input type="text" name="labitem_pccommission" id="labitem_pccommission" class="textfieldcssmem" />%</td>
        </tr>
        
        <tr>
            <td>Item Discount</td>
            <td><input type="text" name="labitem_disc" id="labitem_disc" class="textfieldcssmem" />%</td>
        </tr>
        
        <tr>
            <td></td>
            <td>
                <input type="hidden" name="auto_number" id="auto_number" value="<?php echo $auto_number;?>">
                <input type="submit" value=" Save " name="submit_category" id="submit_category" class="submitbuttoncss" /></td>
            <td></td>
        </tr>
  </table>
</form>
<td><strong style="color:#f00">Store Item Category</strong></td>
<table style="BORDER-COLLAPSE: collapse" width="100%" border="1">
  <tr>
   <td width="10%">SL No.</td>
    <td width="10%">Section </td>
    <td width="10%">Category/Head</td>
    <td width="10%">Date</td>
    <td width="10%">Edit/Delete</td>
  </tr>
  <?php
   $i='';
	$sqlcategory = "select * from category where section='Store Item Category' order by auto_number asc";
	  	$categoryquery = mysqli_query($conn, $sqlcategory);
			if($categoryquery && mysqli_num_rows($categoryquery)>0){
				while ($categoryrow = mysqli_fetch_array($categoryquery))
			 {
				$auto_number = $categoryrow['auto_number'];
				$section = $categoryrow['section'];
				$category = $categoryrow['category'];
				$date = $categoryrow['date'];
				
				$action = "<a href=\"index.php?p=category&auto_number=$auto_number\">Edit</a> | 
				<a href=\"javascript:voauto_number(0)\" onclick=\"removetablerow('category', $auto_number, 'category')\">Remove</a>";
			
			?>
              <tr bgcolor="#FFFFFF">
                <td><?php echo $i=$i+1;?></td>
                <td><?php echo $section;?></td>
                <td><?php echo $category;?></td>
                <td><?php echo $date;?></td>
                <td><?php echo $action;?></td>
              </tr>
                <?php
                }
            }
        ?>
</table>

<td><strong style="color:#f00">Emergency Head</strong></td>
<table style="BORDER-COLLAPSE: collapse" width="100%" border="1">
  <tr>
   <td width="10%">SL No.</td>
    <td width="10%">Section </td>
    <td width="10%">Category/Head</td>
    <td width="10%">Date</td>
    <td width="10%">Edit/Delete</td>
  </tr>
  <?php
   $i='';
	$sqlcategory = "select * from category where section='Emergency' order by auto_number asc";
	  	$categoryquery = mysqli_query($conn, $sqlcategory);
			if($categoryquery && mysqli_num_rows($categoryquery)>0){
				while ($categoryrow = mysqli_fetch_array($categoryquery))
			 {
				$auto_number = $categoryrow['auto_number'];
				$section = $categoryrow['section'];
				$category = $categoryrow['category'];
				$date = $categoryrow['date'];
				
			$action = "<a href=\"index.php?p=category&auto_number=$auto_number\">Edit</a> | 
			<a href=\"javascript:voauto_number(0)\" onclick=\"removetablerow('category', $auto_number, 'category')\">Remove</a>";
 			?>
              <tr bgcolor="#FFFFFF">
                <td><?php echo $i=$i+1;?></td>
                <td><?php echo $section;?></td>
                <td><?php echo $category;?></td>
                <td><?php echo $date;?></td>
                <td><?php echo $action;?></td>
              </tr>
                <?php
                }
            }
        ?>
</table>

<td><strong style="color:#f00">Bank</strong></td>
<table style="BORDER-COLLAPSE: collapse" width="100%" border="1">
  <tr>
   <td width="10%">SL No.</td>
    <td width="10%">Section </td>
    <td width="10%">Bank Name</td>
    <td width="10%">Date</td>
    <td width="10%">Edit/Delete</td>
  </tr>
  <?php
   $i='';
	$sqlcategory = "select * from category where section='Bank' order by auto_number asc";
	  	$categoryquery = mysqli_query($conn, $sqlcategory);
			if($categoryquery && mysqli_num_rows($categoryquery)>0){
				while ($categoryrow = mysqli_fetch_array($categoryquery))
			 {
				$auto_number = $categoryrow['auto_number'];
				$section = $categoryrow['section'];
				$category = $categoryrow['category'];
				$date = $categoryrow['date'];
				
				$action = "<a href=\"index.php?p=category&auto_number=$auto_number\">Edit</a> | 
				<a href=\"javascript:voauto_number(0)\" onclick=\"removetablerow('category', $auto_number, 'category')\">Remove</a>";
			
			?>
              <tr bgcolor="#FFFFFF">
                <td><?php echo $i=$i+1;?></td>
                <td><?php echo $section;?></td>
                <td><?php echo $category;?></td>
                <td><?php echo $date;?></td>
                <td><?php echo $action;?></td>
              </tr>
                <?php
				
                }
            }
        ?>
   
</table>

<td><strong style="color:#f00">Lab Item Section List</strong></td>
<table style="BORDER-COLLAPSE: collapse" width="100%" border="1">
  <tr>
    <td width="10%">SL No.</td>
    <td width="10%">Category</td>
    <td width="10%">Section</td>
    <td width="10%">PC Comission %</td>
    <td width="10%">Discount</td>
    <td width="10%">Edit/Delete</td>
  </tr>
  <?php
   $i='';
	$sqlcategory = "select * from category where section='Lab Item Section' order by auto_number asc";
	  	$categoryquery = mysqli_query($conn, $sqlcategory);
			if($categoryquery && mysqli_num_rows($categoryquery)>0){
				while ($categoryrow = mysqli_fetch_array($categoryquery))
			 {
				$auto_number = $categoryrow['auto_number'];
				$section = $categoryrow['section'];
				$pccomission = $categoryrow['pccomission'];
				$labitem_disc = $categoryrow['labitem_disc'];
				$category = $categoryrow['category'];
				$date = $categoryrow['date'];
				
			$action = "<a href=\"index.php?p=category&auto_number=$auto_number\">Edit</a> | 
			<a href=\"javascript:voauto_number(0)\" onclick=\"removetablerow('category', $auto_number, 'category')\">Remove</a>";
 			?>
              <tr bgcolor="#FFFFFF">
                <td><?php echo $i=$i+1;?></td>
                <td><?php echo $section;?></td>
                <td><?php echo $category;?></td>
                <td><?php echo $pccomission;?></td>
                <td><?php echo $labitem_disc;?></td>
                <td><?php echo $action;?></td>
              </tr>
               <?php
               }
            }
        ?>
 </table>


<td><strong style="color:#f00">Lab Item Group List</strong></td>
<table style="BORDER-COLLAPSE: collapse" width="100%" border="1">
  <tr>
   <td width="10%">SL No.</td>
    <td width="10%">Category</td>
    <td width="10%">Group</td>
    <td width="10%">Date</td>
    <td width="10%">Edit/Delete</td>
  </tr>
  <?php
   $i='';
	$sqlcategory = "select * from category where section='Lab Item Group' order by auto_number asc";
	  	$categoryquery = mysqli_query($conn, $sqlcategory);
			if($categoryquery && mysqli_num_rows($categoryquery)>0){
				while ($categoryrow = mysqli_fetch_array($categoryquery))
			 {
				$auto_number = $categoryrow['auto_number'];
				$section = $categoryrow['section'];
				$category = $categoryrow['category'];
				$date = $categoryrow['date'];
				
				$action = "<a href=\"index.php?p=category&auto_number=$auto_number\">Edit</a> | 
				<a href=\"javascript:voauto_number(0)\" onclick=\"removetablerow('category', $auto_number, 'category')\">Remove</a>";
			
			?>
                <tr bgcolor="#FFFFFF">
                <td><?php echo $i=$i+1;?></td>
                <td><?php echo $section;?></td>
                <td><?php echo $category;?></td>
                <td><?php echo $date;?></td>
                <td><?php echo $action;?></td>
              </tr>
                <?php
				
                }
            }
        ?>
   
</table>

<td><strong style="color:#f00">Report Name List</strong></td>
<table style="BORDER-COLLAPSE: collapse" width="100%" border="1">
  <tr>
   <td width="10%">SL No.</td>
    <td width="10%">Category</td>
    <td width="10%">Group</td>
    <td width="10%">Date</td>
    <td width="10%">Edit/Delete</td>
  </tr>
  <?php
   $i='';
	$sqlcategory = "select * from category where section='Report Name' order by auto_number asc";
	  	$categoryquery = mysqli_query($conn, $sqlcategory);
			if($categoryquery && mysqli_num_rows($categoryquery)>0){
				while ($categoryrow = mysqli_fetch_array($categoryquery))
			 {
				$auto_number = $categoryrow['auto_number'];
				$section = $categoryrow['section'];
				$category = $categoryrow['category'];
				$date = $categoryrow['date'];
				
				$action = "<a href=\"index.php?p=category&auto_number=$auto_number\">Edit</a> | 
				<a href=\"javascript:voauto_number(0)\" onclick=\"removetablerow('category', $auto_number, 'category')\">Remove</a>";
			
			?>
                <tr bgcolor="#FFFFFF">
                <td><?php echo $i=$i+1;?></td>
                <td><?php echo $section;?></td>
                <td><?php echo $category;?></td>
                <td><?php echo $date;?></td>
                <td><?php echo $action;?></td>
              </tr>
                <?php
				
                }
            }
        ?>
   
</table>

<td><strong style="color:#f00">Hospital Category List</strong></td>
<table style="BORDER-COLLAPSE: collapse" width="100%" border="1">
  <tr>
    <td width="10%">SL No.</td>
    <td width="10%">Section </td>
    <td width="10%">Category</td>
    <td width="10%">Date</td>
    <td width="10%">Edit/Delete</td>
  </tr>
  <?php
   $i='';
	$sqlcategory = "select * from category where section='Hospital' order by auto_number asc";
	  	$categoryquery = mysqli_query($conn, $sqlcategory);
			if($categoryquery && mysqli_num_rows($categoryquery)>0){
				while ($categoryrow = mysqli_fetch_array($categoryquery))
			 {
				$auto_number = $categoryrow['auto_number'];
				$section = $categoryrow['section'];
				$category = $categoryrow['category'];
				$date = $categoryrow['date'];
				
				$action = "<a href=\"index.php?p=category&auto_number=$auto_number\">Edit</a> | 
				<a href=\"javascript:voauto_number(0)\" onclick=\"removetablerow('category', $auto_number, 'category')\">Remove</a>";
			
			?>
                <tr bgcolor="#FFFFFF">
                <td><?php echo $i=$i+1;?></td>
                <td><?php echo $section;?></td>
                <td><?php echo $category;?></td>
                <td><?php echo $date;?></td>
                <td><?php echo $action;?></td>
              </tr>
                <?php
				
                }
            }
        ?>
   
</table>


<td><strong style="color:#f00">Ward(Room) List</strong></td>
<table style="BORDER-COLLAPSE: collapse" width="100%" border="1">
  <tr>
    <td width="10%">SL No.</td>
    <td width="10%">Order</td>
    <td width="10%">section </td>
    <td width="10%">Ward(Room)</td>
    <td width="10%">Rate</td>
    <td width="10%">date</td>
    <td width="10%">Edit/Delete</td>
  </tr>
  <?php
   $i='';
	$sqlcategory = "select * from category where section='Ward(room)' order by orderby asc";
	  	$categoryquery = mysqli_query($conn, $sqlcategory);
			if($categoryquery && mysqli_num_rows($categoryquery)>0){
				while ($categoryrow = mysqli_fetch_array($categoryquery))
			 {
				$auto_number = $categoryrow['auto_number'];
				$section = $categoryrow['section'];
				$charge = $categoryrow['charge'];
				$category = $categoryrow['category'];
				$date = $categoryrow['date'];
				$orderby = $categoryrow['orderby'];
				
			$action = "<a href=\"index.php?p=category&auto_number=$auto_number\">Edit</a> | 
			<a href=\"javascript:voauto_number(0)\" onclick=\"removetablerow('category', $auto_number, 'category')\">Remove</a>";
			
			?>
                <tr bgcolor="#FFFFFF">
                <td><?php echo $i=$i+1;?></td>
                <td><?php echo $orderby;?></td>
                <td><?php echo $section;?></td>
                <td><?php echo $category;?></td>
                <td><?php echo $charge;?></td>
                <td><?php echo $date;?></td>
                <td><?php echo $action;?></td>
              </tr>
                <?php
                }
            }
        ?>
   
</table>

<td><strong style="color:#f00">Income Section List</strong></td>
<table style="BORDER-COLLAPSE: collapse" width="100%" border="1">
  <tr>
    <td width="10%">SL No.</td>
    <td width="10%">Section </td>
    <td width="10%">Section</td>
    <td width="10%">Date</td>
    <td width="10%">Edit/Delete</td>
  </tr>
  <?php
   $i='';
	$sqlcategory = "select * from category where section='income section' order by auto_number asc";
	  	$categoryquery = mysqli_query($conn, $sqlcategory);
			if($categoryquery && mysqli_num_rows($categoryquery)>0){
				while ($categoryrow = mysqli_fetch_array($categoryquery))
			 {
				$auto_number = $categoryrow['auto_number'];
				$section = $categoryrow['section'];
				$category = $categoryrow['category'];
				$date = $categoryrow['date'];
				
				$action = "<a href=\"index.php?p=category&auto_number=$auto_number\">Edit</a> | 
				<a href=\"javascript:voauto_number(0)\" onclick=\"removetablerow('category', $auto_number, 'category')\">Remove</a>";
 			?>
                <tr bgcolor="#FFFFFF">
                <td><?php echo $i=$i+1;?></td>
                <td><?php echo $section;?></td>
                <td><?php echo $category;?></td>
                <td><?php echo $date;?></td>
                <td><?php echo $action;?></td>
              </tr>
                <?php
               }
            }
        ?>
 </table>

<td><strong style="color:#f00">Patient Category</strong></td>
<table style="BORDER-COLLAPSE: collapse" width="100%" border="1">
  <tr>
   <td width="10%">SL No.</td>
    <td width="10%">Section </td>
    <td width="10%">Diagnosis Name</td>
    <td width="10%">Date</td>
    <td width="10%">Edit/Delete</td>
  </tr>
  <?php
   $i='';
	$sqlcategory = "select * from category where section='Patient' order by auto_number asc";
	  	$categoryquery = mysqli_query($conn, $sqlcategory);
			if($categoryquery && mysqli_num_rows($categoryquery)>0){
				while ($categoryrow = mysqli_fetch_array($categoryquery))
			 {
				$auto_number = $categoryrow['auto_number'];
				$section = $categoryrow['section'];
				$category = $categoryrow['category'];
				$date = $categoryrow['date'];
				
				$action = "<a href=\"index.php?p=category&auto_number=$auto_number\">Edit</a> | 
				<a href=\"javascript:voauto_number(0)\" onclick=\"removetablerow('category', $auto_number, 'category')\">Remove</a>";
			
			?>
                <tr bgcolor="#FFFFFF">
                <td><?php echo $i=$i+1;?></td>
                <td><?php echo $section;?></td>
                <td><?php echo $category;?></td>
                <td><?php echo $date;?></td>
                <td><?php echo $action;?></td>
              </tr>
                <?php
                 }
            }
        ?>
   
</table>


<td><strong style="color:#f00">Medicine Company List</strong></td>
<table style="BORDER-COLLAPSE: collapse" width="100%" border="1">
  <tr>
   <td width="10%">SL No.</td>
    <td width="10%">Section </td>
    <td width="10%">Group Name</td>
    <td width="10%">Date</td>
    <td width="10%">Edit/Delete</td>
  </tr>
  <?php
   $i='';
	$sqlcategory = "select * from category where section='Medicine Company' order by auto_number asc";
	  	$categoryquery = mysqli_query($conn, $sqlcategory);
			if($categoryquery && mysqli_num_rows($categoryquery)>0){
				while ($categoryrow = mysqli_fetch_array($categoryquery))
			 {
				$auto_number = $categoryrow['auto_number'];
				$section = $categoryrow['section'];
				$category = $categoryrow['category'];
				$date = $categoryrow['date'];
				
			$action = "<a href=\"index.php?p=category&auto_number=$auto_number\">Edit</a> | 
			<a href=\"javascript:voauto_number(0)\" onclick=\"removetablerow('category', $auto_number, 'category')\">Remove</a>";
 			?>
             <tr bgcolor="#FFFFFF">
                <td><?php echo $i=$i+1;?></td>
                <td><?php echo $section;?></td>
                <td><?php echo $category;?></td>
                <td><?php echo $date;?></td>
                <td><?php echo $action;?></td>
              </tr>
                <?php
                }
            }
        ?>
 </table>

    <td><strong style="color:#f00">Medicine Group List</strong></td>
    <table style="BORDER-COLLAPSE: collapse" width="100%" border="1">
      <tr>
       <td width="10%">SL No.</td>
        <td width="10%">Section </td>
        <td width="10%">Group Name</td>
        <td width="10%">Date</td>
        <td width="10%">Edit/Delete</td>
      </tr>
  		<?php
   		$i='';
		$sqlcategory = "select * from category where section='Medicine Group' order by auto_number asc";
	  	$categoryquery = mysqli_query($conn, $sqlcategory);
			if($categoryquery && mysqli_num_rows($categoryquery)>0){
				while ($categoryrow = mysqli_fetch_array($categoryquery))
			 	{
				$auto_number = $categoryrow['auto_number'];
				$section = $categoryrow['section'];
				$category = $categoryrow['category'];
				$date = $categoryrow['date'];
				
			$action = "<a href=\"index.php?p=category&auto_number=$auto_number\">Edit</a> | 
			<a href=\"javascript:voauto_number(0)\" onclick=\"removetablerow('category', $auto_number, 'category')\">Remove</a>";
			
			?>
                <tr bgcolor="#FFFFFF">
                <td><?php echo $i=$i+1;?></td>
                <td><?php echo $section;?></td>
                <td><?php echo $category;?></td>
                <td><?php echo $date;?></td>
                <td><?php echo $action;?></td>
              </tr>
                <?php
                 }
            }
        ?>
   
</table>

<td><strong style="color:#f00">Complains List</strong></td>
<table style="BORDER-COLLAPSE: collapse" width="100%" border="1">
  <tr>
    <td width="10%">SL No.</td>
    <td width="10%">Section </td>
    <td width="10%">Group Name</td>
    <td width="10%">Date</td>
    <td width="10%">Edit/Delete</td>
  </tr>
  <?php
   $i='';
	$sqlcategory = "select * from category where section='Complain' order by auto_number asc";
	  	$categoryquery = mysqli_query($conn, $sqlcategory);
			if($categoryquery && mysqli_num_rows($categoryquery)>0){
				while ($categoryrow = mysqli_fetch_array($categoryquery))
			 {
				$auto_number = $categoryrow['auto_number'];
				$section = $categoryrow['section'];
				$category = $categoryrow['category'];
				$date = $categoryrow['date'];
				
				$action = "<a href=\"index.php?p=category&auto_number=$auto_number\">Edit</a> | 
				<a href=\"javascript:voauto_number(0)\" onclick=\"removetablerow('category', $auto_number, 'category')\">Remove</a>";
			
			?>
                <tr bgcolor="#FFFFFF">
                <td><?php echo $i=$i+1;?></td>
                <td><?php echo $section;?></td>
                <td><?php echo $category;?></td>
                <td><?php echo $date;?></td>
                <td><?php echo $action;?></td>
              </tr>
                <?php
                 }
            }
        ?>
   
</table>


<td><strong style="color:#f00">Medicine Eating Rules</strong></td>
<table style="BORDER-COLLAPSE: collapse" width="100%" border="1">
  <tr>
    <td width="10%">SL No.</td>
    <td width="10%">Section </td>
    <td width="10%">Name</td>
    <td width="10%">Date</td>
    <td width="10%">Edit/Delete</td>
  </tr>
  <?php
   $i='';
	$sqlcategory = "select * from category where section='Medicine Eating Rules' order by auto_number asc";
	  	$categoryquery = mysqli_query($conn, $sqlcategory);
			if($categoryquery && mysqli_num_rows($categoryquery)>0){
				while ($categoryrow = mysqli_fetch_array($categoryquery))
			 {
				$auto_number = $categoryrow['auto_number'];
				$section = $categoryrow['section'];
				$category = $categoryrow['category'];
				$date = $categoryrow['date'];
				
				$action = "<a href=\"index.php?p=category&auto_number=$auto_number\">Edit</a> | 
				<a href=\"javascript:voauto_number(0)\" onclick=\"removetablerow('category', $auto_number, 'category')\">Remove</a>";
			
			?>
                <tr bgcolor="#FFFFFF">
                <td><?php echo $i=$i+1;?></td>
                <td><?php echo $section;?></td>
                <td><?php echo $category;?></td>
                <td><?php echo $date;?></td>
                <td><?php echo $action;?></td>
              </tr>
                <?php
                 }
            }
        ?>
   
</table>


<td><strong style="color:#f00">Diagnosis List</strong></td>
<table style="BORDER-COLLAPSE: collapse" width="100%" border="1">
  <tr>
   <td width="10%">SL No.</td>
    <td width="10%">Section </td>
    <td width="10%">Group Name</td>
    <td width="10%">Date</td>
    <td width="10%">Edit/Delete</td>
  </tr>
  <?php
   $i='';
	$sqlcategory = "select * from category where section='Diagnosis' order by auto_number asc";
	  	$categoryquery = mysqli_query($conn, $sqlcategory);
			if($categoryquery && mysqli_num_rows($categoryquery)>0){
				while ($categoryrow = mysqli_fetch_array($categoryquery))
			 {
				$auto_number = $categoryrow['auto_number'];
				$section = $categoryrow['section'];
				$category = $categoryrow['category'];
				$date = $categoryrow['date'];
				
				$action = "<a href=\"index.php?p=category&auto_number=$auto_number\">Edit</a> | 
				<a href=\"javascript:voauto_number(0)\" onclick=\"removetablerow('category', $auto_number, 'category')\">Remove</a>";
			
			?>
                <tr bgcolor="#FFFFFF">
                <td><?php echo $i=$i+1;?></td>
                <td><?php echo $section;?></td>
                <td><?php echo $category;?></td>
                <td><?php echo $date;?></td>
                <td><?php echo $action;?></td>
              </tr>
                <?php
                 }
            }
        ?>
 </table>

 </content>
</article>