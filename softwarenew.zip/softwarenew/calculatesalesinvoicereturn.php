<script language="JavaScript" type="text/javascript">
 	var itemdata = <?php echo $itemdata;?>;
	var patientdata = <?php echo $patientdata;?>;
	var invoicedata = <?php echo $invoicedata;?>;
	$(document).ready(function($) {
		document.getElementsByName("salesinvoicereturn_item[]")[0].focus();

		$( ".itemname" ).autocomplete({
 			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
 				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
 				document.getElementsByName("salesitem_id[]")[indexpos].value = ui.item.salesitem_id;
				document.getElementsByName("salesinvoicereturn_purchase_rate[]")[indexpos].value = ui.item.salesitem_purchase_rate;
				document.getElementsByName("salesinvoicereturn_rate[]")[indexpos].value = ui.item.salesitem_price;				
				document.getElementsByName("purchaseitem_pack[]")[indexpos].value =ui.item.salesitem_pack;
				document.getElementsByName("salesinvoicereturn_qty[]")[indexpos].value = '';					
				document.getElementsByName("salesinvoicereturn_category[]")[indexpos].value = ui.item.salesitem_category;
				document.getElementsByName("salesinvoicereturn_group[]")[indexpos].value = ui.item.salesitem_group;
				document.getElementsByName("salesinvoicereturn_stock[]")[indexpos].value = ui.item.salesitem_stock;
 				calculateCurrentRowTotal(indexpos);
 				return false;
			}
		});
		
		
		$( "#salesinvoicereturn_patientid" ).autocomplete({
 			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
 				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
 					document.getElementById('salesinvoicereturn_patient').value = ui.item.labelval;
					document.getElementById('salesinvoicereturn_patientid').value = ui.item.opregistration_id;
					document.getElementById('salesinvoice_patientcode').value = ui.item.opregistration_code;
					document.getElementById('salesinvoicereturn_previousdue').value = ui.item.pharmacy_due;
					document.getElementById('salesinvoicereturn_mobile').value = ui.item.opregistration_mobile;
					document.getElementById('salesinvoicereturn_address').value = ui.item.opregistration_address;
 				return false;
			}
		});
		
		$( "#salesinvoicereturn_inv" ).autocomplete({
			
			minLength: 1,
			source: invoicedata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.saleselval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('salesinvoicereturn_patient').value = ui.item.labelval;
				 document.getElementById('salesinvoice_subtotalafterdisc').value = ui.item.salesinvoice_subtotalafterdisc;
				 //document.getElementById('salesinvoicereturn_id').value = ui.item.salesinvoice_id;
				 document.getElementById('salesinvoicereturn_mobile').value = ui.item.salesinvoice_mobile;
				 
				return false;
			}
		});
		
		
		
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
		$( ".sirow input.ccrt" ).keyup(function() {
			var index = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
			calculateCurrentRowTotal(index);
		});
	});
	
	function calculateCurrentRowTotal(index){
		
		var salesinvoicereturn_purchase_rate = parseFloat(document.getElementsByName("salesinvoicereturn_purchase_rate[]")[index].value);
		if(salesinvoicereturn_purchase_rate=='' || isNaN(salesinvoicereturn_purchase_rate)){salesinvoicereturn_purchase_rate = 0.00;}
		
		
		var salesinvoicereturn_rate = parseFloat(document.getElementsByName("salesinvoicereturn_rate[]")[index].value);
		if(salesinvoicereturn_rate=='' || isNaN(salesinvoicereturn_rate)){salesinvoicereturn_rate = 0.00;}
		
		
		var purchaseitem_pack = parseFloat(document.getElementsByName("purchaseitem_pack[]")[index].value);
		if(purchaseitem_pack=='' || isNaN(purchaseitem_pack)){purchaseitem_pack = 0.00;}
		
		var salesinvoicereturn_pqty = parseFloat(document.getElementsByName("salesinvoicereturn_pqty[]")[index].value);
		if(salesinvoicereturn_pqty=='' || isNaN(salesinvoicereturn_pqty)){salesinvoicereturn_pqty = 0.00;}
		
		if(purchaseitem_pack==0 || salesinvoicereturn_pqty==0){
			var salesinvoicereturn_qty = parseFloat(document.getElementsByName("salesinvoicereturn_qty[]")[index].value);
			if(salesinvoicereturn_qty=='' || isNaN(salesinvoicereturn_qty)){salesinvoicereturn_qty = 0.00;}
		}
		else{
			var salesinvoicereturn_qty = parseFloat(purchaseitem_pack*salesinvoicereturn_pqty);
			if(salesinvoicereturn_qty=='' || isNaN(salesinvoicereturn_qty)){salesinvoicereturn_qty = 0.00;}
			document.getElementsByName("salesinvoicereturn_qty[]")[index].value = salesinvoicereturn_qty.toFixed(2);
		}
		
		var qtyPrice = parseFloat(salesinvoicereturn_rate*salesinvoicereturn_qty);
		
		var salesinvoicereturn_discountp = parseFloat(document.getElementsByName("salesinvoicereturn_discountp[]")[index].value);
		if(salesinvoicereturn_discountp=='' || isNaN(salesinvoicereturn_discountp)){salesinvoicereturn_discountp = 0.00;}
		if(salesinvoicereturn_discountp==0){
			var salesinvoicereturn_disc = parseFloat(document.getElementsByName("salesinvoicereturn_disc[]")[index].value);
			if(salesinvoicereturn_disc=='' || isNaN(salesinvoicereturn_disc)){salesinvoicereturn_disc = 0.00;}
		}
		else{
			var salesinvoicereturn_disc = parseFloat(qtyPrice*salesinvoicereturn_discountp*0.01);	
			document.getElementsByName("salesinvoicereturn_disc[]")[index].value = salesinvoicereturn_disc.toFixed(2);
		}
		
		document.getElementsByName("salesinvoicereturn_total[]")[index].value = parseFloat(qtyPrice-salesinvoicereturn_disc).toFixed(2);
	
		calculateGrandTotal();
	}
	
	function calculateGrandTotal(){
		var salesinvoicereturn_totalarray = document.getElementsByName("salesinvoicereturn_total[]");
		var salesinvoicereturn_subtotal = 0.00;
		for(var r=0; r<salesinvoicereturn_totalarray.length; r++){
			var salesinvoicereturn_total = parseFloat(salesinvoicereturn_totalarray[r].value);
			if(salesinvoicereturn_total=='' || isNaN(salesinvoicereturn_total)){salesinvoicereturn_total = 0.00;}
			salesinvoicereturn_subtotal = parseFloat(salesinvoicereturn_subtotal+salesinvoicereturn_total);
		}
		
		document.getElementById("salesinvoicereturn_subtotal").value = salesinvoicereturn_subtotal.toFixed(2);
		
		
		
		var salesinvoicereturn_totaldiscp = parseFloat(document.getElementById("salesinvoicereturn_totaldiscp").value);
		if(salesinvoicereturn_totaldiscp=='' || isNaN(salesinvoicereturn_totaldiscp)){salesinvoicereturn_totaldiscp = 0;}
		if(salesinvoicereturn_totaldiscp==0){
			var salesinvoicereturn_totaldisc = parseFloat(document.getElementById("salesinvoicereturn_totaldisc").value);
			if(salesinvoicereturn_totaldisc=='' || isNaN(salesinvoicereturn_totaldisc)){salesinvoicereturn_totaldisc = 0;}
		}
		else{
			var salesinvoicereturn_totaldisc = parseFloat(salesinvoicereturn_subtotal*salesinvoicereturn_totaldiscp*0.01);
			document.getElementById('salesinvoicereturn_totaldisc').value= salesinvoicereturn_totaldisc.toFixed(2);
		}
		
		
		var salesinvoice_subtotalafterdisc = parseFloat(document.getElementById("salesinvoice_subtotalafterdisc").value);
		if(salesinvoice_subtotalafterdisc=='' || isNaN(salesinvoice_subtotalafterdisc)){salesinvoice_subtotalafterdisc = 0;}
		
		
				// eturn with 5% less
			
		/*var salesinvoicereturn_totaldisc = parseFloat(salesinvoicereturn_totaldisc);
		if(salesinvoicereturn_totaldisc=='' || isNaN(salesinvoicereturn_totaldisc)){salesinvoicereturn_totaldisc = 0;}
		
		if(salesinvoice_subtotalafterdisc>=95){
			var salesinvoicereturn_totaldisc = parseFloat(salesinvoicereturn_subtotal*5*0.01);
			//document.getElementById('salesinvoice_totaldisc').value= salesinvoice_totaldisc.toFixed(2);
		}
		document.getElementById('salesinvoicereturn_totaldisc').value= salesinvoicereturn_totaldisc.toFixed(2);
		*/
		
		// prevoius due
		var salesinvoicereturn_previousdue = parseFloat(document.getElementById("salesinvoicereturn_previousdue").value);
		if(salesinvoicereturn_previousdue=='' || isNaN(salesinvoicereturn_previousdue)){salesinvoicereturn_previousdue = 0;}
		
		
		var salesinvoicereturn_subtotalafterdisc = parseFloat(salesinvoicereturn_subtotal-salesinvoicereturn_totaldisc);
		document.getElementById('salesinvoicereturn_subtotalafterdisc').value= salesinvoicereturn_subtotalafterdisc.toFixed(2);
			
		var salesinvoicereturn_receiveamount = parseFloat(document.getElementById("salesinvoicereturn_receiveamount").value);
		if(salesinvoicereturn_receiveamount=='' || isNaN(salesinvoicereturn_receiveamount)){salesinvoicereturn_receiveamount = 0;}
		
		var salesinvoicereturn_due = parseFloat(salesinvoicereturn_subtotalafterdisc-salesinvoicereturn_receiveamount);
		document.getElementById('salesinvoicereturn_due').value=salesinvoicereturn_due.toFixed(2);		
		
	}
	
	function check_blankrow(){
		var salesinvoicereturn_itemArray = document.getElementsByName('salesinvoicereturn_item[]');
		var salesinvoicereturn_totalArray = document.getElementsByName('salesinvoicereturn_total[]');
			
		var error_messageid = document.getElementById('errmsg_particular_id');
		error_messageid.innerHTML = '';
		
		for(r = 0; r < salesinvoicereturn_itemArray.length; r++) {
												
			if(salesinvoicereturn_itemArray[r].value==''){
				error_messageid.innerHTML = 'Missing item name '+parseInt(r+1);
				salesinvoicereturn_itemArray[r].focus();
				return false;
			}
			
			if(salesinvoicereturn_totalArray[r].value=='' || salesinvoicereturn_totalArray[r].value==0){
				error_messageid.innerHTML = 'Missing item total '+parseInt(r+1);
				salesinvoicereturn_totalArray[r].focus();
				return false;
			}
		}
		
		return true;
	}

	function addnew_particularrow(animate) {
		if(check_blankrow()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" align=\"left\" width=\"918\" cellpadding=\"1\">"+
							'<tbody><tr></tr><tr>'+
								'<td align="center" width=\"130\"> <input type="text" name="salesinvoicereturn_item[]" value="" class="tdclass itemname"/>'+
								'<input type="hidden" name="salesitem_id[]" id="salesitem_id[]" value="" class="tdclass itemname"/>'+
								'<input type="hidden" name="salesinvoicereturn_category[]" class="tdclass"  /></td>'+
								'<input type="hidden" name="salesinvoicereturn_group[]" class="tdclass"  /></td>'+
								'<td align=\"center\" width=\"95\"> <input type="text" name="salesinvoicereturn_stock[]" value=\"\" class="tdclasssale itemname"/></td>'+
								"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"salesinvoicereturn_purchase_rate[]\"  value=\"\" class=\"tdclasssale\"/></td>"+											 
								"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"salesinvoicereturn_rate[]\" value=\"\" class=\"tdclasssale numeric ccrt\"/></td>"+											 
								
								"<td align=\"center\" width=\"95\"><input type=\"text\" title=\"class\" name=\"purchaseitem_pack[]\" class=\"tdclasssale numeric ccrt\" ></td>"+
								"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"salesinvoicereturn_pqty[]\" value=\"\" class=\"tdclasssale numeric ccrt\" /></td>"+
								
								"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"salesinvoicereturn_qty[]\" value=\"\" class=\"tdclasssale numeric ccrt\"/></td>"+
								'<td align="center" width=\"95\"><input type="text" name="salesinvoicereturn_discountp[]" value="" class="tdclasssale numeric ccrt"/></td>'+
								"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"salesinvoicereturn_disc[]\" value=\"\" class=\"tdclasssale numeric  ccrt\" /></td>"+
								'<td align="center" width=\"95\"><input type="text" readonly name="salesinvoicereturn_total[]" value="" class="tdclasssale numeric ccrt"  /></td>'+												
								'<td>'+
								 "<input type=\"button\" value=\"Del\" class=\"tdclasssales deletethislistrow\"  />"+
								'</td>'+
							  '</tr></tbody>'+
						"</table>";
						
			var $newparticularlist = $("<li class=\"sirow\"></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(300); 
			else 
			   $newparticularlist.show();   
			
			$( ".itemname" ).autocomplete({			
				minLength: 1,
				source: itemdata,
				focus: function( event, ui ) {
					//$( "#search_item_number" ).val( ui.item.saleselval );
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					document.getElementsByName("salesitem_id[]")[indexpos].value = ui.item.salesitem_id;
					document.getElementsByName("salesinvoicereturn_purchase_rate[]")[indexpos].value = ui.item.salesitem_purchase_rate;
					document.getElementsByName("salesinvoicereturn_rate[]")[indexpos].value = ui.item.salesitem_price;				
					document.getElementsByName("purchaseitem_pack[]")[indexpos].value =ui.item.salesitem_pack;
					document.getElementsByName("salesinvoicereturn_qty[]")[indexpos].value = '';					
					document.getElementsByName("salesinvoicereturn_category[]")[indexpos].value = ui.item.salesitem_category;
					document.getElementsByName("salesinvoicereturn_group[]")[indexpos].value = ui.item.salesitem_group;
					document.getElementsByName("salesinvoicereturn_stock[]")[indexpos].value = ui.item.salesitem_stock;
				
					calculateCurrentRowTotal(indexpos);
					
					return false;
				}
			});	
			
								
		
			$( ".sirow input.ccrt" ).keyup(function() {
				var index = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				calculateCurrentRowTotal(index);
			});
			
			$( ".sirow input.deletethislistrow" ).click(function() {
				$(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').slideUp(500, function() {
					$(this).remove();
					calculateGrandTotal();
				});
			});
			
			$( ".numeric" ).keyup(function() {
				var price = $(this).val();
				var ValidChars = "-.0123456789";
				var IsNumber=true;
				var Char;
				var validint = '';
				for (var i = 0; i < price.length && IsNumber == true; i++){ 
					Char = price.charAt(i);
					if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
					else{
						validint = validint+Char;
					}
				}
				$(this).val(validint);
			});
		}
	}
	
	function funcSaveBill1()
	{
	var varUserChoice; 
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet); 
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		document.frmsales.submit();
		//return true;
	}
}		
</script>