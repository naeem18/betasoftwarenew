<!--mobile access off-->
<?php /*?><?php
$userAgent = strtolower($_SERVER['HTTP_USER_AGENT']);
if (preg_match('/mobile|android|iphone|ipad|tablet|phone/i', $userAgent)) {
    echo "<h2 style='text-align:center; margin-top:100px;'>❌ Access Not Allowed.<br>Please Contact to Beta Software Solutions (01757827474).</h2>";
    exit;
}
?><?php */?>
<!--Specefic mobile/Desktop access on-->
<?php /*?><?php
// simple device + IP allow list (place at top of page)
$ua = isset($_SERVER['HTTP_USER_AGENT']) ? strtolower($_SERVER['HTTP_USER_AGENT']) : '';
$ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';

// CONFIG: change these to your real allowed IPs
$allowed_mobile_ips  = array('37.111.206.178','203.0.113.11','203.0.113.12'); // 3 mobiles
$allowed_desktop_ips = array('192.168.0.3','198.51.100.22','198.51.100.23'); // 3 pcs

// detect mobile UA (basic)
$is_mobile = (bool) preg_match('/mobile|android|iphone|ipad|tablet|phone/i', $ua);

// quick allow check
if ($is_mobile) {
    if (!in_array($ip, $allowed_mobile_ips)) {
        header('HTTP/1.1 403 Forbidden');
        echo '<h2 style="text-align:center;margin-top:80px;color:#c00">Access denied — mobile not authorized.</h2>';
        exit;
    }
} else {
    if (!in_array($ip, $allowed_desktop_ips)) {
        header('HTTP/1.1 403 Forbidden');
        echo '<h2 style="text-align:center;margin-top:80px;color:#c00">Access denied — desktop not authorized.</h2>';
        exit;
    }
}
// allowed -> page continues
?><?php */?>