<script language="JavaScript" type="text/javascript">
	
	var itemdata = <?php echo $itemdata;?>;
	var patientdata = <?php echo $patientdata;?>;
	
	$(document).ready(function($) {
		document.getElementsByName("purchaseinvoice_item[]")[0].focus();

		$( ".itemname" ).autocomplete({
			
			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.saleselval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				document.getElementsByName("salesitem_id[]")[indexpos].value = ui.item.salesitem_id;
				document.getElementsByName("purchaseinvoice_purchase_rate[]")[indexpos].value = ui.item.salesitem_purchase_rate;
				document.getElementsByName("purchaseinvoice_rate[]")[indexpos].value = ui.item.salesitem_price;				
				document.getElementsByName("purchaseitem_pack[]")[indexpos].value =ui.item.salesitem_pack;
				document.getElementsByName("purchaseinvoice_qty[]")[indexpos].value = '';					
				document.getElementsByName("purchaseinvoice_category[]")[indexpos].value = ui.item.salesitem_category;
				document.getElementsByName("purchaseinvoice_group[]")[indexpos].value = ui.item.salesitem_group;
				document.getElementsByName("purchaseinvoice_stock[]")[indexpos].value = ui.item.salesitem_stock;
				//document.getElementsByName("purchaseinvoice_expire[]")[indexpos].value = ui.item.expire;
				
				calculateCurrentRowTotal(indexpos);
				
				return false;
			}
		});
		
		
		$( "#purchaseinvoice_patient" ).autocomplete({
			
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.saleselval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('purchaseinvoice_patientid').value = ui.item.labelval;
				 document.getElementById('purchaseinvoice_patientcode').value = ui.item.company_code;
				 document.getElementById('purchaseinvoice_previousdue').value = ui.item.company_due;
				 document.getElementById('purchaseinvoice_mobile').value = ui.item.company_mobile;
				 document.getElementById('purchaseinvoice_address').value = ui.item.company_address;
				
				return false;
			}
		});
		
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
	$( ".purchaseinvoice_item" ).keypress(function(keyname) {
			if(keyname.which==13){
				var imei = $(this).val();
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				$.each(itemarraydata, function(key, value){
					var valuearray = value.split('||');
					if(key==imei){
						document.getElementsByName("salesitem_id[]")[indexpos].value = valuearray[0];
						//document.getElementsByName("salesinvoice_item[]")[indexpos].value = valuearray[1];
						document.getElementsByName("purchaseinvoice_category[]")[indexpos].value = valuearray[1];
						document.getElementsByName("purchaseinvoice_stock[]")[indexpos].value = valuearray[2];
						document.getElementsByName("purchaseinvoice_purchase_rate[]")[indexpos].value = valuearray[3];
						document.getElementsByName("purchaseinvoice_rate[]")[indexpos].value = valuearray[4];
						document.getElementsByName("purchaseinvoice_qty[]")[indexpos].value = '';
						calculateCurrentRowTotal(indexpos);
						
						addnew_particularrow(true);
					}
				});
				return false;
			}
		});
			
		
		$( ".sirow input.ccrt" ).keyup(function() {
			var index = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
			calculateCurrentRowTotal(index);
		});
	});
	
	function calculateCurrentRowTotal(indexpos){
		
		var purchaseinvoice_purchase_box = parseFloat(document.getElementsByName("purchaseinvoice_purchase_box[]")[indexpos].value);
		if(purchaseinvoice_purchase_box=='' || isNaN(purchaseinvoice_purchase_box)){purchaseinvoice_purchase_box = 0.00;}
		
		var purchaseinvoice_purchase_rate = parseFloat(document.getElementsByName("purchaseinvoice_purchase_rate[]")[indexpos].value);
		if(purchaseinvoice_purchase_rate=='' || isNaN(purchaseinvoice_purchase_rate)){purchaseinvoice_purchase_rate = 0.00;}
		
		
		var purchaseitem_pack = parseFloat(document.getElementsByName("purchaseitem_pack[]")[indexpos].value);
		if(purchaseitem_pack=='' || isNaN(purchaseitem_pack)){purchaseitem_pack = 0.00;}
		
		var purchaseinvoice_pqty = parseFloat(document.getElementsByName("purchaseinvoice_pqty[]")[indexpos].value);
		if(purchaseinvoice_pqty=='' || isNaN(purchaseinvoice_pqty)){purchaseinvoice_pqty = 0.00;}
		
		
		if(purchaseitem_pack==0 || purchaseinvoice_pqty==0){
			var purchaseinvoice_qty = parseFloat(document.getElementsByName("purchaseinvoice_qty[]")[indexpos].value);
			if(purchaseinvoice_qty=='' || isNaN(purchaseinvoice_qty)){purchaseinvoice_qty = 0.00;}
		}
		else{
			var purchaseinvoice_qty = parseFloat(purchaseitem_pack*purchaseinvoice_pqty);
			if(purchaseinvoice_qty=='' || isNaN(purchaseinvoice_qty)){purchaseinvoice_qty = 0.00;}
			document.getElementsByName("purchaseinvoice_qty[]")[indexpos].value = purchaseinvoice_qty;
		}
		
		var purchaseinvoice_freeqty = parseFloat(document.getElementsByName("purchaseinvoice_freeqty[]")[indexpos].value);
		if(purchaseinvoice_freeqty=='' || isNaN(purchaseinvoice_freeqty)){purchaseinvoice_freeqty = 0.00;}
		
		var purchaseinvoice_qty = parseFloat(document.getElementsByName("purchaseinvoice_qty[]")[indexpos].value);
		if(purchaseinvoice_qty=='' || isNaN(purchaseinvoice_qty)){purchaseinvoice_qty = 0.00;}
		
		var vat = parseFloat(document.getElementsByName("vat[]")[indexpos].value);
		if(vat=='' || isNaN(vat)){vat = 0.00;}
		
		document.getElementsByName("purchaseinvoice_totalqty[]")[indexpos].value = parseFloat(purchaseinvoice_qty+purchaseinvoice_freeqty);
		
		//var qtyPrice = parseFloat(purchaseinvoice_purchase_rate*purchaseinvoice_qty);
		var qtyPrice2 = parseFloat((purchaseinvoice_purchase_box/purchaseitem_pack));
		var qtyPrice = parseFloat((purchaseinvoice_purchase_box));

		var purchaseinvoice_discountp = parseFloat(document.getElementsByName("purchaseinvoice_discountp[]")[indexpos].value);
		if(purchaseinvoice_discountp=='' || isNaN(purchaseinvoice_discountp)){purchaseinvoice_discountp = 0.00;}
		if(purchaseinvoice_discountp==0){
			var purchaseinvoice_disc = parseFloat(document.getElementsByName("purchaseinvoice_disc[]")[indexpos].value);
			if(purchaseinvoice_disc=='' || isNaN(purchaseinvoice_disc)){purchaseinvoice_disc = 0.00;}
		}
		else{
			var purchaseinvoice_disc = parseFloat(qtyPrice*purchaseinvoice_discountp*0.01);	
			document.getElementsByName("purchaseinvoice_disc[]")[indexpos].value = purchaseinvoice_disc.toFixed(2);
		}
		
		var vattotal = parseFloat(((purchaseinvoice_purchase_box-vat)*purchaseinvoice_pqty));
		
		//document.getElementsByName("purchaseinvoice_purchase_rate[]")[indexpos].value = parseFloat(qtyPrice-(purchaseinvoice_disc)).toFixed(2);
		document.getElementsByName("purchaseinvoice_total[]")[indexpos].value = parseFloat(((qtyPrice-purchaseinvoice_disc-vattotal)*purchaseinvoice_pqty)).toFixed(2);
		
		calculateGrandTotal();
	}
	
	function calculateGrandTotal(){
		var purchaseinvoice_totalarray = document.getElementsByName("purchaseinvoice_total[]");
		var purchaseinvoice_subtotal = 0.00;
		for(var r=0; r<purchaseinvoice_totalarray.length; r++){
			var purchaseinvoice_total = parseFloat(purchaseinvoice_totalarray[r].value);
			if(purchaseinvoice_total=='' || isNaN(purchaseinvoice_total)){purchaseinvoice_total = 0.00;}
			purchaseinvoice_subtotal = parseFloat(purchaseinvoice_subtotal+purchaseinvoice_total);
		}
		
		document.getElementById("purchaseinvoice_subtotal").value = purchaseinvoice_subtotal.toFixed(2);
		//Discount total
		var purchaseinvoice_totaldiscp = parseFloat(document.getElementById("purchaseinvoice_totaldiscp").value);
		if(purchaseinvoice_totaldiscp=='' || isNaN(purchaseinvoice_totaldiscp)){purchaseinvoice_totaldiscp = 0;}
		if(purchaseinvoice_totaldiscp==0){
			var purchaseinvoice_totaldisc = parseFloat(document.getElementById("purchaseinvoice_totaldisc").value);
			if(purchaseinvoice_totaldisc=='' || isNaN(purchaseinvoice_totaldisc)){purchaseinvoice_totaldisc = 0;}
		}
		else{
			var purchaseinvoice_totaldisc = parseFloat(purchaseinvoice_subtotal*purchaseinvoice_totaldiscp*0.01);
			document.getElementById('purchaseinvoice_totaldisc').value= purchaseinvoice_totaldisc.toFixed(2);
		}
		
		//VaT total
		var purchaseinvoice_vatp = parseFloat(document.getElementById("purchaseinvoice_vatp").value);
		if(purchaseinvoice_vatp=='' || isNaN(purchaseinvoice_vatp)){purchaseinvoice_vatp = 0;}
		if(purchaseinvoice_vatp==0){
			var purchaseinvoice_vat = parseFloat(document.getElementById("purchaseinvoice_vat").value);
			if(purchaseinvoice_vat=='' || isNaN(purchaseinvoice_vat)){purchaseinvoice_vat = 0;}
		}
		else{
			var purchaseinvoice_vat = parseFloat(purchaseinvoice_subtotal*purchaseinvoice_vatp*0.01);
			document.getElementById('purchaseinvoice_vat').value= purchaseinvoice_vat.toFixed(2);
		}
		
		// prevoius due
		var purchaseinvoice_previousdue = parseFloat(document.getElementById("purchaseinvoice_previousdue").value);
		if(purchaseinvoice_previousdue=='' || isNaN(purchaseinvoice_previousdue)){purchaseinvoice_previousdue = 0;}
		
		//Total  after Less
	var purchaseinvoice_subtotalafterdisc = parseFloat(purchaseinvoice_subtotal-purchaseinvoice_totaldisc);
	document.getElementById('purchaseinvoice_subtotalafterdisc').value= purchaseinvoice_subtotalafterdisc.toFixed(2);
	
	//Total  after VAT
	var purchaseinvoice_subtotalaftervat = parseFloat(purchaseinvoice_subtotalafterdisc + purchaseinvoice_vat);
	document.getElementById('purchaseinvoice_subtotalaftervat').value= purchaseinvoice_subtotalaftervat.toFixed(2);
	
	//Delivery Charge
		/*var purchaseinvoice_deliverycharge = parseFloat(document.getElementById("purchaseinvoice_deliverycharge").value);
		if(purchaseinvoice_deliverycharge=='' || isNaN(purchaseinvoice_deliverycharge)){purchaseinvoice_deliverycharge = 0;}
		document.getElementById('purchaseinvoice_deliverycharge').value= purchaseinvoice_deliverycharge.toFixed(2);
		*/
	
	//Total payable Amount
	/*var purchaseinvoice_payableamount = parseFloat(purchaseinvoice_subtotalaftervat + purchaseinvoice_deliverycharge);
	document.getElementById('purchaseinvoice_payableamount').value= purchaseinvoice_payableamount.toFixed(2);
	*/
			
	var purchaseinvoice_receiveamount = parseFloat(document.getElementById("purchaseinvoice_receiveamount").value);
	if(purchaseinvoice_receiveamount=='' || isNaN(purchaseinvoice_receiveamount)){purchaseinvoice_receiveamount = 0;}
	
	var purchaseinvoice_due = parseFloat(purchaseinvoice_subtotalaftervat-purchaseinvoice_receiveamount);
	document.getElementById('purchaseinvoice_due').value=purchaseinvoice_due.toFixed(2);		
	
	
	
	var varTDShowTotalAmount1 = document.getElementById("purchaseinvoice_subtotalaftervat").value;
	document.getElementById("tdShowTotalAmount1").innerHTML = varTDShowTotalAmount1;
		
	}
	
	function check_blankrow(){
		var purchaseinvoice_itemArray = document.getElementsByName('purchaseinvoice_item[]');
		var purchaseinvoice_totalArray = document.getElementsByName('purchaseinvoice_total[]');
			
		var error_messageid = document.getElementById('errmsg_particular_id');
		error_messageid.innerHTML = '';
		
		for(r = 0; r < purchaseinvoice_itemArray.length; r++) {
												
			if(purchaseinvoice_itemArray[r].value==''){
				error_messageid.innerHTML = 'Missing item name '+parseInt(r+1);
				purchaseinvoice_itemArray[r].focus();
				return false;
			}
			
			/*if(purchaseinvoice_totalArray[r].value=='' || purchaseinvoice_totalArray[r].value==0){
				error_messageid.innerHTML = 'Missing item total '+parseInt(r+1);
				purchaseinvoice_totalArray[r].focus();
				return false;
			}*/
		}
		
		return true;
	}

	function addnew_particularrow(animate) {
		if(check_blankrow()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" border=\"1\" align=\"left\" width=\"1125\" cellpadding=\"1\">"+
							'<tbody><tr></tr><tr>'+
								'<td align="center" width=\"130\"> <input type="text" name="purchaseinvoice_item[]" class="tdclass itemname purchaseinvoice_item"/>'+
								'<input type="hidden" name="salesitem_id[]" id="salesitem_id[]" class="tdclass itemname"/>'+
								'<input type="hidden" name="purchaseinvoice_category[]" class="tdclass"/></td>'+
								'<input type="hidden" name="purchaseinvoice_group[]" class="tdclass"/></td>'+
								'<input type="hidden" name="purchaseinvoice_batch[]" class="tdclasssale itemname"/>'+
								'<td align=\"center\" width=\"60\"> <input type="text" name="purchaseinvoice_stock[]" class="tdclasssale itemname"/></td>'+
								
								"<td align=\"center\" width=\"60\"><input type=\"text\" name=\"purchaseitem_pack[]\" class=\"tdclasssale numeric ccrt\" ></td>"+
								"<td align=\"center\" width=\"60\"><input type=\"text\" name=\"purchaseinvoice_pqty[]\" class=\"tdclasssale numeric ccrt\" /></td>"+
								"<td align=\"center\" width=\"60\"><input type=\"text\" name=\"purchaseinvoice_qty[]\" class=\"tdclasssale numeric ccrt\"/></td>"+
								
								"<td align=\"center\" width=\"60\"><input type=\"text\" name=\"purchaseinvoice_purchase_box[]\" class=\"tdclasssale\"/></td>"+											 
								"<td align=\"center\" width=\"60\"><input type=\"text\" name=\"purchaseinvoice_purchase_rate[]\" class=\"tdclasssale\"/></td>"+											 
								"<td align=\"center\" width=\"60\"><input type=\"text\" name=\"purchaseinvoice_rate[]\" class=\"tdclasssale numeric ccrt\"/></td>"+											 
								
								"<td align=\"center\" width=\"60\"><input type=\"text\" name=\"purchaseinvoice_freeqty[]\" class=\"tdclasssale numeric ccrt\"/></td>"+
								"<td align=\"center\" width=\"60\"><input type=\"text\" name=\"purchaseinvoice_totalqty[]\" class=\"tdclasssale numeric ccrt\"/></td>"+
									"<td align=\"center\" width=\"60\"><input type=\"text\" name=\"vat[]\" class=\"tdclasssale numeric ccrt\"/></td>"+
								'<td align="center" width=\"60\"><input type="text" name="purchaseinvoice_discountp[]" class="tdclasssale numeric ccrt"/></td>'+
								"<td align=\"center\" width=\"60\"><input type=\"text\" name=\"purchaseinvoice_disc[]\" class=\"tdclasssale numeric  ccrt\" /></td>"+
								'<td align="center" width=\"60\"><input type="text" readonly name="purchaseinvoice_total[]"  class="tdclasssale numeric ccrt"  /></td>'+
								'<td align="center" width=\"80\"><input  size="7" type="text" name="purchaseinvoice_expire[]" id="purchaseinvoice_expire2" value="<?php echo date('Y-m-d');?>"/><!--<img src="images/cal.gif" onClick=javascript:NewCssCal("purchaseinvoice_expire2") style="cursor:pointer"/>--></td>'+												
								'<td align="center" width="50">'+
								 "<input type=\"button\" value=\"Del\" class=\"tdclasssales deletethislistrow\" />"+
								'</td>'+
							  '</tr></tbody>'+
						"</table>";
						
			var $newparticularlist = $("<li class=\"sirow\"></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(300); 
			else 
			   $newparticularlist.show();   
			document.getElementsByName("purchaseinvoice_item[]")[parseInt(particular_rowcount-1)].focus();
			
			$( ".itemname" ).autocomplete({			
				minLength: 1,
				source: itemdata,
				focus: function( event, ui ) {
					//$( "#search_item_number" ).val( ui.item.saleselval );
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					document.getElementsByName("salesitem_id[]")[indexpos].value = ui.item.salesitem_id;
					document.getElementsByName("purchaseinvoice_purchase_rate[]")[indexpos].value = ui.item.salesitem_purchase_rate;
					document.getElementsByName("purchaseinvoice_rate[]")[indexpos].value = ui.item.salesitem_price;				
					document.getElementsByName("purchaseitem_pack[]")[indexpos].value = ui.item.salesitem_pack;
					document.getElementsByName("purchaseinvoice_qty[]")[indexpos].value = '';					
					document.getElementsByName("purchaseinvoice_category[]")[indexpos].value = ui.item.salesitem_category;
					document.getElementsByName("purchaseinvoice_group[]")[indexpos].value = ui.item.salesitem_group;
					document.getElementsByName("purchaseinvoice_stock[]")[indexpos].value = ui.item.salesitem_stock;
				
					calculateCurrentRowTotal(indexpos);
					
					return false;
				}
			});	
			
			$( ".sirow input.ccrt" ).keyup(function() {
				var index = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				calculateCurrentRowTotal(index);
			});
			
			$( ".sirow input.deletethislistrow" ).click(function() {
				$(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').slideUp(500, function() {
					$(this).remove();
					calculateGrandTotal();
				});
			});
			
			$( ".numeric" ).keyup(function() {
				var price = $(this).val();
				var ValidChars = "-.0123456789";
				var IsNumber=true;
				var Char;
				var validint = '';
				for (var i = 0; i < price.length && IsNumber == true; i++){ 
					Char = price.charAt(i);
					if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
					else{
						validint = validint+Char;
					}
				}
				$(this).val(validint);
			});
			
		$( ".purchaseinvoice_item" ).keypress(function(keyname) {
				if(keyname.which==13){
					var imei = $(this).val();
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					
					$.each(itemarraydata, function(key, value){
						var valuearray = value.split('||');
						if(key==imei){
							document.getElementsByName("salesitem_id[]")[indexpos].value = valuearray[0];
						//document.getElementsByName("salesinvoice_item[]")[indexpos].value = valuearray[1];
						document.getElementsByName("purchaseinvoice_category[]")[indexpos].value = valuearray[1];
						document.getElementsByName("purchaseinvoice_stock[]")[indexpos].value = valuearray[2];
						document.getElementsByName("purchaseinvoice_purchase_rate[]")[indexpos].value = valuearray[3];
						document.getElementsByName("purchaseinvoice_rate[]")[indexpos].value = valuearray[4];
						document.getElementsByName("purchaseinvoice_qty[]")[indexpos].value = '';
							calculateCurrentRowTotal(indexpos);
							addnew_particularrow(true);
						}
					});
					return false;
				}
			});
				
		}
	}
	
	
	
	function funcSaveBill1()
	{
	var varUserChoice; 
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet); 
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		document.frmsales.submit();
		//return true;
	}
}		
</script>