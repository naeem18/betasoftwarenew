<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$message = '';
if(isset($_POST) && array_key_exists('btnAttUpload', $_POST)){
	$message = '<p>There is an error for submit this file.</p>';
	$entry = $out = $update = $empInsert = 0;
	$created_date = $modified_date  = time();
	require_once 'ExcelLibrary/PHPExcel.php';
	//require_once dirname(__FILE__) . '/ExcelLibrary/Classes/PHPExcel/IOFactory.php';
	
	$uploadfile = basename($_FILES['attendance_file']['name']);
	$upload_filearray = explode('.', $uploadfile);				
	$fileextension = $upload_filearray[floor(count($upload_filearray)-1)];
	$tempFile = $_FILES['attendance_file']['tmp_name'];
	$object = PHPExcel_IOFactory::load($tempFile);
	
	$employeeArray = array();
	$empObj = mysqli_query($conn, "SELECT Mobile FROM doctorentry WHERE status = 'Active'");
	if($empObj){
		while($empOneRow=mysqli_fetch_array($empObj)){
			$employeeArray[] = $empOneRow['Mobile'];
		}
	}
	
	$eIds = array();
	foreach($object->getWorksheetIterator() as $worksheet){
		$highestRow = $worksheet->getHighestRow();
		$highestColumn = $worksheet->getHighestColumn();
		//var_dump($highestColumn);
		for($row=2; $row<=$highestRow; $row++){
 			$Name = $worksheet->getCellByColumnAndRow(0, $row)->getValue();
			$Address = $worksheet->getCellByColumnAndRow(1, $row)->getValue();
			$Mobile = ($worksheet->getCellByColumnAndRow(2, $row)->getValue());
			$MPO = $worksheet->getCellByColumnAndRow(3, $row)->getValue();
 			$doctor_date=date('Y-m-d');
			if($Mobile>0){
				if(!in_array($Mobile, $eIds)){
					$eIds[] = $Mobile;
				}
				if(!in_array($Mobile, $employeeArray)){
					$employeeArray[] = $Mobile;
					
					$insertid  = mysqli_query($conn, "INSERT INTO doctorentry SET `doctor_category`='PC', `doctor_name`='$Name', `doctor_address`='$Address', `doctor_mobile`='$Mobile', `mpo`='$MPO', `doctor_date`='$doctor_date'");
					if($insertid){
						$entry++;
					}
					$empInsert++;
				}
				
				 
				$xlsData[] = array(
  					'Name'=>$Name,
					'Address'=>$Address,
					'Mobile'=>$Mobile,
					'MPO'=>$MPO);
			}
		}
	}
	//print_r($xlsData);
	$dptData = 0;
 	
	$message = "<p>Total $dptData Duplicate found and $entry saved</p>";
	if($empInsert>0){
		$message .= "<br>Total $empInsert employee added. Please work on employee setting first then update new Employee information.";
	}
}
?>
<header class="header_tittle">
    <h3>File Import Information</h3>
</header>

<form action="index.php?p=doctorentryupload" enctype="multipart/form-data" onSubmit="return checkFile();" method="post" accept-charset="utf-8">
    <table cellpadding="5" cellspacing="0" width="100%">
    	<?php
        if($message !=''){
			echo $message;
		}
		?>
        <tr>
        	<td width="200">
            	<label>Upload File*:</label>
            </td>
            <td>
            	<input required class="bordernone" type="file" name="attendance_file" id="attendance_file" accept=".xls,.xlsx" />
      			<span class="errormsg" id="errmsg_attendance_file"></span>
            </td>
        </tr>
        <tr>
        	<td width="200">&nbsp;</td>
            <td>
            	<input type="submit" name="btnAttUpload" id="btnAttUpload" class="btn btn-primary backlink" value=" Upload and View " />
		        <input type="button" onClick="resetform();" value="Cancel" class="hidediv btn btn-warning mleft10" />
            </td>
        </tr>
    </table>
</form>

<script type="text/javascript">
    function checkFile(){
        var elementmessage = document.getElementById('errmsg_attendance_file');
        elementmessage.innerHTML = '';
        
        var ext = $('#attendance_file').val().split('.').pop().toLowerCase();
        var allow = new Array('xls','xlsx');
        if(jQuery.inArray(ext, allow) == -1) {
            elementmessage.innerHTML = 'File type is invalid. Only <strong>.xls/.xlsx</strong> file types are allowed.';
            $('#attendance_file').focus();
			
			return false;
        }
        return true;
    }

    function resetform(){
        document.frmImportCustomers.instance_id.value = 0;
        $('#attendance_file').val('');
        $("#formtitle").html('Attendance Import Information');
        $("#btnAttUpload").val(' Upload and View ');                                                
    }
</script>
<table align="left" width="100%" border="1" style="BORDER-COLLAPSE: collapse;" cellspacing="1" cellpadding="3">
      <tr>
        <td colspan="100%" bgcolor="#0033FF" align="center" style="color:#fff; border:1px solid #03F;">
             <strong>PC MPO Information </strong>
        </td>
      </tr>
      <tr bgcolor="#ccc" align="center">
        <td>ID</td>
        <td>Name</td>
        <td>Address</td>
        <td>Mobile*(Must be unique)</td>
        <td>MPO</td>
      </tr>
    
 
				 
</table>