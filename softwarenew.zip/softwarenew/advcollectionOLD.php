<?php
$patientdata = '';
$sqlopregistration = "select * from opregistration where status!= 'Released' order by opregistration_id asc";
$opregistrationquery = mysqli_query($conn, $sqlopregistration);
if($opregistrationquery && mysqli_num_rows($opregistrationquery)>0){

	while ($oprow = mysqli_fetch_array($opregistrationquery))
	{
		$opregistration_id = $oprow['opregistration_id'];
		$opregistration_code = $oprow['opregistration_code'];
		$opregistration_name = $oprow['opregistration_name'];
		$ward = $oprow['ward'];
		$advanced = $oprow['advanced'];
		$admissionfee = $oprow['admissionfee'];
		$opregistration_mobile = $oprow['opregistration_mobile'];
		$opregistration_address = $oprow['opregistration_address'];
		$patientdata[] =array( 'labelval' => $opregistration_name,
							'label' => 'ID:'.$opregistration_id. ' Code:'. $opregistration_code.' Name:'. $opregistration_name,
							'opregistration_id'=>$opregistration_id,
							'opregistration_code'=>$opregistration_code,
							'advanced'=>$advanced,
							'admissionfee'=>$admissionfee,
							'ward'=>$ward,
							'opregistration_mobile'=>$opregistration_mobile,
							'opregistration_address'=>$opregistration_address
							);
		}
	}
$patientdata = json_encode($patientdata);
?>

<link rel="stylesheet" href="autocomplete/jquery-ui.css">
<script src="autocomplete/jquery-ui.min.js"></script>

<script language="JavaScript" type="text/javascript">
	
	var patientdata = <?php echo $patientdata;?>;
	$(document).ready(function($) {
		
		
		$( "#opregistration_idsearch" ).autocomplete({
			 
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
 				document.getElementById('labcollection_name').value = ui.item.labelval;
				document.getElementById('labcollection_number').value = ui.item.opregistration_mobile;
				document.getElementById('opregistration_idsearch').value = ui.item.opregistration_id;
				document.getElementById('opregistration_id').value = ui.item.opregistration_id;
				document.getElementById('opregistration_code').value = ui.item.opregistration_code;
				document.getElementById('labcollection_ward').value = ui.item.ward;
				document.getElementById('advanced').value = ui.item.advanced;
				document.getElementById('admissionfee').value = ui.item.admissionfee;
				document.getElementById('labcollection_address').value = ui.item.opregistration_address;
 				return false;
			}
		});
		
			
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
	});
	
		
	function calculate_total(){
 		var advanced = parseFloat(document.getElementById("advanced").value);
		if(advanced=='' || isNaN(advanced)){advanced = 0;}
		
		var collection_amount = parseFloat(document.getElementById("collection_amount").value);
		if(collection_amount=='' || isNaN(collection_amount)){collection_amount = '';}
		
		var total_balance = parseFloat(advanced + collection_amount);
		document.getElementById('total_balance').value=	total_balance.toFixed(2);
 		}
		
	function funcSaveBill1()
	{
	var varUserChoice;
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet);
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		document.frmsales.submit();
		//return true;
	}
}	
</script>

<article class="bottomcontent">
	<h3 align="center">Admission Fee/Advanced Collection</h3>
    <content>
      <?php
        if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
            echo "<p class=\"red12bold\">You have missing Something</p>";
        }
        elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
            echo "<p class=\"red12bold\">Error occured! Could not insert.</p>";   
        }
        elseif(isset($_GET['message']) && $_GET['message']=='insert-successfully'){
            echo "<p class=\"red12bold\">Information insert successfully. Click Print Button To Print or View Previous Bill <td width=\"30\" align=\"center\" >
			<a onclick=\"PrintDiv();\"><input type=\"button\" required value=\"Print\" class=\"tdclass\"  /></a></td></p>";   
        }
       ?>          
<form action="save_advanced.php" name="frmcontact" id="frmcontact" onsubmit="return checkcontactform();" onKeyDown="return disableEnterKey(event)" method="post" enctype="multipart/form-data">
<table width="500" align="center" border="0" bgcolor="#ccc" cellpadding="2">
  		<tr>
        <td width="220" align="right">Select Section</td>
             <td>
                <select required id="type" name="type" >
                    <option value="">Select</option>
                    <option value="Admission Fee">Admission Fee</option>
                    <option value="Advanced">Advanced</option>
                 </select>
            </td>
            </tr>
            
  <tr>
  	<input type="hidden" name="uniqid" id="uniqid" value="<?php echo rand(10000, 99999);?>">
    <input type="hidden" name="user" id="user" required value="<?php echo $_SESSION['fullname'];?>" size="30" />
    <td align="right"><strong>SEARCH BY ID/CODE</strong></td>
    <td><input type="text" required name="opregistration_idsearch" id="opregistration_idsearch" size="30" /></td>
  </tr>
  <tr>
    <td align="right">PID</td>
    <td><input type="hidden" required name="opregistration_code" id="opregistration_code" size="30"/>
        <input type="text" readonly name="opregistration_id" id="opregistration_id" size="30" />
    </td>
  </tr>
   
   <tr>
    <td align="right">Name</td>
    <td><input type="text" readonly name="labcollection_name" id="labcollection_name" required size="30" /></td>
   </tr>
   
   <tr>
    <td align="right">Mobile </td>
    <td><input readonly type="text" name="labcollection_number" id="labcollection_number" size="30" /></td>
   </tr>
   
   <tr>
       <td align="right">Ward </td>
       <td><input readonly type="text" name="labcollection_ward" id="labcollection_ward" size="30" /></td>
           <input type="hidden" name="labcollection_address" id="labcollection_address" size="30" />
   </tr>
   
   <tr>
     <td align="right">Date: </td>
     <td><input type="text" name="labcollection_date" readonly id="labcollection_date" value="<?php echo date('Y-m-d H:i:s');?>" size="30" /></td>
    	<input type="hidden" name="labcollection_update" id="labcollection_update" class="tdclass2" />
  </tr>
 </table>

 <table align="center" border="0" width="500" cellpadding="2" bgcolor="#f2f2f2">
    <tr>
    <td align="right">Note </td>
    <td><textarea style="width:450px" type="text" name="note" id="note"/></textarea></td>
    </tr>
 </table>	
		
  <table border="0" width="500" align="center" bgcolor="#e3e7ff" cellpadding="2">
    <tr><td></td></tr>
    <tr>
     <td align="right" style="border-top:1px solid #999;">Current Advance Paid: </td>
    	<td width="50" style="border-top:1px solid #999;"> 
        <input type="text" readonly name="advanced" id="advanced" size="30" onKeyUp="calculate_total();" /></td>
    </tr>
    
     <tr>
     <td align="right">Admission Fee Due: </td>
     <td><input type="text" readonly name="admissionfee" id="admissionfee" size="30" class="numeric" onKeyUp="calculate_total();" /></td>
  	</tr>
    
    <tr>
     <td align="right"><strong>Collection Amount</strong>: </td>
     <td><input type="text" required name="collection_amount" id="collection_amount" size="30" class="numeric" onKeyUp="calculate_total();" /></td>
  	</tr>
    
    <tr>
     <td align="right">Total Balance: </td>
     <td><input type="text" readonly name="total_balance" id="total_balance" size="30" class="numeric" onKeyUp="calculate_total();" /></td>
  	</tr>
    
    <tr>
     <td align="right"></td>
	 <td align="right">
         <input type="hidden" name="advanced_id" id="advanced_id" value="<?php echo $advanced_id;?>">
       	 <input type="submit" value=" save " name="submit_invoice" id="submit_invoice" class="tdclass1" onClick="return funcSaveBill1()"  />
      </td>
  	</tr>
 </table>
</form>
 </content>
</article>

<div id="divToPrint" style="display:none;">
<article style="margin:0 auto">
  	<?php
		$advanced_id = $_GET['advanced_id'];
        $labinvoice_sql = "select * from advanced where advanced_id = $advanced_id ";
        $labinvoicequery = mysqli_query($conn, $labinvoice_sql);
        if($labinvoicequery && mysqli_num_rows($labinvoicequery)>0){
            while ($onerow = mysqli_fetch_array($labinvoicequery)){
               	$opregistration_id = $onerow['opregistration_id'];
              	$opregistration_code = $onerow['opregistration_code'];
              	$advanced_id = $onerow['advanced_id'];
                $advanced = $onerow['advanced'];
                $ward = $onerow['ward'];
                $advanced_date = $onerow['advanced_date'];
				$name = $onerow['name'];
                $user = $onerow['user'];
				$note = $onerow['note'];
				
				$sqlst2 = "select opregistration_doctor,opregistration_mobile from opregistration where opregistration_id='$opregistration_id'";
				$exec3 = mysqli_query($conn, $sqlst2) or die ("Error in Query3".mysql_error());
				$onerow = mysqli_fetch_array($exec3);
					$opregistration_doctor = $onerow['opregistration_doctor'];
					$opregistration_mobile = $onerow['opregistration_mobile'];
                 ?>
                
        <?php if($heading=='Yes'){ ?>
        <table width="100%" border="1" style="border-collapse:collapse;" align="center">
           <tr>
            <td align="left">
              <div style="padding-left:15px; color:#000;font-size:21px"><strong><?php echo $hospitaldata_name;?></strong></div>
              <div style="padding-left:15px;color:#000;font-size:16px"><?php echo $hospitaldata_address1;?></div>
              <div style="padding-left:15px;font-size:15px;"><?php echo 'Contact : '; ?><?php echo $hospitaldata_mobile;?></div>
            </td>
           </tr>
        </table>
         <?php }?>              
        <table width="100%" align="center" style="border:1px solid #999;font-size:15px;
          <?php if($heading=='Yes'){ ?> margin-top:2px<?php }?> <?php if($heading=='No'){ ?> margin-top:55px<?php }?>" bgcolor="#FFF" cellpadding="0">
          <tr>
            <td width="300" align="left">
                <div><strong>Patient Code : <?php echo $opregistration_id;?></strong> </div>
                <div><strong>Patient : <?php echo $name;?> </strong> </div>
                <div><strong>Ward : <?php echo $ward;?> </strong> </div>
            </td>
            <td width="200" align="right">
                <div style="font-size:14px"><strong>Advance Received Invoice</strong></div>
                <div>Invoice No : <?php echo $advanced_id;?></div>
                 <div><strong>Mobile : <?php echo $opregistration_mobile;?> </strong> </div>
                <div>Date : <?php echo $advanced_date;?></div>
           </td>
          </tr>
          <tr><td colspan="6">Dr.: <?php echo $opregistration_doctor;?></td></tr>
         </table>
                         
          <table width="100%" align="center" bgcolor="#FFF" style=" font-size:17px; border:1px #999 solid; border-top:none;">
              <tr height="20" align="center">
                <td style="border:1px solid #999;"><strong>Particular</strong></td>
                <td style="border:1px solid #999;">Amount</td>
              </tr>
             
                <tr align="center">
                	<td style="padding:30px 0;"><?php echo 'Paid Amount'?></td>
                	<td style="padding:30px 0;"><strong><?php echo $advanced;?></strong></td>
                </tr>
             </table>
                 <?php
				}
			}
          ?>
         <table align="center" style="font-size:12px; font-style:italic">
        	<tr>
                <td><?php include ("convert_currency_to_words.php");
                echo 'InWord:';	echo covert_currency_to_words($advanced); ?>
                </td>
            </tr>
        </table>
       
        <table width="100%" align="center" style=" font-size:12px; padding:5px 2px" bgcolor="#FFF" cellpadding="0">
         <tr>
            <td width="350">
                <div align="left">Prepared By: <?php echo $user; ?></div>
            </td>
            <td width="200">
                <div style="padding-bottom:10px" align="right"></div>
                <div align="right">Received By</div>
            </td>
         </tr>
        </table>
        <table align="center" style="font-size:12px; font-style:italic">
        	<tr>
                <td align="left"><?php echo $note; ?>
                </td>
            </tr>
        </table>

    <table width="100%" align="center" >
    	<tr>
        	<td width="300" style=" font-size:10px">Software by: Betasofts.com</td>
        </tr>
    </table>
 </article>
</div>