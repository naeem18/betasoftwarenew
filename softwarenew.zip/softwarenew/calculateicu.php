<script language="JavaScript" type="text/javascript">
	
	var itemdata = <?php echo $itemdata;?>;
	var patientdata = <?php echo $patientdata;?>;
	var pcdata = <?php echo $pcdata;?>;
	//var cabin = <?php //echo $cabin;?>;
	$(document).ready(function($) {
		document.getElementsByName("hospitalinvoiceicu_item[]")[0].focus();

		$( ".itemname" ).autocomplete({
			
			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				var hospitalinvoiceicu_ratearray = document.getElementsByName("hospitalinvoiceicu_rate[]");
				hospitalinvoiceicu_ratearray[indexpos].value = ui.item.hospitalitem_price;
				
				var hospitalinvoiceicu_qtyarray = document.getElementsByName("hospitalinvoiceicu_qty[]");
				hospitalinvoiceicu_qtyarray[indexpos].value = 1;
				
  				
			var hospitalinvoiceicu_surgeoncommissionarray = document.getElementsByName("hospitalinvoiceicu_surgeoncommission[]");
			hospitalinvoiceicu_surgeoncommissionarray[indexpos].value = ui.item.hospitalitem_surgeoncommission;
			
			var hospitalinvoiceicu_cosurgeoncommissionarray = document.getElementsByName("hospitalinvoiceicu_cosurgeoncommission[]");
			hospitalinvoiceicu_cosurgeoncommissionarray[indexpos].value = ui.item.hospitalitem_cosurgeoncommission;
			
			var hospitalinvoiceicu_anaesthesiacommissionarray=document.getElementsByName("hospitalinvoiceicu_anaesthesiacommission[]");
			hospitalinvoiceicu_anaesthesiacommissionarray[indexpos].value = ui.item.hospitalitem_anaesthesiacommission;
			
 				
				var hospitalinvoiceicu_pccomissionarray = document.getElementsByName("hospitalinvoiceicu_pccomission[]");
				hospitalinvoiceicu_pccomissionarray[indexpos].value = ui.item.hospitalitem_pccommission;
				
				var hospitalinvoiceicu_categoryarray = document.getElementsByName("hospitalinvoiceicu_category[]");
				hospitalinvoiceicu_categoryarray[indexpos].value = ui.item.hospitalitem_category;
				
				var hospitalinvoiceicu_unitarray = document.getElementsByName("hospitalinvoiceicu_unit[]");
				hospitalinvoiceicu_unitarray[indexpos].value = ui.item.hospitalitem_unit;
				
				var hospitalinvoiceicu_refvaluearray = document.getElementsByName("hospitalinvoiceicu_refvalue[]");
				hospitalinvoiceicu_refvaluearray[indexpos].value = ui.item.hospitalitem_refvalue;
				
				calculaterowtotal(indexpos);
				calculate_pctotal();
				calculate_surgeontotal();
				calculate_cosurgeontotal();
				calculate_anaesthesiatotal();
				return false;
			}
		});
		
		
		$( "#hospitalinvoiceicu_patientid" ).autocomplete({
			
			minLength: 1,
			source: patientdata,
			
			focus: function( event, ui ) {
 				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
 				 document.getElementById('hospitalinvoiceicu_patient').value = ui.item.labelval;
				 document.getElementById('hospitalinvoiceicu_patientid').value = ui.item.opregistration_id;
				 document.getElementById('hospitalinvoiceicu_patientcode').value = ui.item.opregistration_code;
				 document.getElementById('hospitalinvoiceicu_age').value = ui.item.opregistration_age;
				 document.getElementById('hospitalinvoiceicu_pc').value = ui.item.pcname;
				 //document.getElementById('hospitalinvoiceicu_icu_due').value = ui.item.icu_due;
				 document.getElementById('hospitalinvoiceicu_cabin').value = ui.item.ward;
				 document.getElementById('hospitalinvoiceicu_gender').value = ui.item.opregistration_gender;
				 document.getElementById('hospitalinvoiceicu_mobile').value = ui.item.opregistration_mobile;
				 document.getElementById('hospitalinvoiceicu_address').value = ui.item.opregistration_address;
				 document.getElementById('hospitalinvoiceicu_admissiondate').value = ui.item.opregistration_date;
 				return false;
			}
		});
		
 		// pc search
		$( "#hospitalinvoiceicu_pc" ).autocomplete({
			
			minLength: 1,
			source: pcdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('hospitalinvoiceicu_pc').value = ui.item.labelval;
				 document.getElementById('hospitalinvoiceicu_mpo').value = ui.item.mpo;
				
				return false;
			}
		});
		
		/*$( "#hospitalinvoiceicu_patientid" ).autocomplete({
			
			minLength: 1,
			source: cabin,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('hospitalinvoiceicu_ward').value = ui.item.labelval;
				
				return false;
			}
		});
		*/
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
	});
	function calculate_discountp(){
		var hospitalinvoiceicu_discountparray = document.getElementsByName("hospitalinvoiceicu_discountp[]");
		var hospitalinvoiceicu_discarray = document.getElementsByName("hospitalinvoiceicu_disc[]");
		var hospitalinvoiceicu_ratearray = document.getElementsByName("hospitalinvoiceicu_rate[]");
		var hospitalinvoiceicu_qtyarray = document.getElementsByName("hospitalinvoiceicu_qty[]");
		if(hospitalinvoiceicu_discountparray.length>0){
			for(var p=0; p<hospitalinvoiceicu_discountparray.length; p++){
				var hospitalinvoiceicu_discountp = parseFloat(hospitalinvoiceicu_discountparray[p].value);
				if(hospitalinvoiceicu_discountp=='' || isNaN(hospitalinvoiceicu_discountp)){hospitalinvoiceicu_discountp = 0;}
				
				var hospitalinvoiceicu_disc = parseFloat(hospitalinvoiceicu_discarray[p].value);
				if(hospitalinvoiceicu_disc=='' || isNaN(hospitalinvoiceicu_disc)){hospitalinvoiceicu_disc = 0;}
				if(hospitalinvoiceicu_discountp>0){
					var hospitalinvoiceicu_rate = parseFloat(hospitalinvoiceicu_ratearray[p].value);
					if(hospitalinvoiceicu_rate=='' || isNaN(hospitalinvoiceicu_rate)){hospitalinvoiceicu_rate = 0;}
					
					var hospitalinvoiceicu_qty = hospitalinvoiceicu_qtyarray[p].value;
					if(hospitalinvoiceicu_qty=='' || isNaN(hospitalinvoiceicu_qty)){hospitalinvoiceicu_qty = 0;}
					
					var total = parseFloat(hospitalinvoiceicu_rate*hospitalinvoiceicu_qty);			
					var hospitalinvoiceicu_disc = parseFloat(total*hospitalinvoiceicu_discountp*0.01);
					
					hospitalinvoiceicu_discarray[p].value = hospitalinvoiceicu_disc.toFixed(2);
				}
				
				calculaterowtotal(p);
			}
		}
	}
	
	function calculaterowtotal(indexpos){
		if(indexpos=='all'){
			var hospitalinvoiceicu_ratearray = document.getElementsByName("hospitalinvoiceicu_rate[]");
			var hospitalinvoiceicu_qtyarray = document.getElementsByName("hospitalinvoiceicu_qty[]");
			var hospitalinvoiceicu_discarray = document.getElementsByName("hospitalinvoiceicu_disc[]");
			var hospitalinvoiceicu_totalarray = document.getElementsByName("hospitalinvoiceicu_total[]");
			
			if(hospitalinvoiceicu_ratearray.length>0){
				for(var p=0; p<hospitalinvoiceicu_ratearray.length; p++){
					var hospitalinvoiceicu_rate = parseFloat(hospitalinvoiceicu_ratearray[p].value);
					if(hospitalinvoiceicu_rate=='' || isNaN(hospitalinvoiceicu_rate)){hospitalinvoiceicu_rate = 0;}
					
					var hospitalinvoiceicu_qty = parseFloat(hospitalinvoiceicu_qtyarray[p].value);
					if(hospitalinvoiceicu_qty=='' || isNaN(hospitalinvoiceicu_qty)){hospitalinvoiceicu_qty = 0;}
					
					var total = parseFloat(hospitalinvoiceicu_rate*hospitalinvoiceicu_qty);
					
					var hospitalinvoiceicu_disc = parseFloat(hospitalinvoiceicu_discarray[p].value);
					if(hospitalinvoiceicu_disc=='' || isNaN(hospitalinvoiceicu_disc)){hospitalinvoiceicu_disc = 0;}
					
					var total = parseFloat(total-hospitalinvoiceicu_disc);
					
					hospitalinvoiceicu_totalarray[p].value = total.toFixed(2);
				}
			}
			
		}
		else{
			var hospitalinvoiceicu_ratearray = document.getElementsByName("hospitalinvoiceicu_rate[]");
			var hospitalinvoiceicu_rate = parseFloat(hospitalinvoiceicu_ratearray[indexpos].value);
			if(hospitalinvoiceicu_rate=='' || isNaN(hospitalinvoiceicu_rate)){hospitalinvoiceicu_rate = 0;}
			
			var hospitalinvoiceicu_qtyarray = document.getElementsByName("hospitalinvoiceicu_qty[]");
			var hospitalinvoiceicu_qty = parseFloat(hospitalinvoiceicu_qtyarray[indexpos].value);
			if(hospitalinvoiceicu_qty=='' || isNaN(hospitalinvoiceicu_qty)){hospitalinvoiceicu_qty = 0;}
			
			var total = parseFloat(hospitalinvoiceicu_rate*hospitalinvoiceicu_qty);
			
			var hospitalinvoiceicu_discarray = document.getElementsByName("hospitalinvoiceicu_disc[]");
			var hospitalinvoiceicu_disc = parseFloat(hospitalinvoiceicu_discarray[indexpos].value);
			if(hospitalinvoiceicu_disc=='' || isNaN(hospitalinvoiceicu_disc)){hospitalinvoiceicu_disc = 0;}
			
			var total = parseFloat(total-hospitalinvoiceicu_disc);
			
			var hospitalinvoiceicu_totalarray = document.getElementsByName("hospitalinvoiceicu_total[]");
			hospitalinvoiceicu_totalarray[indexpos].value = total.toFixed(2);
		}
		
		calculate_total();
	}
	
	function calculate_total(){
		var hospitalinvoiceicu_icu_due = parseFloat(document.getElementById("hospitalinvoiceicu_icu_due").value);
		if(hospitalinvoiceicu_icu_due=='' || isNaN(hospitalinvoiceicu_icu_due)){hospitalinvoiceicu_icu_due = 0;}
		
		
		var hospitalinvoiceicu_subtotal = 0;
		var hospitalinvoiceicu_totalarray = document.getElementsByName("hospitalinvoiceicu_total[]");
		if(hospitalinvoiceicu_totalarray.length>0){
			for(var p=0; p<hospitalinvoiceicu_totalarray.length; p++){
				var hospitalinvoiceicu_total = parseFloat(hospitalinvoiceicu_totalarray[p].value);
				if(hospitalinvoiceicu_total=='' || isNaN(hospitalinvoiceicu_total)){hospitalinvoiceicu_total = 0;}
				hospitalinvoiceicu_subtotal = parseFloat(hospitalinvoiceicu_subtotal+hospitalinvoiceicu_total);
			}
		}
		//subtotal calculation
		document.getElementById("hospitalinvoiceicu_subtotal").value = (hospitalinvoiceicu_subtotal).toFixed(2);
		
		var hospitalinvoiceicu_totaldiscp = parseFloat(document.getElementById("hospitalinvoiceicu_totaldiscp").value);
		if(hospitalinvoiceicu_totaldiscp=='' || isNaN(hospitalinvoiceicu_totaldiscp)){hospitalinvoiceicu_totaldiscp = 0;}
		
		var hospitalinvoiceicu_totaldisc = parseFloat(document.getElementById("hospitalinvoiceicu_totaldisc").value);
		if(hospitalinvoiceicu_totaldisc=='' || isNaN(hospitalinvoiceicu_totaldisc)){hospitalinvoiceicu_totaldisc = 0;}
		
		var hospitalinvoiceicu_icu_due = parseFloat(document.getElementById("hospitalinvoiceicu_icu_due").value);
		if(hospitalinvoiceicu_icu_due=='' || isNaN(hospitalinvoiceicu_icu_due)){hospitalinvoiceicu_icu_due = 0;}
		
		
		
		if(hospitalinvoiceicu_totaldiscp>0){
			var hospitalinvoiceicu_totaldisc = parseFloat(hospitalinvoiceicu_subtotal*hospitalinvoiceicu_totaldiscp*0.01);
			document.getElementById('hospitalinvoiceicu_totaldisc').value= hospitalinvoiceicu_totaldisc.toFixed(2);
		}
		
		var service = parseFloat((hospitalinvoiceicu_subtotal)*0.20);
		document.getElementById('service').value=	service.toFixed(2);
		
		//var gross = parseFloat(hospitalinvoiceicu_icu_due+hospitalinvoiceicu_subtotal + service);
		//document.getElementById('gross').value=	gross.toFixed(2);
		
		var gross = parseFloat(hospitalinvoiceicu_subtotal + service);
		document.getElementById('gross').value=	gross.toFixed(2);
		
		
		//var hospitalinvoiceicu_subtotalafterdisc = parseFloat(hospitalinvoiceicu_icu_due+hospitalinvoiceicu_subtotal + service-hospitalinvoiceicu_totaldisc);
		//document.getElementById('hospitalinvoiceicu_subtotalafterdisc').value=	hospitalinvoiceicu_subtotalafterdisc.toFixed(2);
		
		var hospitalinvoiceicu_subtotalafterdisc = parseFloat(hospitalinvoiceicu_subtotal +hospitalinvoiceicu_icu_due + service-hospitalinvoiceicu_totaldisc);
		document.getElementById('hospitalinvoiceicu_subtotalafterdisc').value=	hospitalinvoiceicu_subtotalafterdisc.toFixed(2);
			
		var hospitalinvoiceicu_receiveamount = parseFloat(document.getElementById("hospitalinvoiceicu_receiveamount").value);
		if(hospitalinvoiceicu_receiveamount=='' || isNaN(hospitalinvoiceicu_receiveamount)){hospitalinvoiceicu_receiveamount = 0;}
		
		var hospitalinvoiceicu_due = parseFloat(hospitalinvoiceicu_subtotalafterdisc-hospitalinvoiceicu_receiveamount);
		document.getElementById('hospitalinvoiceicu_due').value=hospitalinvoiceicu_due.toFixed(2);		
		
	}
	
	function calculate_pctotal(){
		var hospitalinvoiceicu_totalpccomission = 0;
		var hospitalinvoiceicu_pccomissionarray = document.getElementsByName("hospitalinvoiceicu_pccomission[]");
		if(hospitalinvoiceicu_pccomissionarray.length>0){
			for(var p=0; p<hospitalinvoiceicu_pccomissionarray.length; p++){
				var hospitalinvoiceicu_pccomission = parseFloat(hospitalinvoiceicu_pccomissionarray[p].value);
				if(hospitalinvoiceicu_pccomission=='' || isNaN(hospitalinvoiceicu_pccomission)){hospitalinvoiceicu_pccomission = 0;}
				hospitalinvoiceicu_totalpccomission = parseFloat(hospitalinvoiceicu_totalpccomission+hospitalinvoiceicu_pccomission);
			}
		}
		
		document.getElementById("hospitalinvoiceicu_totalpccomission").value = hospitalinvoiceicu_totalpccomission.toFixed(2);
		
	}
	


	

function calculate_surgeontotal(){
	var hospitalinvoiceicu_totalsurgeoncomission = 0;
	var hospitalinvoiceicu_surgeoncommissionarray = document.getElementsByName("hospitalinvoiceicu_surgeoncommission[]");
	if(hospitalinvoiceicu_surgeoncommissionarray.length>0){
		for(var p=0; p<hospitalinvoiceicu_surgeoncommissionarray.length; p++){
			var hospitalinvoiceicu_surgeoncommission = parseFloat(hospitalinvoiceicu_surgeoncommissionarray[p].value);
			if(hospitalinvoiceicu_surgeoncommission=='' || isNaN(hospitalinvoiceicu_surgeoncommission)){hospitalinvoiceicu_surgeoncommission = 0;}
		hospitalinvoiceicu_totalsurgeoncomission = parseFloat(hospitalinvoiceicu_totalsurgeoncomission+hospitalinvoiceicu_surgeoncommission);
		}
	}
	document.getElementById("hospitalinvoiceicu_totalsurgeoncomission").value = hospitalinvoiceicu_totalsurgeoncomission.toFixed(2);
	}
	
	
	function calculate_cosurgeontotal(){
		var hospitalinvoiceicu_totalcosurgeoncomission = 0;
		var hospitalinvoiceicu_cosurgeoncommissionarray = document.getElementsByName("hospitalinvoiceicu_cosurgeoncommission[]");
		if(hospitalinvoiceicu_cosurgeoncommissionarray.length>0){
			for(var p=0; p<hospitalinvoiceicu_cosurgeoncommissionarray.length; p++){
				var hospitalinvoiceicu_cosurgeoncommission = parseFloat(hospitalinvoiceicu_cosurgeoncommissionarray[p].value);
				if(hospitalinvoiceicu_cosurgeoncommission=='' || isNaN(hospitalinvoiceicu_cosurgeoncommission)){hospitalinvoiceicu_cosurgeoncommission = 0;}
				hospitalinvoiceicu_totalcosurgeoncomission = parseFloat(hospitalinvoiceicu_totalcosurgeoncomission+hospitalinvoiceicu_cosurgeoncommission);
			}
		}
		document.getElementById("hospitalinvoiceicu_totalcosurgeoncomission").value = hospitalinvoiceicu_totalcosurgeoncomission.toFixed(2);
	}		
	
	
	function calculate_anaesthesiatotal(){
		var hospitalinvoiceicu_totalanaesthesiacomission = 0;
		var hospitalinvoiceicu_anaesthesiacommissionarray = document.getElementsByName("hospitalinvoiceicu_anaesthesiacommission[]");
		if(hospitalinvoiceicu_anaesthesiacommissionarray.length>0){
			for(var p=0; p<hospitalinvoiceicu_anaesthesiacommissionarray.length; p++){
				var hospitalinvoiceicu_anaesthesiacommission = parseFloat(hospitalinvoiceicu_anaesthesiacommissionarray[p].value);
				if(hospitalinvoiceicu_anaesthesiacommission=='' || isNaN(hospitalinvoiceicu_anaesthesiacommission)){hospitalinvoiceicu_anaesthesiacommission = 0;}
				hospitalinvoiceicu_totalanaesthesiacomission = parseFloat(hospitalinvoiceicu_totalanaesthesiacomission+hospitalinvoiceicu_anaesthesiacommission);
			}
		}
		
		document.getElementById("hospitalinvoiceicu_totalanaesthesiacomission").value = hospitalinvoiceicu_totalanaesthesiacomission.toFixed(2);
		
	}
	
		
	
	function check_particular(){
		/*var particular_idlistarray = new Array();
		var particular_id = document.getElementsByName('particular_id[]');
		var particular_count = particular_id.length;
		var particular_priceid = document.getElementsByName('particular_price[]');
		var particular_qtyid = document.getElementsByName('particular_qty[]');
			
		var error_messageid = document.getElementById('errmsg_particular_id');
		error_messageid.innerHTML = '';
		
		for(i = 0; i < particular_count; i++) {
												
			if(particular_id[i].value=='' || particular_id[i].value==0){
				error_messageid.innerHTML = 'Missing Particular Name '+parseInt(i+1);
				particular_id[i].focus();
				returnvalue = false;
			}
			
			if(particular_idlistarray.length>0 && particular_idlistarray.indexOf(particular_id[i].value) != -1){
				error_messageid.innerHTML = 'Dupplicate Particular Name '+i;
				particular_id[i].focus();
				return false;
			}
			else{
				particular_idlistarray[i] = particular_id[i].value;
			}
			
			var particular_priceval = parseInt(particular_priceid[i].value);
			if(isNaN(particular_priceval) || particular_priceval==''){particular_priceval = 0;}
			if(particular_priceval==0){
				error_messageid.innerHTML = 'Missing Price '+Math.floor(i+1);
				particular_priceid[i].focus();
				return false;
			}
										
			var particular_qtyval = parseInt(particular_qtyid[i].value);
			if(isNaN(particular_qtyval) || particular_qtyval==''){particular_qtyval = 0;}							
			if(particular_qtyval==0){
				error_messageid.innerHTML = 'Missing QTY '+Math.floor(i+1);
				particular_qtyid.focus();
				return false;
			}
		}*/
		return true;
	}
	function addnew_particularrow(animate) {
		if(check_particular()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" style=\"BORDER-COLLAPSE: collapse; border:2px solid #FFF\" bgcolor=\"#9DCEFF\" align=\"left\" width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"2\">"+
							'<tr>'+
								'<td align="right">Particular</td>'+
								'<td> <input type="text" name="hospitalinvoiceicu_item[]" value="" class="tdclass itemname"/></td>'+
								 '<input type="hidden" name="auto_number[]" value=""/>'+ 
								 '<input type="hidden" name="hospitalinvoiceicu_category[]" value="" class="tdclass"  />'+
								'<input type="hidden" name="hospitalinvoiceicu_unit[]" value="" class="tdclass"  />'+
								'<input type="hidden" name="hospitalinvoiceicu_refvalue[]" value="" class="tdclass"  />'+
								'<td align="right">Charge</td>'+
								"<td> <input type=\"text\" name=\"hospitalinvoiceicu_rate[]\"  id=\"hospitalinvoiceicu_rate\" value=\"\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/></td>"+											 
								'<td align="right">Qty</td>'+
								"<td> <input type=\"text\" name=\"hospitalinvoiceicu_qty[]\"   id=\"hospitalinvoiceicu_qty\" value=\"\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/></td>"+
								'<!--<td align="right">Disc%</td>-->'+
								'<td> <input type="hidden" name="hospitalinvoiceicu_discountp[]" value="" class="tdclasssale" onKeyUp="calculate_discountp();"/></td>'+
								'<!--<td align="right">Disc</td>-->'+
								"<td> <input type=\"hidden\" name=\"hospitalinvoiceicu_disc[]\" value=\"\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\" /></td>"+
								
								
								
							'<td align="right">Surgeon</td>'+
							"<td> <input type=\"text\" name=\"hospitalinvoiceicu_surgeoncommission[]\" id=\"hospitalinvoiceicu_surgeoncommission\"  class=\"tdclasssale\" /></td>"+
							
							'<td align="right">Assist</td>'+
							"<td><input type=\"text\" name=\"hospitalinvoiceicu_cosurgeoncommission[]\" id=\"hospitalinvoiceicu_cosurgeoncommission\" class=\"tdclasssale\" /></td>"+
							
							'<td align="right">Anaesthesist</td>'+
							"<td> <input type=\"text\" name=\"hospitalinvoiceicu_anaesthesiacommission[]\" id=\"hospitalinvoiceicu_anaesthesiacommission\" class=\"tdclasssale\" /></td>"+
								
								
								
								
								'<!--<td align="right">P.C</td>-->'+
								'<td> <input type="hidden" name="hospitalinvoiceicu_pccomission[]" value="" class="tdclasssale" onKeyUp="calculate_pctotal();"  /></td>'+
								'<td align="right">Total</td>'+
								'<td> <input type="text" readonly name="hospitalinvoiceicu_total[]"  id="hospitalinvoiceicu_total" value="" class="tdclasssale"  /></td>'+												
								'<td>'+
								 "<input type=\"button\" value=\"Cancel\" onClick=\"deletethislistrow('particularlistrowno"+particular_rowcount+"');\" class=\"tdclasssale\"  />"+
								'</td>'+
							  '</tr>'+
						"</table>";
						
			var $newparticularlist = $("<li></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(200); 
			else 
			   $newparticularlist.show();   
			document.getElementsByName("hospitalinvoiceicu_item[]")[parseInt(particular_rowcount-1)].focus();
			
			$( ".itemname" ).autocomplete({			
				minLength: 1,
				source: itemdata,
				focus: function( event, ui ) {
					//$( "#search_item_number" ).val( ui.item.labelval );
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					
					var hospitalinvoiceicu_ratearray = document.getElementsByName("hospitalinvoiceicu_rate[]");
					hospitalinvoiceicu_ratearray[indexpos].value = ui.item.hospitalitem_price;
					
					var hospitalinvoiceicu_qtyarray = document.getElementsByName("hospitalinvoiceicu_qty[]");
					hospitalinvoiceicu_qtyarray[indexpos].value = 1;
					
					
			var hospitalinvoiceicu_surgeoncommissionarray = document.getElementsByName("hospitalinvoiceicu_surgeoncommission[]");
			hospitalinvoiceicu_surgeoncommissionarray[indexpos].value = ui.item.hospitalitem_surgeoncommission;
			
			var hospitalinvoiceicu_cosurgeoncommissionarray = document.getElementsByName("hospitalinvoiceicu_cosurgeoncommission[]");
			hospitalinvoiceicu_cosurgeoncommissionarray[indexpos].value = ui.item.hospitalitem_cosurgeoncommission;
			
			var hospitalinvoiceicu_anaesthesiacommissionarray = document.getElementsByName("hospitalinvoiceicu_anaesthesiacommission[]");
			hospitalinvoiceicu_anaesthesiacommissionarray[indexpos].value = ui.item.hospitalitem_anaesthesiacommission;
			
			
			
					var hospitalinvoiceicu_pccomissionarray = document.getElementsByName("hospitalinvoiceicu_pccomission[]");
					hospitalinvoiceicu_pccomissionarray[indexpos].value = ui.item.hospitalitem_pccommission;
					
					var hospitalinvoiceicu_categoryarray = document.getElementsByName("hospitalinvoiceicu_category[]");
					hospitalinvoiceicu_categoryarray[indexpos].value = ui.item.hospitalitem_category;
					
					var hospitalinvoiceicu_unitarray = document.getElementsByName("hospitalinvoiceicu_unit[]");
					hospitalinvoiceicu_unitarray[indexpos].value = ui.item.hospitalitem_unit;
					
					var hospitalinvoiceicu_refvaluearray = document.getElementsByName("hospitalinvoiceicu_refvalue[]");
					hospitalinvoiceicu_refvaluearray[indexpos].value = ui.item.hospitalitem_refvalue;
				
	
					calculaterowtotal(indexpos);
					calculate_pctotal();
					calculate_surgeontotal();
					calculate_cosurgeontotal();
					calculate_anaesthesiatotal();
					
					return false;
				}
			});						
		}
	}
	
	function deletethislistrow(tableidname){
		$("#"+tableidname).parent("li").slideUp(200, function() {
			$(this).remove();
			calculaterowtotal('all');
		});
	}

function funcSaveBill1()
{
	
	var varUserChoice; 
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet); 
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		document.frmsales.submit();
		//return true;
	}
}	
	
</script>