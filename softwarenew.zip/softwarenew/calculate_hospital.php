<script language="JavaScript" type="text/javascript">
	
	var itemdata = <?php echo $itemdata;?>;
	var patientdata = <?php echo $patientdata;?>;
	var pcdata = <?php echo $pcdata;?>;
	var drdata = <?php echo $drdata;?>;
	//var cabin = <?php //echo $cabin;?>;
	$(document).ready(function($) {
		//document.getElementsByName("hospitalinvoice_item[]")[0].focus();

		$( ".itemname" ).autocomplete({

			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				var hospitalinvoice_ratearray = document.getElementsByName("hospitalinvoice_rate[]");
				hospitalinvoice_ratearray[indexpos].value = ui.item.hospitalitem_price;
				
				var hospitalinvoice_rateminarray = document.getElementsByName("hospitalinvoice_ratemin[]");
				hospitalinvoice_rateminarray[indexpos].value = ui.item.hospitalitem_pricemin;
				
				var hospitalinvoice_qtyarray = document.getElementsByName("hospitalinvoice_qty[]");
				hospitalinvoice_qtyarray[indexpos].value = 1;
				
				var hospitalinvoice_pccomissionarray = document.getElementsByName("hospitalinvoice_pccomission[]");
				hospitalinvoice_pccomissionarray[indexpos].value = ui.item.hospitalitem_pccommission;
				
				var hospitalinvoice_categoryarray = document.getElementsByName("hospitalinvoice_category[]");
				hospitalinvoice_categoryarray[indexpos].value = ui.item.hospitalitem_category;
				
				var hospitalinvoice_unitarray = document.getElementsByName("hospitalinvoice_unit[]");
				hospitalinvoice_unitarray[indexpos].value = ui.item.hospitalitem_unit;
				
				var hospitalinvoice_refvaluearray = document.getElementsByName("hospitalinvoice_refvalue[]");
				hospitalinvoice_refvaluearray[indexpos].value = ui.item.hospitalitem_refvalue;
				
				calculaterowtotal(indexpos);
				calculate_pctotal();
				addnew_particularrow(true);
				return false;
			}
		});
		
 		$( "#hospitalinvoice_patientid" ).autocomplete({
 			minLength: 1,
			source: patientdata,
 			focus: function( event, ui ) {
 				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
 				 document.getElementById('hospitalinvoice_patient').value = ui.item.labelval;
				 document.getElementById('hospitalinvoice_patientid').value = ui.item.opregistration_id;
				 document.getElementById('bar').value = ui.item.bar;
				 document.getElementById('hospitalinvoice_patientcode').value = ui.item.opregistration_code;
				 document.getElementById('hospitalinvoice_age').value = ui.item.opregistration_age;
				 document.getElementById('hospitalinvoice_pc').value = ui.item.pcname;
				 document.getElementById('hospitalinvoice_mpo').value = ui.item.mpo;
				 document.getElementById('hospitalinvoice_lab_due').value = ui.item.lab_due;
				 document.getElementById('hospitalinvoice_ot_due').value = ui.item.ot_due;
				 //document.getElementById('hospitalinvoice_pharmacy_due').value = ui.item.pharmacy_due;
				 document.getElementById('hospitalinvoice_therapy_due').value = ui.item.therapy_due;
				 document.getElementById('hospitalinvoice_icu_due').value = ui.item.icu_due;
				 	document.getElementById('hospitalinvoice_nicu_due').value = ui.item.nicu_due;
				 document.getElementById('advanced').value = ui.item.advanced;
				 document.getElementById('hospitalinvoice_cabin').value = ui.item.ward;
				 document.getElementById('hospitalinvoice_ambulance').value = ui.item.ambulance_due;
				 document.getElementById('day').value = ui.item.day;
				 document.getElementById('hospitalinvoice_ward').value = ui.item.ward_fee;
				 document.getElementById('hospitalinvoice_admissionfee').value = ui.item.admissionfee;
				 document.getElementById('hospitalinvoice_gender').value = ui.item.opregistration_gender;
				 document.getElementById('hospitalinvoice_father').value = ui.item.opregistration_father;
				 document.getElementById('hospitalinvoice_mobile').value = ui.item.opregistration_mobile;
				 document.getElementById('hospitalinvoice_address').value = ui.item.opregistration_address;
				 document.getElementById('diagnosis').value = ui.item.diagnosis;
				 document.getElementById('hospitalinvoice_admissiondate').value = ui.item.opregistration_date;
 				 calculate_total();
				
				return false;
			}
		});


		// pc search
		$( "#hospitalinvoice_pc" ).autocomplete({
 			minLength: 1,
			source: pcdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
 				 document.getElementById('hospitalinvoice_pc').value = ui.item.labelval;
				 document.getElementById('hospitalinvoice_mpo').value = ui.item.mpo;
 				return false;
			}
		});


		// Dr search
		$( "#hospitalinvoice_surgeon" ).autocomplete({
 			minLength: 1,
			source: drdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
 				 document.getElementById('hospitalinvoice_surgeon').value = ui.item.labelval;
  				return false;
			}
		});


		/*$( "#hospitalinvoice_patientid" ).autocomplete({
			
			minLength: 1,
			source: cabin,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('hospitalinvoice_ward').value = ui.item.labelval;
				
				return false;
			}
		});
		*/
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
	});
	function calculate_discountp(){
		var hospitalinvoice_discountparray = document.getElementsByName("hospitalinvoice_discountp[]");
		var hospitalinvoice_discarray = document.getElementsByName("hospitalinvoice_disc[]");
		var hospitalinvoice_ratearray = document.getElementsByName("hospitalinvoice_rate[]");
		var hospitalinvoice_rateminarray = document.getElementsByName("hospitalinvoice_ratemin[]");
		var hospitalinvoice_qtyarray = document.getElementsByName("hospitalinvoice_qty[]");
		var hospitalinvoice_pccomissionarray = document.getElementsByName("hospitalinvoice_pccomission[]");
		
		if(hospitalinvoice_discountparray.length>0){
			for(var p=0; p<hospitalinvoice_discountparray.length; p++){
				var hospitalinvoice_discountp = parseFloat(hospitalinvoice_discountparray[p].value);
				if(hospitalinvoice_discountp=='' || isNaN(hospitalinvoice_discountp)){hospitalinvoice_discountp = 0;}
				
				var hospitalinvoice_disc = parseFloat(hospitalinvoice_discarray[p].value);
				if(hospitalinvoice_disc=='' || isNaN(hospitalinvoice_disc)){hospitalinvoice_disc = 0;}
				
					if(hospitalinvoice_discountp>0){
					var hospitalinvoice_rate = parseFloat(hospitalinvoice_ratearray[p].value);
					if(hospitalinvoice_rate=='' || isNaN(hospitalinvoice_rate)){hospitalinvoice_rate = 0;
					}
					
					
					var hospitalinvoice_pccomission = parseFloat(hospitalinvoice_pccomissionarray[p].value);
					if(hospitalinvoice_pccomission=='' || isNaN(hospitalinvoice_pccomission)){hospitalinvoice_pccomission = 0;}
					
					var hospitalinvoice_qty = hospitalinvoice_qtyarray[p].value;
					if(hospitalinvoice_qty=='' || isNaN(hospitalinvoice_qty)){hospitalinvoice_qty = 0;}
					
					var pctotal = parseFloat(hospitalinvoice_pccomission*hospitalinvoice_qty);			
					
					var total = parseFloat(hospitalinvoice_rate*hospitalinvoice_qty);			
					var totalmin = parseFloat(hospitalinvoice_ratemin*hospitalinvoice_qty);			
					
					//var hospitalinvoice_disc = parseFloat(pctotal*hospitalinvoice_discountp*0.01);
					var hospitalinvoice_disc = parseFloat(total*hospitalinvoice_discountp*0.01);
					
					hospitalinvoice_discarray[p].value = hospitalinvoice_disc.toFixed(2);
				}
				
				calculaterowtotal(p);
			}
		}
	}
	
	function calculaterowtotal(indexpos){
		if(indexpos=='all'){
			var hospitalinvoice_ratearray = document.getElementsByName("hospitalinvoice_rate[]");
			var hospitalinvoice_rateminarray = document.getElementsByName("hospitalinvoice_ratemin[]");
			var hospitalinvoice_pccomissionarray = document.getElementsByName("hospitalinvoice_pccomission[]");
			var hospitalinvoice_qtyarray = document.getElementsByName("hospitalinvoice_qty[]");
			var hospitalinvoice_discarray = document.getElementsByName("hospitalinvoice_disc[]");
			var hospitalinvoice_pccomission_totalarray = document.getElementsByName("hospitalinvoice_pccomission_total[]");
			var hospitalinvoice_totalarray = document.getElementsByName("hospitalinvoice_total[]");
			var hospitalinvoice_totalminarray = document.getElementsByName("hospitalinvoice_totalmin[]");
			
			if(hospitalinvoice_ratearray.length>0){
				for(var p=0; p<hospitalinvoice_ratearray.length; p++){
					var hospitalinvoice_rate = parseFloat(hospitalinvoice_ratearray[p].value);
					if(hospitalinvoice_rate=='' || isNaN(hospitalinvoice_rate)){hospitalinvoice_rate = 0;}
					
					var hospitalinvoice_ratemin = parseFloat(hospitalinvoice_rateminarray[p].value);
					if(hospitalinvoice_ratemin=='' || isNaN(hospitalinvoice_ratemin)){hospitalinvoice_ratemin = 0;}
					
					var hospitalinvoice_pccomission = parseFloat(hospitalinvoice_pccomissionarray[p].value);
					if(hospitalinvoice_pccomission=='' || isNaN(hospitalinvoice_pccomission)){hospitalinvoice_pccomission = 0;}
					
					var hospitalinvoice_qty = parseFloat(hospitalinvoice_qtyarray[p].value);
					if(hospitalinvoice_qty=='' || isNaN(hospitalinvoice_qty)){hospitalinvoice_qty = 0;}
					
					var pctotal = parseFloat(hospitalinvoice_pccomission*hospitalinvoice_qty);
					var total = parseFloat(hospitalinvoice_rate*hospitalinvoice_qty);
					var totalmin = parseFloat(hospitalinvoice_ratemin*hospitalinvoice_qty);
					
					var hospitalinvoice_disc = parseFloat(hospitalinvoice_discarray[p].value);
					if(hospitalinvoice_disc=='' || isNaN(hospitalinvoice_disc)){hospitalinvoice_disc = 0;}
					
					var pctotal = parseFloat(pctotal-hospitalinvoice_disc);
					var total = parseFloat(total-hospitalinvoice_disc);
					var totalmin = parseFloat(totalmin-hospitalinvoice_disc);
					
					hospitalinvoice_pccomission_totalarray[p].value = pctotal.toFixed(2);
					hospitalinvoice_totalarray[p].value = total.toFixed(2);
					
					hospitalinvoice_totalminarray[p].value = totalmin.toFixed(2);
				}
			}
		}
		else{
			var hospitalinvoice_ratearray = document.getElementsByName("hospitalinvoice_rate[]");
			var hospitalinvoice_rate = parseFloat(hospitalinvoice_ratearray[indexpos].value);
			if(hospitalinvoice_rate=='' || isNaN(hospitalinvoice_rate)){hospitalinvoice_rate = 0;}
			
			var hospitalinvoice_rateminarray = document.getElementsByName("hospitalinvoice_ratemin[]");
			var hospitalinvoice_ratemin = parseFloat(hospitalinvoice_rateminarray[indexpos].value);
			if(hospitalinvoice_ratemin=='' || isNaN(hospitalinvoice_ratemin)){hospitalinvoice_ratemin = 0;}
			
			
			var hospitalinvoice_pccomissionarray = document.getElementsByName("hospitalinvoice_pccomission[]");
			var hospitalinvoice_pccomission = parseFloat(hospitalinvoice_pccomissionarray[indexpos].value);
			if(hospitalinvoice_pccomission=='' || isNaN(hospitalinvoice_pccomission)){hospitalinvoice_pccomission = 0;}
			
			var hospitalinvoice_qtyarray = document.getElementsByName("hospitalinvoice_qty[]");
			var hospitalinvoice_qty = parseFloat(hospitalinvoice_qtyarray[indexpos].value);
			if(hospitalinvoice_qty=='' || isNaN(hospitalinvoice_qty)){hospitalinvoice_qty = 0;}
			
			var pctotal = parseFloat(hospitalinvoice_pccomission*hospitalinvoice_qty);
			var total = parseFloat(hospitalinvoice_rate*hospitalinvoice_qty);
			var totalmin = parseFloat(hospitalinvoice_ratemin*hospitalinvoice_qty);
			
			var hospitalinvoice_discarray = document.getElementsByName("hospitalinvoice_disc[]");
			var hospitalinvoice_disc = parseFloat(hospitalinvoice_discarray[indexpos].value);
			if(hospitalinvoice_disc=='' || isNaN(hospitalinvoice_disc)){hospitalinvoice_disc = 0;}
			
			var pctotal = parseFloat(pctotal-hospitalinvoice_disc);
			var total = parseFloat(total-hospitalinvoice_disc);
			var totalmin = parseFloat(totalmin-hospitalinvoice_disc);
			
			var hospitalinvoice_pccomission_totalarray = document.getElementsByName("hospitalinvoice_pccomission_total[]");
			hospitalinvoice_pccomission_totalarray[indexpos].value = pctotal.toFixed(2);
			
			var hospitalinvoice_totalarray = document.getElementsByName("hospitalinvoice_total[]");
			hospitalinvoice_totalarray[indexpos].value = total.toFixed(2);
			
			var hospitalinvoice_totalminarray = document.getElementsByName("hospitalinvoice_totalmin[]");
			hospitalinvoice_totalminarray[indexpos].value = totalmin.toFixed(2);
		}
		calculate_pctotal();
		calculate_total();
	}
	
	function calculate_total(){
		var hospitalinvoice_lab_due = parseFloat(document.getElementById("hospitalinvoice_lab_due").value);
		if(hospitalinvoice_lab_due=='' || isNaN(hospitalinvoice_lab_due)){hospitalinvoice_lab_due = 0;}

		var hospitalinvoice_subtotal = 0;
		var hospitalinvoice_totalarray = document.getElementsByName("hospitalinvoice_total[]");
		if(hospitalinvoice_totalarray.length>0){
			for(var p=0; p<hospitalinvoice_totalarray.length; p++){
				var hospitalinvoice_total = parseFloat(hospitalinvoice_totalarray[p].value);
				if(hospitalinvoice_total=='' || isNaN(hospitalinvoice_total)){hospitalinvoice_total = 0;}
				hospitalinvoice_subtotal = parseFloat(hospitalinvoice_subtotal+hospitalinvoice_total);
			}
		}
		//subtotal calculation
		document.getElementById("hospitalinvoice_subtotal").value = (hospitalinvoice_subtotal).toFixed(2);



		//Min Charge Subtotal Calculation
		var hospitalinvoice_subtotalmin = 0;
		var hospitalinvoice_totalminarray = document.getElementsByName("hospitalinvoice_totalmin[]");
		if(hospitalinvoice_totalminarray.length>0){
			for(var p=0; p<hospitalinvoice_totalminarray.length; p++){
				var hospitalinvoice_totalmin = parseFloat(hospitalinvoice_totalminarray[p].value);
				if(hospitalinvoice_totalmin=='' || isNaN(hospitalinvoice_totalmin)){hospitalinvoice_totalmin = 0;}
				hospitalinvoice_subtotalmin = parseFloat(hospitalinvoice_subtotalmin+hospitalinvoice_totalmin);
			}
		}
 		document.getElementById("hospitalinvoice_subtotalmin").value = (hospitalinvoice_subtotalmin).toFixed(2);



		var hospitalinvoice_totaldiscp = parseFloat(document.getElementById("hospitalinvoice_totaldiscp").value);
		if(hospitalinvoice_totaldiscp=='' || isNaN(hospitalinvoice_totaldiscp)){hospitalinvoice_totaldiscp = 0;}

		var hospitalinvoice_totaldisc = parseFloat(document.getElementById("hospitalinvoice_totaldisc").value);
		if(hospitalinvoice_totaldisc=='' || isNaN(hospitalinvoice_totaldisc)){hospitalinvoice_totaldisc = 0;}

		//var hospitalinvoice_lab_due = parseFloat(document.getElementById("hospitalinvoice_lab_due").value);
		//if(hospitalinvoice_lab_due=='' || isNaN(hospitalinvoice_lab_due)){hospitalinvoice_lab_due = 0;}

		var hospitalinvoice_ot_due = parseFloat(document.getElementById("hospitalinvoice_ot_due").value);
		if(hospitalinvoice_ot_due=='' || isNaN(hospitalinvoice_ot_due)){hospitalinvoice_ot_due = 0;}
		
		var hospitalinvoice_ambulance = parseFloat(document.getElementById("hospitalinvoice_ambulance").value);
		if(hospitalinvoice_ambulance=='' || isNaN(hospitalinvoice_ambulance)){hospitalinvoice_ambulance = 0;}

		var hospitalinvoice_pharmacy_due = parseFloat(document.getElementById("hospitalinvoice_pharmacy_due").value);
		if(hospitalinvoice_pharmacy_due=='' || isNaN(hospitalinvoice_pharmacy_due)){hospitalinvoice_pharmacy_due = 0;}

		var hospitalinvoice_therapy_due = parseFloat(document.getElementById("hospitalinvoice_therapy_due").value);
		if(hospitalinvoice_therapy_due=='' || isNaN(hospitalinvoice_therapy_due)){hospitalinvoice_therapy_due = 0;}

		var hospitalinvoice_icu_due = parseFloat(document.getElementById("hospitalinvoice_icu_due").value);
		if(hospitalinvoice_icu_due=='' || isNaN(hospitalinvoice_icu_due)){hospitalinvoice_icu_due = 0;}

		var hospitalinvoice_nicu_due = parseFloat(document.getElementById("hospitalinvoice_nicu_due").value);
		if(hospitalinvoice_nicu_due=='' || isNaN(hospitalinvoice_nicu_due)){hospitalinvoice_nicu_due = 0;}

		//cabin calculation
		var hospitalinvoice_ward = parseFloat(document.getElementById("hospitalinvoice_ward").value);
		if(hospitalinvoice_ward=='' || isNaN(hospitalinvoice_ward)){hospitalinvoice_ward = 0;}

		var hospitalinvoice_admissionfee = parseFloat(document.getElementById("hospitalinvoice_admissionfee").value);
		if(hospitalinvoice_admissionfee=='' || isNaN(hospitalinvoice_admissionfee)){hospitalinvoice_admissionfee = 0;}

		var advanced = parseFloat(document.getElementById("advanced").value);
		if(advanced=='' || isNaN(advanced)){advanced = 0;}
		
		var gross = parseFloat(document.getElementById("gross").value);
		if(gross=='' || isNaN(gross)){gross = 0;}
		
		
		/*if(hospitalinvoice_totaldiscp>0){
			var hospitalinvoice_totaldisc = parseFloat(hospitalinvoice_subtotal*hospitalinvoice_totaldiscp*0.01);
			document.getElementById('hospitalinvoice_totaldisc').value= hospitalinvoice_totaldisc.toFixed(2);
		}*/
		
		if(hospitalinvoice_totaldiscp>0){
			var hospitalinvoice_totaldisc = parseFloat(gross*hospitalinvoice_totaldiscp*0.01);
			document.getElementById('hospitalinvoice_totaldisc').value= hospitalinvoice_totaldisc.toFixed(2);
		}
		// update 20-09-18
		var servicep = parseFloat(document.getElementById("servicep").value);
		if(servicep=='' || isNaN(servicep)){servicep = 0;}

		var service = parseFloat(document.getElementById("service").value);
		if(service=='' || isNaN(service)){service = 0;}

		//if(servicep>0){
//			var service = parseFloat((hospitalinvoice_subtotal +hospitalinvoice_lab_due+ hospitalinvoice_ambulance+hospitalinvoice_ot_due  + hospitalinvoice_therapy_due + hospitalinvoice_ward)*servicep*0.01);
//			document.getElementById('service').value= service.toFixed(0);
//		}
		
		if(servicep>0){
			var service = parseFloat((hospitalinvoice_admissionfee+hospitalinvoice_subtotal + hospitalinvoice_ambulance
			+hospitalinvoice_ot_due +hospitalinvoice_nicu_due+hospitalinvoice_icu_due+ hospitalinvoice_therapy_due + hospitalinvoice_ward)*servicep*0.01);
			document.getElementById('service').value= service.toFixed(0);
		}
		
		// update 20-09-18 end //
 		
		//var service = parseFloat((hospitalinvoice_subtotal + hospitalinvoice_lab_due + hospitalinvoice_ot_due +hospitalinvoice_pharmacy_due + hospitalinvoice_therapy_due + hospitalinvoice_ward +hospitalinvoice_admissionfee)*0.15);
		//document.getElementById('service').value=	service.toFixed(2);
		
		//var gross = parseFloat(hospitalinvoice_lab_due+hospitalinvoice_subtotal + service);
		//document.getElementById('gross').value=	gross.toFixed(2);
		
		//old with + hospitalinvoice_lab_due+ hospitalinvoice_pharmacy_due
		//var gross = parseFloat(hospitalinvoice_admissionfee+hospitalinvoice_subtotal + hospitalinvoice_lab_due + hospitalinvoice_ot_due + hospitalinvoice_pharmacy_due + hospitalinvoice_therapy_due + hospitalinvoice_ward + service);
		//document.getElementById('gross').value=	gross.toFixed(2);
		
		var gross = parseFloat(hospitalinvoice_admissionfee+ hospitalinvoice_ward+hospitalinvoice_subtotal + hospitalinvoice_ot_due +hospitalinvoice_nicu_due+hospitalinvoice_icu_due 
		+ hospitalinvoice_therapy_due + service);
		document.getElementById('gross').value=	gross.toFixed(2);
		
		
		/*var hospitalinvoice_admissiondate = parseFloat(document.getElementById("hospitalinvoice_admissiondate").value);
		if(hospitalinvoice_admissiondate=='' || isNaN(hospitalinvoice_admissiondate)){hospitalinvoice_admissiondate = 0;}
		
		var hospitalinvoice_deliverydate = parseFloat(document.getElementById("hospitalinvoice_deliverydate").value);
		if(hospitalinvoice_deliverydate=='' || isNaN(hospitalinvoice_deliverydate)){hospitalinvoice_deliverydate = 0;}
		
		var gross = parseFloat(hospitalinvoice_subtotal + service+(//echo (date('d',strtotime($hospitalinvoice_deliverydate))-date('d',strtotime($hospitalinvoice_admissiondate)) )* 1000);
		document.getElementById('gross').value=	gross.toFixed(2);
		*/
		
		
		 
		 
		
		var hospitalinvoice_subtotalafterdisc = parseFloat(hospitalinvoice_admissionfee+hospitalinvoice_subtotal 
		+hospitalinvoice_ot_due + hospitalinvoice_therapy_due
		+hospitalinvoice_nicu_due+hospitalinvoice_icu_due + hospitalinvoice_ward +hospitalinvoice_ambulance
		+ service - hospitalinvoice_totaldisc - advanced);
		document.getElementById('hospitalinvoice_subtotalafterdisc').value=	hospitalinvoice_subtotalafterdisc.toFixed(2);
		
		
		//min charge 
 		var hospitalinvoice_subtotalafterdiscmin = parseFloat(hospitalinvoice_admissionfee+hospitalinvoice_subtotalmin 
		+hospitalinvoice_ot_due + hospitalinvoice_therapy_due
		+hospitalinvoice_nicu_due+hospitalinvoice_icu_due + hospitalinvoice_ward +hospitalinvoice_ambulance
		+ service - advanced);
		document.getElementById('hospitalinvoice_subtotalafterdiscmin').value=	hospitalinvoice_subtotalafterdiscmin.toFixed(2);
		//end min charge
			
		var hospitalinvoice_receiveamount = parseFloat(document.getElementById("hospitalinvoice_receiveamount").value);
		if(hospitalinvoice_receiveamount=='' || isNaN(hospitalinvoice_receiveamount)){hospitalinvoice_receiveamount = 0;}
		//Advanced amount calculation
		
		var hospitalinvoice_due = parseFloat(hospitalinvoice_subtotalafterdisc-hospitalinvoice_receiveamount);
		document.getElementById('hospitalinvoice_due').value=hospitalinvoice_due.toFixed(2);		
		
		var varTDShowTotalAmount1 = document.getElementById("hospitalinvoice_subtotalafterdisc").value;
		document.getElementById("tdShowTotalAmount1").innerHTML = varTDShowTotalAmount1;
		
		
		
		// alart for min bill amount//
		var subtotal = parseFloat(document.getElementById("hospitalinvoice_subtotalafterdisc").value) || 0;
		var minAmount = parseFloat(document.getElementById("hospitalinvoice_subtotalafterdiscmin").value) || 0;

		if (subtotal < minAmount) {
		 alert("Hospital invoice amount cannot be less than the minimum allowed amount.");
		  // Ei Amount Guli 0 hoye jabe
			document.getElementById("hospitalinvoice_totaldiscp").value = 0;
			document.getElementById("hospitalinvoice_totaldisc").value = 0;
			document.getElementById("hospitalinvoice_subtotalafterdisc").value = document.getElementById("gross").value;
			document.getElementById("hospitalinvoice_receiveamount").value = 0;
			document.getElementById("hospitalinvoice_due").value = 0;
		
			document.getElementById("hospitalinvoice_subtotalafterdisc").focus();
		 return false;
		}
		

		
	}
	
	function calculate_pctotal(){
		var hospitalinvoice_totalpccomission = 0;
		var hospitalinvoice_pccomission_totalarray = document.getElementsByName("hospitalinvoice_pccomission_total[]");
			//var hospitalinvoice_qtyarray = document.getElementsByName("hospitalinvoice_qty[]");
		if(hospitalinvoice_pccomission_totalarray.length>0){
			for(var p=0; p<hospitalinvoice_pccomission_totalarray.length; p++){
				var hospitalinvoice_pccomission_total = parseFloat(hospitalinvoice_pccomission_totalarray[p].value);
				if(hospitalinvoice_pccomission_total=='' || isNaN(hospitalinvoice_pccomission_total)){hospitalinvoice_pccomission_total = 0;}

				//var hospitalinvoice_qty = parseFloat(hospitalinvoice_qtyarray[p].value);
				//if(hospitalinvoice_qty=='' || isNaN(hospitalinvoice_qty)){hospitalinvoice_qty = 0;}

				hospitalinvoice_totalpccomission = parseFloat(hospitalinvoice_totalpccomission+hospitalinvoice_pccomission_total);
			}
		}
		
		document.getElementById("hospitalinvoice_totalpccomission").value = hospitalinvoice_totalpccomission.toFixed(2);
	}
	
	function check_particular(){
		/*var particular_idlistarray = new Array();
		var particular_id = document.getElementsByName('particular_id[]');
		var particular_count = particular_id.length;
		var particular_priceid = document.getElementsByName('particular_price[]');
		var particular_qtyid = document.getElementsByName('particular_qty[]');
			
		var error_messageid = document.getElementById('errmsg_particular_id');
		error_messageid.innerHTML = '';
		
		for(i = 0; i < particular_count; i++) {
												
			if(particular_id[i].value=='' || particular_id[i].value==0){
				error_messageid.innerHTML = 'Missing Particular Name '+parseInt(i+1);
				particular_id[i].focus();
				returnvalue = false;
			}
			
			if(particular_idlistarray.length>0 && particular_idlistarray.indexOf(particular_id[i].value) != -1){
				error_messageid.innerHTML = 'Dupplicate Particular Name '+i;
				particular_id[i].focus();
				return false;
			}
			else{
				particular_idlistarray[i] = particular_id[i].value;
			}
			
			var particular_priceval = parseInt(particular_priceid[i].value);
			if(isNaN(particular_priceval) || particular_priceval==''){particular_priceval = 0;}
			if(particular_priceval==0){
				error_messageid.innerHTML = 'Missing Price '+Math.floor(i+1);
				particular_priceid[i].focus();
				return false;
			}
										
			var particular_qtyval = parseInt(particular_qtyid[i].value);
			if(isNaN(particular_qtyval) || particular_qtyval==''){particular_qtyval = 0;}							
			if(particular_qtyval==0){
				error_messageid.innerHTML = 'Missing QTY '+Math.floor(i+1);
				particular_qtyid.focus();
				return false;
			}
		}*/
		return true;
	}
	function addnew_particularrow(animate) {
		if(check_particular()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" style=\"BORDER-COLLAPSE: collapse; border:2px solid #FFF\" bgcolor=\"#ccc\" align=\"left\" width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"2\">"+
							'<tr>'+
								'<td align="right">Particular</td>'+
								'<td><input type="text" name="hospitalinvoice_item[]" class="tdclass itemname"/></td>'+
								'<input type="hidden" name="auto_number[]" />'+ 
								'<input type="hidden" name="hospitalinvoice_category[]" class="tdclass"  />'+
								'<input type="hidden" name="hospitalinvoice_unit[]" class="tdclass"  />'+
								'<input type="hidden" name="hospitalinvoice_refvalue[]" class="tdclass"  />'+
								'<td align="right">Unit Charge</td>'+
								"<td><input type=\"text\" name=\"hospitalinvoice_rate[]\" id=\"hospitalinvoice_rate\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/></td>"+											 
								
								'<td align="right">Min Charge</td>'+
								"<td><input type=\"text\" name=\"hospitalinvoice_ratemin[]\" id=\"hospitalinvoice_ratemin\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/></td>"+											 
								
								'<td align="right">Unit/Qty</td>'+
								"<td><input type=\"text\" name=\"hospitalinvoice_qty[]\" id=\"hospitalinvoice_qty\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/></td>"+
								
								'<td align="right">P.C</td>'+
								"<td><input type=\"text\" name=\"hospitalinvoice_pccomission[]\" id=\"hospitalinvoice_pccomission\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/></td>"+											 
								'<td align="right">Disc%</td>'+
								'<td><input type="text" name="hospitalinvoice_discountp[]" class="tdclasssale" onKeyUp="calculate_discountp();"/></td>'+
								'<td align="right">Disc</td>'+
								"<td><input type=\"text\" name=\"hospitalinvoice_disc[]\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\" /></td>"+
								'<td align="right">P.C Gross</td>'+
								'<td><input type="text" name="hospitalinvoice_pccomission_total[]" class="tdclasssale" onKeyUp="calculate_pctotal();"  /></td>'+
								'<td align="right">Total</td>'+
								'<td><input type="text" readonly name="hospitalinvoice_total[]" id="hospitalinvoice_total" class="tdclasssale"  /></td>'+												
								'<input type="hidden" readonly name="hospitalinvoice_totalmin[]" id="hospitalinvoice_totalmin" class="tdclasssale" />'+												
								'<td>'+
								 "<input type=\"button\" value=\"Cancel\" onClick=\"deletethislistrow('particularlistrowno"+particular_rowcount+"');\" class=\"tdclasssale\"  />"+
								'</td>'+
							  '</tr>'+
						"</table>";
						
			var $newparticularlist = $("<li></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(300); 
			else 
			   $newparticularlist.show();   
			document.getElementsByName("hospitalinvoice_item[]")[parseInt(particular_rowcount-1)].focus();
			
			$( ".itemname" ).autocomplete({			
				minLength: 1,
				source: itemdata,
				focus: function( event, ui ) {
					//$( "#search_item_number" ).val( ui.item.labelval );
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					
					var hospitalinvoice_ratearray = document.getElementsByName("hospitalinvoice_rate[]");
					hospitalinvoice_ratearray[indexpos].value = ui.item.hospitalitem_price;
					
					var hospitalinvoice_rateminarray = document.getElementsByName("hospitalinvoice_ratemin[]");
					hospitalinvoice_rateminarray[indexpos].value = ui.item.hospitalitem_pricemin;
					
					var hospitalinvoice_qtyarray = document.getElementsByName("hospitalinvoice_qty[]");
					hospitalinvoice_qtyarray[indexpos].value = 1;
					
					var hospitalinvoice_pccomissionarray = document.getElementsByName("hospitalinvoice_pccomission[]");
					hospitalinvoice_pccomissionarray[indexpos].value = ui.item.hospitalitem_pccommission;
					
					var hospitalinvoice_categoryarray = document.getElementsByName("hospitalinvoice_category[]");
					hospitalinvoice_categoryarray[indexpos].value = ui.item.hospitalitem_category;
					
					var hospitalinvoice_unitarray = document.getElementsByName("hospitalinvoice_unit[]");
					hospitalinvoice_unitarray[indexpos].value = ui.item.hospitalitem_unit;
					
					var hospitalinvoice_refvaluearray = document.getElementsByName("hospitalinvoice_refvalue[]");
					hospitalinvoice_refvaluearray[indexpos].value = ui.item.hospitalitem_refvalue;
					
					calculaterowtotal(indexpos);
					calculate_pctotal();
					addnew_particularrow(true);
					return false;
				}
			});			
		}
	}

	function deletethislistrow(tableidname){
		$("#"+tableidname).parent("li").slideUp(200, function() {
			$(this).remove();
			calculaterowtotal('all');
		});
	}

function funcSaveBill1()
{
	var varUserChoice;
	varUserChoice = confirm('Are You Sure Want To Save This Entry?');
	//alert(fRet);
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		document.frmsales.submit();
		//return true;
	}
}

	function checkcontactform(){
	
		var subtotal = parseFloat(document.getElementById("hospitalinvoice_subtotalafterdisc").value) || 0;
		var minAmount = parseFloat(document.getElementById("hospitalinvoice_subtotalafterdiscmin").value) || 0;
	
		// যদি বেশি হলে আটকাতে চান
		if (subtotal < minAmount) {
	
			alert("Amount cannot be greater than the minimum amount.");
	
			document.getElementById("hospitalinvoice_totaldisc").value = 0;
	
			document.getElementById("hospitalinvoice_subtotalafterdisc").focus();
	
			return false;
		}
	
		return true;
	}

 
</script>