<?php
// Prevent "session already started" error
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

date_default_timezone_set('Asia/Dhaka');
require_once 'labdd.php';

// Fetch values safely
$searchflag2 = isset($_REQUEST['searchflag2']) ? $_REQUEST['searchflag2'] : "";
$Division = isset($_REQUEST['Division']) ? $_REQUEST['Division'] : "";
$Circle = isset($_REQUEST['Circle']) ? $_REQUEST['Circle'] : "";

// Pagination settings
$limit = 10; // Records per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Total record count query
$countQuery = "SELECT COUNT(*) AS total FROM ibusdata WHERE Division LIKE ? AND Circle LIKE ?";
$stmtCount = $conn->prepare($countQuery);
$searchDivision = "%{$Division}%";
$searchCircle = "%{$Circle}%";
$stmtCount->bind_param("ss", $searchDivision, $searchCircle);
$stmtCount->execute();
$countResult = $stmtCount->get_result();
$totalRows = $countResult->fetch_assoc()['total'];
$totalPages = ceil($totalRows / $limit);
$stmtCount->close();

// Fetch data with pagination
$sql = "SELECT ibusdataid, BINStatus, Circle, Division, MobileNumber, Name, FactoryBusinessOperationAddress 
        FROM ibusdata 
        WHERE Division LIKE ? AND Circle LIKE ? 
        ORDER BY ibusdataid ASC 
        LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssii", $searchDivision, $searchCircle, $limit, $offset);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Company List with Pagination</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
    <h2 class="text-center">Company List</h2>
    <div class="card p-3 shadow-sm">
        <table class="table table-striped table-responsive">
            <thead class="table-dark">
                <tr>
                    <th>Sl No.</th>
                    <th>Revenue Collection</th>
                    <th>Type</th>
                    <th>Name</th>
                    <th>Mobile</th>
                    <th>Address</th>
                    <th>Division</th>
                    <th>Circle</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $s = $offset; // Adjust starting serial number for pagination
                while ($row = $result->fetch_assoc()) {
                    $s++;
                    echo "<tr>
                            <td>{$s}</td>
                            <td><a href='index.php?p=revenuecollectionentry&ibusdataid={$row['ibusdataid']}' target='_blank' class='btn btn-sm btn-info'>Revenue Collection</a></td>
                            <td>" . htmlspecialchars($row['BINStatus']) . "</td>
                            <td>" . htmlspecialchars($row['Name']) . "</td>
                            <td>" . htmlspecialchars($row['MobileNumber']) . "</td>
                            <td>" . htmlspecialchars($row['FactoryBusinessOperationAddress']) . "</td>
                            <td>" . htmlspecialchars($row['Division']) . "</td>
                            <td>" . htmlspecialchars($row['Circle']) . "</td>
                          </tr>";
                }
                ?>
            </tbody>
        </table>

        <!-- Pagination Controls -->
        <nav>
            <ul class="pagination justify-content-center">
                <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="">&laquo; Previous</a>
                    </li>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                        <a class="page-link" href=""> <?php echo $i; ?> </a>
                    </li>
                <?php endfor; ?>

                <?php if ($page < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link" href="">Next &raquo;</a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
