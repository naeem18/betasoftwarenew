<?php
//openA
date_default_timezone_set('Asia/Dhaka');
// --- Search parameters ---
$employee_name = isset($_REQUEST['employee_name']) ? trim($_REQUEST['employee_name']) : '';
$fromdate      = !empty($_REQUEST['ADate1']) ? $_REQUEST['ADate1'] : date('Y-m-d');
$todate        = !empty($_REQUEST['ADate2']) ? $_REQUEST['ADate2'] : date('Y-m-d');
?>

<!-- Search Form -->
<form method="post" action="">
    Employee: <input type="text" name="employee_name" value="<?php echo htmlspecialchars($employee_name); ?>">
    From: <input type="date" name="ADate1" value="<?php echo $fromdate; ?>">
    To: <input type="date" name="ADate2" value="<?php echo $todate; ?>">
    <button type="submit">Search</button>
</form>

<table border="1" cellspacing="0" cellpadding="5" width="100%" style="border-collapse: collapse;">
    <tr bgcolor="#0033FF" style="color:#fff;">
        <th>SL</th>
        <th>ID</th>
        <th>Name</th>
        <th>Entry Date</th>
        <th>Roster Start</th>
        <th>Roster End</th>
        <th>In Time</th>
        <th>Grace (15m)</th>
        <th>Late (Min)</th>
        <th>Salary/Day</th>
        <th>Deduction</th>
        <th>Net Salary</th>
        <th>Overtime (Min)</th>
        <th>Status</th>
        <th>Debug</th>
    </tr>

<?php
$s = 0;
$totalLate = 0;
$totalDeduction = 0;
$totalNet = 0;
$totalOvertime = 0;

$monthlySummary = []; // Employee wise summary

// Fetch attendance
$sql = "SELECT md.*, e.name, e.gross 
        FROM machine_data md
        JOIN employee e ON md.e_id = e.e_id
        WHERE md.entry_date BETWEEN '$fromdate' AND '$todate' 
          AND md.in_out=1 ";
if (!empty($employee_name)) {
    $sql .= " AND e.name LIKE '%".mysqli_real_escape_string($conn,$employee_name)."%' ";
}
$sql .= " ORDER BY md.entry_date ASC, md.entry_time ASC";

$result = mysqli_query($conn, $sql) or die("Attendance query failed: ".mysqli_error($conn));

while($row = mysqli_fetch_assoc($result)){
    $s++;
    $e_id = $row['e_id'];
    $name = $row['name'];
    $gross = $row['gross'];
    $entry_date = $row['entry_date'];
    $entry_time = strtotime($entry_date.' '.$row['entry_time']);
    if(!$entry_time) continue;

    // --- Get all rosters for this employee on this date ---
    $sqlRoster = "SELECT * FROM rostering 
                  WHERE e_id='".mysqli_real_escape_string($conn,$e_id)."' 
                    AND fromdate <= '$entry_date' 
                    AND todate >= '$entry_date'
                  ORDER BY fromtime ASC";
    $rosterQ = mysqli_query($conn, $sqlRoster) or die("Roster query failed: ".mysqli_error($conn));

    $lateMinutes = 0;
    $deduction = 0;
    $netSalary = 0;
    $overtimeMinutes = 0;
    $status = "❌ No Roster Found";
    $rosterStartStr = $rosterEndStr = "-";
    $debug = "SQL: $sqlRoster | Rows: ".mysqli_num_rows($rosterQ);

    if(mysqli_num_rows($rosterQ) > 0){
        $status = "❌ Outside Roster";
        while($roster = mysqli_fetch_assoc($rosterQ)){
            $rosterStart = strtotime($roster['fromdate'].' '.$roster['fromtime']);
            $rosterEnd   = strtotime($roster['todate'].' '.$roster['totime']);
            if(!$rosterStart || !$rosterEnd){ $debug.=" | Invalid roster"; continue; }

            // Overnight shift
            if($rosterEnd <= $rosterStart) $rosterEnd = strtotime('+1 day', $rosterEnd);

            if($rosterStartStr=='-'){
                $rosterStartStr = date('h:i:s A',$rosterStart);
                $rosterEndStr   = date('h:i:s A',$rosterEnd);
            }

            if($entry_time < $rosterStart){
                // Entry before roster start
                $lateMinutes = 0;
                $deduction = 0;
                $netSalary = round($gross/30,2);
                $status = "On Time";
                $debug.=" | Entry before roster start";
                break;
            } elseif($entry_time >= $rosterStart && $entry_time <= $rosterEnd){
                // Entry during roster
                $graceEnd = $rosterStart + (15*60);
                $lateMinutes = max(0,floor(($entry_time-$graceEnd)/60));
                $dailySalary = $gross/30;
                $perMinuteRate = $dailySalary/(8*60);
                $deduction = round($lateMinutes*$perMinuteRate,2);
                $netSalary = round($dailySalary-$deduction,2);
                $status = ($lateMinutes>0)?"Late":"On Time";
                $debug.=" | Matched roster";
                break;
            } elseif($entry_time > $rosterEnd){
                // Entry after roster end → overtime
                $dailySalary = $gross/30;
                $perMinuteRate = $dailySalary/(8*60);
                $lateMinutes = 0;
                $deduction = 0;
                $netSalary = round($dailySalary,2);
                $overtimeMinutes = floor(($entry_time-$rosterEnd)/60);
                $status = "Overtime";
                $debug.=" | Entry after roster → Overtime $overtimeMinutes min";
                break;
            } else {
                $debug.=" | Entry unmatched";
            }
        }
    }

    // Accumulate totals
    $totalLate += $lateMinutes;
    $totalDeduction += $deduction;
    $totalNet += $netSalary;
    $totalOvertime += $overtimeMinutes;

    // Monthly summary
    if(!isset($monthlySummary[$e_id])){
        $monthlySummary[$e_id] = [
            'name'=>$name,
            'totalLate'=>0,
            'totalDeduction'=>0,
            'totalNet'=>0,
            'totalOvertime'=>0
        ];
    }
    $monthlySummary[$e_id]['totalLate'] += $lateMinutes;
    $monthlySummary[$e_id]['totalDeduction'] += $deduction;
    $monthlySummary[$e_id]['totalNet'] += $netSalary;
    $monthlySummary[$e_id]['totalOvertime'] += $overtimeMinutes;
    ?>

    <tr>
        <td><?php echo $s;?></td>
        <td><?php echo $e_id;?></td>
        <td><?php echo htmlspecialchars($name);?></td>
        <td><?php echo $entry_date;?></td>
        <td><?php echo $rosterStartStr;?></td>
        <td><?php echo $rosterEndStr;?></td>
        <td><?php echo date('h:i:s A',$entry_time);?></td>
        <td>15 min</td>
        <td><?php echo $lateMinutes;?></td>
        <td><?php echo number_format($dailySalary,2);?></td>
        <td><?php echo number_format($deduction,2);?></td>
        <td><?php echo number_format($netSalary,2);?></td>
        <td><?php echo $overtimeMinutes;?></td>
        <td><?php echo $status;?></td>
        <td><?php echo $debug;?></td>
    </tr>
<?php } ?>

<tr bgcolor="#FFCC99">
    <td colspan="8" align="right"><strong>Totals</strong></td>
    <td><strong><?php echo $totalLate;?> min</strong></td>
    <td>-</td>
    <td><strong><?php echo number_format($totalDeduction,2);?></strong></td>
    <td><strong><?php echo number_format($totalNet,2);?></strong></td>
    <td><strong><?php echo $totalOvertime;?> min</strong></td>
    <td>-</td>
    <td>-</td>
</tr>
</table>

<h2>Monthly Summary per Employee</h2>
<table border="1" cellpadding="5" cellspacing="0">
    <tr bgcolor="#006600" style="color:#fff;">
        <th>ID</th>
        <th>Name</th>
        <th>Total Late (Min)</th>
        <th>Total Deduction</th>
        <th>Total Net Salary</th>
        <th>Total Overtime (Min)</th>
    </tr>
<?php
foreach($monthlySummary as $eid=>$summary){
    echo "<tr>";
    echo "<td>{$eid}</td>";
    echo "<td>".htmlspecialchars($summary['name'])."</td>";
    echo "<td>{$summary['totalLate']}</td>";
    echo "<td>".number_format($summary['totalDeduction'],2)."</td>";
    echo "<td>".number_format($summary['totalNet'],2)."</td>";
    echo "<td>{$summary['totalOvertime']}</td>";
    echo "</tr>";
}
?>
</table>
