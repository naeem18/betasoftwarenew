<script language="JavaScript" type="text/javascript">
	var itemdataarray = <?php echo $itemdataarray;?>;
	var itemdata = <?php echo $itemdata;?>;
	var patientdata = <?php echo $patientdata;?>;
	var pcdata = <?php echo $pcdata;?>;
	var drdata = <?php echo $drdata;?>;
	var itemarraydata = itemdataarray;
	$(document).ready(function($) {
		document.getElementsByName("labinvoice_item[]")[0].focus();

		$( ".itemname" ).autocomplete({
			
			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				var labitem_idarray = document.getElementsByName("labitem_id[]");
				labitem_idarray[indexpos].value = ui.item.labitem_id;

				var labinvoice_ratearray = document.getElementsByName("labinvoice_rate[]");
				labinvoice_ratearray[indexpos].value = ui.item.labitem_price;

				var labinvoice_qtyarray = document.getElementsByName("labinvoice_qty[]");
				labinvoice_qtyarray[indexpos].value = 1;

				var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
				labinvoice_pccomissionarray[indexpos].value = ui.item.labitem_pccommission;

				var labinvoice_drcomissionarray = document.getElementsByName("labinvoice_drcomission[]");
				labinvoice_drcomissionarray[indexpos].value = ui.item.labitem_drcommission;

				var labinvoice_grouparray = document.getElementsByName("labinvoice_group[]");
				labinvoice_grouparray[indexpos].value = ui.item.labitem_group;
				
				var labinvoice_categoryarray = document.getElementsByName("labinvoice_category[]");
				labinvoice_categoryarray[indexpos].value = ui.item.labitem_category;
				
				var labinvoice_testgrouparray = document.getElementsByName("labinvoice_testgroup[]");
				labinvoice_testgrouparray[indexpos].value = ui.item.labitem_testgroup;

				var labinvoice_samplearray = document.getElementsByName("labinvoice_sample[]");
				labinvoice_samplearray[indexpos].value = ui.item.labitem_sample;
				
				var categoryarray = document.getElementsByName("category[]");
				categoryarray[indexpos].value = ui.item.category;
				
				var notearray = document.getElementsByName("note[]");
				notearray[indexpos].value = ui.item.note;
				
				var orderbyarray = document.getElementsByName("orderby[]");
				orderbyarray[indexpos].value = ui.item.orderby;
				
				var machine_namearray = document.getElementsByName("machine_name[]");
				machine_namearray[indexpos].value = ui.item.machine_name;

				var labinvoice_unitarray = document.getElementsByName("labinvoice_unit[]");
				labinvoice_unitarray[indexpos].value = ui.item.labitem_unit;

				var labinvoice_refvaluearray = document.getElementsByName("labinvoice_refvalue[]");
				labinvoice_refvaluearray[indexpos].value = ui.item.labitem_refvalue;

				var labinvoice_reagentarray = document.getElementsByName("labinvoice_reagent[]");
				labinvoice_reagentarray[indexpos].value = ui.item.labitem_reagent;

				calculaterowtotal(indexpos);
				//calculate_pctotal();
				//calculate_drtotal();
				addnew_particularrow(true);
				return false;
			}
		});

		$( "#labinvoice_patientid" ).autocomplete({
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('labinvoice_patient').value = ui.item.labelval;
				 document.getElementById('labinvoice_patientid').value = ui.item.opregistration_id;
				 document.getElementById('labinvoice_patientcode').value = ui.item.opregistration_code;
				 document.getElementById('labinvoice_age').value = ui.item.opregistration_age;
				 document.getElementById('labinvoice_gender').value = ui.item.opregistration_gender;
				 document.getElementById('labinvoice_mobile').value = ui.item.opregistration_mobile;
				 document.getElementById('labinvoice_address').value = ui.item.opregistration_address;
				 document.getElementById('labinvoice_pc').value = ui.item.pcname;
				 document.getElementById('labinvoice_mpo').value = ui.item.mpo;
				 document.getElementById('labinvoice_ward').value = ui.item.ward;
				 document.getElementById('labinvoice_previousdue').value = ui.item.lab_due;
				 document.getElementById('previous_labinvoice_totalpccomission').value = ui.item.labinvoice_totalpccomission;
				
				return false;
			}
		});
		
		// pc search
		$( "#labinvoice_pc" ).autocomplete({
			
			minLength: 1,
			source: pcdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('labinvoice_pc').value = ui.item.labelval;
				 document.getElementById('labinvoice_mpo').value = ui.item.mpo;
				 document.getElementById('doctor_id').value = ui.item.doctor_id;
				 document.getElementById('previous_pc_comission').value = ui.item.pc_comission;
				
				return false;
			}
		});
		
		// dr search
		$( "#labinvoice_doctor" ).autocomplete({
			
			minLength: 1,
			source: drdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('labinvoice_doctor').value = ui.item.labelval;
				 document.getElementById('labinvoice_doctor').value = ui.item.doctor_name;
				return false;
			}
		});
		
		
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
		$( ".labinvoice_item" ).keypress(function(keyname) {
			if(keyname.which==13){
				var imei = $(this).val();
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				$.each(itemarraydata, function(key, value){
					var valuearray = value.split('||');
					if(key==imei){
						document.getElementsByName("labitem_id[]")[indexpos].value = valuearray[0];
						//document.getElementsByName("salesinvoice_item[]")[indexpos].value = valuearray[1];
						document.getElementsByName("labinvoice_category[]")[indexpos].value = valuearray[1];
						document.getElementsByName("labinvoice_unit[]")[indexpos].value = valuearray[2];
						document.getElementsByName("labinvoice_refvalue[]")[indexpos].value = valuearray[3];
						document.getElementsByName("labinvoice_rate[]")[indexpos].value = valuearray[4];
						document.getElementsByName("labinvoice_reagent[]")[indexpos].value = valuearray[5];
						document.getElementsByName("labinvoice_pccomission[]")[indexpos].value = valuearray[6];
						document.getElementsByName("labinvoice_drcomission[]")[indexpos].value = valuearray[7];
						document.getElementsByName("labinvoice_qty[]")[indexpos].value = 1;
						calculaterowtotal(indexpos);
						addnew_particularrow(true);
					}
				});
				return false;
			}
		});
	});
	
	function calculate_discountp(){
		
		var labinvoice_discountparray = document.getElementsByName("labinvoice_discountp[]");
		var labinvoice_discarray = document.getElementsByName("labinvoice_disc[]");
		var labinvoice_ratearray = document.getElementsByName("labinvoice_rate[]");
		var labinvoice_qtyarray = document.getElementsByName("labinvoice_qty[]");
		//var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
			
		if(labinvoice_discountparray.length>0){
			for(var p=0; p<labinvoice_discountparray.length; p++){
				var labinvoice_discountp = parseFloat(labinvoice_discountparray[p].value);
				if(labinvoice_discountp=='' || isNaN(labinvoice_discountp)){labinvoice_discountp = 0;}
				
				var labinvoice_disc = parseFloat(labinvoice_discarray[p].value);
				if(labinvoice_disc=='' || isNaN(labinvoice_disc)){labinvoice_disc = 0;}
				if(labinvoice_discountp>0){
					var labinvoice_rate = parseFloat(labinvoice_ratearray[p].value);
					if(labinvoice_rate=='' || isNaN(labinvoice_rate)){labinvoice_rate = 0;}
					
					var labinvoice_qty = labinvoice_qtyarray[p].value;
					if(labinvoice_qty=='' || isNaN(labinvoice_qty)){labinvoice_qty = 0;}
					
					var total = parseFloat(labinvoice_rate*labinvoice_qty);			
					var labinvoice_disc = parseFloat(total*labinvoice_discountp*0.01);
					
					labinvoice_discarray[p].value = labinvoice_disc.toFixed(2);
				}
				
				calculaterowtotal(p);
			}
		}
	}
	
	function calculaterowtotal(indexpos){
		if(indexpos=='all'){
			var labinvoice_ratearray = document.getElementsByName("labinvoice_rate[]");
			var labinvoice_qtyarray = document.getElementsByName("labinvoice_qty[]");
			var labinvoice_discarray = document.getElementsByName("labinvoice_disc[]");
			var labinvoice_totalarray = document.getElementsByName("labinvoice_total[]");
				var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
			
			if(labinvoice_ratearray.length>0){
				for(var p=0; p<labinvoice_ratearray.length; p++){
					var labinvoice_rate = parseFloat(labinvoice_ratearray[p].value);
					if(labinvoice_rate=='' || isNaN(labinvoice_rate)){labinvoice_rate = 0;}
					
					
					var labinvoice_qty = parseFloat(labinvoice_qtyarray[p].value);
					if(labinvoice_qty=='' || isNaN(labinvoice_qty)){labinvoice_qty = 0;}
					
					var total = parseFloat(labinvoice_rate*labinvoice_qty);
					
					var labinvoice_disc = parseFloat(labinvoice_discarray[p].value);
					if(labinvoice_disc=='' || isNaN(labinvoice_disc)){labinvoice_disc = 0;}
					
					var total = parseFloat(total-labinvoice_disc);
					labinvoice_totalarray[p].value = total.toFixed(2);
					
					
					
				}
			}
		}
		else{
			var labinvoice_ratearray = document.getElementsByName("labinvoice_rate[]");
			var labinvoice_rate = parseFloat(labinvoice_ratearray[indexpos].value);
			if(labinvoice_rate=='' || isNaN(labinvoice_rate)){labinvoice_rate = 0;}
			
			var labinvoice_qtyarray = document.getElementsByName("labinvoice_qty[]");
			var labinvoice_qty = parseFloat(labinvoice_qtyarray[indexpos].value);
			if(labinvoice_qty=='' || isNaN(labinvoice_qty)){labinvoice_qty = 0;}
			
			var total = parseFloat(labinvoice_rate*labinvoice_qty);
			
			var labinvoice_discarray = document.getElementsByName("labinvoice_disc[]");
			var labinvoice_disc = parseFloat(labinvoice_discarray[indexpos].value);
			if(labinvoice_disc=='' || isNaN(labinvoice_disc)){labinvoice_disc = 0;}
			
			var total = parseFloat(total-labinvoice_disc);
			
			var labinvoice_totalarray = document.getElementsByName("labinvoice_total[]");
			labinvoice_totalarray[indexpos].value = total.toFixed(2);
			
		}
		
		calculate_total();
	}
	
	function calculate_total(){
		var labinvoice_subtotal = 0;
		var labinvoice_totalarray = document.getElementsByName("labinvoice_total[]");
		if(labinvoice_totalarray.length>0){
			for(var p=0; p<labinvoice_totalarray.length; p++){
				var labinvoice_total = parseFloat(labinvoice_totalarray[p].value);
				if(labinvoice_total=='' || isNaN(labinvoice_total)){labinvoice_total = 0;}
				labinvoice_subtotal = parseFloat(labinvoice_subtotal+labinvoice_total);
			}
		}
		//subtotal calculation
		document.getElementById("labinvoice_subtotal").value = labinvoice_subtotal.toFixed(2);
		
		var labinvoice_totaldiscp = parseFloat(document.getElementById("labinvoice_totaldiscp").value);
		if(labinvoice_totaldiscp=='' || isNaN(labinvoice_totaldiscp)){labinvoice_totaldiscp = 0;}
		
		var labinvoice_totaldisc = parseFloat(document.getElementById("labinvoice_totaldisc").value);
		if(labinvoice_totaldisc=='' || isNaN(labinvoice_totaldisc)){labinvoice_totaldisc = 0;}
		
		if(labinvoice_totaldiscp>0){
			var labinvoice_totaldisc = parseFloat(labinvoice_subtotal*labinvoice_totaldiscp*0.01);
			document.getElementById('labinvoice_totaldisc').value= labinvoice_totaldisc;
		}
		var labinvoice_subtotalafterdisc = parseFloat(labinvoice_subtotal-labinvoice_totaldisc);
		document.getElementById('labinvoice_subtotalafterdisc').value=	labinvoice_subtotalafterdisc.toFixed(2);
			
		var labinvoice_receiveamount = parseFloat(document.getElementById("labinvoice_receiveamount").value);
		if(labinvoice_receiveamount=='' || isNaN(labinvoice_receiveamount)){labinvoice_receiveamount = 0;}
		
		var labinvoice_due = parseFloat(labinvoice_subtotalafterdisc-labinvoice_receiveamount);
		document.getElementById('labinvoice_due').value=labinvoice_due.toFixed(2);		
		
		
		
	var varTDShowTotalAmount1 = document.getElementById("labinvoice_subtotalafterdisc").value;
	document.getElementById("tdShowTotalAmount1").innerHTML = varTDShowTotalAmount1;

		
		//pc comission  percentage...
		
	var labinvoice_totalpccomission = document.getElementById("labinvoice_totalpccomission").value;
	if(labinvoice_totalpccomission=='' || isNaN(labinvoice_totalpccomission)){labinvoice_totalpccomission = 0;}
		
		labinvoice_totalpccomission_percent = ((labinvoice_totalpccomission*100)/labinvoice_subtotal);
		document.getElementById('labinvoice_totalpccomission_percent').value=labinvoice_totalpccomission_percent;
		//pc comission  percentage...
		
		// new 21-08-16
		// discount 50/50
		var labinvoice_totalpccomission = 0;
		var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
		if(labinvoice_pccomissionarray.length>0){
			for(var p=0; p<labinvoice_pccomissionarray.length; p++){
				var labinvoice_pccomission = parseFloat(labinvoice_pccomissionarray[p].value);
				if(labinvoice_pccomission=='' || isNaN(labinvoice_pccomission)){labinvoice_pccomission = 0;}
				labinvoice_totalpccomission = parseFloat((labinvoice_totalpccomission+labinvoice_pccomission));
			//if(labinvoice_totaldiscp>0){
			//var labinvoice_totalpccomission = parseFloat(labinvoice_totalpccomission*labinvoice_totaldiscp*0.01);
			//}
			}
		}
		document.getElementById("labinvoice_totalpccomission").value = labinvoice_totalpccomission-labinvoice_totaldisc;
		
		// 50/50
		//document.getElementById("labinvoice_totalpccomission").value = labinvoice_totalpccomission-labinvoice_totaldisc/2;
		// end 21-08-16
		
		// Discount (dr, pc: 100%)
		var labinvoice_totalpccomission = 0;
		var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
		if(labinvoice_pccomissionarray.length>0){
			for(var p=0; p<labinvoice_pccomissionarray.length; p++){
				var labinvoice_pccomission = parseFloat(labinvoice_pccomissionarray[p].value);
				if(labinvoice_pccomission=='' || isNaN(labinvoice_pccomission)){labinvoice_pccomission = 0;}
				labinvoice_totalpccomission = parseFloat((labinvoice_totalpccomission+labinvoice_pccomission));
			if(labinvoice_totaldiscp>0){
			document.getElementById("labinvoice_totalpccomission").value = labinvoice_totalpccomission-labinvoice_totaldisc;
				}
			}
		}
		// end 21-08-16
		
		// dr comission
		// new 21-08-16
		var labinvoice_totaldrcomission = 0;
		var labinvoice_drcomissionarray = document.getElementsByName("labinvoice_drcomission[]");
		if(labinvoice_drcomissionarray.length>0){
			for(var m=0; m<labinvoice_drcomissionarray.length; m++){
				var labinvoice_drcomission = parseFloat(labinvoice_drcomissionarray[m].value);
				if(labinvoice_drcomission=='' || isNaN(labinvoice_drcomission)){labinvoice_drcomission = 0;}
				
			labinvoice_totaldrcomission = parseFloat((labinvoice_totaldrcomission+labinvoice_drcomission));
			//labinvoice_totalpccomission = parseFloat(labinvoice_totalpccomission);
			if(labinvoice_totaldiscp>0){
			var labinvoice_totaldisc = parseFloat(labinvoice_totaldrcomission*labinvoice_totaldiscp*0.01);
			//document.getElementById('labinvoice_totaldisc').value= labinvoice_totaldisc;
		}}
		}
		document.getElementById("labinvoice_totaldrcomission").value = labinvoice_totaldrcomission;
		// end 21-08-16
		
	
	}
	

	function calculate_pctotal(){
		var labinvoice_totalpccomission = 0;
		var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
		if(labinvoice_pccomissionarray.length>0){
			for(var p=0; p<labinvoice_pccomissionarray.length; p++){
				var labinvoice_pccomission = parseFloat(labinvoice_pccomissionarray[p].value);
				if(labinvoice_pccomission=='' || isNaN(labinvoice_pccomission)){labinvoice_pccomission = 0;}
				labinvoice_totalpccomission = parseFloat(labinvoice_totalpccomission+labinvoice_pccomission);
				}
			}
		document.getElementById("labinvoice_totalpccomission").value = labinvoice_totalpccomission;
		calculate_total();
						
		}
	
	function calculate_drtotal(){
		var labinvoice_totaldrcomission = 0;
		var labinvoice_drcomissionarray = document.getElementsByName("labinvoice_drcomission[]");
		if(labinvoice_drcomissionarray.length>0){
			for(var m=0; m<labinvoice_drcomissionarray.length; m++){
				var labinvoice_drcomission = parseFloat(labinvoice_drcomissionarray[m].value);
				if(labinvoice_drcomission=='' || isNaN(labinvoice_drcomission)){labinvoice_drcomission = 0;}
				labinvoice_totaldrcomission = parseFloat(labinvoice_totaldrcomission+labinvoice_drcomission);
			}
		}
		
		document.getElementById("labinvoice_totaldrcomission").value = labinvoice_totaldrcomission;
		
	}
	
	
	
	function check_particular(){
		
		return true;
	}
	function addnew_particularrow(animate) {
		if(check_particular()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" style=\"BORDER-COLLAPSE: collapse; border:2px solid #FFF\" bgcolor=\"#c0d2ff\" align=\"left\" width=\"<?php echo $printdata_address3;?>\" border=\"0\" cellspacing=\"1\" cellpadding=\"4\">"+
							'<tr>'+
								'<td align="right">Test Name</td>'+
								'<td><input type="text" name="labinvoice_item[]" class="tdclasss itemname labinvoice_item"/></td>'+
								'<input type="hidden" name="labitem_id[]" id="labitem_id" class="tdclass itemname" />'+
								'<input type="hidden" name="labinvoice_group[]" class="tdclass" />'+
								'<input type="hidden" name="labinvoice_category[]" class="tdclass" />'+
								'<input type="hidden" name="category[]" class="tdclass" />'+
								'<input type="hidden" name="note[]" class="tdclass" />'+
								'<input type="hidden" name="orderby[]" class="tdclass" />'+
								'<input type="hidden" name="labinvoice_testgroup[]" class="tdclass" />'+
								'<input type="hidden" name="labinvoice_sample[]" class="tdclass" />'+
								'<input type="hidden" name="machine_name[]" class="tdclass" />'+
								'<input type="hidden" name="labinvoice_unit[]" class="tdclass" />'+
								'<input type="hidden" name="labinvoice_refvalue[]" class="tdclass" />'+
								'<!--<td align="right">Stock</td>-->'+
								"<input type=\"hidden\" name=\"labinvoice_reagent[]\" id=\"labinvoice_reagent\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/>"+											 
								'<td align="right">Rate</td>'+
								"<td><input type=\"text\" name=\"labinvoice_rate[]\"  id=\"labinvoice_rate\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/></td>"+											 
								'<!--<td align="right">Qty</td>-->'+
								"<input type=\"hidden\" name=\"labinvoice_qty[]\" id=\"labinvoice_qty\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/>"+
								'<td align="right">Disc%</td>'+
								'<td><input type="text" name="labinvoice_discountp[]" class="tdclasssale" onKeyUp="calculate_discountp();"/></td>'+
								'<td align="right">Disc</td>'+
								"<td><input type=\"text\" name=\"labinvoice_disc[]\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\" /></td>"+
								'<td align="right">P.C</td>'+
								'<td><input type="text" name="labinvoice_pccomission[]"  class="tdclasssale" onKeyUp="calculate_pctotal();" /></td>'+
								'<!--<td align="right">Dr.</td>-->'+
								'<td><input type="hidden" name="labinvoice_drcomission[]" class="tdclasssale" onKeyUp="calculate_pctotal();" /></td>'+
								'<td align="right">Total</td>'+
								'<td><input type="text" readonly name="labinvoice_total[]" id="labinvoice_total" class="tdclasssale" /></td>'+												
								'<td>'+
								 "<input type=\"button\" value=\"Del\" onClick=\"deletethislistrow('particularlistrowno"+particular_rowcount+"');\" class=\"tdclasssale\"  />"+
								'</td>'+
							  '</tr>'+
						"</table>";
						
			var $newparticularlist = $("<li></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(200); 
			else 
			   $newparticularlist.show();   
			 document.getElementsByName("labinvoice_item[]")[parseInt(particular_rowcount-1)].focus();
			
			$( ".itemname" ).autocomplete({			
				minLength: 1,
				source: itemdata,
				focus: function( event, ui ) {
					//$( "#search_item_number" ).val( ui.item.labelval );
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					var labitem_idarray = document.getElementsByName("labitem_id[]");
				labitem_idarray[indexpos].value = ui.item.labitem_id;

				var labinvoice_ratearray = document.getElementsByName("labinvoice_rate[]");
				labinvoice_ratearray[indexpos].value = ui.item.labitem_price;

				var labinvoice_qtyarray = document.getElementsByName("labinvoice_qty[]");
				labinvoice_qtyarray[indexpos].value = 1;

				var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
				labinvoice_pccomissionarray[indexpos].value = ui.item.labitem_pccommission;

				var labinvoice_drcomissionarray = document.getElementsByName("labinvoice_drcomission[]");
				labinvoice_drcomissionarray[indexpos].value = ui.item.labitem_drcommission;

				var labinvoice_grouparray = document.getElementsByName("labinvoice_group[]");
				labinvoice_grouparray[indexpos].value = ui.item.labitem_group;
				
				var labinvoice_categoryarray = document.getElementsByName("labinvoice_category[]");
				labinvoice_categoryarray[indexpos].value = ui.item.labitem_category;
				
				var labinvoice_testgrouparray = document.getElementsByName("labinvoice_testgroup[]");
				labinvoice_testgrouparray[indexpos].value = ui.item.labitem_testgroup;

				var labinvoice_samplearray = document.getElementsByName("labinvoice_sample[]");
				labinvoice_samplearray[indexpos].value = ui.item.labitem_sample;
				
				var categoryarray = document.getElementsByName("category[]");
				categoryarray[indexpos].value = ui.item.category;
				
				var notearray = document.getElementsByName("note[]");
				notearray[indexpos].value = ui.item.note;
				
				var orderbyarray = document.getElementsByName("orderby[]");
				orderbyarray[indexpos].value = ui.item.orderby;
				
				var machine_namearray = document.getElementsByName("machine_name[]");
				machine_namearray[indexpos].value = ui.item.machine_name;

				var labinvoice_unitarray = document.getElementsByName("labinvoice_unit[]");
				labinvoice_unitarray[indexpos].value = ui.item.labitem_unit;

				var labinvoice_refvaluearray = document.getElementsByName("labinvoice_refvalue[]");
				labinvoice_refvaluearray[indexpos].value = ui.item.labitem_refvalue;

				var labinvoice_reagentarray = document.getElementsByName("labinvoice_reagent[]");
				labinvoice_reagentarray[indexpos].value = ui.item.labitem_reagent;
	
					calculaterowtotal(indexpos);
					calculate_pctotal();
					calculate_drtotal();
					addnew_particularrow(true);   //automatic add next row
					return false;
				}
			});	

			$( ".labinvoice_item" ).keypress(function(keyname) {
			if(keyname.which==13){
				var imei = $(this).val();
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();

				$.each(itemarraydata, function(key, value){
					var valuearray = value.split('||');
					if(key==imei){
						document.getElementsByName("labitem_id[]")[indexpos].value = valuearray[0];
						//document.getElementsByName("salesinvoice_item[]")[indexpos].value = valuearray[1];
						document.getElementsByName("labinvoice_category[]")[indexpos].value = valuearray[1];
						document.getElementsByName("labinvoice_unit[]")[indexpos].value = valuearray[2];
						document.getElementsByName("labinvoice_refvalue[]")[indexpos].value = valuearray[3];
						document.getElementsByName("labinvoice_rate[]")[indexpos].value = valuearray[4];
						document.getElementsByName("labinvoice_reagent[]")[indexpos].value = valuearray[5];
						document.getElementsByName("labinvoice_pccomission[]")[indexpos].value = valuearray[6];
						document.getElementsByName("labinvoice_drcomission[]")[indexpos].value = valuearray[7];
						document.getElementsByName("labinvoice_qty[]")[indexpos].value = 1;

						calculaterowtotal(indexpos);
						addnew_particularrow(true);
					}
				});
				return false;
			}
		});				
		}
	}

	function deletethislistrow(tableidname){
		$("#"+tableidname).parent("li").slideUp(200, function() {
			$(this).remove();
			calculaterowtotal('all');
		});
	}
	
// prevent multi times save

function funcSaveBill1()
{
	
	var varUserChoice; 
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet); 
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		document.frmsales.submit();
		//return true;
	}
}

function checkcontactform(){
		var labinvoice_mobile = document.getElementById("labinvoice_mobile");
		var error_labinvoice_mobile = document.getElementById("error_labinvoice_mobile");
		error_labinvoice_mobile.innerHTML = '';
		if(labinvoice_mobile.value==''){
			error_labinvoice_mobile.innerHTML = "Number is missing.";
			labinvoice_mobile.focus();
			return false;
		}
		else if(labinvoice_mobile.value.length<10){
			error_labinvoice_mobile.innerHTML = "Number should be 11 Digit.";
			labinvoice_mobile.focus();
			return false;
		}
		
		
		var labinvoice_totaldiscp = document.getElementById("labinvoice_totaldiscp");
		var error_labinvoice_totaldiscp = document.getElementById("error_labinvoice_totaldiscp");
		error_labinvoice_totaldiscp.innerHTML = '';
		if(labinvoice_totaldiscp.value==''){
			error_labinvoice_totaldiscp.innerHTML = "Disc is missing.";
			labinvoice_totaldiscp.focus();
			return false;
		}
		else if(labinvoice_totaldiscp.value>50){
			error_labinvoice_totaldiscp.innerHTML = "Disc should be less than 10%";
			labinvoice_totaldiscp.focus();
			return false;
		}
		
		//pc Discount 
		var labinvoice_totaldisc = document.getElementById("labinvoice_totaldisc");
		var error_labinvoice_totaldisc = document.getElementById("error_labinvoice_totaldisc");
		error_labinvoice_totaldisc.innerHTML = '';
		if(labinvoice_totaldisc.value==''){
			error_labinvoice_totaldisc.innerHTML = "Disc is missing.";
			labinvoice_totaldisc.focus();
			return false;
		}
		else if(labinvoice_totaldisc.value>1000){
			error_labinvoice_totaldisc.innerHTML = "Disc should be greater than 1000";
			labinvoice_totaldisc.focus();
			return false;
		}
		
		var labinvoice_totalpccomission = document.getElementById("labinvoice_totalpccomission");
		var error_labinvoice_totalpccomission = document.getElementById("error_labinvoice_totalpccomission");
		error_labinvoice_totalpccomission.innerHTML = '';
		if(labinvoice_totalpccomission.value==''){
			error_labinvoice_totalpccomission.innerHTML = "PC comission is missing.";
			labinvoice_totalpccomission.focus();
			return false;
		}
		else if(labinvoice_totalpccomission.value<1){
			error_labinvoice_totalpccomission.innerHTML = "PC comission should be less than 1";
			labinvoice_totalpccomission.focus();
			return false;
		}
				
		return true;

	}
</script>