<?php
$searchstr='';
date_default_timezone_set('Asia/Dhaka'); 

if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
	{
		$transactiondatefrom = $_REQUEST['ADate1'];
		$transactiondateto = $_REQUEST['ADate2'];
	}
	else
	{
		$transactiondatefrom = date('Y-m-d', strtotime('-1 month'));
		$transactiondateto = date('Y-m-d');
	}
?>
<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td valign="top" align="center">
    	<form name="cbform1" method="post" action="index.php?p=balancesheet">
            <table width="100%" border="0" align="center" cellpadding="2" cellspacing="0" bordercolor="#666666" id="AutoNumber3" style="border-collapse: collapse">
              <tbody>
                <tr bgcolor="#011E6A">
                  <td colspan="6" bgcolor="#CCCCCC" class="bodytext3"><strong>Search Date wise</strong></td>
                </tr>           
                <tr>
                    <td class="bodytext31" width="10%" valign="center"  align="right" bgcolor="#FFFFFF"> Date From&nbsp;:&nbsp;</td>
                    <td width="16%" align="left" valign="center"  bgcolor="#FFFFFF" class="bodytext31">
                        <input name="ADate1" id="ADate1" style="border: 1px solid #001E6A" value="<?php echo $transactiondatefrom; ?>"  size="10"  readonly="readonly" onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
                    </td>
                    <td width="10%" align="right" valign="center"  bgcolor="#FFFFFF" class="bodytext31"> Date To&nbsp;:&nbsp;</td>
                    <td width="16%" align="left" valign="center"  bgcolor="#FFFFFF">
                    <span class="bodytext31">
                        <input name="ADate2" id="ADate2" style="border: 1px solid #001E6A" value="<?php echo $transactiondateto; ?>"  size="10"  readonly="readonly" onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate2')" style="cursor:pointer"/>
                    </span>
                    </td>
                    <td align="left" valign="top"  bgcolor="#FFFFFF">
                        <input type="hidden" name="cbfrmflag1" value="cbfrmflag1">
                        <input  style="border: 1px solid #001E6A" type="submit" value="Search" name="Submit" />
                        <input name="resetbutton" type="reset" id="resetbutton"  style="border: 1px solid #001E6A" value="Reset" />
                    </td>
                    <td width="10%" align="right" valign="top"  bgcolor="#FFFFFF">
                       <input name="print" type="button" id="print"  style="border: 1px solid #001E6A" value="Print" onClick="PrintElem('#printarea');" />
                    </td>
                </tr>
              </tbody>
            </table>
		</form>
     	<script type="text/javascript">
        
            function PrintElem(elem)
            {
                var data = $(elem).html();
				
				var mywindow = window.open('', 'my div', 'height=500,width=800');
                mywindow.document.write('<html><head><title>Print Loss/Profit Report</title>');
                mywindow.document.write('<link rel="stylesheet" href="css/default.css" type="text/css" />');
                mywindow.document.write('</head><body >');
                mywindow.document.write(data);
                mywindow.document.write('</body></html>');
                mywindow.document.close(); // necessary for IE >= 10
                mywindow.focus(); // necessary for IE >= 10
                mywindow.print();
               //	mywindow.close();
        
                return true;
            }        
        </script>
   	</td>
</tr>

<tr>
    <td align="center" id="printarea">
		<?php 
		$datetime1 = new DateTime($transactiondatefrom);
		$datetime2 = new DateTime($transactiondateto);
		$interval = $datetime1->diff($datetime2);
		$totaldays = $interval->format('%a');
		if($datetime1<$datetime2){
			$fromdate = $transactiondatefrom;
			$todate = $transactiondateto;
		}
		else{
			$fromdate = $transactiondateto;
			$todate = $transactiondatefrom;
		}
		?>
          <table align="center" width="60%" border="1" style="BORDER-COLLAPSE: collapse" cellspacing="1" cellpadding="2">
          <tr>
            <td align="center" colspan="17" bgcolor="#011E6A" style="color:#FFF; padding-left:15px;">
            	<strong>Balance Sheet :: For The Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></strong>
            </td>
          </tr>
          </table>
        
        <table align="center" style="BORDER-COLLAPSE: collapse" width="60%" border="1" >
       
            <tr bgcolor="#77F7AA" >
                <td width="300"><strong>Section</strong></td>
              	<td width="300"><strong>Capital (Amount)</strong></td> 
               </tr>
         </table>
        
       <table align="center" style="BORDER-COLLAPSE: collapse" width="60%" border="1" >
           <tr bgcolor="#CCCCCC" style="color:#00F">
           <td align="left" style="color:#3654E0"><strong>Capital/Investment </strong></td>
           </tr>
      </table>
               
 	<table align="center" bgcolor="#FFFFFF" style="border-collapse:collapse" width="60%" border="1" >

 	<?php
		$totalsuminitialcapital_amount='0.00';
			
			$sqlst = "select * from initialcapital  order by initialcapital_id asc";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery &&  mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery)) {
					$initialcapital_id = $strow['initialcapital_id'];
                    $initialcapital_name = $strow['initialcapital_name'];
					$user = $strow['user'];
                   	$initialcapital_head = $strow['initialcapital_head'];
                    $initialcapital_amount = $strow['initialcapital_amount'];
                    $initialcapital_description = $strow['initialcapital_description'];
                    $initialcapital_date = $strow['initialcapital_date'];
					$totalsuminitialcapital_amount  = $totalsuminitialcapital_amount + $initialcapital_amount;
				}
			}
		?>
        <tr>
          <td width="300" align="left">Initial Capital: </td>
          <td align="left" width="300" >
          <strong><?php echo number_format($totalsuminitialcapital_amount, 2, '.', ''); ?></strong></td>
         </tr>
        
        </table>
        
       
<table align="center" bgcolor="#FFFFFF" style="border-collapse:collapse" width="60%" border="1" >
<?php
 $s='';
 $total_deposite_amount=0;
 $total_withdrawal_amount=0;
  for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
	$sqlst = "select * from bankinvoice where bankinvoice_date between '$newfromdate' and '$newtodate' $searchstr order by bankinvoice_id asc";
	  	$stquery = mysqli_query($conn, $sqlst);
			if($stquery && mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery))
			 	{
                    $bankinvoice_id = $strow['bankinvoice_id'];
					$user = $strow['user'];
                    $bankinvoice_name = $strow['bankinvoice_name'];
                    $bankinvoice_number = $strow['bankinvoice_number'];
                    $bankinvoice_address = $strow['bankinvoice_address'];
					$deposite_amount = $strow['deposite_amount'];
					$withdrawal_amount = $strow['withdrawal_amount'];
					$bankinvoice_date=	$strow['bankinvoice_date'];
				
					$total_deposite_amount=$total_deposite_amount+$deposite_amount;
					$total_withdrawal_amount=$total_withdrawal_amount+$withdrawal_amount;
					}
				}
		 	 }
		  ?>
      
         <tr>
          <td width="300" align="left">Add Share Capital:</td>
          <td align="left" width="300" >
          <strong><?php // echo number_format($totalsuminitialcapital_amount, 2, '.', ''); ?></strong></td>
         </tr>
        </table>
        
        
   	<table align="center" style="border-collapse:collapse" width="60%" border="1" >
	<?php
         $s='';
         $total_deposite_amount=0;
         $total_withdrawal_amount=0;
          for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
                    
            $sqlst = "select * from bankinvoice where bankinvoice_date between '$newfromdate' and '$newtodate' $searchstr order by bankinvoice_id asc";
                $stquery = mysqli_query($conn, $sqlst);
                    if($stquery && mysqli_num_rows($stquery)>0){
                    while ($strow = mysqli_fetch_array($stquery))
                        {
                            $bankinvoice_id = $strow['bankinvoice_id'];
                            $user = $strow['user'];
                            $bankinvoice_name = $strow['bankinvoice_name'];
                            $bankinvoice_number = $strow['bankinvoice_number'];
                            $bankinvoice_address = $strow['bankinvoice_address'];
                            $deposite_amount = $strow['deposite_amount'];
                            $withdrawal_amount = $strow['withdrawal_amount'];
                            $bankinvoice_date=	$strow['bankinvoice_date'];
                        
                            $total_deposite_amount=$total_deposite_amount+$deposite_amount;
                            $total_withdrawal_amount=$total_withdrawal_amount+$withdrawal_amount;
                            }
                        }
                     }
                  ?>
      
                <tr>
                 <td  width="300" align="left">Retained Profits (After Giving Profit to  ShareHolders):</td>
                <td  width="300"></td>
                </tr>
        </table>
        
   		<table align="center" style="BORDER-COLLAPSE: collapse" width="60%" border="1" >
            <tr bgcolor="#CCCCCC">
            <td align="left" style="color:#3654E0"><strong>Liabilities </strong></td>
            <td align="left" style="color:#3654E0"></td>
            </tr>
       
  <?php
 $totalpurchaseinvoice_due='0.00';
		
  for($i=0; $i<=$totaldays; $i++){
	$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
	$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
	$sqlst = "select * from storepurchaseinvoice where purchaseinvoice_due > 0 and purchaseinvoice_date between '$newfromdate' and '$newtodate' $searchstr order by purchaseinvoice_id desc";
	  	$stquery = mysqli_query($conn, $sqlst);
			if($stquery && mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery))
			
			 	{
                    $purchaseinvoice_id = $strow['purchaseinvoice_id'];
                    $purchaseinvoice_patientid = $strow['purchaseinvoice_patientid'];
					$user = $strow['user'];
                    $purchaseinvoice_patient = $strow['purchaseinvoice_patient'];
                    $purchaseinvoice_address = $strow['purchaseinvoice_address'];
					$purchaseinvoice_mobile = $strow['purchaseinvoice_mobile'];
					$purchaseinvoice_subtotal = $strow['purchaseinvoice_subtotal'];
					$purchaseinvoice_subtotalafterdisc = $strow['purchaseinvoice_subtotalafterdisc'];
					$purchaseinvoice_receiveamount = $strow['purchaseinvoice_receiveamount'];
					$purchaseinvoice_due = $strow['purchaseinvoice_due'];
					$purchaseinvoice_description = $strow['purchaseinvoice_description'];
					$purchaseinvoice_date=	$strow['purchaseinvoice_date'];
						
					$totalpurchaseinvoice_due  = $totalpurchaseinvoice_due + $purchaseinvoice_due;
					
					}
				}
			}
		  ?>
      
        <tr>
          <td width="300" align="left">Account Payable[Purchase Dues Amount]: </td>
          <td align="left" width="300" >
          <strong><?php echo number_format($totalpurchaseinvoice_due, 2, '.', ''); ?></strong></td>
         </tr>
         </table>
       
  <table align="center" style="BORDER-COLLAPSE: collapse" width="60%" border="1" >
  <?php
	$total_deposite_amount=0;
  	for($i=0; $i<=$totaldays; $i++){
		$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
		$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
	$sqlst = "select * from loaninvoice where  withdrawal_amount!='' and  loaninvoice_date between '$newfromdate' and '$newtodate' $searchstr order by loaninvoice_id desc";
	  	$stquery = mysqli_query($conn, $sqlst);
			if($stquery && mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery))
			 	{
                    $loaninvoice_id = $strow['loaninvoice_id'];
					$user = $strow['user'];
                    $loaninvoice_name = $strow['loaninvoice_name'];
                    $loaninvoice_number = $strow['loaninvoice_number'];
                    $loaninvoice_address = $strow['loaninvoice_address'];
					$withdrawal_amount = $strow['withdrawal_amount'];
					$loaninvoice_date=	$strow['loaninvoice_date'];
				
					$total_deposite_amount=$total_deposite_amount+$withdrawal_amount;
				
					}
				}
		  	}
		  ?>
      
        <tr>
            <td align="left" width="300">Loan Payable:</td>
            <td width="300"><?php echo $total_deposite_amount;?></td>
        </tr>
        
        <tr>
            <td align="right" width="300">Total Liabilities :</td>
            <td align="left" width="300" bgcolor="#E9E3E4"><strong><?php //echo number_format($profite, 2, '.', ''); ?></strong></td>
        </tr> 
        </table>
        
   	<table align="center" style="BORDER-COLLAPSE: collapse; margin-top:2px;" width="60%" border="1">
		<?php
		$totalsumlabinvoice_receiveamount='0.00';
		$totalsumlabinvoice_receiveamount='0.00';
		$totalsumcollection_amount='0.00';
		$totalsumdiscount_amount='0.00';
		$totalsumexpense_amount='0.00';
		$totalsumlabinvoice_subtotal  ='';
		$totalsumlabinvoice_subtotalafterdisc  ='';
		$totalsumlabinvoice_due  ='';
		$totalsumlabpcpaid_amount='0.00';
		$totalsumsalaryentry_paid='0.00';
		$s='';
			
			$sqllabinvoice = "select * from dailytransection_lab order by section asc";
	  		$labinvoicequery = mysqli_query($conn, $sqllabinvoice);
			if($labinvoicequery &&  mysqli_num_rows($labinvoicequery)>0){
			while ($labinvoicerow = mysqli_fetch_array($labinvoicequery)) {
					$dailytransection_lab_id = $labinvoicerow['dailytransection_lab_id'];
                    $labinvoice_patientid = $labinvoicerow['labinvoice_patientid'];
                    $labinvoice_id = $labinvoicerow['labinvoice_id'];
                    $labinvoice_patient = $labinvoicerow['labinvoice_patient'];
                    $labinvoice_receiveamount = $labinvoicerow['labinvoice_receiveamount'];
                    $discount_amount = $labinvoicerow['discount_amount'];
					$expense_amount = $labinvoicerow['expense_amount'];
					$salaryentry_paid = $labinvoicerow['salaryentry_paid'];
					$labpcpaid_amount = $labinvoicerow['labpcpaid_amount'];
					$labinvoice_address = $labinvoicerow['labinvoice_address'];
                    $user = $labinvoicerow['user'];
					$update_user = $labinvoicerow['update_user'];
					 $section = $labinvoicerow['section'];
					$collection_amount = $labinvoicerow['collection_amount'];
					$labinvoice_subtotal = $labinvoicerow['labinvoice_subtotal'];
					$labinvoice_subtotalafterdisc = $labinvoicerow['labinvoice_subtotalafterdisc'];
					$labinvoice_due = $labinvoicerow['labinvoice_due'];
					$dailytransection_lab_date = $labinvoicerow['dailytransection_lab_date'];
					$dailytransection_lab_update = $labinvoicerow['dailytransection_lab_update'];
				
				 
					$totalsumlabinvoice_receiveamount  = $totalsumlabinvoice_receiveamount + $labinvoice_receiveamount;
					$totalsumcollection_amount  = $totalsumcollection_amount + $collection_amount;
					$totalsumdiscount_amount  = $totalsumdiscount_amount + $discount_amount;
					$totalsumlabinvoice_subtotal  = $totalsumlabinvoice_subtotal + $labinvoice_subtotal;
					$totalsumlabinvoice_subtotalafterdisc  = $totalsumlabinvoice_subtotalafterdisc + $labinvoice_subtotalafterdisc;
					$totalsumlabinvoice_due  = $totalsumlabinvoice_due + $labinvoice_due;
					$totalsumexpense_amount  = $totalsumexpense_amount + $expense_amount;
					$totalsumsalaryentry_paid  = $totalsumsalaryentry_paid + $salaryentry_paid;
					$totalsumlabpcpaid_amount  = $totalsumlabpcpaid_amount + $labpcpaid_amount;
					}
				}
			?>
        
        <tr>
            <td align="left" bgcolor="#ccc" width="300" style="color:#00F">Loss or Profit: </td>
           <td align="left"  width="300"><?php echo $totalsumlabinvoice_receiveamount+$totalsumcollection_amount -$totalsumexpense_amount-$totalsumsalaryentry_paid-$totalsumlabpcpaid_amount; ?> </td>
            </tr>
        </table>
      <br>
     <br>
        
        <table align="center" style="BORDER-COLLAPSE: collapse" width="60%" border="1" >
            <tr bgcolor="#77F7AA" >
                <td width="300"><strong>Section</strong></td>
              	<td width="300"><strong> Asset (Amount)</strong></td> 
              </tr>
         </table> 
         
    <table align="center" style="BORDER-COLLAPSE: collapse" width="60%" border="1" >
        <tr bgcolor="#CCCCCC">
         <td align="left" style="color:#3654E0"><strong>Fixed Asset/Property/Equiepment </strong></td>
       </tr>
       
       
		<?php
		$totalsumassetentry_amount='0.00';
			$sqlst = "select * from assetentry order by assetentry_id asc";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery &&  mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery)) {
					$assetentry_id = $strow['assetentry_id'];
                    $assetentry_name = $strow['assetentry_name'];
					$user = $strow['user'];
                   	$assetentry_head = $strow['assetentry_head'];
                    $assetentry_amount = $strow['assetentry_amount'];
                    $assetentry_description = $strow['assetentry_description'];
                    $assetentry_date = $strow['assetentry_date'];
					$totalsumassetentry_amount  = $totalsumassetentry_amount + $assetentry_amount;
					?>
                <tr>
                    <td ><?php echo $assetentry_name; ?></td>
                    <td><?php echo $assetentry_amount; ?></td>
              	</tr>
                <?php
                	
				}
			}
		?>
        	<tr>
              <td width="300" align="left">Total Fixed Asset:</td>
               <td width="300" align="left" >
              <strong><?php echo number_format($totalsumassetentry_amount, 2, '.', ''); ?></strong></td>
            </tr>
            </table>
            
    <table align="center" style="BORDER-COLLAPSE: collapse" width="60%" border="1" >
		<?php
		$totalsuminventorysalesinvoice_receiveamount='0.00';
		
		for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
			$sqlst = "select * from inventorysalesinvoice where inventorysalesinvoice_date between '$newfromdate' and '$newtodate' $searchstr order by inventorysalesinvoice_id desc";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery &&  mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery)) {
					$inventorysalesinvoice_id = $strow['inventorysalesinvoice_id'];
                    $inventorysalesinvoice_patientid = $strow['inventorysalesinvoice_patientid'];
                    $inventorysalesinvoice_patient = $strow['inventorysalesinvoice_patient'];
					$user = $strow['user'];
              		$inventorysalesinvoice_receiveamount = $strow['inventorysalesinvoice_receiveamount'];
		 
        			$totalsuminventorysalesinvoice_receiveamount  = $totalsuminventorysalesinvoice_receiveamount + $inventorysalesinvoice_receiveamount;
          
					}
				}
			}
			?>
        	<tr>
              <td width="300">Asset Sold: </td>
              <td width="300" align="left"><?php echo number_format($totalsuminventorysalesinvoice_receiveamount, 2, '.', ''); ?></td>
            </tr>
              
              <tr>
             <td width="300" align="right">Total Fixed Asset:</td>
              <td width="300" align="left" bgcolor="#E9E3E4"><strong> <?php echo number_format($totalsuminventorysalesinvoice_receiveamount, 2, '.', ''); ?></strong></td>
             </tr>
        </table>
        
  	<table align="center"  style="border-collapse:collapse" width="60%" border="1" >
  <tr bgcolor="#CCCCCC">
   <td align="left" style="color:#3654E0"><strong>Current Asset </strong></td>
    <td align="left" style="color:#3654E0"></td>
  </tr>
        
		
 <?php
 $s='';
 $total_deposite_amount=0;
 $total_withdrawal_amount=0;
  for($i=0; $i<=$totaldays; $i++){
	$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
	$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
	$sqlst = "select * from bankinvoice where bankinvoice_date between '$newfromdate' and '$newtodate' $searchstr order by bankinvoice_id asc";
	  	$stquery = mysqli_query($conn, $sqlst);
			if($stquery && mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery))
			 	{
                    $bankinvoice_id = $strow['bankinvoice_id'];
					$user = $strow['user'];
                    $bankinvoice_name = $strow['bankinvoice_name'];
                    $bankinvoice_number = $strow['bankinvoice_number'];
                    $bankinvoice_address = $strow['bankinvoice_address'];
					$deposite_amount = $strow['deposite_amount'];
					$withdrawal_amount = $strow['withdrawal_amount'];
					$bankinvoice_date=	$strow['bankinvoice_date'];
				
					$total_deposite_amount=$total_deposite_amount+$deposite_amount;
					$total_withdrawal_amount=$total_withdrawal_amount+$withdrawal_amount;
					}
				}
		   }
		  ?>
      
     <tr>
     <td align="left" width="300">Bank: </td>
     <td width="300"><strong><?php echo number_format($total_deposite_amount - $total_withdrawal_amount, 2, '.', '');?></strong></td></tr>
  </table>
       
    <table align="center"  style="border-collapse:collapse" width="60%" border="1" >
    <?php
    $totalsuminventoryinvoice  = '0.00';;
    $totalsuminvdueinvoice  ='0.00';
    $totalsumsalarypaid  ='0.00';
    $totalsumlabinvoice  = '0.00';
    $totalsumlabcollection  = '0.00';
    $totalsumhospitalinvoice  = '0.00';
    $totalsumhospitalcollection  = '0.00';
    $totalsumpharmacyinvoice='0.00';
    $totalsumpharmacycollection = '0.00';
    $totalsumexpense='0.00';
    $totalsumexpense2='0.00';
    $totalsumhospitalpcpaid='0.00';
    $totalsumlabpcpaid='0.00';
    $totalsumhospital='0.00';
    $totalsumlab='0.00';
    $totalsumtotal_inventorysalesinvoice_receiveamount='0.00';
    $totalsumtotal_purchaseinvoice_receiveamount_pharmacy = '0.00';
    $totalsumtotal_paid_amount  ='0.00';
    
    $intotal='0.00';
    $profite='0.00';			
    
    for($i=0; $i<=$totaldays; $i++){
    $newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
    $newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
    
    
    $total_purchaseinvoicepaid_amount =0;
    $total_purchaseinvoice_receiveamount=0;
    $total_sales_amount = 0;
    $total_labinvoicecollection_amount=0;
    $total_hospitalinvoicecollection_amount=0;
    $total_hospital_amount = 0;
    $total_pharmacy_amount =0;
    $total_salesinvoicecollection_amount =0;
    $total_credit_amount = 0;
    $total_expense_amount = 0;
    $total_labpcpaid_amount=0;
    $total_hospitalpcpaid_amount=0;
    $total_cash_amount = 0;
    $total_cash_amount1 = 0;
    $transactionamount =0;
    $cashamount=0;
    $total_salaryentry_paid=0;	
    $total_purchaseinvoice_receiveamount_pharmacy = '0';
    $total_paid_amount  ='0';
    $total_inventorysalesinvoice_receiveamount='0';
    
    $query2 = "select purchaseinvoice_receiveamount from storepurchaseinvoice where purchaseinvoice_date between '$newfromdate' and '$newtodate' and purchaseinvoice_receiveamount>0  order by purchaseinvoice_date asc";
    $exec2 = mysqli_query($conn, $query2);
    if(mysqli_num_rows($exec2)>0){
        while ($onerow = mysqli_fetch_array($exec2)){
            $total_purchaseinvoice_receiveamount = round($total_purchaseinvoice_receiveamount+$onerow['purchaseinvoice_receiveamount']);
        }
    }
    
    $query2 = "select purchaseinvoicepaid_amount from storepurchaseinvoicepaid where purchaseinvoicepaid_date between '$newfromdate' and '$newtodate' and purchaseinvoicepaid_amount>0  order by purchaseinvoicepaid_date asc";
    $exec2 = mysqli_query($conn, $query2);
    if(mysqli_num_rows($exec2)>0){
        while ($onerow = mysqli_fetch_array($exec2)){
            $total_purchaseinvoicepaid_amount = round($total_purchaseinvoicepaid_amount+$onerow['purchaseinvoicepaid_amount']);
        }
    }
    
    
    
    $query2 = "select labinvoice_receiveamount from labinvoice where labinvoice_date between '$newfromdate' and '$newtodate' and labinvoice_receiveamount>0  order by labinvoice_date asc";
    $exec2 = mysqli_query($conn, $query2);
    if(mysqli_num_rows($exec2)>0){
        while ($onerow = mysqli_fetch_array($exec2)){
            $total_sales_amount = round($total_sales_amount+$onerow['labinvoice_receiveamount']);
        }
    }
    
    $query2 = "select collection_amount from labcollection where labcollection_date between '$newfromdate' and '$newtodate' and collection_amount>0  order by labcollection_date asc";
    $exec2 = mysqli_query($conn, $query2);
    if(mysqli_num_rows($exec2)>0){
        while ($onerow = mysqli_fetch_array($exec2)){
            $total_labinvoicecollection_amount = round($total_labinvoicecollection_amount+$onerow['collection_amount']);
        }
    }
    
    $query2 = "select hospitalinvoice_receiveamount from hospitalinvoice where hospitalinvoice_deliverydate between '$newfromdate' and '$newtodate' and hospitalinvoice_receiveamount>0  order by hospitalinvoice_deliverydate asc";
    $exec2 = mysqli_query($conn, $query2);
    if(mysqli_num_rows($exec2)>0){
        while ($onerow = mysqli_fetch_array($exec2)){
            $total_hospital_amount = round($total_hospital_amount+$onerow['hospitalinvoice_receiveamount']);
            
        }
    }
    
    $query2 = "select hospitalinvoicecollection_amount from hospitalinvoicecollection where hospitalinvoicecollection_date between '$newfromdate' and '$newtodate' and hospitalinvoicecollection_amount>0  order by hospitalinvoicecollection_date asc";
    $exec2 = mysqli_query($conn, $query2);
    if(mysqli_num_rows($exec2)>0){
        while ($onerow = mysqli_fetch_array($exec2)){
            $total_hospitalinvoicecollection_amount = round($total_hospitalinvoicecollection_amount+$onerow['hospitalinvoicecollection_amount']);
        }
    }
    
    //pharmacy.........
    $query2 = "select salesinvoice_receiveamount from salesinvoice where salesinvoice_date between '$newfromdate' and '$newtodate' and salesinvoice_receiveamount>0  order by salesinvoice_date asc";
    $exec2 = mysqli_query($conn, $query2);
    if(mysqli_num_rows($exec2)>0){
        while ($onerow = mysqli_fetch_array($exec2)){
            $total_pharmacy_amount = round($total_pharmacy_amount+$onerow['salesinvoice_receiveamount']);
        }
    }
    
    $query2 = "select salesinvoicecollection_amount from salesinvoicecollection where salesinvoicecollection_date between '$newfromdate' and '$newtodate' and salesinvoicecollection_amount>0  order by salesinvoicecollection_date asc";
    $exec2 = mysqli_query($conn, $query2);
    if(mysqli_num_rows($exec2)>0){
        while ($onerow = mysqli_fetch_array($exec2)){
            $total_salesinvoicecollection_amount = round($total_salesinvoicecollection_amount+$onerow['salesinvoicecollection_amount']);
        }
    }
    
    
    $query2 = "select expense_amount from expense where expense_date between '$newfromdate' and '$newtodate' and expense_amount <> 0 order by expense_date asc";
    $exec2 = mysqli_query($conn, $query2);
    if(mysqli_num_rows($exec2)>0){
        while ($onerow = mysqli_fetch_array($exec2)){
            $total_expense_amount = round($total_expense_amount+$onerow['expense_amount']);
        }
    }
    
    
    $query2 = "select labpcpaid_amount from labpcpaid where labpcpaid_date between '$newfromdate' and '$newtodate' and labpcpaid_amount <> 0 order by labpcpaid_date asc";
    $exec2 = mysqli_query($conn, $query2);
    if(mysqli_num_rows($exec2)>0){
        while ($onerow = mysqli_fetch_array($exec2)){
            $total_labpcpaid_amount = round($total_labpcpaid_amount+$onerow['labpcpaid_amount']);
        }
    }
    
    $query2 = "select hospitalpcpaid_amount from hospitalpcpaid where hospitalpcpaid_date between '$newfromdate' and '$newtodate' and hospitalpcpaid_amount <> 0 order by hospitalpcpaid_date asc";
    $exec2 = mysqli_query($conn, $query2);
    if(mysqli_num_rows($exec2)>0){
        while ($onerow = mysqli_fetch_array($exec2)){
            $total_hospitalpcpaid_amount = round($total_hospitalpcpaid_amount+$onerow['hospitalpcpaid_amount']);
        }
    }
    
    $query2 = "select salaryentry_paid from salaryentry where salaryentry_date between '$newfromdate' and '$newtodate' and salaryentry_paid <> 0 order by salaryentry_date asc";
    $exec2 = mysqli_query($conn, $query2);
    if(mysqli_num_rows($exec2)>0){
        while ($onerow = mysqli_fetch_array($exec2)){
            $total_salaryentry_paid = round($total_salaryentry_paid+$onerow['salaryentry_paid']);
        }
    }
    
    
    $query2 = "select purchaseinvoice_receiveamount from purchaseinvoice where purchaseinvoice_date between '$newfromdate' and '$newtodate' and purchaseinvoice_receiveamount <> 0 order by purchaseinvoice_date asc";
    $exec2 = mysqli_query($conn, $query2);
    if(mysqli_num_rows($exec2)>0){
        while ($onerow = mysqli_fetch_array($exec2)){
            $total_purchaseinvoice_receiveamount_pharmacy = round($total_purchaseinvoice_receiveamount_pharmacy+$onerow['purchaseinvoice_receiveamount']);
        }
    }
    
    $query2 = "select paid_amount from companyinvoice where companyinvoice_date between '$newfromdate' and '$newtodate' and paid_amount <> 0 order by companyinvoice_date asc";
    $exec2 = mysqli_query($conn, $query2);
    if(mysqli_num_rows($exec2)>0){
        while ($onerow = mysqli_fetch_array($exec2)){
            $total_paid_amount = round($total_paid_amount+$onerow['paid_amount']);
        }
    }
    
    
    $query2 = "select inventorysalesinvoice_receiveamount from inventorysalesinvoice where inventorysalesinvoice_date between '$newfromdate' and '$newtodate' and inventorysalesinvoice_receiveamount <> 0 order by inventorysalesinvoice_date asc";
    $exec2 = mysqli_query($conn, $query2);
    if(mysqli_num_rows($exec2)>0){
        while ($onerow = mysqli_fetch_array($exec2)){
            $total_inventorysalesinvoice_receiveamount = round($total_inventorysalesinvoice_receiveamount+$onerow['inventorysalesinvoice_receiveamount']);
        }
    }
    
    
    $tcash=$total_cash_amount1+$total_cash_amount;
    
    if($total_salaryentry_paid !=0 ||  $total_sales_amount != 0 || $total_hospitalpcpaid_amount!=0 || $total_labpcpaid_amount!=0 || $total_labinvoicecollection_amount!=0 || $total_hospital_amount != 0 || $total_hospitalinvoicecollection_amount!=0 || $total_pharmacy_amount || $total_expense_amount != 0 || $total_cash_amount != 0 || $total_cash_amount1 != 0 || $total_credit_amount != 0 || $total_inventorysalesinvoice_receiveamount !=0){	
    
    $gross =$total_salesinvoicecollection_amount+$total_sales_amount
    +$total_labinvoicecollection_amount+$total_hospital_amount+$total_hospitalinvoicecollection_amount
    +$total_pharmacy_amount+$total_inventorysalesinvoice_receiveamount;
    $total_credit_amount= $gross - $total_expense_amount;
    ?>
    
    <?php  
        $totalsuminventoryinvoice  = $totalsuminventoryinvoice + $total_purchaseinvoice_receiveamount;
        $totalsuminvdueinvoice  = $totalsuminvdueinvoice + $total_purchaseinvoicepaid_amount;
        
        $totalsumlabinvoice  = $totalsumlabinvoice + $total_sales_amount;
        $totalsumlabcollection  = $totalsumlabcollection + $total_labinvoicecollection_amount;
        
        $totalsumhospitalinvoice  = $totalsumhospitalinvoice + $total_hospital_amount;
        $totalsumhospitalcollection  = $totalsumhospitalcollection + $total_hospitalinvoicecollection_amount;
        $totalsumsalarypaid  = $totalsumsalarypaid + $total_salaryentry_paid;
        
        $totalsumpharmacyinvoice  = $totalsumpharmacyinvoice + $total_pharmacy_amount;
        $totalsumpharmacycollection  = $totalsumpharmacycollection + $total_salesinvoicecollection_amount;
        
        $totalsumexpense2  =$totalsumexpense2 + $total_expense_amount;
        
        $totalsumhospitalpcpaid = $totalsumhospitalpcpaid + $total_hospitalpcpaid_amount;
        $totalsumlabpcpaid  = $totalsumlabpcpaid + $total_labpcpaid_amount;
        
        $totalsumtotal_purchaseinvoice_receiveamount_pharmacy = $totalsumtotal_purchaseinvoice_receiveamount_pharmacy + $total_purchaseinvoice_receiveamount_pharmacy;
        $totalsumtotal_paid_amount  = $totalsumtotal_paid_amount + $total_paid_amount;
        
        $totalsumtotal_inventorysalesinvoice_receiveamount  = $totalsumtotal_inventorysalesinvoice_receiveamount + $total_inventorysalesinvoice_receiveamount;
        
        $intotal=   $totalsumpharmacycollection + $totalsumpharmacyinvoice
        +$totalsumhospitalinvoice + $totalsumhospitalcollection +$totalsumlabinvoice
         + $totalsumlabcollection + $totalsumtotal_inventorysalesinvoice_receiveamount;
        
        $totalsumexpense  = $totalsumexpense2  
        +$totalsuminventoryinvoice +$totalsuminvdueinvoice
        +$totalsumsalarypaid+$totalsumtotal_purchaseinvoice_receiveamount_pharmacy
        +$totalsumtotal_paid_amount ;
        
        $profite  =$intotal - ($totalsumexpense);
   
    	}			
    }
    ?>
    
    <tr>
    <td align="left" width="300">Cash In Hand: </td>
    <td align="left" width="300"><strong><?php echo number_format($profite, 2, '.', ''); ?></strong></td>
    </tr>
    </table>
    
    <table align="center"  style="border-collapse:collapse" width="60%" border="1" >
    
    <tr bgcolor="#CCCCCC">
    <td align="left" style=" color: #00F"><strong>Account Receivable </strong></td>
    <td align="left" style="color:#3654E0"></td>
    </tr>
    
    <?php
    $s='';
    $total_labinvoice_due ='0';
    for($i=0; $i<=$totaldays; $i++){
    $newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
    $newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
    
    $sqlst = "select labinvoice_due,labinvoice_date from labinvoice where labinvoice_due > 0 and labinvoice_patientid=0 and labinvoice_date between '$newfromdate' and '$newtodate' $searchstr order by labinvoice_date asc";
    $stquery = mysqli_query($conn, $sqlst);
    if($stquery && mysqli_num_rows($stquery)>0){
    while ($strow = mysqli_fetch_array($stquery))
        {
            $labinvoice_due = $strow['labinvoice_due'];
            $labinvoice_date=	$strow['labinvoice_date'];
        	$total_labinvoice_due = $total_labinvoice_due + $labinvoice_due;
        
        	}
    	}
    }
    ?>
    
    <tr>
      <td width="300" align="left">Account Receivable [Outdoor Lab]:</td>
      <td align="left" width="300" >
      <strong><?php echo number_format($total_labinvoice_due, 2, '.', ''); ?></strong></td>
     </tr>
     </table>
     
    <table align="center"  style="border-collapse:collapse" width="60%" border="1" >
    <?php
    $labinvoice_due_total=0;
    $s='';
    for($i=0; $i<=$totaldays; $i++){
    $newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
    $newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
    
    $sqlst = "select due from opregistration where due>0 AND opregistration_date between '$newfromdate' and '$newtodate' $searchstr order by opregistration_id asc";
        $stquery = mysqli_query($conn, $sqlst);
        if($stquery && mysqli_num_rows($stquery)>0){
        while ($strow = mysqli_fetch_array($stquery))
         {
            $due = $strow['due'];
            $labinvoice_due_total=$labinvoice_due_total+$due;
            
                }
              }
            }
         ?>
    <tr>
      <td width="300" align="left">Account Receivable [Indoor Lab]: </td>
      <td align="left" width="300" >
      <strong><?php echo number_format($labinvoice_due_total, 2, '.', ''); ?></strong></td>
    </tr>
    </table>
    
    <table align="center"  style="border-collapse:collapse" width="60%" border="1" >
    <?php
    $i='';
    $totalhospitalinvoice_due ='0';
    for($i=0; $i<=$totaldays; $i++){
    $newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
    $newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
    
    $sqlst = "select * from hospitalinvoice where hospitalinvoice_due > 0 and  hospitalinvoice_deliverydate  between '$newfromdate' and '$newtodate' $searchstr order by hospitalinvoice_id asc";
    $stquery = mysqli_query($conn, $sqlst);
    if($stquery && mysqli_num_rows($stquery)>0){
    while ($strow = mysqli_fetch_array($stquery))
    
     {
        $hospitalinvoice_due = $strow['hospitalinvoice_due'];
        $totalhospitalinvoice_due = $totalhospitalinvoice_due+$hospitalinvoice_due;
        	}
    	}
    }
    
    ?>
    
    <tr>
      <td width="300" align="left">Account Receivable [Hospital]: </td>
     <td align="left" width="300" >
      <strong><?php echo number_format($totalhospitalinvoice_due, 2, '.', ''); ?></strong></td>
      </tr>
     
     
    <tr>
    <td align="right" width="300">Total Current Asset:</td>
    <td align="left" width="300" bgcolor="#E9E3E4"><strong><?php echo number_format($profite, 2, '.', ''); ?></strong></td>
    </tr>
    
    </table>   
    
    <table align="center" style="BORDER-COLLAPSE: collapse" width="60%" border="1" >
    <tr bgcolor="#CCCCCC">
    <td align="left" style="color:#3654E0"><strong>Other/Intengible Asset </strong></td>
    <td align="left" style="color:#3654E0"></td>
    </tr>
    
    <?php
    $totalsuminventorysalesinvoice_receiveamount='0.00';
    for($i=0; $i<=$totaldays; $i++){
    $newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
    $newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
    
    $sqlst = "select * from inventorysalesinvoice where inventorysalesinvoice_date between '$newfromdate' and '$newtodate' $searchstr order by inventorysalesinvoice_id desc";
    $stquery = mysqli_query($conn, $sqlst);
    if($stquery &&  mysqli_num_rows($stquery)>0){
    while ($strow = mysqli_fetch_array($stquery)) {
            $inventorysalesinvoice_id = $strow['inventorysalesinvoice_id'];
            $inventorysalesinvoice_patientid = $strow['inventorysalesinvoice_patientid'];
            $inventorysalesinvoice_patient = $strow['inventorysalesinvoice_patient'];
            $user = $strow['user'];
      	$inventorysalesinvoice_receiveamount = $strow['inventorysalesinvoice_receiveamount'];
    	$totalsuminventorysalesinvoice_receiveamount  = $totalsuminventorysalesinvoice_receiveamount + $inventorysalesinvoice_receiveamount;
   
        	}
    	}
    }
    ?>
    <tr>
    <td width="300">GoodWill: </td>
    <td width="300" align="left"><strong><?php //echo number_format($, 2, '.', ''); ?></strong></td>
    </tr>
    
    <tr>
    <td width="300">Trade Names: </td>
    <td width="300" align="left"><strong><?php //echo number_format($, 2, '.', ''); ?></strong></td>
    </tr>
    
    <tr>
      <td width="300" align="right">Total Intengible Asset: </td>
       <td width="300" align="left" bgcolor="#E9E3E4"><strong> <?php //echo  ?></strong></td>
    </tr>
    </table>  
    </td>
</tr>
</table>