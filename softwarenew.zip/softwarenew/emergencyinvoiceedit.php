<?php
date_default_timezone_set('Asia/Dhaka');
$selectname_list = '';
$itemdata = '';
$itemdataarray = array();
$sqllabitem = "select * from labitem order by labitem_id asc";
$labitemquery = mysqli_query($conn, $sqllabitem);
if($labitemquery && mysqli_num_rows($labitemquery)>0){

	while ($labitemrow = mysqli_fetch_array($labitemquery)){
		$labitem_id = $labitemrow['labitem_id'];
		$labitem_name = $labitemrow['labitem_name'];
		$labitem_group = $labitemrow['labitem_group'];
		$labitem_unit = $labitemrow['labitem_unit'];
		$labitem_refvalue = $labitemrow['labitem_refvalue'];
		$labitem_price = $labitemrow['labitem_price'];
		$labitem_reagent = $labitemrow['labitem_reagent'];
		$labitem_pccommission = $labitemrow['labitem_pccommission'];
		$labitem_drcommission = $labitemrow['labitem_drcommission'];
		$labitem_tax = $labitemrow['labitem_tax'];

		$itemdataarray[$labitem_name] = "$labitem_id||$labitem_group||$labitem_unit||$labitem_refvalue||$labitem_price||$labitem_reagent||$labitem_pccommission||$labitem_drcommission||$labitem_tax";

		$itemdata[] =array( 'labelval' => $labitem_name,
							'label' => $labitem_name,
							'labitem_id'=>$labitem_id,
							'labitem_group'=>$labitem_group,
							'labitem_unit'=>$labitem_unit,
							'labitem_refvalue'=>$labitem_refvalue,
							'labitem_price'=>$labitem_price,
							'labitem_reagent'=>$labitem_reagent,
							'labitem_pccommission'=>$labitem_pccommission,
							'labitem_drcommission'=>$labitem_drcommission,
							'labitem_tax'=>$labitem_tax
							);
	}
}
$itemdataarray = json_encode($itemdataarray);
$itemdata = json_encode($itemdata);

$patientdata = '';
$sqlopregistration = "select * from opregistration order by opregistration_id asc";
$opregistrationquery = mysqli_query($conn, $sqlopregistration);
if($opregistrationquery && mysqli_num_rows($opregistrationquery)>0){

	while ($oprow = mysqli_fetch_array($opregistrationquery)){
		$opregistration_id = $oprow['opregistration_id'];
		$opregistration_name = $oprow['opregistration_name'];
		$opregistration_age = $oprow['opregistration_age'];
		//$due = $oprow['due'];
		$opregistration_gender = $oprow['opregistration_gender'];
		$opregistration_mobile = $oprow['opregistration_mobile'];
		$opregistration_address = $oprow['opregistration_address'];
		$patientdata[] =array( 'labelval' => $opregistration_name,
							'label' => $opregistration_id,
							'opregistration_id'=>$opregistration_id,
							'opregistration_age'=>$opregistration_age,
 							'opregistration_gender'=>$opregistration_gender,
							'opregistration_mobile'=>$opregistration_mobile,
							'opregistration_address'=>$opregistration_address
							);
			}
		}
$patientdata = json_encode($patientdata);


$pcdata = '';
$sqlpc = "select * from doctorentry where doctor_category='pc' order by doctor_name asc";
$opregistrationquery1 = mysqli_query($conn, $sqlpc);
if($opregistrationquery1 && mysqli_num_rows($opregistrationquery1)>0){

	while ($oprow = mysqli_fetch_array($opregistrationquery1)){
		$doctor_id = $oprow['doctor_id'];
		$doctor_name = $oprow['doctor_name'];
		$mpo = $oprow['mpo'];
		$pcdata[] =array( 'labelval' => $doctor_name,
							'label' => $doctor_name,
							'doctor_name'=>$doctor_name,
							'mpo'=>$mpo
							);
		}
	}
$pcdata = json_encode($pcdata);

$drdata = '';
$sqldr = "select * from doctorentry where doctor_category='doctor' order by doctor_name asc";
$opregistrationquery2 = mysqli_query($conn, $sqldr);
if($opregistrationquery2 && mysqli_num_rows($opregistrationquery2)>0){

	while ($oprow = mysqli_fetch_array($opregistrationquery2)){
		$doctor_id = $oprow['doctor_id'];
		$doctor_name = $oprow['doctor_name'];
		$drdata[] =array( 'labelval' => $doctor_name,
							'label' => $doctor_name,
							'doctor_name'=>$doctor_name
							);
		}
	}
$drdata = json_encode($drdata);
?>
<link rel="stylesheet" href="autocomplete/jquery-ui.css">
<script src="autocomplete/jquery-ui.min.js"></script>

<style type="text/css">
.ui-autocomplete { height:auto !important; max-height:300px; overflow:auto; background:#FFF; border:1px solid #CCC;	width:200px;}
.search_row{text-align:left;}
.ui-autocomplete li{ min-height:30px; border-bottom:1px dotted #CCC; padding:10px; text-align:left;}
</style>

<?php include("calculate-emergency.php");?>

<article class="bottomcontent">
<header class="header_tittle">
    <h2><a href="#" title="Key Facts">Emergency Invoice Edit</a></h2>
</header>
   <content>
    
       <?php
        if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
            echo "<p class=\"red12bold\">You have missing Something</p>";
        }
        elseif(isset($_GET['message']) && $_GET['message']=='duplicatename'){//why "elseif" in a word?
            echo "<p class=\"red12bold\">This Patient  already exists. Please try with different.</p>";   
        }
        elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
            echo "<p class=\"red12bold\">Error occured! Could not insert.</p>";   
        }
        elseif(isset($_GET['message']) && $_GET['message']=='insert-successfully'){
            echo "<p class=\"red12bold\">information insert successfully</p>";   
        }
		$emergencyinvoice_id = 0;
		$emergencyinvoice_patientid = '';
		$emergencyinvoice_patient = '';
		$emergencyinvoice_age = '';
		$emergencyinvoice_gender = '';
		$emergencyinvoice_mobile ='';
		$emergencyinvoice_address = '';
		$emergencyinvoice_doctor = '';
		$emergencyinvoice_pc = '';
		$emergencyinvoice_totalpccomission='';
		$emergencyinvoice_category = '';
		
		$emergencyinvoicedetails_item = '';
		$emergencyinvoicedetails_rate = '';
		$emergencyinvoicedetails_qty = '';
		$emergencyinvoicedetails_discountp = '';
		$emergencyinvoicedetails_disc = '';
		$emergencyinvoicedetails_total = '';
		$emergencyinvoicedetails_pccomission = '';
		$emergencyinvoice_duesholder = '';
		
		$emergencyinvoice_subtotal = '';
		$emergencyinvoice_totaldiscp = '';
		$emergencyinvoice_totaldisc = '';
		$emergencyinvoice_subtotalafterdisc = '';
		$emergencyinvoice_receiveamount = '';
		$emergencyinvoice_due = '';
		$emergencyinvoice_description = '';

        
        if(isset($_GET['emergencyinvoice_id'])){
            $emergencyinvoice_id = $_GET['emergencyinvoice_id'];
            $sqlst = "select * from emergencyinvoice where emergencyinvoice_id = $emergencyinvoice_id";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery){
                while($strow = mysqli_fetch_array($stquery)){
                    $emergencyinvoice_id = $strow['emergencyinvoice_id'];
                    $emergencyinvoice_patientid = $strow['emergencyinvoice_patientid'];
                    $emergencyinvoice_patient = $strow['emergencyinvoice_patient'];
                    $emergencyinvoice_age = $strow['emergencyinvoice_age'];
                    $emergencyinvoice_gender = $strow['emergencyinvoice_gender'];
					$emergencyinvoice_mobile = $strow['emergencyinvoice_mobile'];
                    $emergencyinvoice_address = $strow['emergencyinvoice_address'];
                    $emergencyinvoice_doctor = $strow['emergencyinvoice_doctor'];
                    $emergencyinvoice_pc = $strow['emergencyinvoice_pc'];
                    $emergencyinvoice_mpo = $strow['emergencyinvoice_mpo'];
                    $emergencyinvoice_totalpccomission = $strow['emergencyinvoice_totalpccomission']; 
					 $emergencyinvoice_totaldrcomission = $strow['emergencyinvoice_totaldrcomission']; 
					$emergencyinvoice_subtotal = $strow['emergencyinvoice_subtotal'];
					$emergencyinvoice_totaldiscp = $strow['emergencyinvoice_totaldiscp'];
					$emergencyinvoice_totaldisc = $strow['emergencyinvoice_totaldisc'];
					$emergencyinvoice_subtotalafterdisc = $strow['emergencyinvoice_subtotalafterdisc'];
					$emergencyinvoice_receiveamount = $strow['emergencyinvoice_receiveamount'];
					$emergencyinvoice_due = $strow['emergencyinvoice_due'];
					$emergencyinvoice_previousdue = $strow['emergencyinvoice_previousdue'];
					$emergencyinvoice_date = $strow['emergencyinvoice_date'];
					$emergencyinvoice_duesholder = $strow['emergencyinvoice_duesholder'];
					$emergencyinvoice_description = $strow['emergencyinvoice_description'];
                }
            }
        }
     ?>
<form action="save_emergencyinvoice.php" name="frmcontact" onsubmit="return checkcontactform();" method="post" enctype="multipart/form-data">
                          
<table width="<?php echo $printdata_address3;?>" border="0" bgcolor="#E94F32" cellpadding="2">
   <tr>
   <input type="hidden" name="bar" id="bar"/>
   <input type="hidden" name="user" id="user" required value="<?php echo $_SESSION['fullname'];?>" class="tdclass"  />
   <input type="hidden" name="update_user" id="update_user" required value="<?php echo $_SESSION['fullname'];?>" class="tdclass"  />
   <td align="right">Patient Name</td>
    <td> <input readonly type="text" name="emergencyinvoice_patient" id="emergencyinvoice_patient" value="<?php echo $emergencyinvoice_patient; ?>" required class="tdclass"  />
    <td align="right">Age</td>
    <td> <input type="text" name="emergencyinvoice_age" id="emergencyinvoice_age" required value="<?php echo $emergencyinvoice_age; ?>" class="tdclass73"  /></td>
    <td align="right">Gender</td>
    <td> <input type="text" name="emergencyinvoice_gender" id="emergencyinvoice_gender" value="<?php echo $emergencyinvoice_gender; ?>" class="tdclass73"  /></td>
    <td align="right">Mobile</td>
    <td> <input type="text" name="emergencyinvoice_mobile" id="emergencyinvoice_mobile" value="<?php echo $emergencyinvoice_mobile; ?>" class="tdclass"  /></td>
  	<td align="right">Address</td>
	<td> <textarea type="text" name="emergencyinvoice_address" id="emergencyinvoice_address"  class="tdclass"  /><?php echo $emergencyinvoice_address; ?></textarea></td>
  </tr>
  <td></td>
  </table>
  <table width="<?php echo $printdata_address3;?>" border="0" bgcolor="#E94F32" cellpadding="2">

  <tr>
   	<td align="right" bgcolor="#0066FF">Patient ID</td>
    <td> <input type="text" readonly name="emergencyinvoice_patientid" id="emergencyinvoice_patientid" value="<?php echo $emergencyinvoice_patientid; ?>" class="tdclass2" /></td>

    <td align="right"><strong>Doctor</strong> </td>
    <td><input type="text" size="23" value="<?php echo $emergencyinvoice_doctor; ?>" name="emergencyinvoice_doctor" id="emergencyinvoice_doctor"/></td>
    
        
     <td align="right" bgcolor="#ccc">P.C</td>
     <td><input type="text" name="emergencyinvoice_pc" id="emergencyinvoice_pc" value="<?php echo $emergencyinvoice_pc; ?>" class="tdclass2" /></td>
  
    <td align="right">M.P.O</td>
    <td><input type="text" name="emergencyinvoice_mpo" id="emergencyinvoice_mpo" value="<?php echo $emergencyinvoice_mpo; ?>" class="tdclass2" /></td>
  
  
    <!--<td align="right">Date:</td>-->
     <input type="hidden" name="emergencyinvoice_date" readonly id="emergencyinvoice_date" value="<?php echo $emergencyinvoice_date;?>" class="tdclass2" />
      
     <!-- <td align="right">Delivery Date:</td>-->
     <input type="hidden" name="emergencyinvoice_deliverydate" id="emergencyinvoice_deliverydate" placeholder="12.12.2015"  class="tdclass2" />
     
  </tr>
</table>
  
<br />
<div id="errmsg_particular_id"></div>
<ul id="particularlist" class="ullistnone">
	<?php
	if(isset($_GET['emergencyinvoice_id'])){
		$emergencyinvoice_id = $_GET['emergencyinvoice_id'];
		$sqlst = "select * from emergencyinvoicedetails where emergencyinvoice_id = $emergencyinvoice_id";
		$stquery = mysqli_query($conn, $sqlst);
		if($stquery){
			$p=0;
			while($strow = mysqli_fetch_array($stquery)){
				$auto_number = $strow['auto_number'];
				$emergencyinvoicedetails_item = $strow['emergencyinvoicedetails_item'];
				$emergencyinvoicedetails_category = $strow['emergencyinvoicedetails_category'];
				$emergencyinvoicedetails_rate = $strow['emergencyinvoicedetails_rate'];
				$emergencyinvoicedetails_qty = $strow['emergencyinvoicedetails_qty'];
				$emergencyinvoicedetails_discountp = $strow['emergencyinvoicedetails_discountp'];
				$emergencyinvoicedetails_disc = $strow['emergencyinvoicedetails_disc'];
				$emergencyinvoicedetails_total = $strow['emergencyinvoicedetails_total'];
				$emergencyinvoicedetails_pccomission = $strow['emergencyinvoicedetails_pccomission'];
				$emergencyinvoicedetails_drcomission = $strow['emergencyinvoicedetails_drcomission'];
				?>
                <li>
                    <table id="particularlistrowno<?php echo $p;?>" width="<?php echo $printdata_address3;?>" style="BORDER-COLLAPSE: collapse; border:2px solid #FFF" border="0" bgcolor="#77F7AA" cellpadding="2">
                     
                      <tr>
                        <td align="right">Test Name</td>
                        <td>
                        	<input type="hidden" name="auto_number[]" value="<?php echo $auto_number;?>"/>                     
                        	<input type="text" required name="emergencyinvoice_item[]"  id="emergencyinvoice_item"  value="<?php echo $emergencyinvoicedetails_item;?>" class="tdclass itemname emergencyinvoice_item" autocomplete="off" />
                      		 <input type="hidden" name="labitem_id[]" id="labitem_id" value="<?php echo $labitem_id;?>" class="tdclass" />
            				<input type="hidden" name="emergencyinvoice_category[]" value="<?php echo $emergencyinvoicedetails_category;?>" class="tdclass itemname"  /> 
                            <input type="hidden" name="emergencyinvoice_unit[]" class="tdclass"  />
                 			<input type="hidden" name="emergencyinvoice_refvalue[]" class="tdclass"  />                    
                        </td>                        
                       	<td align="right">Rate</td>
                        <td><input type="text" name="emergencyinvoice_rate[]" id="emergencyinvoice_rate" onKeyUp="calculaterowtotal('all');" value="<?php echo $emergencyinvoicedetails_rate;?>" class="tdclasssale" /></td>
                       
                        <!--<td align="right">Stock</td>-->
            			<input type="hidden" name="emergencyinvoice_reagent[]" id="emergencyinvoice_reagent" class="tdclasssale numeric" onKeyUp="calculaterowtotal('all');" />
            
                     
                         <!--<td align="right">Qty</td>-->
                        <input type="hidden" name="emergencyinvoice_qty[]" id="emergencyinvoice_qty" onKeyUp="calculaterowtotal('all');" value="<?php echo $emergencyinvoicedetails_qty;?>" class="tdclasssale" />
                       
                        <td align="right">Disc%</td>
                        <td><input type="text" name="emergencyinvoice_discountp[]" id="emergencyinvoice_discountp" value="<?php echo $emergencyinvoicedetails_discountp;?>" onKeyUp="calculate_discountp();" class="tdclasssale"  /></td>
                       
                      
                        <td align="right">Disc</td>
                        <td><input type="text" name="emergencyinvoice_disc[]" id="emergencyinvoice_disc" value="<?php echo $emergencyinvoicedetails_disc;?>" onKeyUp="calculaterowtotal('all');" class="tdclasssale"  /></td>
                       
                        <td align="right">P.C</td>
                        <td><input type="text" name="emergencyinvoice_pccomission[]" id="emergencyinvoice_pccomission" value="<?php echo $emergencyinvoicedetails_pccomission;?>" onKeyUp="calculate_pctotal();"  class="tdclasssale"  /></td>
                       
                        <td align="right">Dr.</td>
                        <td><input type="text" name="emergencyinvoice_drcomission[]" id="emergencyinvoice_drcomission" value="<?php echo $emergencyinvoicedetails_drcomission;?>" onKeyUp="calculate_drtotal();"  class="tdclasssale"  /></td>
                       
                      
                        <td align="right">Total</td>
                        <td><input type="text" readonly name="emergencyinvoice_total[]" id="emergencyinvoice_total" value="<?php echo $emergencyinvoicedetails_total; ?>" class="tdclasssale"  /></td>
                        <td><input type="button" value="Add" onClick="addnew_particularrow(true)" class="tdclasssale" /></td>
                      </tr>
                 </table>
                 </li>
            	<?php
				$p++;
				}
			}
		}
	 ?>
</ul>
 <br />
  
  <table width="<?php echo $printdata_address3;?>" border="0" bgcolor="#F3F3F3">
  <tr>
   <td align="right">Description </td>
    <td><textarea type="text" name="emergencyinvoice_description" id="emergencyinvoice_description" value="<?php echo $emergencyinvoice_description;?>" class="tdclass" /><?php echo $emergencyinvoice_description;?></textarea></td>
  	<td align="right">Dues Holder </td>
    <td><textarea type="text" name="emergencyinvoice_duesholder" id="emergencyinvoice_duesholder" class="tdclass" /><?php echo $emergencyinvoice_duesholder;?></textarea></td>
  
    <td align="right">P.C Total </td>
    <td><input type="text"  name="emergencyinvoice_totalpccomission" id="emergencyinvoice_totalpccomission" value="<?php echo $emergencyinvoice_totalpccomission;?>" class="tdclass"/></td>
  	
    <td align="right">Dr. Total </td>
    <td><input type="text"  name="emergencyinvoice_totaldrcomission" id="emergencyinvoice_totaldrcomission" value="<?php echo $emergencyinvoice_totaldrcomission;?>" class="tdclass"/></td>
   </tr>
</table>

	
<table width="<?php echo $printdata_address3;?>" border="0" bgcolor="#FFFFFF" cellpadding="2">
      <tr>
     <td align="right" style="border-top:1px solid #999;"><strong>Previous Due</strong>:</td>
    	<td width="50" style="border-top:1px solid #999;"> 
        <input type="text" readonly name="emergencyinvoice_previousdue" id="emergencyinvoice_previousdue" value="<?php echo $emergencyinvoice_previousdue;?>" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
    </tr>
    
    <tr>
     <td align="right">Sub Total: </td>
     <td><input type="text" readonly name="emergencyinvoice_subtotal" id="emergencyinvoice_subtotal" value="<?php echo $emergencyinvoice_subtotal;?>" class="tdclass" /></td>
    </tr>
    
    <tr>
     <td align="right">Discount 100%(Dr,PC):</td>
     <td><input type="text"  name="emergencyinvoice_totaldiscp" id="emergencyinvoice_totaldiscp" value="<?php echo $emergencyinvoice_totaldiscp;?>" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
  	</tr>
     <tr>
     <td align="right">Discount:</td>
     <td><input type="text" name="emergencyinvoice_totaldisc" id="emergencyinvoice_totaldisc" value="<?php echo $emergencyinvoice_totaldisc;?>" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
    </tr>
    <!--<tr>
     <td align="right"><strong>Advance Amount Paid</strong>:</td>
     <td><input type="text" readonly name="advanced" id="advanced" value="<?php //echo $advanced;?>" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
  	</tr>-->
     <tr>
     <td align="right">Total Amount [After Discount]:</td>
     <td><input type="text" readonly name="emergencyinvoice_subtotalafterdisc" id="emergencyinvoice_subtotalafterdisc" value="<?php echo $emergencyinvoice_subtotalafterdisc;?>" class="tdclass" /></td>
  	</tr>
     
    <tr>
     <td align="right">Received Amount:</td>
     <td><input type="text" name="emergencyinvoice_receiveamount" id="emergencyinvoice_receiveamount" value="<?php echo $emergencyinvoice_receiveamount;?>" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
   	</tr>
    
    <tr>
     <td align="right">Dues Amount:</td>
     <td><input type="text" readonly name="emergencyinvoice_due" id="emergencyinvoice_due" value="<?php echo $emergencyinvoice_due;?>" class="tdclass" /></td>
  	</tr>
    
    <tr><td align="right"></td>
    	<td>
         <input type="hidden" name="emergencyinvoice_id" id="emergencyinvoice_id" value="<?php echo $emergencyinvoice_id;?>">
         <input type="submit" value=" Save " name="submit_invoice" id="submit_invoice" class="tdclass" />
         <input type="button" name="patient" id="patient" value="Cancel" class="tdclass"/>
     	</td>
  	</tr>
 </table>
</form>         
</content>
</article>