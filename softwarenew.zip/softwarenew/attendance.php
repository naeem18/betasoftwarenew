<?php
//include ("labdd.php");
//date_default_timezone_set('Asia/Dhaka'); 
$searchstr='';
if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
{
	$transactiondatefrom = $_REQUEST['ADate1'];
	$transactiondateto = $_REQUEST['ADate2'];
	
	$doctor_name = $_REQUEST['doctor_name'];
	if($doctor_name !=''){
		$searchstr .= " and doctor_name like '%$doctor_name%'";
	}
}
else
{
	$transactiondatefrom = date('Y-m-d', strtotime('-1 year'));
	$transactiondateto = date('Y-m-d');
}
?>


<script language="javascript">
function cbcustomername1()
{
	document.cbform1.submit();
}
</script>

<script type="text/javascript">
window.onload = function ()
{
	var oTextbox = new AutoSuggestControl(document.getElementById("searchcustomername"), new StateSuggestions());        
}
</script>

<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    
</tr>

	<td>
    
		<?php 
		
		$datetime1 = new DateTime($transactiondatefrom);
		$datetime2 = new DateTime($transactiondateto);
		$interval = $datetime1->diff($datetime2);
		$totaldays = $interval->format('%a');
		if($datetime1<$datetime2){
			$fromdate = $transactiondatefrom;
			$todate = $transactiondateto;
		}
		else{
			$fromdate = $transactiondateto;
			$todate = $transactiondatefrom;
		}
		?>
        
        <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1" cellspacing="0" cellpadding="2">
        <tbody>
         <tr>
            <td colspan="15" bgcolor="#31a8b3" align="center" style="color:#fff; margin-bottom:50px; border-collapse:collapse border:1px solid #03F; padding-left:15px;">
            	<strong><?php echo $hospitaldata_name;?></strong><br>
                <samp>Attendance <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></samp>
            </td>
          </tr>
           
         <table align="center" style="BORDER-COLLAPSE: collapse; margin-top:50px" width="100%" border="1" cellspacing="0" cellpadding="2">
       
         <tr>
            <td>&emsp;</td>
            <td colspan="5"><input type="button" name="signin" value="SIGN IN"></td>
               <td><input type="button" name="signin" value="SIGN OUT"></td>
            
              </tr>
		</table>
        
             <tbody>
          </table>
        </td>
</table>