<link rel="stylesheet" href="autocomplete/jquery-ui.css">
<script src="autocomplete/jquery-ui.min.js"></script>
<script language="JavaScript" type="text/javascript">
function disableEnterKey(e)
	{
	var evt = e || window.event; 
		var key = evt.keyCode;
		//alert (key);
		if(key == 13) // if enter key press
		{
			//alert ("Enter Key Press");
			return false;
		}
	}
</script>	
<script language="JavaScript" type="text/javascript">
	
	
	function calculate_total(){
		
		var opregistration_due = parseFloat(document.getElementById("opregistration_due").value);
		if(opregistration_due=='' || isNaN(opregistration_due)){opregistration_due = 0;}
		
		var labinvoice_totalpccomission = parseFloat(document.getElementById("labinvoice_totalpccomission").value);
		if(labinvoice_totalpccomission=='' || isNaN(labinvoice_totalpccomission)){labinvoice_totalpccomission = 0;}
		
		var discount_amount = parseFloat(document.getElementById("discount_amount").value);
		if(discount_amount=='' || isNaN(discount_amount)){discount_amount = 0;}
			
		var Tcollection_amount = parseFloat(document.getElementById("Tcollection_amount").value);
		if(Tcollection_amount=='' || isNaN(Tcollection_amount)){Tcollection_amount = '';}
		
		//var labinvoice_totalpccomission_update = parseFloat(labinvoice_totalpccomission - discount_amount/2);
		//document.getElementById('labinvoice_totalpccomission_update').value=labinvoice_totalpccomission_update.toFixed(2);
		
		var labinvoice_totalpccomission_update = parseFloat(labinvoice_totalpccomission - discount_amount);
		document.getElementById('labinvoice_totalpccomission_update').value=labinvoice_totalpccomission_update.toFixed(2);
		
		var total_balance = parseFloat(opregistration_due - discount_amount - Tcollection_amount);
		document.getElementById('total_balance').value=	total_balance.toFixed(2);
		
		}
	function funcSaveBill1()
{
	
	var varUserChoice; 
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet); 
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		document.frmsales.submit();
		//return true;
	}
}				

</script>
	<article class="bottomcontent">
    	<h3 align="center">Dental Collection Invoice</h3>
   		<content>
         <?php
			if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
				echo "<p class=\"red12bold\">You have missing Something</p>";
			}
			elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
				echo "<p class=\"red12bold\">Error occured! Could not insert.</p>";   
			}
			elseif(isset($_GET['message']) && $_GET['message']=='save-successfully'){
				echo "<p class=\"red12bold\">Information insert successfully. Click Print Button To Print or View Previous Bill <td width=\"30\" align=\"center\" >
				<a onclick=\"PrintDiv();\"><input type=\"button\" required value=\"Print\" class=\"tdclass\" /></a></td></p>";   
			}
			$labinvoice_patient ='';
			$labinvoice_patientid ='';
			$labinvoice_gender = '';
			$labinvoice_mobile ='';
			$labinvoice_address = '';
			$labinvoice_doctor = '';
			$labinvoice_pc ='';
			$labinvoice_totalpccomission ='';
			$labinvoice_due=''; 
			$labinvoice_subtotalafterdisc ='';
			  
		 if(isset($_GET['labinvoice_id'])){
            require('labdd.php');
            $labinvoice_id = $_GET['labinvoice_id'];
            $sqlst = "select * from dentalinvoice where labinvoice_id = $labinvoice_id";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery){
                while($strow = mysqli_fetch_array($stquery)){
                    $labinvoice_id = $strow['labinvoice_id'];
                    $labinvoice_patientid = $strow['labinvoice_patientid'];
                    $labinvoice_patient = $strow['labinvoice_patient'];
                    $labinvoice_age = $strow['labinvoice_age'];
                    $labinvoice_gender = $strow['labinvoice_gender'];
					 $labinvoice_mpo = $strow['labinvoice_mpo'];
					$labinvoice_mobile = $strow['labinvoice_mobile'];
                    $labinvoice_address = $strow['labinvoice_address'];
                    $labinvoice_doctor = $strow['labinvoice_doctor'];
                    $labinvoice_pc = $strow['labinvoice_pc'];
                    $labinvoice_totalpccomission = $strow['labinvoice_totalpccomission']; 
					$labinvoice_duesholder = $strow['labinvoice_duesholder']; 
					$labinvoice_description = $strow['labinvoice_description']; 
					$labinvoice_subtotal = $strow['labinvoice_subtotal'];
					$labinvoice_totaldiscp = $strow['labinvoice_totaldiscp'];
					$labinvoice_totaldisc = $strow['labinvoice_totaldisc'];
					$labinvoice_subtotalafterdisc = $strow['labinvoice_subtotalafterdisc'];
					$labinvoice_receiveamount = $strow['labinvoice_receiveamount'];
					$labinvoice_due = $strow['labinvoice_due'];
					$labinvoice_description = $strow['labinvoice_description'];
					$labinvoice_date = $strow['labinvoice_date'];
                }
            }
        }
      ?>
  <form action="save_dentalcollectioninvoice.php" name="frmcontact" onsubmit="return checkcontactform();" onKeyDown="return disableEnterKey(event)" method="post" enctype="multipart/form-data">
	<table width="550" align="center" border="0" bgcolor="#89C5C5" cellpadding="2">
      <input type="hidden" name="user" id="user" required value="<?php echo $_SESSION['fullname'];?>" class="tdclass"/>
      <input type="hidden" name="labinvoice_id" id="labinvoice_id" value="<?php echo $labinvoice_id;?>" class="tdclass"/>
      <input type="hidden" name="labinvoice_patientid" id="labinvoice_patientid" value="<?php echo $labinvoice_patientid;?>" />
      <input type="hidden" name="labinvoice_date" id="labinvoice_date" value="<?php echo $labinvoice_date;?>" class="tdclass" />

      <tr>
         <td align="right">Patient</td>
         <td><input type="text" readonly name="labcollection_name" id="labcollection_name" value="<?php echo $labinvoice_patient;?>" class="tdclass"  /></td>
       
         <td align="right">Patient ID</td>
         <td width="30"><input type="text" readonly name="opregistration_id" id="opregistration_id" value="<?php echo $labinvoice_patientid;?>" class="tdclass2"  /></td>
      </tr>
   
       <tr>
        <td align="right">Mobile</td>
        <td><input type="text" name="labcollection_number" id="labcollection_number" value="<?php echo $labinvoice_mobile;?>" class="tdclass"  /></td>
        
        <td align="right">Address</td>
        <td><textarea type="text" name="labcollection_address" id="labcollection_address" class="tdclass"  /><?php echo $labinvoice_address;?></textarea></td>
      </tr>
   
       <tr>
         <td align="right">Date</td>
         <td><input type="text" name="labcollection_date" readonly id="labcollection_date" value="<?php echo date('Y-m-d H:i:s');?>" class="tdclass2" /></td>
          
         <td align="right">PC</td>
         <td width="30"><input type="text" readonly name="labinvoice_pc" id="labinvoice_pc" value="<?php echo $labinvoice_pc;?>" class="tdclass2" /></td>
      </tr>
   
      <tr>
        <td align="right">PC Comission</td>
        <td width="30"> <input type="text" <?php if($_SESSION['employeename']!='SUPERADMINISTRATOR'){?> readonly <?php }?> name="labinvoice_totalpccomission" id="labinvoice_totalpccomission" value="<?php echo $labinvoice_totalpccomission;?>"  class="tdclass numeric" onKeyUp="calculate_total();"/></td>
      
        <td align="right">Current PC Comission</td>
        <td width="30"> <input type="text" <?php if($_SESSION['employeename']=='SUPERADMINISTRATOR'){?> readonly <?php }?>name="labinvoice_totalpccomission_update" id="labinvoice_totalpccomission_update"  class="tdclass numeric" onKeyUp="calculate_total();"/></td>
      </tr>
	</table>

     <table border="0" width="550" align="center" cellpadding="2" bgcolor="#F3F3F3">
      <tr>
        <td align="right">Note</td>
        <td><textarea type="text" name="note" id="note"/></textarea></td>
        <td align="right">MPO</td>
        <td><textarea type="text" name="labinvoice_mpo" id="labinvoice_mpo"/><?php echo $labinvoice_mpo;?></textarea></td>
      </tr>
     </table>
 
 <table width="550" align="center" border="0" bgcolor="#FFFFFF" cellpadding="2">
  	<tr>
        <td align="right" style="border-top:1px solid #999;">Invoice Amounts:</td>
    	<td width="50" style="border-top:1px solid #999;">
    	<input type="text" readonly name="labinvoice_subtotalafterdisc" id="labinvoice_subtotalafterdisc" value="<?php echo $labinvoice_subtotalafterdisc;?>" class="tdclass"  /></td>
  	</tr>
    
    <tr>
     	<td align="right">Total Dues:</td>
    	<td><input type="text" readonly name="opregistration_due" id="opregistration_due" value="<?php echo $labinvoice_due;?>" onKeyUp="calculate_total();" class="tdclass"  /></td>
  	</tr>
      <tr>
     	<td align="right">Discount Amount:</td>
    	<td><input type="text" name="discount_amount" id="discount_amount" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
  	</tr>
   
     <tr>
     	<td align="right"><strong>Receive Amount</strong>:</td>
    	<td><input type="text" required name="Tcollection_amount" id="Tcollection_amount" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
  	</tr>

      <tr>
         <td align="right">Current Dues Amount:</td>
         <td><input type="text" readonly name="total_balance" id="total_balance" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
  	  </tr>
    
	<tr>
       <td align="right"></td>
	   <td>
         <input type="hidden" name="labcollection_id" id="labcollection_id" value="<?php echo $labcollection_id;?>">
         <input type="submit"  value=" save " name="submit_invoice" id="submit_invoice" onClick="return funcSaveBill1()" class="tdclass1" />
       </td>
  	</tr>
   </table>
  </form>         
</content>
</article>

	<div id="divToPrint" style="display:none;">
	  <article class="bottomcontent" style="margin:0 auto;">
  	<?php
		$labcollection_id = $_GET['labcollection_id'];
        $labinvoice_sql = "select * from dentalcollection where labcollection_id = $labcollection_id ";
        $labinvoicequery = mysqli_query($conn, $labinvoice_sql);
        if($labinvoicequery && mysqli_num_rows($labinvoicequery)>0 && ($labcollection_id<40000)){
            while ($onerow = mysqli_fetch_array($labinvoicequery)){
					$labcollection_id = $onerow['labcollection_id'];
					$labinvoice_id = $onerow['labinvoice_id'];
					$labinvoice_date = $onerow['labinvoice_date'];
					$total_balance = $onerow['total_balance'];
					$opregistration_id = $onerow['opregistration_id'];
					$labcollection_name = $onerow['labcollection_name'];
					$labcollection_address = $onerow['labcollection_address'];
					$labcollection_number = $onerow['labcollection_number'];
					$labcollection_date = $onerow['labcollection_date'];
					
					$collection_amount = $onerow['collection_amount'];
					$labinvoice_subtotalafterdisc = $onerow['labinvoice_subtotalafterdisc'];
					$discount_amount = $onerow['discount_amount'];
					$note = $onerow['note'];
					$user = $onerow['user'];		
					$due = $onerow['due'];		
              ?>
                
              
                <table align="center" width="<?php echo $printdata_mobile; ?>"  style="border:1px solid #999; padding:0 5px; font-size:12px; "  bgcolor="#FFF" cellpadding="0">
                <tr>
                <?php
                if($hospitaldata_logo!=''){
					?>
                    <td width="65">
                    <div align="left" style="font-size:15px;">
                    <img alt="barcode" width="60" height="60" src="logo_images/<?php echo $hospitaldata_logo; ?>"  /></div>
                   </td>
               <?php }?>
                <td width="320" style="border-right:1px solid #666">
                    <div align="left" style="font-size:16px;"><strong><?php echo $hospitaldata_name;?></strong></div>
                    <div align="left"> <?php echo $hospitaldata_address1;?></div>
                </td>
                 <td width="90">
                    <div align="right" style="font-size:13px;"><strong><?php echo 'Contact';?></strong></div>
                    <div align="right"> <?php echo $hospitaldata_mobile;?></div>
                </td>
                 </tr>
            </table>
                       
            <table align="center" width="<?php echo $printdata_mobile; ?>" style="border:1px solid #999;font-size:13px; border-bottom:none; padding:2px 8px 0 8px; margin-top:13px" bgcolor="#FFF" cellpadding="0">
            <tr>
                <td width="250">
                    <!--<div  align="left"><strong>Patient ID : <?php //echo $opregistration_id;?></strong> </div>-->
                    <div  align="left"><strong>Patient : <?php echo $labcollection_name;?> </strong> </div>
                    <div  align="left">Mobile : <?php echo $labcollection_number;?></div>
                   <!-- <div  align="left">Address : <?php //echo $labcollection_address;?></div>-->
               		<?php if($labinvoice_id>0) {?><div  align="left">Lab Invoice No : <?php echo $labinvoice_id;?></div>
               		<div  align="left">Lab Inv Date : <?php  echo $labinvoice_date;?></div>
                    <?php }?>
                    </td>
                <td width="200">
                    <div  align="right" style="font-size:14px"><strong>Due Collection Invoice</strong></div>
                    <div  align="right">Collection No : <?php echo $labcollection_id;?></div>
                    <div  align="right">C.Date: <?php  echo $labcollection_date;?></div>
               </td>
             </tr>
          </table>
               
      		<table align="center" width="<?php echo $printdata_mobile; ?>" bgcolor="#FFF" style="padding:0 0 40px;font-size:12px; border:1px #000000 solid; border-top:none;" cellspacing="0" cellpadding="0">
                  <tr height="20">
                    <td style="border:1px solid #999; text-align:center;border-top:none;"><strong>SL</strong> </td>
                    <td style="border:1px solid #999;text-align:center;border-top:none;"><strong>Test Name</strong></td>
                   <!-- <td style="border:1px solid #999; text-align:center;border-top:none;">Rate</td>-->
                    <!-- <td style="border:1px solid #000; text-align:center;">Qty</td>-->
                   <!-- <td style="border:1px solid #999; text-align:center;">Disc(%)</td>-->
                    <!--<td style="border:1px solid #999; text-align:center;border-top:none;">Disc</td>-->
                    <td style="border:1px solid #999; text-align:center;border-top:none;"><strong>Total</strong></td>
                  </tr>
                <?php
				 $totalRate=0;
				 $totaldisc=0;
				
                $labinvoicedetails_sql = "select * from dentalinvoicedetails where status !='Deleted' AND labinvoice_id = $labinvoice_id order by auto_number asc";
                $labinvoicedetailsquery = mysqli_query($conn, $labinvoicedetails_sql);
                if($labinvoicedetailsquery && mysqli_num_rows($labinvoicedetailsquery)>0){
                    $i=0;
                    while($page_inforow = mysqli_fetch_array($labinvoicedetailsquery)){
                        $i++;
                        $auto_number = $page_inforow['auto_number'];
                        $labinvoicedetails_item = $page_inforow['labinvoicedetails_item'];
                        $labinvoicedetails_rate = $page_inforow['labinvoicedetails_rate'];
                        $labinvoicedetails_qty = $page_inforow['labinvoicedetails_qty'];
                        $labinvoicedetails_discountp = $page_inforow['labinvoicedetails_discountp'];
                        $labinvoicedetails_disc = $page_inforow['labinvoicedetails_disc'];
                        $labinvoicedetails_total = $page_inforow['labinvoicedetails_total'];
                      
					   $totalRate=$totalRate+$labinvoicedetails_rate;
					   $totaldisc=$totaldisc+$labinvoicedetails_disc;
					    ?>
                        <tr>
                            <td style="text-align:center;"><?php echo $i;?></td>
                            <td style=" text-align:left; padding-left:3px" width="270"> <?php echo $labinvoicedetails_item;?></td>
                            <?php /*?><td style=" text-align:center;"> <?php echo $labinvoicedetails_rate;?></td><?php */?>
                            <?php /*?> <td style="text-align:center;">  <?php echo $labinvoicedetails_discountp;?>%</td><?php */?>
                            <?php /*?><td style="text-align:center;"> <?php  echo number_format($labinvoicedetails_disc);?></td><?php */?>
                            <td style="text-align:center;"> <?php echo $labinvoicedetails_total;?></td>
                          </tr>
                 
                        <?php
						}
					}
					?>
            </table>
            <table align="center" width="<?php echo $printdata_mobile; ?>" style="border:1px solid #000000; border-top:none;font-size:12px" bgcolor="#FFFFFF" cellpadding="1">
			 <tr>
                 <td align="right"><strong>Net Payable Amount(After Discount)</strong> :&emsp;</td>
                <td> <?php echo $labinvoice_subtotalafterdisc;?></td>
                </tr>
            </table>           
            
             <table align="center" width="<?php echo $printdata_mobile; ?>" bgcolor="#FFF" style="padding:0 0 40px;font-size:13px; border:1px #999 solid; border-top:none; "cellspacing="0" cellpadding="0">
                
              <tr height="20">
                <td style="border:1px solid #999;text-align:center;"><strong>Particular</strong></td>
<!--                <td style="border:1px solid #999; text-align:center;">Invoice Amount</td>
-->                <td style="border:1px solid #999; text-align:center;">Previous Dues</td>
                <td style="border:1px solid #999; text-align:center;">Discount</td>
               <td style="border:1px solid #999; text-align:center;">Received</td>
                <td style="border:1px solid #999; text-align:center;">Current Dues</td>
             </tr>
             
                <tr>
                <td style=" text-align:center;"><?php echo 'Due Collection'?></td>
<?php /*?>                <td style=" text-align:center;"><?php echo $labinvoice_subtotalafterdisc;?></td>
<?php */?>                <td style=" text-align:center;"><strong><?php echo $total_balance+$collection_amount+$discount_amount;?></strong></td>
                <td style=" text-align:center;"><?php echo $discount_amount;?></td>
                <td style=" text-align:center;"><strong><?php echo $collection_amount;?></strong></td>
                 <td style=" text-align:center;"><?php echo $due;?></td>
               </tr>
            </table>
                    
                <?php
				}
			}
        ?>
         <table align="center" width="<?php echo $printdata_mobile; ?>" style="font-size:12px; font-style:italic">
        <tr> <td><?php include ("convert_currency_to_words.php");

		echo 'InWord:';	echo covert_currency_to_words($collection_amount); ?></td></tr>
        </table>

 <table align="center" width="<?php echo $printdata_mobile; ?>" border="0">
    <tr>
        <td width="400" style=" font-size:12px"><?php echo $note; ?></td>
 </tr>
 </table>
      
        <table align="center" width="<?php echo $printdata_mobile; ?>" style=" font-size:12px; padding:5px 2px" bgcolor="#FFF" cellpadding="0">
                          
        <tr>
            <td width="350">
                <div  align="left">Prepared By:<?php echo $user; ?>  
                  </div>
            </td>
            <td width="200">
                <div  style="padding-bottom:10px" align="right"></div>
                <div  align="right">Received By</div>
            </td>
         </tr>
             
        </table>

    <table align="center" width="<?php echo $printdata_mobile; ?>" border="0">
    <tr>
        <td width="400" style=" font-size:10px">Software by: Betasofts.com</td>
      </tr></table>
   
</article>
</div>