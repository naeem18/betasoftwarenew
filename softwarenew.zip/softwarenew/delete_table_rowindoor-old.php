<?php
session_start();
if(isset($_GET['idvalue'])){	
	
	
	$idvalue = $_GET['idvalue'];
	if($idvalue>0){
		require('labdd.php');
		
		$str2 = "DELETE from hospitalinvoice where hospitalinvoice_id = '$idvalue'";
		$userquery = mysqli_query($conn, $str2);
		
		 $str = "DELETE from hospitalinvoicedetails where hospitalinvoice_id = '$idvalue'";
		$userquery = mysqli_query($conn, $str);
		
		 $str3 = "DELETE from dailytransection_lab where section='H Cash' AND labinvoice_id = '$idvalue'";
		$userquery = mysqli_query($conn, $str3);
		
		
		if($userquery){			
			header("location:index.php?p=statementbyhospitalinvoice&message=remove-successfully");			
		}
		else{
			header("location:index.php?p=$returnpage&message=couldnotremove");
		}
	}
	else{
		header("location:index.php?p=statementbyhospitalinvoice&message=incorrect_id");
	}
}
?>
