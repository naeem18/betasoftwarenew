<?php
$patientdata = '';
$sqlcompany = "select * from company order by company_id asc";
$companyquery = mysqli_query($conn, $sqlcompany);
if($companyquery && mysqli_num_rows($companyquery)>0){

	while ($companyrow = mysqli_fetch_array($companyquery)){
		$company_id = $companyrow['company_id'];
		$company_name = $companyrow['company_name'];
		$company_due = $companyrow['company_due'];
		$company_mobile = $companyrow['company_mobile'];
		$company_address = $companyrow['company_address'];
		$patientdata[] =array( 'labelval' => $company_id,
							'label' => $company_name,
							'company_id'=>$company_id,
							'company_due'=>$company_due,
							'company_mobile'=>$company_mobile,
							'company_address'=>$company_address
							);
		}
	}
$patientdata = json_encode($patientdata);

?>

<link rel="stylesheet" href="autocomplete/jquery-ui.css">
<script src="autocomplete/jquery-ui.min.js"></script>

<script language="JavaScript" type="text/javascript">
/*function disableEnterKey(e)
{
		var evt = e || window.event; 
			var key = evt.keyCode;
			//alert (key);
			if(key == 13) // if enter key press
			{
				//alert ("Enter Key Press");
				return false;
			}

}*/
</script>	
<style type="text/css">
.ui-autocomplete { height:auto !important; max-height:300px; overflow:auto; background:#FFF; border:1px solid #CCC;	width:200px;}
.search_row{text-align:left;}
.ui-autocomplete li{ min-height:30px; border-bottom:1px dotted #CCC; padding:10px; text-align:left;}
</style>

<?php //include("calculate_due.php");?>
<script language="JavaScript" type="text/javascript">
	
	var patientdata = <?php echo $patientdata;?>;
	$(document).ready(function($) {
		
		
		$( "#companyinvoice_name" ).autocomplete({
			
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('companyid').value = ui.item.labelval;
				 document.getElementById('companyinvoice_number').value = ui.item.company_mobile;
				 document.getElementById('company_due').value = ui.item.company_due;
				 document.getElementById('companyinvoice_address').value = ui.item.company_address;
				
				return false;
			}
		});
		
			
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
		
	});
	
		
	function calculate_total(){
		
		var company_due = parseFloat(document.getElementById("company_due").value);
		if(company_due=='' || isNaN(company_due)){company_due = 0;}
		
		var disc_amount = parseFloat(document.getElementById("disc_amount").value);
		if(disc_amount=='' || isNaN(disc_amount)){disc_amount = 0;}
			
		var paid_amount = parseFloat(document.getElementById("paid_amount").value);
		if(paid_amount=='' || isNaN(paid_amount)){paid_amount = 0;}
		
		var total_balance = parseFloat(company_due - disc_amount-paid_amount);
		document.getElementById('total_balance').value=	total_balance.toFixed(2);
		
		}
	
	function funcSaveBill1()
{
	
	var varUserChoice; 
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet); 
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		document.frmsales.submit();
		//return true;
	}
}
</script>
<h3 align="center">Pharmacy Purchase Due Paid Invoice</h3>
<article class="bottomcontent">
   <content>
        <?php
        if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
            echo "<p class=\"red12bold\">You have missing Something</p>";
        }
        elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
            echo "<p class=\"red12bold\">Error occured! Could not insert.</p>";   
        }
        elseif(isset($_GET['message']) && $_GET['message']=='save-successfully'){
            echo "<p class=\"red12bold\">Information insert successfully. Click Print Button To Print or View Previous Bill <td width=\"30\" align=\"center\" >
			<a onclick=\"PrintDiv();\"><input type=\"button\" required value=\"Print\" class=\"tdclass\"  /></a></td></p>";   
        }
       ?>          
<form action="save_companyinvoice.php" name="frmcontact" onsubmit="return checkcontactform();" onKeyDown="return disableEnterKey(event)" method="post" enctype="multipart/form-data">
                          
<table width="700" border="0" bgcolor="#31a8b3" cellpadding="2">
      
  <tr>
  	<input type="hidden" name="user" id="user" required value="<?php echo $_SESSION['fullname'];?>" class="tdclass"  />
    <td align="right"  bgcolor="#0066FF">Company Name </td>
    <td><input type="text" name="companyinvoice_name" id="companyinvoice_name" required class="tdclass"/>
    <td align="right">Mobile Number </td>
    <td><input type="text" name="companyinvoice_number" id="companyinvoice_number" class="tdclass"/></td>
  </tr>
    
  <tr>
   	<td align="right">Company ID </td>
    <td><input type="text" readonly name="companyid" id="companyid" class="tdclass2" /></td>
       
    <td align="right">Address </td>
	<td><textarea type="text" name="companyinvoice_address" id="companyinvoice_address" class="tdclass" /></textarea></td>
 
    <td align="right">Date: </td>
     <td><input type="text" name="companyinvoice_date" readonly id="companyinvoice_date" value="<?php echo date('Y-m-d H:i:s');?>" class="tdclass2"/></td>
      
     <!-- <td align="right">Delivery Date: </td>-->
     <td><input type="hidden" name="companyinvoice_update" id="companyinvoice_update" placeholder="12.12.2015" value="<?php //echo date('d-m-Y');?>" class="tdclass2"  /></td>
     
  </tr>
</table>

<table  border="0" width="700" cellpadding="2"  bgcolor="#F3F3F3">
  <tr>
   <td align="right">Note </td>
   <td><textarea type="text" name="note" id="note"/></textarea></td>
  </tr>
 </table>	
 
  <table  border="0" width="700" bgcolor="#e3e7ff" cellpadding="2">
  	<tr>
     <td align="right" style="border-top:1px solid #999;">Current Balance: </td>
    	<td width="50" style="border-top:1px solid #999;"> 
        <input type="text" readonly name="company_due" id="company_due" class="tdclass" onKeyUp="calculate_total();" /></td>
    </tr>
    
    <tr>
     <td align="right"><strong>Discount Amount</strong>: </td>
    <td> <input type="text" name="disc_amount" id="disc_amount" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
  	</tr>
    
    <tr>
     <td align="right"><strong>Pay Amount</strong>: </td>
     <td><input type="text" required name="paid_amount" id="paid_amount" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
  	</tr>
    
    <tr>
     <td align="right">Total Balance Amount: </td>
     <td><input type="text" readonly name="total_balance" id="total_balance" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
  	</tr>
    
   
    <tr>
     <td align="right"></td>
	 <td>
         <input type="hidden" name="companyinvoice_id" id="companyinvoice_id" value="<?php echo $companyinvoice_id;?>">
       	 <input type="submit"  onClick="return funcSaveBill1()" value=" SAVE " name="submit_invoice" id="submit_invoice" class="tdclass1" />
     </td>
  	</tr>
   
</table>
</form>         
          
</content>
</article>

<div id="divToPrint" style="display:none;">
<article class="bottomcontent" style=" margin:0 auto">
  	<?php
		$companyinvoice_id = $_GET['companyinvoice_id'];
        $labinvoice_sql = "select * from companyinvoice where companyinvoice_id = $companyinvoice_id ";
        $labinvoicequery = mysqli_query($conn, $labinvoice_sql);
        if($labinvoicequery && mysqli_num_rows($labinvoicequery)>0 && ($companyinvoice_id<20000)){
            while ($onerow = mysqli_fetch_array($labinvoicequery)){
               	$companyinvoice_id = $onerow['companyinvoice_id'];
                $companyinvoice_name = $onerow['companyinvoice_name'];
                $companyinvoice_address = $onerow['companyinvoice_address'];
                $companyinvoice_number = $onerow['companyinvoice_number'];
                $companyinvoice_date = $onerow['companyinvoice_date'];
                $total_balance = $onerow['total_balance'];
                $company_due = $onerow['company_due'];
              	$disc_amount = $onerow['disc_amount'];
              	$paid_amount = $onerow['paid_amount'];
              	$user = $onerow['user'];		
                $note = $onerow['note'];		
        ?>
                
                <table width="<?php echo $printdata_mobile; ?>" border="1" align="center" style="padding:10px 10px; border-collapse:collapse;font-size:12px;" bgcolor="#FFF" cellpadding="2">
                	<tr>
                    <td width="300" align="center" style="border-right:1px solid #666">
                       <div align="left" style=" color:#000;font-size:16px"><strong><?php echo $hospitaldata_name;?></strong></div>
                       <div align="left" style="color:#000;font-size:12px"><?php echo $hospitaldata_address1;?></div>
                     </td>
                    <td width="150">
                      <div align="right" style="font-size:13px;"><strong><?php echo 'Contact Number'; ?></strong></div>
                      <div align="right"><?php echo $hospitaldata_mobile;?></div>
                    </td>
                     </tr>
                </table>
                       
            <table width="<?php echo $printdata_mobile; ?>" align="center" style="border:1px solid #999;font-size:12px; border-bottom:none; padding:2px 8px 0 8px; margin-top:8px" bgcolor="#FFF" cellpadding="0">
                <tr>
                    <td width="300">
                        <div align="left"><strong>Company</strong> : <?php echo $companyinvoice_name;?></div>
                        <div align="left">Mobile :<?php echo $companyinvoice_number;?></div>
               			<div align="left">Address :<?php echo $companyinvoice_address;?></div>
                   </td>
                    <td width="150">
                        <div align="right" style="font-size:14px"><strong>Paid Invoice</strong></div>
                        <div align="right">Invoice No : <?php echo $companyinvoice_id;?></div>
                        <div align="right">Date : <?php echo $companyinvoice_date;?></div>
                    </td>
                 </tr>
            </table>
                         
             <table align="center" width="<?php echo $printdata_mobile; ?>" bgcolor="#FFF" style="padding:0 0 40px;font-size:12px; border:1px #999 solid; border-top:none; "cellspacing="0" cellpadding="0">
                
                  <tr height="20">
                    <td style="border:1px solid #999;text-align:center;"><strong>Particular</strong></td>
                    <td style="border:1px solid #999; text-align:center;">Amount</td>
                  </tr>
                 
                <tr>
                    <td style=" text-align:center;"> <?php echo 'Previous Due'?></td>
                    <td style=" text-align:center;"> <?php echo $company_due;?></td>
                  </tr>
                  <tr>
                    <td style=" text-align:center;"> <?php echo 'Discount Amount'?></td>
                    <td style=" text-align:center;"> <?php echo $disc_amount;?></td>
                  </tr>
                  <tr>
                    <td style=" text-align:center;"> <strong><?php echo 'Due Paid'?></strong></td>
                    <td style=" text-align:center;"><strong> <?php echo $paid_amount;?></strong></td>
                  </tr>
                  <tr>
                    <td style=" text-align:center;"> <?php echo 'Current Due'?></td>
                    <td style=" text-align:center;"> <?php echo $total_balance;?></td>
                  </tr>
               
            </table>
                    
                <?php
				}
			}
        ?>
         <table align="center" width="450" style="font-size:12px; font-style:italic">
        <tr> 
        	<td><?php include ("convert_currency_to_words.php");
			echo 'InWords:';	echo covert_currency_to_words($paid_amount); ?>
            </td>
           </tr>
        </table>
         
        <table width="<?php echo $printdata_mobile; ?>" align="center" style=" font-size:12px; padding:15px 2px" bgcolor="#FFF" cellpadding="0">
                          
        <tr>
            <td width="350">
                <div align="left">Prepared By: <?php echo $user; ?></div>
            </td>
            <td width="200">
                <div align="right">Receiver Sign</div>
             </td>
            <td width="200">
                <div align="right">Authorised Sign</div>
            </td>
         </tr>
        </table>

	<table width="<?php echo $printdata_mobile; ?>" align="center" border="0">
      <tr>
        <td width="450" style="font-size:10px"><?php echo $note; ?></td>
      </tr>
	</table>
</article>
</div>