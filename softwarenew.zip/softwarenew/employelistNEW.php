	  <header>
            <h3>Add New Employee</h3>
        </header>
 		<?php
			if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
			echo "<h2 class=\"red12bold\">You have missing Something</h2>";
			}
			elseif(isset($_GET['message']) && $_GET['message']=='duplicatename'){
			echo "<h2 class=\"red12bold\">This Item  already exists. Please try with different item .</h2>";   
			}
			elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
			echo "<h2 class=\"red12bold\">Error occured! Could not insert.</h2>";   
			}
			elseif(isset($_GET['message']) && $_GET['message']=='insert-successfully'){
			echo "<h2 class=\"red12bold\">Item insert successfully</h2>";   
			}
  			$employeenewid = 0;
			$name = '';
			$salary = '';
 			 
         if(isset($_GET['employeenewid'])){
            $employeenewid = $_GET['employeenewid'];
            $sqlsalesitem = "select * from employeenew where employeenewid = $employeenewid";
            $salesitemquery = mysqli_query($conn, $sqlsalesitem);
            if($salesitemquery){
                while($srow = mysqli_fetch_array($salesitemquery)){
                    $employeenewid = $srow['employeenewid'];
                    $name = $srow['name'];
					$eid = $srow['eid'];
					$department = $srow['department'];
					$salary = $srow['salary'];
 					}
				}
			}
        ?>        
 		<form action="save_employeeNEW.php" name="frmcontact" onsubmit="return checkcontactform();" method="post" enctype="multipart/form-data">
             <table width="70%" border="1" style="border-collapse:collapse" bgcolor="#fff">
                <tr>
                    <td width="220">Photo </td>
                    <td>
                        <input type="file" size="10" name="employenameentry_photo" id="employenameentry_photo" class="textfieldcssmem"  />
                    </td>
                </tr>
               
                <tr>
                    <td>Name*</td>
                    <td>
                        <input type="text" required name="name" id="name" value="<?php echo $name;?>" class="textfieldcssmem"  />
                    </td>
                </tr>
                
                <tr>
                    <td>Father*</td>
                    <td>
                        <input type="text" name="father" id="father" value="<?php //echo $father;?>" class="textfieldcssmem"  />
                    </td>
                </tr>
                
                <tr>
                    <td>Designation*</td>
                    <td>
                        <input type="text" name="designation" id="designation" value="<?php //echo $designation;?>" class="textfieldcssmem"  />
                    </td>
                </tr>
                
                 <tr>
                    <td>Address*</td>
                    <td>
                       <textarea type="text" name="address" id="address" class="textfieldcssmem" ><?php //echo $address;?></textarea>
                    </td>
                </tr>
                
                  <tr>
                    <td><strong>Monthly Salary</strong>*</td>
                    <td><input type="text" name="salary" id="salary" value="<?php echo $salary;?>" class="textfieldcssmem" /></td>
                  </tr>
                
                <tr>
                    <td>&nbsp;</td>
                    <td>
                        <input type="hidden" name="employeenewid" id="employeenewid" value="<?php echo $employeenewid;?>">
                        <input type="submit" value=" Save " name="submit" id="submit" class="submitbuttoncss" />
                    </td>
                </tr>
          </table>
      </form>
      

<style>
body{
    font-family:Segoe UI;
    background:#f5f6fa;
}

.container{
    max-width:1100px;
    margin:20px auto;
}

/* Search */
.search-box{
    background:#fff;
    padding:15px;
    border-radius:10px;
    margin-bottom:15px;
    box-shadow:0 3px 10px rgba(0,0,0,0.1);
}

input{
    padding:6px;
    border:1px solid #ccc;
    border-radius:5px;
}

button{
    padding:7px 12px;
    background:#0d6efd;
    color:#fff;
    border:none;
    border-radius:5px;
    cursor:pointer;
}

/* Table */
.table-box{
    background:#fff;
    padding:15px;
    border-radius:10px;
    box-shadow:0 3px 10px rgba(0,0,0,0.1);
}

table{
    width:100%;
    border-collapse:collapse;
}

th{
    background:#0d6efd;
    color:#fff;
    padding:8px;
}

td{
    padding:6px;
    border-bottom:1px solid #ddd;
}

tr:hover{
    background:#f1f1f1;
}

/* Print */
@media print{
    .search-box, button{
        display:none;
    }
}
</style>


<body>
<div class="container">
<div class="table-box">
<table>
<tr>
    <th>#</th>
    <th>eid</th>
    <th>name</th>
    <th>department</th>
    <th>salary</th>
    <th>action</th>
</tr>

<?php
$i=0;

$sql = "
SELECT eid, name, department, salary
FROM employeenew ORDER BY name ASC
";

$res = mysqli_query($conn, $sql);

if($res && mysqli_num_rows($res)>0){
    while($row = mysqli_fetch_assoc($res)){
?>
<tr>
    <td><?php echo ++$i; ?></td>
    <td><?php echo $row['eid']; ?></td>
    <td><?php echo $row['name']; ?></td>
    <td><?php echo $row['department']; ?></td>
    <td><?php echo $row['salary']; ?></td>
    <td><?php //echo $row['action']; ?></td>
</tr>
<?php
    }
}else{
?>
<tr>
    <td colspan="6" align="center">No Data Found</td>
</tr>
<?php } ?>

</table>
</div>
</div>
</body>