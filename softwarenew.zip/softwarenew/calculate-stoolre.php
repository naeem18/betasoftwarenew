<script language="JavaScript" type="text/javascript">
	
	var patientdata = <?php echo $patientdata;?>;
	var drdata = <?php echo $drdata;?>;
	$(document).ready(function($) {
		
		$( "#labreport_labinvoiceid" ).autocomplete({
			
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('labreport_patient').value = ui.item.labelval;
				 document.getElementById('labreport_age').value = ui.item.labinvoice_age;
				 document.getElementById('labreport_patientid').value = ui.item.labinvoice_patientid;
				 document.getElementById('labreport_gender').value = ui.item.labinvoice_gender;
				 document.getElementById('labreport_mobile').value = ui.item.labinvoice_mobile;
				 document.getElementById('labreport_address').value = ui.item.labinvoice_address;
				 document.getElementById('labreport_doctor').value = ui.item.labinvoice_doctor;
				
				return false;
			}
		});
		$( "#labreport_doctor" ).autocomplete({
			
			minLength: 1,
			source: drdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('labreport_doctor').value = ui.item.labelval;
				 document.getElementById('labreport_doctor').value = ui.item.doctor_name;
				return false;
			}
		});
		
	});
	
</script>