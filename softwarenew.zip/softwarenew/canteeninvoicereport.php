<style>
body{
	background: #F4F4F4;
	color:#000000;
	font-size:13px;;
	font-family:Tahoma;
	/*font-family:Tunga;*/
	line-height:1.5;
	text-align:left;
	width:1370px !important;
	margin:0 auto;
	margin-left:0px;
}
</style>
<script type="text/javascript" language="javascript">
	function removetablerow2(idvalue){
		var conf = confirm("Do you sure want to delete this ID="+idvalue+" from this Table ");
		if(conf)
			window.location='delete_table_row2.php?idvalue='+idvalue;
		}
</script>
<?php
$searchstr='';
if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
{
	$transactiondatefrom = $_REQUEST['ADate1'];
	$transactiondateto = $_REQUEST['ADate2'];
	
	$labinvoice_patient = $_REQUEST['labinvoice_patient'];
	$labinvoice_pc = $_REQUEST['labinvoice_pc'];
	$labinvoice_mpo = $_REQUEST['labinvoice_mpo'];
	$canteeninvoice_id = $_REQUEST['canteeninvoice_id'];
	$labinvoice_patientid = $_REQUEST['labinvoice_patientid'];
	$user = $_REQUEST['user'];
	$labinvoice_doctor = $_REQUEST['labinvoice_doctor'];
	$labinvoice_mobile = $_REQUEST['labinvoice_mobile'];
	
	if($labinvoice_patient !=''){
		$searchstr .= " and labinvoice_patient like '%$labinvoice_patient%'";
	}
	elseif($canteeninvoice_id !=''){
		$searchstr .= " and canteeninvoice_id like '%$canteeninvoice_id%'";
	}
	elseif($user !=''){
		$searchstr .= " and user like '%$user%'";
	}
	elseif($labinvoice_patientid !=''){
		$searchstr .= " and labinvoice_patientid like '%$labinvoice_patientid%'";
	}
	elseif($labinvoice_mpo !=''){
		$searchstr .= " and labinvoice_mpo like '%$labinvoice_mpo%'";
	}
	elseif($labinvoice_pc !=''){
		$searchstr .= " and labinvoice_pc like '%$labinvoice_pc%'";
	}
	elseif($labinvoice_doctor !=''){
		$searchstr .= " and labinvoice_doctor like '%$labinvoice_doctor%'";
	
	}
	elseif($labinvoice_mobile !=''){
		$searchstr .= " and labinvoice_mobile like '%$labinvoice_mobile%'";
	}
}
else
{
	$transactiondatefrom = date('Y-m-d', strtotime('-0 day'));
	$transactiondateto = date('Y-m-d');
}
?>
<?php 
	$datetime1 = new DateTime($transactiondatefrom);
	$datetime2 = new DateTime($transactiondateto);
	$interval = $datetime1->diff($datetime2);
	$totaldays = $interval->format('%a');
	if($datetime1<$datetime2){
		$fromdate = $transactiondatefrom;
		$todate = $transactiondateto;
	}
	else{
		$fromdate = $transactiondateto;
		$todate = $transactiondatefrom;
	}
?>

	  <body>
    	<table width="100%" cellpadding="0">  
          <tr>
           <td valign="top" align="center">
           	  <form name="cbform1" method="post" action="index.php?p=canteeninvoicereport">
            	<table width="100%" align="left" cellpadding="1" bordercolor="#666666">
                   <tr bgcolor="#011E6A">
                      <td colspan="100%" bgcolor="#CCCCCC" class="bodytext3"><strong>Search By..</strong></td>
                    </tr>           
                    <tr bgcolor="#FFFFFF">
                    
				    <td align="right">From</td>
                    <td>
                        <input name="ADate1" id="ADate1" style="border: 1px solid #001E6A;" value="<?php echo $transactiondatefrom; ?>" size="6" readonly onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
                    </td>
                    <td>To</td>
                    <td>
                        <input name="ADate2" id="ADate2" style="border: 1px solid #001E6A;" value="<?php echo $transactiondateto; ?>" size="6" readonly onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate2')" style="cursor:pointer"/>
                    </td>
                  
                    <td>Inv</td>
            	    <td><input type="text" style="width:40px" name="canteeninvoice_id" id="canteeninvoice_id"/></td>
                    <td>ID</td>
            	    <td> <input type="text" style="width:40px" name="labinvoice_patientid" id="labinvoice_patientid" /></td>
             		<td>Name</td>
            	    <td><input type="text" style="width:90px" placeholder="Name Name" name="labinvoice_patient" id="labinvoice_patient" /></td>
                    <td><input type="text" placeholder="mobile" size="7" name="labinvoice_mobile" id="labinvoice_mobile" /></td>
                    <td>Dr.</td>
            	    <td> <input type="text" style="width:90px" placeholder="Doctor Name" name="labinvoice_doctor" id="labinvoice_doctor" /></td>
            		<td>MPO</td>
            	    <td><input type="text" style="width:90px" name="labinvoice_mpo" id="labinvoice_mpo" /></td>
            		<td>PC</td>
            	    <td><input type="text" style="width:90px" name="labinvoice_pc" id="labinvoice_pc" /></td>
            		<td>User</td>
            	    <td><input type="text" size="6" placeholder="user" name="user" id="user" /></td>
                 	<td><input style="border: 1px solid #001E6A" type="submit" value="Search" name="Submit" /></td>
                    <td><input name="print" type="button" id="print"  style="border: 1px solid #001E6A" value="Print" onClick="PrintDiv();" /></td>
                    
         	 	<td  bgcolor="#ffffff"  align="center">
					<script language="javascript">
                    function excelexport1()
                    {
                         window.location = "dbexcelfiles/Statement By Invoice.xls"
                    }
                    </script>&nbsp;
                </td>
                <td bgcolor="#ffffff"><input onClick="javascript:excelexport1();" type="button" value="Export To Excel" name="Submit2" class="button" style="border: 1px solid #001E6A" /></td>
             </tr>
              </tbody>
            </table>
		</form>
   	</td>
</tr>

	<td align="center">
         <table align="center" style="BORDER-COLLAPSE: collapse" width="1300" border="1" cellspacing="0" cellpadding="2">
           <tr>
            <td colspan="28" bgcolor="#ccc" align="center" style="color:#03F; border:1px solid #03F;">
            	<strong><?php echo $hospitaldata_name;?></strong><br>
                <strong>Statement By Eye Invoice :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></strong>
            </td>
          </tr>
          
            <tr bgcolor="#096B7F" style="color:#FFF">
                <td>SL</td>
                <td>INV No.</td>
                <td>ID No.</td>
                <td>Print Inv</td>
                <td>Inv Date</td>
                <td>Name</td>
                <td>Mobile</td>
                <td>Gross</td>
                <td>Disc%</td>
                <td>Disc</td>
                <td><strong>Nett</strong></td>
                <td style="color:yellow">Inv Cash</td>
                <!--<td style="color:yellow">Due Collection</td>
                <td>Final Disc</td>-->
                <td style="color:yellow"><strong>Dues</strong></td>
                <td>Ref. Dr.</td>
                <td>MPO</td>
                <td>P.C Name</td>
               	<td>P.C Com Due</td>
                <td>Description</td>
                <td>User Name</td>
                <td>Updated User</td>
                <td>Edit</td>
                <td>Remove</td>
            </tr>
		<?php
		$s='';
		$totalsumlabinvoice_subtotal='0.00';
		$totalsumlabinvoice_subtotalafterdisc='0.00';
		$totalsumlabinvoice_totaldisc='0.00';
		$totalsumlabinvoice_receiveamount='0.00';
		$totalsumlabinvoice_due='0.00';
		$totalsumlabinvoice_subtotalafterdisc='0.00';
		$totalsumlabinvoice_pccommission='0.00';
		$totalsumcollection_amount='0.00';
			
		for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
			$sqlst = "SELECT * FROM  canteeninvoice WHERE labinvoice_date between '$newfromdate' AND '$newtodate' $searchstr ORDER BY canteeninvoice_id ASC";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery &&  mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery)) {
					$canteeninvoice_id = $strow['canteeninvoice_id'];
                    $labinvoice_patientid = $strow['labinvoice_patientid'];
                    $labinvoice_patient = $strow['labinvoice_patient'];
					$labinvoice_mobile = $strow['labinvoice_mobile'];
                    $user = $strow['user'];
					$update_user = $strow['update_user'];
                    $labinvoice_age = $strow['labinvoice_age'];
                    $labinvoice_gender = $strow['labinvoice_gender'];
                    $labinvoice_address = $strow['labinvoice_address'];
                    $labinvoice_doctor = $strow['labinvoice_doctor'];
                    $labinvoice_pc = $strow['labinvoice_pc'];
					$labinvoice_mpo = $strow['labinvoice_mpo'];
					$labinvoice_totalpccomission = $strow['labinvoice_totalpccomission'];
					$labinvoice_subtotal = $strow['labinvoice_subtotal'];
					$labinvoice_totaldiscp = $strow['labinvoice_totaldiscp'];
					$labinvoice_totaldisc = $strow['labinvoice_totaldisc'];
					$labinvoice_subtotalafterdisc = $strow['labinvoice_subtotalafterdisc'];
					$labinvoice_receiveamount = $strow['labinvoice_receiveamount'];
					$labinvoice_due = $strow['labinvoice_due'];
					$collection_amount = $strow['collection_amount'];
					$labinvoice_finaldisc = $strow['labinvoice_finaldisc'];
					$labinvoice_description = $strow['labinvoice_description'];
					$labinvoice_date=	$strow['labinvoice_date'];
					$labinvoice_collecteddate=	$strow['labinvoice_collecteddate'];
					 
			$action = "<a href=\"index.php?p=canteeninvoiceedit&canteeninvoice_id=$canteeninvoice_id\">Edit</a>";
			$action6 = "<a href=\"javascript:void(0)\" onclick=\"removetablerow2($canteeninvoice_id)\">Remove</a>";
			$action1 = "<a href=\"index.php?p=printcanteeninvoice&canteeninvoice_id=$canteeninvoice_id\" target=\"_blank\">Print</a>";
			
            $totalsumlabinvoice_subtotal  = $totalsumlabinvoice_subtotal + $labinvoice_subtotal;
            $totalsumlabinvoice_subtotalafterdisc  = $totalsumlabinvoice_subtotalafterdisc + $labinvoice_subtotalafterdisc;
            $totalsumlabinvoice_totaldisc  = $totalsumlabinvoice_totaldisc + $labinvoice_totaldisc;
            $totalsumlabinvoice_receiveamount  = $totalsumlabinvoice_receiveamount + $labinvoice_receiveamount;
            $totalsumlabinvoice_due  = $totalsumlabinvoice_due + $labinvoice_due;
            $totalsumlabinvoice_pccommission=$totalsumlabinvoice_pccommission+$labinvoice_totalpccomission;
            $totalsumcollection_amount=$totalsumcollection_amount+$collection_amount;
		    ?>
                <tr bgcolor="#f5f5f5" >
                    <td><?php echo $s=$s+1;?></td>
                    <td><?php echo $canteeninvoice_id;?></td>
                    <td><?php echo $labinvoice_patientid;?></td>
                   	<td><?php echo $action1;?></td>
                    <td><?php echo $labinvoice_date;?></td>
                    <td><?php echo $labinvoice_patient;?></td>
                    <td><?php echo $labinvoice_mobile;?></td>
                    
                   <td><?php echo $labinvoice_subtotal;?></td>
                    <td><?php echo $labinvoice_totaldiscp;?></td>
                    <td><?php echo $labinvoice_totaldisc;?></td>
                    <td style="color: #00C"><?php echo $labinvoice_subtotalafterdisc;?></td>
                    <td><?php echo $labinvoice_receiveamount;?></td>
                   	<td style="color: #F00"><?php echo $labinvoice_due;?></td>
                    <td><?php echo $labinvoice_doctor;?></td>
                    <td><?php echo $labinvoice_mpo;?></td>
                    <td><?php echo $labinvoice_pc;?></td>
                    <td><?php echo $labinvoice_totalpccomission;?></td>
                    <td><?php echo $labinvoice_description;?></td>
                    <td><?php echo $user;?></td>
                    <td style="color:#F00"><?php echo $update_user;?></td>
                   	<td><?php if($_SESSION['employeename']=='ADMINISTRATOR') { echo $action;} if($_SESSION['employeename']=='SUPERADMINISTRATOR'){ echo $action; } ?></td>
                    <td><?php if($_SESSION['employeename']=='SUPERADMINISTRATOR'){ echo $action6; } ?></td>
               	</tr>
                <?php
                }
			}
		}
		?>
        	<tr bgcolor="#F2EBEB">
                <td colspan="7"></td>
                <td><strong>Total:</strong></td>
                <td><strong>Gross: <?php echo number_format($totalsumlabinvoice_subtotal); ?></strong></td>
                <td><strong><?php //echo number_format($totalsumcreditamount1, 2, '.', ''); ?></strong></td>
                <td><strong>Disc: <?php echo number_format($totalsumlabinvoice_totaldisc, 2, '.', ''); ?></strong></td>
                <td><strong>Net: <?php echo number_format($totalsumlabinvoice_subtotalafterdisc); ?></strong></td>
                <td><strong>Inv Cash: <?php echo $totalsumlabinvoice_receiveamount; ?></strong></td>
               <?php /*?> <td><strong>Dues Collection: <?php echo $totalsumcollection_amount; ?></strong></td>
                <td><strong><?php //echo number_format($totalsumlabinvoice_subtotalafterdisc, 2, '.', ''); ?></strong></td><?php */?>
                <td><strong>Dues: <?php echo number_format($totalsumlabinvoice_due); ?></strong></td>
                <td colspan="3">&nbsp;</td>
                <td><strong>P.C-Due: <?php echo number_format($totalsumlabinvoice_pccommission); ?></strong></td>
                <td colspan="6">&nbsp;</td>
           </tr>
        </table>
     </td>
<tr>

<td align="center" id="divToPrint" style="display:none">
    <?php 
            
            $datetime1 = new DateTime($transactiondatefrom);
            $datetime2 = new DateTime($transactiondateto);
            $interval = $datetime1->diff($datetime2);
            $totaldays = $interval->format('%a');
            if($datetime1<$datetime2){
                $fromdate = $transactiondatefrom;
                $todate = $transactiondateto;
            }
            else{
                $fromdate = $transactiondateto;
                $todate = $transactiondatefrom;
            }
            ?>
            
           <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1" cellspacing="0" cellpadding="2">
              <tbody>
              <tr>
            <td colspan="18" bgcolor="#fff" align="center" style="color:#000; border:1px solid #000;">
            	<strong><?php echo $hospitaldata_name; ?></strong><br>
                <samp>Statement By canteen Invoice :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></samp>
            </td>
          	</tr>
                <tr align="left">
                <td><strong>SL</strong></td>
                <td><strong>Bill</strong></td>
                <td><strong>Inv Date</strong></td>
                <td><strong>Collected Date</strong></td>
                <td><strong>Name</strong></td>
                <td><strong>Gross</strong></td>
                <td><strong>Disc</strong></td>
                <td><strong>Net</strong></td>
                <td><strong>Cash</strong></td>
                <td><strong>Dues</strong></td>
                <td><strong>Ref. Dr.</strong></td>
                <td><strong>MPO Name</strong></td>
                <td><strong>P.C Name</strong></td>
                <td><strong>P.C Com</strong></td>
                <td>Description</td>
                <td><strong>User Name</strong></td>
            </tr>
            <?php
			$s='';
			$totalsumlabinvoice_subtotal='0.00';
			$totalsumlabinvoice_subtotalafterdisc='0.00';
			$totalsumlabinvoice_totaldisc='0.00';
			$totalsumlabinvoice_receiveamount='0.00';
			$totalsumlabinvoice_due='0.00';
			$totalsumlabinvoice_subtotalafterdisc='0.00';
			$totalsumlabinvoice_pccommission='0.00';

            for($i=0; $i<=$totaldays; $i++){
                $newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
                $newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));

                $sqlst = "select * from canteeninvoice where labinvoice_date between '$newfromdate' and '$newtodate' $searchstr order by canteeninvoice_id asc";
                $stquery = mysqli_query($conn, $sqlst);
                if($stquery &&  mysqli_num_rows($stquery)>0){
                while ($strow = mysqli_fetch_array($stquery)) {
                        $canteeninvoice_id = $strow['canteeninvoice_id'];
                        $labinvoice_patientid = $strow['labinvoice_patientid'];
						$user = $strow['user'];
                        $labinvoice_patient = $strow['labinvoice_patient'];
                        $labinvoice_age = $strow['labinvoice_age'];
                        $labinvoice_gender = $strow['labinvoice_gender'];
                        $labinvoice_address = $strow['labinvoice_address'];
                        $labinvoice_doctor = $strow['labinvoice_doctor'];
                        $labinvoice_pc = $strow['labinvoice_pc'];
                        $labinvoice_mpo = $strow['labinvoice_mpo'];
                        $labinvoice_totalpccomission = $strow['labinvoice_totalpccomission'];
                        $labinvoice_subtotal = $strow['labinvoice_subtotal'];
                        $labinvoice_totaldiscp = $strow['labinvoice_totaldiscp'];
                        $labinvoice_totaldisc = $strow['labinvoice_totaldisc'];
                        $labinvoice_subtotalafterdisc = $strow['labinvoice_subtotalafterdisc'];
                        $labinvoice_receiveamount = $strow['labinvoice_receiveamount'];
                        $labinvoice_due = $strow['labinvoice_due'];
                        $labinvoice_description = $strow['labinvoice_description'];
                        $labinvoice_date=	$strow['labinvoice_date'];
                        $labinvoice_collecteddate=	$strow['labinvoice_collecteddate'];
                         
                        $totalsumlabinvoice_subtotal  = $totalsumlabinvoice_subtotal + $labinvoice_subtotal;
                        $totalsumlabinvoice_subtotalafterdisc  = $totalsumlabinvoice_subtotalafterdisc + $labinvoice_subtotalafterdisc;
                        $totalsumlabinvoice_totaldisc  = $totalsumlabinvoice_totaldisc + $labinvoice_totaldisc;
                        $totalsumlabinvoice_receiveamount  = $totalsumlabinvoice_receiveamount + $labinvoice_receiveamount;
                        $totalsumlabinvoice_due  = $totalsumlabinvoice_due + $labinvoice_due;
                        $totalsumlabinvoice_pccommission=$totalsumlabinvoice_pccommission+$labinvoice_totalpccomission;
                        ?>
                    <tr align="left">
                        <td><?php echo $s=$s+1;?></td>
                        <td><?php echo $canteeninvoice_id;?></td>
                        <td><?php echo date('d.m.y',strtotime($newfromdate));?></td>
                        <td><?php echo $labinvoice_collecteddate;?></td>
                   		<td><?php echo $labinvoice_patient;?></td>
                        <td><?php echo $labinvoice_subtotal;?></td>
                        <td><?php echo $labinvoice_totaldisc;?></td>
                        <td><?php echo $labinvoice_subtotalafterdisc;?></td>
                        <td><?php echo $labinvoice_receiveamount;?></td>
                        <td><?php echo $labinvoice_due;?></td>
                        <td><?php echo $labinvoice_doctor;?></td>
                    	<td><?php echo $labinvoice_mpo;?></td>
                        <td><?php echo $labinvoice_pc;?></td>
                        <td><?php echo $labinvoice_totalpccomission;?></td>
                        <td><?php echo $labinvoice_description;?></td>
                        <td><?php echo $user;?></td>
                    </tr>
                    <?php
                    }
                  }
            	}
             ?>
            
            <tr>
              <td align="left" colspan="4">&nbsp;</td>
              <td align="left"><strong>Total : </strong></td>
              <td align="left"><strong><?php echo number_format($totalsumlabinvoice_subtotal, 2, '.', ''); ?></strong></td>
              <td align="left"><strong><?php echo number_format($totalsumlabinvoice_totaldisc, 2, '.', ''); ?></strong></td>
              <td align="left"><strong><?php echo number_format($totalsumlabinvoice_subtotalafterdisc, 2, '.', ''); ?></strong></td>
              <td align="left"><strong><?php echo number_format($totalsumlabinvoice_receiveamount, 2, '.', ''); ?></strong></td>
              <td align="left"><strong><?php echo number_format($totalsumlabinvoice_due, 2, '.', ''); ?></strong></td>
              <td valign="center" colspan="3" align="left">&nbsp;</td>
              <td align="left"><strong><?php echo number_format($totalsumlabinvoice_pccommission, 2, '.', ''); ?></strong></td>
              <td colspan="2" ></td>
              </tr>
              </tbody>
            </table>
            
        </td>
    </tr>
</table>
</body>