<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$message = '';

if(isset($_POST['btnAttUpload'])){

    require_once 'ExcelLibrary/PHPExcel.php';

    $entry = 0;
    $empInsert = 0;
    $duplicate = 0;

    $tempFile = $_FILES['attendance_file']['tmp_name'];
    $object = PHPExcel_IOFactory::load($tempFile);

    // =========================
    // EXISTING EMPLOYEE LOAD
    // =========================
    $employeeMap = array();

    $empObj = mysqli_query($conn, "SELECT employeenewid, eid FROM employeenew");
    while($row = mysqli_fetch_assoc($empObj)){
        $employeeMap[$row['eid']] = $row['employeenewid'];
    }

    // =========================
    // DATE FIX FUNCTION
    // =========================
    function fixDateTime($value){

        if(empty($value)) return '';

        if(is_numeric($value)){
            return date('Y-m-d H:i:s', PHPExcel_Shared_Date::ExcelToPHP($value));
        }

        $time = strtotime($value);
        if($time){
            return date('Y-m-d H:i:s', $time);
        }

        return '';
    }

    // =========================
    // LOOP EXCEL
    // =========================
    foreach($object->getWorksheetIterator() as $worksheet){

        $highestRow = $worksheet->getHighestRow();

        for($row=2; $row<=$highestRow; $row++){

            $eid   = trim($worksheet->getCellByColumnAndRow(0, $row)->getValue());
            $name  = trim($worksheet->getCellByColumnAndRow(1, $row)->getValue());
            $department  = trim($worksheet->getCellByColumnAndRow(2, $row)->getValue());

            $entry_raw = $worksheet->getCellByColumnAndRow(3, $row)->getValue();
            $exit_raw  = $worksheet->getCellByColumnAndRow(4, $row)->getValue();

            if(empty($eid)) continue;

            // escape
            $eidDB = mysqli_real_escape_string($conn, $eid);
            $nameDB = mysqli_real_escape_string($conn, $name);
            $deptDB = mysqli_real_escape_string($conn, $department);

            // =========================
            // DATE FIX
            // =========================
            $entry_time = fixDateTime($entry_raw);
            $exit_time  = fixDateTime($exit_raw);

            // =========================
            // EMPLOYEE INSERT / UPDATE
            // =========================
            if(!isset($employeeMap[$eid])){

                // check DB
                $checkEmp = mysqli_query($conn, "
                    SELECT employeenewid, name, department 
                    FROM employeenew 
                    WHERE eid='$eidDB' 
                    LIMIT 1
                ");

                if(mysqli_num_rows($checkEmp) > 0){

                    $rowEmp = mysqli_fetch_assoc($checkEmp);
                    $employeenewid = $rowEmp['employeenewid'];

                    // update if changed
                    if($rowEmp['name'] != $name || $rowEmp['department'] != $department){
                        mysqli_query($conn, "
                            UPDATE employeenew SET
                                name='$nameDB',
                                department='$deptDB'
                            WHERE employeenewid='$employeenewid'
                        ");
                    }

                }else{

                    // insert new
                    mysqli_query($conn, "
                        INSERT INTO employeenew 
                        SET 
                            name='$nameDB',
                            eid='$eidDB',
                            department='$deptDB'
                    ");

                    $employeenewid = mysqli_insert_id($conn);
                    $empInsert++;
                }

                $employeeMap[$eid] = $employeenewid;

            }else{

                $employeenewid = $employeeMap[$eid];

                // always keep updated
                mysqli_query($conn, "UPDATE employeenew SET name='$nameDB',
                        department='$deptDB'
                    WHERE employeenewid='$employeenewid'
                ");
            }

             
            $check = mysqli_query($conn, "
                SELECT id FROM machine_datanew 
                WHERE eid='$eidDB' 
                AND entry_time='$entry_time'
                LIMIT 1
            ");

            if(mysqli_num_rows($check) > 0){
                $duplicate++;
                continue;
            }

            // =========================
            // INSERT MACHINE DATA
            // =========================
            $insert = mysqli_query($conn, "
                INSERT INTO machine_datanew 
                SET 
                    employeenewid = '$employeenewid',
                    eid = '$eidDB',
                    name = '$nameDB',
                    department = '$deptDB',
                    entry_time = '$entry_time',
                    exit_time = '$exit_time'
            ");

            if($insert){
                $entry++;
            }
        }
    }

    // =========================
    // RESULT
    // =========================
    $message = "
        <p>
        ✅ Saved: $entry <br>
        ⚠ Duplicate Skipped: $duplicate <br>
        👤 New Employee Added: $empInsert
        </p>
    ";
}
?>
<header class="header_tittle">
 <h3>Attendance File Upload Safe Hospital </h3>
</header>

<form action="index.php?p=employenameentryNEW" enctype="multipart/form-data" onSubmit="return checkFile();" method="post" accept-charset="utf-8">
    <table cellpadding="5" cellspacing="0" width="100%">
    	<?php
        if($message !=''){
			echo $message;
		}
		?>
        <tr>
        	<td width="200">
            	<label>Attendance Import File*:</label>
            </td>
            <td>
            	<input required class="bordernone" type="file" name="attendance_file" id="attendance_file" accept=".xls,.xlsx" />
      			<span class="errormsg" id="errmsg_attendance_file"></span>
            </td>
        </tr>
        <tr>
        	<td width="200">&nbsp;</td>
            <td>
            	<input type="submit" name="btnAttUpload" id="btnAttUpload" class="btn btn-primary backlink" value=" Upload" />
		        <input type="button" onClick="resetform();" value="Cancel" class="hidediv btn btn-warning mleft10" />
            </td>
        </tr>
    </table>
</form>

<script type="text/javascript">
    function checkFile(){
        var elementmessage = document.getElementById('errmsg_attendance_file');
        elementmessage.innerHTML = '';
        
        var ext = $('#attendance_file').val().split('.').pop().toLowerCase();
        var allow = new Array('xls','xlsx');
        if(jQuery.inArray(ext, allow) == -1) {
            elementmessage.innerHTML = 'File type is invalid. Only <strong>.xls/.xlsx</strong> file types are allowed.';
            $('#attendance_file').focus();
			
			return false;
        }
        return true;
    }

    function resetform(){
        document.frmImportCustomers.instance_id.value = 0;
        $('#attendance_file').val('');
        $("#formtitle").html('Attendance Import Information');
        $("#btnAttUpload").val(' Upload and View ');                                                
    }
</script>

<?php
require('labdd.php');

$from = isset($_POST['from']) ? $_POST['from'] : date('Y-m-d');
$to   = isset($_POST['to']) ? $_POST['to'] : date('Y-m-d');

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Attendance Report</title>

<style>
body{
    font-family:Segoe UI;
    background:#f5f6fa;
}

.container{
    max-width:1100px;
    margin:20px auto;
}

/* Search */
.search-box{
    background:#fff;
    padding:15px;
    border-radius:10px;
    margin-bottom:15px;
    box-shadow:0 3px 10px rgba(0,0,0,0.1);
}

input{
    padding:6px;
    border:1px solid #ccc;
    border-radius:5px;
}

button{
    padding:7px 12px;
    background:#0d6efd;
    color:#fff;
    border:none;
    border-radius:5px;
    cursor:pointer;
}

/* Table */
.table-box{
    background:#fff;
    padding:15px;
    border-radius:10px;
    box-shadow:0 3px 10px rgba(0,0,0,0.1);
}

table{
    width:100%;
    border-collapse:collapse;
}

th{
    background:#0d6efd;
    color:#fff;
    padding:8px;
}

td{
    padding:6px;
    border-bottom:1px solid #ddd;
}

tr:hover{
    background:#f1f1f1;
}

/* Print */
@media print{
    .search-box, button{
        display:none;
    }
}
</style>

<script>
function printReport(){
    window.print();
}
</script>

</head>

<body>

<div class="container">

<!-- SEARCH -->
<div class="search-box">
<form method="post" action="index.php?p=employenameentryNEW">
    From: <input type="date" name="from" value="<?php echo $from; ?>">
    To: <input type="date" name="to" value="<?php echo $to; ?>">
    <button type="submit">Search</button>
    <button type="button" onclick="printReport()">Print</button>
</form>
</div>

<!-- REPORT -->
<div class="table-box">

<h3 style="text-align:center;">
Attendance Report <br>
<?php echo date('d-m-Y',strtotime($from)); ?> to <?php echo date('d-m-Y',strtotime($to)); ?>
</h3>

<table>
<tr>
    <th>#</th>
    <th>eid</th>
    <th>name</th>
    <th>department</th>
    <th>entry_time</th>
    <th>exit_time</th>
</tr>

<?php
$i=0;

$sql = "
SELECT eid, name, department, entry_time, exit_time
FROM machine_datanew
WHERE DATE(entry_time) BETWEEN '$from' AND '$to'
ORDER BY entry_time ASC
";

$res = mysqli_query($conn, $sql);

if($res && mysqli_num_rows($res)>0){
    while($row = mysqli_fetch_assoc($res)){
?>
<tr>
    <td><?php echo ++$i; ?></td>
    <td><?php echo $row['eid']; ?></td>
    <td><?php echo $row['name']; ?></td>
    <td><?php echo $row['department']; ?></td>
    <td><?php echo $row['entry_time']; ?></td>
    <td><?php echo $row['exit_time']; ?></td>
</tr>
<?php
    }
}else{
?>
<tr>
    <td colspan="6" align="center">No Data Found</td>
</tr>
<?php } ?>

</table>

</div>

</div>

</body>
</html>