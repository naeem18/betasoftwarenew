<script language="JavaScript" type="text/javascript">
//var itemdata = <?php //echo $itemdata;?>;
	$(document).ready(function($) {
		
		
		
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
	});
	
	
	
	function calculate_total(){
		
		
		var salesinvoice_finaldisc = parseFloat(document.getElementById("salesinvoice_finaldisc").value);
		if(salesinvoice_finaldisc=='' || isNaN(salesinvoice_finaldisc)){salesinvoice_finaldisc = 0;}
		
		var salesinvoicecollection_amount = parseFloat(document.getElementById("salesinvoicecollection_amount").value);
		if(salesinvoicecollection_amount=='' || isNaN(salesinvoicecollection_amount)){salesinvoicecollection_amount = 0;}
		
		var salesinvoice_due = parseFloat(document.getElementById("salesinvoice_due").value);
		if(salesinvoice_due=='' || isNaN(salesinvoice_due)){salesinvoice_due = 0;}
		
	
		var salesinvoice_currentdue = parseFloat(salesinvoice_due - salesinvoicecollection_amount  - salesinvoice_finaldisc);
		document.getElementById('salesinvoice_currentdue').value=salesinvoice_currentdue.toFixed(2);
		
	}
	
	
</script>