<?php
date_default_timezone_set('Asia/Dhaka');
require('labdd.php');

// ===== Helper Function =====
function getDateRange() {
    $from = isset($_REQUEST['ADate1']) ? $_REQUEST['ADate1'] : date('Y-m-01', strtotime('-6 months'));
    $to   = isset($_REQUEST['ADate2']) ? $_REQUEST['ADate2'] : date('Y-m-d');
    if ($from > $to) list($from, $to) = array($to, $from);
    return array($from, $to);
}

function getSum($conn, $query) {
    $res = mysqli_query($conn, $query);
    $row = mysqli_fetch_row($res);
    return $row ? (float)$row[0] : 0;
}

// ===== Date Range =====
list($fromdate, $todate) = getDateRange();
$fromdatetime = $fromdate . " 00:00:00";
$todatetime   = $todate . " 23:59:59";

// ===== Collect All Totals =====
$data = array();
$data['lab_cash'] = getSum($conn, "SELECT SUM(labinvoice_receiveamount) FROM labinvoice WHERE dstatus!='Deleted' AND labinvoice_date BETWEEN '$fromdatetime' AND '$todatetime'");
$data['lab_collection'] = getSum($conn, "SELECT SUM(collection_amount) FROM labcollection WHERE status!='Deleted' AND labcollection_date BETWEEN '$fromdatetime' AND '$todatetime'");
$data['appointment'] = getSum($conn, "SELECT SUM(appointmententry_amount) FROM appointmententry WHERE appointmententry_date BETWEEN '$fromdatetime' AND '$todatetime'");
$data['dental_cash'] = getSum($conn, "SELECT SUM(labinvoice_receiveamount) FROM dentalinvoice WHERE labinvoice_date BETWEEN '$fromdatetime' AND '$todatetime'");
$data['dental_collection'] = getSum($conn, "SELECT SUM(collection_amount) FROM dentalcollection WHERE labinvoice_date BETWEEN '$fromdatetime' AND '$todatetime'");
$data['ambulance'] = getSum($conn, "SELECT SUM(received) FROM ambulance WHERE created_date BETWEEN '$fromdatetime' AND '$todatetime'");
$data['admission'] = getSum($conn, "SELECT SUM(labinvoice_receiveamount) FROM dailytransection_lab WHERE section='Admission Fee' AND dailytransection_lab_date BETWEEN '$fromdatetime' AND '$todatetime'");
$data['advanced'] = getSum($conn, "SELECT SUM(advanced) FROM advanced WHERE type!='Admission Fee' AND advanced_date BETWEEN '$fromdatetime' AND '$todatetime'");
$data['hospital_cash'] = getSum($conn, "SELECT SUM(hospitalinvoice_receiveamount) FROM hospitalinvoice WHERE status!='Deleted' AND hospitalinvoice_deliverydate BETWEEN '$fromdatetime' AND '$todatetime'");
$data['hospital_collection'] = getSum($conn, "SELECT SUM(hospitalinvoicecollection_amount) FROM hospitalinvoicecollection WHERE hospitalinvoicecollection_date BETWEEN '$fromdatetime' AND '$todatetime'");
$data['icu_cash'] = getSum($conn, "SELECT SUM(hospitalinvoiceicu_receiveamount) FROM hospitalinvoiceicu WHERE status!='Deleted' AND hospitalinvoiceicu_deliverydate BETWEEN '$fromdatetime' AND '$todatetime'");
$data['icu_collection'] = getSum($conn, "SELECT SUM(hospitalinvoiceicucollection_amount) FROM hospitalinvoiceicucollection WHERE hospitalinvoiceicucollection_date BETWEEN '$fromdatetime' AND '$todatetime'");
$data['inventory_sales'] = getSum($conn, "SELECT SUM(inventorysalesinvoice_receiveamount) FROM inventorysalesinvoice WHERE inventorysalesinvoice_date BETWEEN '$fromdatetime' AND '$todatetime'");
$data['emergency_cash'] = getSum($conn, "SELECT SUM(emergencyinvoice_receiveamount) FROM emergencyinvoice WHERE emergencyinvoice_date BETWEEN '$fromdatetime' AND '$todatetime'");
$data['emergency_collection'] = getSum($conn, "SELECT SUM(collection_amount) FROM emergencycollection WHERE emergencyinvoice_date BETWEEN '$fromdatetime' AND '$todatetime'");
$data['bank_withdrawal'] = getSum($conn, "SELECT SUM(withdrawal_amount) FROM bankinvoice WHERE bankinvoice_date BETWEEN '$fromdatetime' AND '$todatetime'");
$data['loan_received'] = getSum($conn, "SELECT SUM(withdrawal_amount) FROM loaninvoice WHERE loaninvoice_date BETWEEN '$fromdatetime' AND '$todatetime'");

$data['expense'] = getSum($conn, "SELECT SUM(expense_amount) FROM expense WHERE expense_date BETWEEN '$fromdatetime' AND '$todatetime'");
$data['lab_return'] = getSum($conn, "SELECT SUM(labinvoice_receiveamount) FROM labinvoice_return WHERE labinvoice_date BETWEEN '$fromdatetime' AND '$todatetime'");
$data['lab_pc_paid'] = getSum($conn, "SELECT SUM(labpcpaid_amount) FROM labpcpaid WHERE labpcpaid_date BETWEEN '$fromdatetime' AND '$todatetime'");
$data['hospital_pc_paid'] = getSum($conn, "SELECT SUM(hospitalpcpaid_amount) FROM hospitalpcpaid WHERE hospitalpcpaid_date BETWEEN '$fromdatetime' AND '$todatetime'");
$data['purchase_receive'] = getSum($conn, "SELECT SUM(purchaseinvoice_receiveamount) FROM storepurchaseinvoice WHERE purchaseinvoice_date BETWEEN '$fromdatetime' AND '$todatetime'");
$data['purchase_paid'] = getSum($conn, "SELECT SUM(purchaseinvoicepaid_amount) FROM storepurchaseinvoicepaid WHERE purchaseinvoicepaid_date BETWEEN '$fromdatetime' AND '$todatetime'");
$data['salary_paid'] = getSum($conn, "SELECT SUM(salaryentry_paid) FROM salaryentry WHERE salaryentry_date BETWEEN '$fromdatetime' AND '$todatetime'");
$data['loan_deposit'] = getSum($conn, "SELECT SUM(deposite_amount) FROM loaninvoice WHERE loaninvoice_date BETWEEN '$fromdatetime' AND '$todatetime'");
$data['bank_deposit'] = getSum($conn, "SELECT SUM(deposite_amount) FROM bankinvoice WHERE bankinvoice_date BETWEEN '$fromdatetime' AND '$todatetime'");

// ===== Calculations =====
$receipt = $data['lab_cash'] + $data['lab_collection'] + $data['appointment'] + 
            $data['dental_cash'] + $data['dental_collection'] + $data['ambulance'] + 
            $data['admission'] + $data['advanced'] + $data['hospital_cash'] + 
            $data['hospital_collection'] + $data['icu_cash'] + $data['icu_collection'] + 
            $data['inventory_sales'] + $data['emergency_cash'] + $data['emergency_collection'] + 
            $data['bank_withdrawal'] + $data['loan_received'];

$payment = $data['expense'] + $data['lab_return'] + $data['lab_pc_paid'] + 
            $data['hospital_pc_paid'] + $data['purchase_receive'] + $data['purchase_paid'] + 
            $data['salary_paid'] + $data['loan_deposit'] + $data['bank_deposit'];

$cash = $receipt - $payment;

// ===== Output Table =====
echo "<h3 style='text-align:center'>Consolidated Report (" . date('d M Y', strtotime($fromdate)) . " - " . date('d M Y', strtotime($todate)) . ")</h3>";
echo "<table border='1' cellpadding='3' cellspacing='0' style='border-collapse:collapse;width:100%;font-size:12px;'>
<tr style='background:#176EBF;color:#fff'>
<th>Lab Cash</th>
<th>Lab Coll</th>
<th>Dr Visit</th>
<th>Dental Cash</th>
<th>Dental Coll</th>
<th>Ambu lance</th>
<th>Admi ssion</th>
<th>Adv anced</th>
<th>Hosp Cash</th>
<th>Hosp Coll</th>
<th>ICU Cash</th>
<th>ICU Coll</th>
<th>Inv Sales</th>
<th>Emrg Cash</th>
<th>Emrg Coll</th>
<th>Bank W</th>
<th>Loan Rcv</th>

<th bgcolor=\"#7ADFD1\">Expense</th>
<th bgcolor=\"#7ADFD1\">Lab Return</th>
<th bgcolor=\"#7ADFD1\">Lab PC</th>
<th bgcolor=\"#7ADFD1\">Hosp PC</th>
<th bgcolor=\"#7ADFD1\">Inv Purchase</th>
<th bgcolor=\"#7ADFD1\">Purchase Paid</th>
<th bgcolor=\"#7ADFD1\">Salary</th>
<th bgcolor=\"#7ADFD1\">Loan Paid</th>
<th bgcolor=\"#7ADFD1\">Bank Dep</th>
<th>Income</th>
<th>Expense</th>
<th>Balance</th>
</tr>";

echo "<tr>";
foreach ($data as $v) echo "<td>".number_format($v,2)."</td>";
echo "<td style='color:blue;font-weight:bold'>".number_format($receipt,2)."</td>";
//echo "<td colspan='6'></td>"; // spacing for unused columns
echo "<td style='color:red;font-weight:bold'>".number_format($payment,2)."</td>";
echo "<td style='color:green;font-weight:bold'>".number_format($cash,2)."</td>";
echo "</tr>";
echo "</table>";
?>
