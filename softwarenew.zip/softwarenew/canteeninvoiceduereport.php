<?php
date_default_timezone_set('Asia/Dhaka');
$searchstr='';
if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
{
	$transactiondatefrom = $_REQUEST['ADate1'];
	$transactiondateto = $_REQUEST['ADate2'];
	
	$user = $_REQUEST['user'];
	$labinvoice_patient = $_REQUEST['labinvoice_patient'];
	$canteeninvoice_id = $_REQUEST['canteeninvoice_id'];
	$labinvoice_patientid = $_REQUEST['labinvoice_patientid'];
	$labinvoice_duesholder = $_REQUEST['labinvoice_duesholder'];
	$labinvoice_pc = $_REQUEST['labinvoice_pc'];
	if($labinvoice_patientid !=''){
		$searchstr .= " and labinvoice_patientid like '%$labinvoice_patientid%'";
	}
	elseif($labinvoice_patient !=''){
		$searchstr .= " and labinvoice_patient like '%$labinvoice_patient%'";
	}
	elseif($canteeninvoice_id !=''){
		$searchstr .= " and canteeninvoice_id like '%$canteeninvoice_id%'";
	}
	elseif($user !=''){
		$searchstr .= " and user like '%$user%'";
	}
	elseif($labinvoice_duesholder !=''){
		$searchstr .= " and labinvoice_duesholder like '%$labinvoice_duesholder%'";
	}
	elseif($labinvoice_pc !=''){
		$searchstr .= " and labinvoice_pc like '%$labinvoice_pc%'";
	}
}
else
{
	$transactiondatefrom = date('Y-m-d', strtotime('-7 day'));
	$transactiondateto = date('Y-m-d');
}
?>

<table width="100%" border="0" cellspacing="0" cellpadding="2">

  <tr>
    <td valign="top" align="center">
    	<form name="cbform1" method="post" action="index.php?p=canteeninvoiceduereport">
            <table width="100%" border="1" align="center" cellpadding="0" bgcolor="#FFFFFF" cellspacing="0" bordercolor="#666666" id="AutoNumber3" style="border-collapse: collapse">
              <tbody>
                <tr bgcolor="#011E6A">
                  <td colspan="100%" bgcolor="#CCCCCC" align="center"><strong>Search Date wise</strong></td>
                </tr>           
                <tr>
                    <td>From:<input size="7" name="ADate1" id="ADate1" style="border: 1px solid #001E6A" value="<?php echo $transactiondatefrom; ?>"  readonly="readonly" onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
                    </td>
                    <td>To:
                        <input size="7" name="ADate2" id="ADate2" style="border: 1px solid #001E6A" value="<?php echo $transactiondateto; ?>" readonly onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate2')" style="cursor:pointer"/>
                    </td>
                    <td>ID<input style="width:50px" type="text" name="labinvoice_patientid" id="labinvoice_patientid" /></td>
            		<td>INV<input style="width:50px" type="text" name="canteeninvoice_id" id="canteeninvoice_id"/></td>
            		
                    <td>Name<input type="text"  style="width:80px" name="labinvoice_patient" id="labinvoice_patient" /></td>
            		<td>PC<input type="text"  style="width:80px" name="labinvoice_pc" id="labinvoice_pc" /></td>
            		<td>Dues Holder<input type="text" size="8" name="labinvoice_duesholder" id="labinvoice_duesholder" /></td>
                    <td>User<input style="width:70px" type="text" placeholder="user" name="user" id="user" /></td>
                    <td><input  style="border: 1px solid #001E6A" type="submit" value="Search" name="Submit" /></td>
                    <td><input name="print" type="button" id="print" style="border: 1px solid #001E6A" value="Print" onClick="PrintDiv();" /></td>
                </tr>
              </tbody>
            </table>
		</form>
   	</td>
</tr>

	<tr>
    <td>
		<?php 
		$datetime1 = new DateTime($transactiondatefrom);
		$datetime2 = new DateTime($transactiondateto);
		$interval = $datetime1->diff($datetime2);
		$totaldays = $interval->format('%a');
		if($datetime1<$datetime2){
			$fromdate = $transactiondatefrom;
			$todate = $transactiondateto;
		}
		else{
			$fromdate = $transactiondateto;
			$todate = $transactiondatefrom;
		}
		?>
        <table align="center" style="border-collapse:collapse" bgcolor="#FFFFFF" width="100%" border="1" cellspacing="1" cellpadding="2">
          <tr>
            <td colspan="13" bgcolor="#ccc" align="center" style="color:#03F; border:1px solid #03F;">
            	<strong><?php echo $hospitaldata_name;?></strong><br>
                <strong>Statement By Dues :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></strong>
            </td>
          </tr>
           
           <tr align="left" bgcolor="#003399" style="color:#FFF">
           <td>SL No.</td>
           <td>INV No.</td>
           <td>Date</td>
           <td>Name</td>
           <td>Mobile</td>
           <td>MPO</td>
           <td>PC</td>
           <td>PC Comission</td>
           <td>Invoice Amount</td>
           <td><strong>Dues Tk</strong></td>
           <td>Dues Holder</td>
           <td>User Name</td>
           <td>Collection </td>
          </tr>
  
  <?php
 $s='';
 $total_labinvoice_due ='0';
  for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
	$sqlst = "select * from canteeninvoice where labinvoice_due > 0 and labinvoice_patientid=0 and 
	labinvoice_date between '$newfromdate' and '$newtodate' $searchstr order by canteeninvoice_id asc";
	  	$stquery = mysqli_query($conn, $sqlst);
			if($stquery && mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery))
			 	{
                    $canteeninvoice_id = $strow['canteeninvoice_id'];
                    $labinvoice_patientid = $strow['labinvoice_patientid'];
					$user = $strow['user'];
                    $labinvoice_patient = $strow['labinvoice_patient'];
                    $labinvoice_mobile = $strow['labinvoice_mobile'];
                    $labinvoice_mpo = $strow['labinvoice_mpo'];
                    $labinvoice_pc = $strow['labinvoice_pc'];
                   	$labinvoice_totalpccomission = $strow['labinvoice_totalpccomission'];
					$labinvoice_subtotal = $strow['labinvoice_subtotal'];
					$labinvoice_totaldiscp = $strow['labinvoice_totaldiscp'];
					$labinvoice_totaldisc = $strow['labinvoice_totaldisc'];
					$labinvoice_subtotalafterdisc = $strow['labinvoice_subtotalafterdisc'];
					$labinvoice_receiveamount = $strow['labinvoice_receiveamount'];
					$labinvoice_due = $strow['labinvoice_due'];
					$labinvoice_duesholder = $strow['labinvoice_duesholder'];
					$labinvoice_date=	$strow['labinvoice_date'];
					$action = "<a href=\"index.php?p=canteencollectioninvoice&canteeninvoice_id=$canteeninvoice_id\" target=\"_blank\">Collection</a>";			
					$total_labinvoice_due = $total_labinvoice_due + $labinvoice_due;
				?>
                <tr>
                    <td><?php echo $s=$s+1;?></td>
                    <td><?php echo $canteeninvoice_id;?></td>
                    <td><?php echo date('d.m.y',strtotime($newfromdate));?></td>
                    <td><?php echo $labinvoice_patient;?></td>
                    <td><?php echo $labinvoice_mobile;?></td>
                    <td><?php echo $labinvoice_mpo;?></td>
                   	<td><?php echo $labinvoice_pc;?></td>
                    <td><?php echo $labinvoice_totalpccomission;?></td>
                    <td><?php echo $labinvoice_subtotalafterdisc;?></td>
                    <td><strong><?php echo $labinvoice_due;?></strong></td>
                    <td><?php echo $labinvoice_duesholder;?></td>
                    <td><?php echo $user;?></td>
                    <td><?php echo $action;?></td>
                  </tr>
                <?php
				}
			}
	  	}
	  ?>
      <tr bgcolor="#CCCCCC">
      <td colspan="9"></td>
      	<td align="left">Dues:<strong><?php echo $total_labinvoice_due;?></strong> Tk</td>
      	<td colspan="4" align="center">
      </tr>
     </table>

    </td>
    
    <td align="center" id="divToPrint" style="display:none">
	
     	<?php 
		$datetime1 = new DateTime($transactiondatefrom);
		$datetime2 = new DateTime($transactiondateto);
		$interval = $datetime1->diff($datetime2);
		$totaldays = $interval->format('%a');
		if($datetime1<$datetime2){
			$fromdate = $transactiondatefrom;
			$todate = $transactiondateto;
		}
		else{
			$fromdate = $transactiondateto;
			$todate = $transactiondatefrom;
		}
		?>
        <table align="center" style="border-collapse:collapse" bgcolor="#FFFFFF" width="100%" border="1" cellspacing="1" cellpadding="2">
          <tr>
            <td colspan="13" bgcolor="#ccc" align="center" style="color:#03F; border:1px solid #03F;">
            	<strong><?php echo $hospitaldata_name;?></strong><br>
                <strong>Statement By Out Door Lab Dues :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></strong>
            </td>
          </tr>
           
           <tr align="left" bgcolor="#003399" style="color:#FFF">
           <td>SL No.</td>
           <td>INV No.</td>
           <td>Date</td>
           <td>Name</td>
           <td>Mobile</td>
           <td>MPO</td>
           <td>PC</td>
           <td>PC Comission</td>
           <td>Invoice Amount</td>
           <td><strong>Dues Tk</strong></td>
           <td>Dues Holder</td>
           <td>User Name</td>
          
          </tr>
  
  <?php
 $s='';
 $total_labinvoice_due ='0';
  for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
	$sqlst = "select * from canteeninvoice where labinvoice_due > 0 and labinvoice_patientid=0 and labinvoice_date between '$newfromdate' and '$newtodate' $searchstr order by labinvoice_date asc";
	  	$stquery = mysqli_query($conn, $sqlst);
			if($stquery && mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery))
			 	{
                    $canteeninvoice_id = $strow['canteeninvoice_id'];
                    $labinvoice_patientid = $strow['labinvoice_patientid'];
					$user = $strow['user'];
                    $labinvoice_patient = $strow['labinvoice_patient'];
                    $labinvoice_mobile = $strow['labinvoice_mobile'];
                    $labinvoice_mpo = $strow['labinvoice_mpo'];
                    $labinvoice_pc = $strow['labinvoice_pc'];
                   	$labinvoice_totalpccomission = $strow['labinvoice_totalpccomission'];
					$labinvoice_subtotal = $strow['labinvoice_subtotal'];
					$labinvoice_totaldiscp = $strow['labinvoice_totaldiscp'];
					$labinvoice_totaldisc = $strow['labinvoice_totaldisc'];
					$labinvoice_subtotalafterdisc = $strow['labinvoice_subtotalafterdisc'];
					$labinvoice_receiveamount = $strow['labinvoice_receiveamount'];
					$labinvoice_due = $strow['labinvoice_due'];
					$labinvoice_duesholder = $strow['labinvoice_duesholder'];
					$labinvoice_date=	$strow['labinvoice_date'];
					$action = "<a href=\"index.php?p=labcollection_outdoor&canteeninvoice_id=$canteeninvoice_id\">Collection</a>";			
					$total_labinvoice_due = $total_labinvoice_due + $labinvoice_due;
				?>
                <tr>
                    <td><?php echo $s=$s+1;?></td>
                    <td><?php echo $canteeninvoice_id;?></td>
                    <td><?php echo date('d.m.y',strtotime($newfromdate));?></td>
                    <td><?php echo $labinvoice_patient;?></td>
                    <td><?php echo $labinvoice_mobile;?></td>
                    <td><?php echo $labinvoice_mpo;?></td>
                   	<td><?php echo $labinvoice_pc;?></td>
                    <td><?php echo $labinvoice_totalpccomission;?></td>
                    <td><?php echo $labinvoice_subtotalafterdisc;?></td>
                    <td><strong><?php echo $labinvoice_due;?></strong></td>
                    <td><?php echo $labinvoice_duesholder;?></td>
                    <td><?php echo $user;?></td>
                 
                  </tr>
                <?php
				}
			}
	  	}
	  ?>
      <tr bgcolor="#CCCCCC">
      <td colspan="9"></td>
      	<td align="left">Dues:<strong><?php echo $total_labinvoice_due;?></strong> Tk</td>
      	<td colspan="3" align="center">
      </tr>
     </table>

    </td>
</tr>
</table>