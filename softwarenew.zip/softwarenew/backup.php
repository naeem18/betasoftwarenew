<?php
// ----------------- CONFIGURATION -----------------
include('labdd.php');
$backupFolder = "G:/db_backup"; // <-- Save folder
$daysToKeep = 40;               // <-- কত দিনের বেশি ফাইল রাখবেন

if (!is_dir($backupFolder)) mkdir($backupFolder, 0777, true);

// ----------------- DATABASE CONNECTION -----------------
//$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) die("DB connection failed\n");

// ----------------- CREATE BACKUP -----------------
$filename = $backupFolder . "/db_backup_" . date('Y-m-d_H-i') . ".sql";
$output = fopen($filename, 'w');

// Get all tables
$tables = [];
$res = mysqli_query($conn, "SHOW TABLES");
while ($row = mysqli_fetch_row($res)) $tables[] = $row[0];

foreach ($tables as $table) {
    $res2 = mysqli_query($conn, "SELECT * FROM `$table`");
    $row2 = mysqli_fetch_row(mysqli_query($conn, "SHOW CREATE TABLE `$table`"));
    fwrite($output, $row2[1] . ";\n\n");

    while ($row = mysqli_fetch_row($res2)) {
        $vals = array_map(function($val) use ($conn){
            return isset($val) ? "'" . mysqli_real_escape_string($conn, $val) . "'" : "NULL";
        }, $row);
        fwrite($output, "INSERT INTO `$table` VALUES(" . implode(",", $vals) . ");\n");
    }
    fwrite($output, "\n\n");
}

fclose($output);
echo "Backup saved: $filename\n";

// ----------------- DELETE OLD FILES -----------------
$files = glob($backupFolder . "/db_backup_*.sql");
$now = time();
foreach ($files as $file) {
    if (is_file($file) && ($now - filemtime($file)) > ($daysToKeep * 86400)) {
        unlink($file);
        echo "Deleted old backup: $file\n";
    }
}
?>
