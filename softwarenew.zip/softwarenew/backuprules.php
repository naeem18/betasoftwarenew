backup.php e time/ day set kora ($daysToKeep = 40;) 40 days backup thakbe.
auto_backup.bat file ta software er vitor "autocomplete" file e rekhe shell:startup diye auto run kora. er vitor edit kore backup time set kora.
auto_backup.bat er modhe backup.php file ta dekhate hobe