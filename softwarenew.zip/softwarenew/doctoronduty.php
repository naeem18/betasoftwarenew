<h3 align="center">On Duty Doctor List</h3>		
	<div style="width:1250px;">
		   <?php
			$sqlst = "select * from doctorentry where doctor_category= 'doctor' and status='active' order by doctor_id asc";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery){
 			$i = 1;
			  while ($strow = mysqli_fetch_array($stquery)) {
					$doctor_id = $strow['doctor_id'];
                    $doctor_name = $strow['doctor_name'];
                    $doctor_mobile = $strow['doctor_mobile'];
                    $dutytime = $strow['dutytime'];
                    $dayall = $strow['dayall'];
                    $doctortype = $strow['doctortype'];
                    $photo = $strow['photo'];
                    $doctor_address = $strow['doctor_address'];
                    $doctor_date = $strow['doctor_date'];
					?>
                   <div style="width:250px; float:left; height:300px; border:1px solid #000;">
                       <div align="center"><img src="patient_images/<?php echo $photo; ?>" height="120" width="140"/></div>
                       <div><?php echo $doctor_name; ?></div>
                       <div><?php echo $doctortype; ?></div>
                       <div><?php echo $dayall; ?></div>
                       <div><?php echo $dutytime; ?></div>
                       <div><?php echo $doctor_date; ?></div>
                   </div> 
                  <?php
				  $i++;
				}
			}
		?>
 	</div>