	<?php
		date_default_timezone_set('Asia/Dhaka');
		if (isset($_REQUEST["searchflag2"])) { $searchflag2 = $_REQUEST["searchflag2"]; } else { $searchflag2 = ""; }
		if (isset($_REQUEST["search2"])) { $search2 = $_REQUEST["search2"]; } else { $search2 = ""; }
	?>
	 
	<script language="JavaScript" type="text/javascript">
        function additem1process2()
        {
            //alert ("Inside Funtion");
            if (document.form2.labitem_category.value == "")
            {	
                alert ("Please Select Category Name.");
                document.form2.labitem_category.focus();
                return false;
            }
            
            if (document.form2.labitem_name.value == "")
            {
                alert ("Pleae Enter Lab Item Name.");
                document.form2.labitem_category.focus();
                return false;
            }
            
        }	
    </script>
    <body>
        <article class="bottomcontent" style="width:1310px">
            <h4 align="center"> Add New Dental Item</h4>
			<content>
			<?php
			if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
			echo "<h2 class=\"red12bold\">You have missing Something</h2>";
			}
			elseif(isset($_GET['message']) && $_GET['message']=='duplicatename'){
			echo "<h2 class=\"red12bold\">This Item  already exists. Please try with different item .</h2>";   
			}
			elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
			echo "<h2 class=\"red12bold\">Error occured! Could not insert.</h2>";   
			}
			elseif(isset($_GET['message']) && $_GET['message']=='insert-successfully'){
			echo "<h2 class=\"red12bold\">Item insert successfully</h2>";   
			}
					
			$labitem_id = 0;
			$labitem_group = '';
			$labitem_category = '';
			$labitem_sub_category ='';
			$labitem_sample ='';
			$labitem_name = '';
			$machine_name = '';
			$labitem_unit = '';
			$labitem_price = '';
			$labitem_pccommission = '';
			$labitem_refvalue = '';
			$labitem_tax = '';
			$reportname='';
			
			$category='';
			$note='';
			$orderby='';
			$labitem_result='';
        
        if(isset($_GET['labitem_id'])){
            $labitem_id = $_GET['labitem_id'];
            $sqllabitem = "select * from labitem where labitem_id = $labitem_id";
            $labitemquery = mysqli_query($conn, $sqllabitem);
            if($labitemquery){
                while($labitemrow = mysqli_fetch_array($labitemquery)){
                    $labitem_id = $labitemrow['labitem_id'];
                    $labitem_group = $labitemrow['labitem_group'];
                    $labitem_category = $labitemrow['labitem_category'];
                    $reportname = $labitemrow['reportname'];
                    $labitem_sample = $labitemrow['labitem_sample'];
                    $labitem_sub_category = $labitemrow['labitem_sub_category'];
                    $machine_name = $labitemrow['machine_name'];
                    $category = $labitemrow['category'];
                    $note = $labitemrow['note'];
                    $labitem_name = $labitemrow['labitem_name'];
                    $labitem_unit = $labitemrow['labitem_unit'];
                    $labitem_price = $labitemrow['labitem_price'];
                    $labitem_pccommission = $labitemrow['labitem_pccommission'];
                    $labitem_drcommission = $labitemrow['labitem_drcommission'];
                    $labitem_refvalue = $labitemrow['labitem_refvalue'];
					$labitem_reagent = $labitemrow['labitem_reagent'];
                    $labitem_tax = $labitemrow['labitem_tax'];
					 $labitem_result = $labitemrow['labitem_result']; 
					 $orderby = $labitemrow['orderby'];
                }
            }
        }
        ?>        
                            
		<form action="save_labitem.php" name="frmcontact" onsubmit="return checkcontactform();" method="post" enctype="multipart/form-data">
       
            <table width="50%" align="center" bgcolor="f2f2f2" cellpadding="2" border="1">
               <tr>
                    <td width="220"><label>Select Section *</label></td>
                     <td>
                        <select required id="labitem_group" name="labitem_group" >
                            <option value="Dental">Dental</option>
                         </select>
                    </td>
                </tr>
                 
                <tr>
                    <td width="220"><label>Select Group </label></td>
                     <td>
                        <select id="labitem_category" name="labitem_category" >
                            <option value="<?php echo $labitem_category; ?>"><?php echo $labitem_category; ?> </option>
                             <?php
                          
                            $query5 = "select * from category where section='Lab Item Group' order by category";
                            $exec5 = mysqli_query($conn, $query5) or die ("Error in Query5".mysql_error());
                            while ($res5 = mysqli_fetch_array($exec5))
                            {
                                $res5doctorname = trim($res5["category"]);
                                $res5doctorcode = $res5["auto_number"];
                                if($res5doctorname !=''){						
                                    ?>
                                    <option value="<?php echo $res5doctorname; ?>"><?php echo $res5doctorname; ?></option>
                                    <?php
                                }
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                
                <tr>
                    <td width="220"><label>Report Name </label></td>
                     <td>
                        <select id="reportname" name="reportname" >
                            <option value="<?php echo $reportname; ?>"><?php echo $reportname; ?></option>
                             <?php
                          
                            $query5 = "select * from category where section='Labitem Test Group' order by category";
                            $exec5 = mysqli_query($conn, $query5) or die ("Error in Query5".mysql_error());
                            while ($res5 = mysqli_fetch_array($exec5))
                            {
                                $res5doctorname = trim($res5["category"]);
                                $res5doctorcode = $res5["auto_number"];
                                if($res5doctorname !=''){						
                                    ?>
                                    <option value="<?php echo $res5doctorname; ?>"><?php echo $res5doctorname; ?></option>
                                    <?php
                                }
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                
                 <tr>
                    <td width="200"><label>Sub Group</label></td>
                     <td>
                        <select  id="labitem_sub_category" name="labitem_sub_category" >
                           <option value="<?php echo $labitem_sub_category; ?>"><?php echo $labitem_sub_category; ?></option>
                            <?php
                            $doyouknowarray = array('PHYSICAL EXAMINATION', 'CHEMICAL EXAMINATION', 'MICROSCOPIC EXAMINATION', 'OVA OF',
							 'ON REQUEST', 'CRYSTALS', 'HBsAg', 'PROTHROMBIN TIME', 'Laboratory Report', 'Serum Electrolytes',
							  'Cross Matching Report', 'LFT', 'Lipid Profile', 'Immunology Report', 'Serology Report', 'CBC',
							   'Semen Analysis Report', 'USG', 'OTHERS');
                            	foreach($doyouknowarray as $singleoption){
                                $selected = '';
                                if($labitem_sub_category=="$singleoption"){$selected = ' selected="selected"';}
                                echo "<option value=\"$singleoption\"$selected>$singleoption</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                
                <tr>
                    <td width="200"><label>Sample for Test</label></td>
                     <td>
                        <select id="labitem_sample" name="labitem_sample" >
                            <option value="<?php echo $labitem_sample; ?>"><?php echo $labitem_sample; ?></option>
                            <?php
                            $doyouknowarray = array('BLOOD', 'URINE', 'SERUM', 'SPUTUM', 'STOOL');
                            foreach($doyouknowarray as $singleoption){
                                $selected = '';
                                if($labitem_sub_category=="$singleoption"){$selected = ' selected="selected"';}
                                echo "<option value=\"$singleoption\"$selected>$singleoption</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
               
                 <tr>
                    <td width="220"><label><strong>Machine Name</strong> </label></td>
                    <td width="310">
                        <textarea type="text" name="machine_name" id="machine_name" class="textfieldcssmem" ><?php echo $machine_name;?></textarea>
                    </td>
                </tr>
                
                <tr>
                    <td width="220"><label><strong>Item Name</strong> *</label></td>
                    <td width="310">
                        <input type="text" required name="labitem_name" id="labitem_name" value="<?php echo $labitem_name;?>" class="textfieldcssmem"  />
                    </td>
                </tr>
                 
                  <tr>
                    <td width="220"><label>Item Unit (Optional) </label></td>
                    <td width="310">
                        <input type="text" placeholder="ms, mg" name="labitem_unit" id="labitem_unit" value="<?php echo $labitem_unit;?>" class="textfieldcssmem"  />
                    </td>
                   
                </tr>
                
                 <tr>
                    <td width="120"><label><strong>Item Charge/Rate</strong> *</label></td>
                    <td width="310">
                        <input type="text" name="labitem_price" id="labitem_price" value="<?php echo $labitem_price;?>" class="textfieldcssmem"  />
                    </td>
                   
                </tr>
               <?php if($labitem_id!=''){?>
                 <tr>
                    <td width="120"><label>P.C Comission </label></td>
                    <td width="310">
                        <input type="text" value="<?php echo $labitem_pccommission*100/$labitem_price;?>" name="labitem_pccommission" id="labitem_pccommission" class="textfieldcssmem"  />
                    %</td>
                </tr>
                <?php } ?>
                
                <?php if($labitem_id==0){?>
                 <tr>
                    <td width="120"><label>P.C Comission </label></td>
                    <td width="310">
                        <input type="text" name="labitem_pccommission" id="labitem_pccommission" class="textfieldcssmem"  />
                    %</td>
                </tr>
                <?php } ?>
                
                <tr>
                    <td width="120"><label>Dr Comission </label></td>
                    <td width="310">
                        <input type="text" name="labitem_drcommission" id="labitem_drcommission" value="<?php echo $labitem_drcommission;?>" class="textfieldcssmem"  />
                    </td>
                </tr>
                
                 <tr>
                    <td width="120"><label>Reference Value (Optional)</label></td>
                    <td width="310">
                        <textarea type="text" name="labitem_refvalue" id="labitem_refvalue" class="textfieldcssmem" ><?php echo $labitem_refvalue;?></textarea>
                    </td>
                </tr>
                
                <tr>
                    <td width="120"><label>Result Value (Optional)</label></td>
                    <td width="310">
                        <textarea type="text" name="labitem_result" id="labitem_result" class="textfieldcssmem" ><?php echo $labitem_result;?></textarea>
                    </td>
                </tr>
                
                <tr>
                    <td width="120"><label>Order(For report)</label></td>
                    <td width="310">
                        <input type="text" name="orderby" id="orderby" value="<?php echo $orderby;?>" class="textfieldcssmem"  />
                   </td>
                </tr>
                
                 <tr>
                    <td><label>Category(For Test Report)</label></td>
                    <td><textarea type="text" name="category" id="category" class="textfieldcssmem" ><?php echo $category;?></textarea></td>
                </tr>
                 <tr>
                    <td><label>Note(For Test Report)</label></td>
                    <td><textarea type="text" name="note" id="note" class="textfieldcssmem" ><?php echo $note;?></textarea></td>
                </tr>
                
                <tr>
                    <td><label>Select Tax </label></td>
                     <td>
                        <select id="labitem_tax" title="class" name="labitem_tax" >
                            <option value="">0.00</option>
                            <?php
                            $doyouknowarray = array('5', '10', '15');
                            foreach($doyouknowarray as $singleoption){
                                $selected = '';
                                if($labitem_tax=="$singleoption"){$selected = ' selected="selected"';}
                                echo "<option value=\"$singleoption\"$selected>$singleoption</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td width="120"><label><strong>Reagent Stock</strong></label></td>
                    <td width="310">
                    <input type="text" name="labitem_reagent" id="labitem_reagent" value="<?php //echo $labitem_reagen;?>" class="textfieldcssmem"  />
                    </td>
                </tr>
                 
                <tr>
                    <td>&nbsp;</td>
                    <td>
                        <input type="hidden" name="labitem_id" id="labitem_id" value="<?php echo $labitem_id;?>">
                        <input type="submit" value=" Save " name="submit_labitem" id="submit_labitem" class="submitbuttoncss" />
                    </td>
                </tr>
          </table>
      </form>

 <form name="form2" id="form2" method="post" action="index.php?p=dentalitem" onSubmit="return additem1process2()">  
	<table align="center" width="100%" border="1" style="BORDER-COLLAPSE: collapse" cellspacing="1" cellpadding="2">
    <tr>
        <td colspan="100%" align="center" bgcolor="#011E6A" style="color:#FFF; padding-left:15px;">
            <strong>Dental Item List</strong>
        </td>
      </tr> 	
              
       <tr bgcolor="#011E6A">
        <td colspan="100%" bgcolor="#FFFFFF" class="bodytext3">
        <input name="search2" type="text" id="search2" size="40" value="<?php echo $search2; ?>">
        <input type="hidden" name="searchflag2" id="searchflag2" value="searchflag2">
        <input type="submit" name="Submit2" value="Search" style="border: 1px solid #001E6A" /></td>
       </tr>
       
      <tr bgcolor="#0033FF" style="color: honeydew">
        <td>SL No.</td>
        <td>SECTION</td>
        <td>Category Name</td>
        <td>Sub Category</td>
        <td>Order</td>
        <td>Report Name</td>
        <td>Test Name</td>
        <!--<td>Stock</td>-->
        <td>Unit</td>
        <td>Ref Value</td>
        <td>Result Value</td>
        <td>Sample</td>
        <td>Machine Name</td>
       <td>Charge</td>
        <td>P.C Com</td>
        <td>Dr.Com</td>
        <td>Category(Report)</td>
        <td><strong>Note</strong></td>
        <td>Edit/Delete</td>
      </tr>
	  <?php
       $i='';
    if ($searchflag2 == 'searchflag2')
	  {

	$search2 = $_REQUEST["search2"];
   	$sqllabitem = "select * from labitem where labitem_group='Dental' order by labitem_name asc";
	
			$labitemquery = mysqli_query($conn, $sqllabitem);
				while ($labitemrow = mysqli_fetch_array($labitemquery))
			 	{
               		
				$labitem_id = $labitemrow['labitem_id'];
				$labitem_group = $labitemrow['labitem_group'];
                $labitem_category = $labitemrow['labitem_category'];
				$labitem_sub_category = $labitemrow['labitem_sub_category'];
				$reportname = $labitemrow['reportname'];
				$labitem_sample = $labitemrow['labitem_sample'];
				$machine_name = $labitemrow['machine_name'];
                $labitem_name = $labitemrow['labitem_name'];
				$labitem_unit = $labitemrow['labitem_unit'];
				$category = $labitemrow['category'];
				$note = $labitemrow['note'];
				$labitem_price = $labitemrow['labitem_price'];
				$labitem_pccommission = $labitemrow['labitem_pccommission'];
				$labitem_drcommission = $labitemrow['labitem_drcommission'];
				$labitem_refvalue = $labitemrow['labitem_refvalue'];
				$labitem_tax = $labitemrow['labitem_tax'];
				$labitem_result = $labitemrow['labitem_result'];
				$orderby = $labitemrow['orderby'];
				$labitem_reagent = $labitemrow['labitem_reagent'];
				$action = "<a href=\"index.php?p=labitem&labitem_id=$labitem_id\">Edit</a> | 
				<a href=\"javascript:void(0)\" onclick=\"removetablerow('labitem', $labitem_id, 'labitem')\">Remove</a>";
			
			?>
                <tr>
                    <td><?php echo $i=$i+1;?></td>
                    <td><?php echo $labitem_group;?></td>
                    <td><?php echo $labitem_category;?></td>
                    <td><?php echo $labitem_sub_category;?></td>
                    <td><?php echo $orderby;?></td>
                    <td><?php echo $reportname;?></td>
                    <td bgcolor="#EEF889"><?php echo $labitem_name;?></td>
                  	<?php /*?><td><?php echo $labitem_reagent;?></td><?php */?>
                    <td><?php echo $labitem_unit;?></td>
                    <td><?php echo $labitem_refvalue;?></td>
                    <td><?php echo $labitem_result;?></td>
                     <td><?php echo $labitem_sample;?></td>
                    <td><?php echo $machine_name;?></td>
                   <td><?php echo $labitem_price;?></td>
                    <td><?php echo $labitem_pccommission;?></td>
                    <td><?php echo $labitem_drcommission;?></td>
                    <td><?php echo $category;?></td>
                    <td><?php echo $note;?></td>
                   <td><?php if($_SESSION['employeename']=='SUPERADMINISTRATOR'){ echo $action; }?></td>
              </tr>
                <?php
			 		}
                }
			
			else
			{
       
  		$sqllabitem = "select * from labitem where labitem_group='Dental' order by labitem_name asc";
			$labitemquery = mysqli_query($conn, $sqllabitem);
				while ($labitemrow = mysqli_fetch_array($labitemquery))
			 		{
					$labitem_id = $labitemrow['labitem_id'];
					$labitem_group = $labitemrow['labitem_group'];
					$labitem_category = $labitemrow['labitem_category'];
					$labitem_sub_category = $labitemrow['labitem_sub_category'];
					$reportname = $labitemrow['reportname'];
					$labitem_sample = $labitemrow['labitem_sample'];
					$category = $labitemrow['category'];
					$note = $labitemrow['note'];
					$machine_name = $labitemrow['machine_name'];
                    $labitem_name = $labitemrow['labitem_name'];
					$labitem_unit = $labitemrow['labitem_unit'];
					$labitem_price = $labitemrow['labitem_price'];
					$labitem_pccommission = $labitemrow['labitem_pccommission'];
					$labitem_drcommission = $labitemrow['labitem_drcommission'];
					$labitem_refvalue = $labitemrow['labitem_refvalue'];
					$labitem_tax = $labitemrow['labitem_tax'];
					$labitem_result = $labitemrow['labitem_result'];
				$orderby = $labitemrow['orderby'];
				$labitem_reagent = $labitemrow['labitem_reagent'];
				$action = "<a href=\"index.php?p=labitem&labitem_id=$labitem_id\">Edit</a> | 
				<a href=\"javascript:void(0)\" onclick=\"removetablerow('labitem', $labitem_id, 'labitem')\">Remove</a>";
			
			?>
                <tr>
                     <td><?php echo $i=$i+1;?></td>
                    <td><?php echo $labitem_group;?></td>
                    <td><?php echo $labitem_category;?></td>
                    <td><?php echo $labitem_sub_category;?></td>
                    <td><?php echo $orderby;?></td>
                    <td><?php echo $reportname;?></td>
                    <td bgcolor="#EEF889"><?php echo $labitem_name;?></td>
                  	<?php /*?><td><?php echo $labitem_reagent;?></td><?php */?>
                    <td><?php echo $labitem_unit;?></td>
                    <td><?php echo $labitem_refvalue;?></td>
                    <td><?php echo $labitem_result;?></td>
                     <td><?php echo $labitem_sample;?></td>
                    <td><?php echo $machine_name;?></td>
                    <td><?php echo $labitem_price;?></td>
                    <td><?php echo $labitem_pccommission;?></td>
                    <td><?php echo $labitem_drcommission;?></td>
                    <td><?php echo $category;?></td>
                    <td><?php echo $note;?></td>
                   <td><?php if($_SESSION['employeename']=='SUPERADMINISTRATOR'){ echo $action; }?></td>
              </tr>
                <?php
			 		}
                }
           ?>
</table>
</form>
	
 </content>
</article>
</body>