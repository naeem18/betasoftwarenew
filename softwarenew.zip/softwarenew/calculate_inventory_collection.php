<script language="JavaScript" type="text/javascript">
var itemdata = <?php echo $itemdata;?>;
	$(document).ready(function($) {
		
		$( ".itemname" ).autocomplete({
			
			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				var inventorysalesinvoice_ratearray = document.getElementsByName("inventorysalesinvoice_rate[]");
				inventorysalesinvoice_ratearray[indexpos].value = ui.item.salesitem_price;
				
				var inventorysalesinvoice_qtyarray = document.getElementsByName("inventorysalesinvoice_qty[]");
				inventorysalesinvoice_qtyarray[indexpos].value = 1;
				
				var inventorysalesinvoice_pccomissionarray = document.getElementsByName("inventorysalesinvoice_pccomission[]");
				inventorysalesinvoice_pccomissionarray[indexpos].value = ui.item.salesitem_pccommission;
				
				var inventorysalesinvoice_categoryarray = document.getElementsByName("inventorysalesinvoice_category[]");
				inventorysalesinvoice_categoryarray[indexpos].value = ui.item.salesitem_category;
				
				calculaterowtotal(indexpos);
				calculate_pctotal();
				
				return false;
			}
		});
		
		
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
	});
	
	function calculate_discountp(){
		
		var inventorysalesinvoice_discountparray = document.getElementsByName("inventorysalesinvoice_discountp[]");
		var inventorysalesinvoice_discarray = document.getElementsByName("inventorysalesinvoice_disc[]");
		var inventorysalesinvoice_ratearray = document.getElementsByName("inventorysalesinvoice_rate[]");
		var inventorysalesinvoice_qtyarray = document.getElementsByName("inventorysalesinvoice_qty[]");
		
		if(inventorysalesinvoice_discountparray.length>0){
			for(var p=0; p<inventorysalesinvoice_discountparray.length; p++){
				var inventorysalesinvoice_discountp = parseFloat(inventorysalesinvoice_discountparray[p].value);
				if(inventorysalesinvoice_discountp=='' || isNaN(inventorysalesinvoice_discountp)){inventorysalesinvoice_discountp = 0;}
				
				var inventorysalesinvoice_disc = parseFloat(inventorysalesinvoice_discarray[p].value);
				if(inventorysalesinvoice_disc=='' || isNaN(inventorysalesinvoice_disc)){inventorysalesinvoice_disc = 0;}
				if(inventorysalesinvoice_discountp>0){
					var inventorysalesinvoice_rate = parseFloat(inventorysalesinvoice_ratearray[p].value);
					if(inventorysalesinvoice_rate=='' || isNaN(inventorysalesinvoice_rate)){inventorysalesinvoice_rate = 0;}
					
					var inventorysalesinvoice_qty = inventorysalesinvoice_qtyarray[p].value;
					if(inventorysalesinvoice_qty=='' || isNaN(inventorysalesinvoice_qty)){inventorysalesinvoice_qty = 0;}
					
					var total = parseFloat(inventorysalesinvoice_rate*inventorysalesinvoice_qty);			
					var inventorysalesinvoice_disc = parseFloat(total*inventorysalesinvoice_discountp*0.01);
					
					inventorysalesinvoice_discarray[p].value = inventorysalesinvoice_disc.toFixed(2);
				}
				
				calculaterowtotal(p);
			}
		}
	}
	
	function calculaterowtotal(indexpos){
		if(indexpos=='all'){
			var inventorysalesinvoice_ratearray = document.getElementsByName("inventorysalesinvoice_rate[]");
			var inventorysalesinvoice_qtyarray = document.getElementsByName("inventorysalesinvoice_qty[]");
			var inventorysalesinvoice_discarray = document.getElementsByName("inventorysalesinvoice_disc[]");
			var inventorysalesinvoice_totalarray = document.getElementsByName("inventorysalesinvoice_total[]");
			
			if(inventorysalesinvoice_ratearray.length>0){
				for(var p=0; p<inventorysalesinvoice_ratearray.length; p++){
					var inventorysalesinvoice_rate = parseFloat(inventorysalesinvoice_ratearray[p].value);
					if(inventorysalesinvoice_rate=='' || isNaN(inventorysalesinvoice_rate)){inventorysalesinvoice_rate = 0;}
					
					var inventorysalesinvoice_qty = parseFloat(inventorysalesinvoice_qtyarray[p].value);
					if(inventorysalesinvoice_qty=='' || isNaN(inventorysalesinvoice_qty)){inventorysalesinvoice_qty = 0;}
					
					var total = parseFloat(inventorysalesinvoice_rate*inventorysalesinvoice_qty);
					
					var inventorysalesinvoice_disc = parseFloat(inventorysalesinvoice_discarray[p].value);
					if(inventorysalesinvoice_disc=='' || isNaN(inventorysalesinvoice_disc)){inventorysalesinvoice_disc = 0;}
					
					var total = parseFloat(total-inventorysalesinvoice_disc);
					
					inventorysalesinvoice_totalarray[p].value = total.toFixed(2);
				}
			}
			
		}
		else{
			var inventorysalesinvoice_ratearray = document.getElementsByName("inventorysalesinvoice_rate[]");
			var inventorysalesinvoice_rate = parseFloat(inventorysalesinvoice_ratearray[indexpos].value);
			if(inventorysalesinvoice_rate=='' || isNaN(inventorysalesinvoice_rate)){inventorysalesinvoice_rate = 0;}
			
			var inventorysalesinvoice_qtyarray = document.getElementsByName("inventorysalesinvoice_qty[]");
			var inventorysalesinvoice_qty = parseFloat(inventorysalesinvoice_qtyarray[indexpos].value);
			if(inventorysalesinvoice_qty=='' || isNaN(inventorysalesinvoice_qty)){inventorysalesinvoice_qty = 0;}
			
			var total = parseFloat(inventorysalesinvoice_rate*inventorysalesinvoice_qty);
			
			var inventorysalesinvoice_discarray = document.getElementsByName("inventorysalesinvoice_disc[]");
			var inventorysalesinvoice_disc = parseFloat(inventorysalesinvoice_discarray[indexpos].value);
			if(inventorysalesinvoice_disc=='' || isNaN(inventorysalesinvoice_disc)){inventorysalesinvoice_disc = 0;}
			
			var total = parseFloat(total-inventorysalesinvoice_disc);
			
			var inventorysalesinvoice_totalarray = document.getElementsByName("inventorysalesinvoice_total[]");
			inventorysalesinvoice_totalarray[indexpos].value = total.toFixed(2);
		}
		
		calculate_total();
	}
	
	function calculate_total(){
		
		//subtotal calculation
		var inventorysalesinvoice_subtotal = document.getElementById("inventorysalesinvoice_subtotal").value;
		if(inventorysalesinvoice_subtotal=='' || isNaN(inventorysalesinvoice_subtotal)){inventorysalesinvoice_subtotal = 0;}
		
		var inventorysalesinvoice_totaldisc = parseFloat(document.getElementById("inventorysalesinvoice_totaldisc").value);
		if(inventorysalesinvoice_totaldisc=='' || isNaN(inventorysalesinvoice_totaldisc)){inventorysalesinvoice_totaldisc = 0;}
		
		var inventorysalesinvoice_finaldisc = parseFloat(document.getElementById("inventorysalesinvoice_finaldisc").value);
		if(inventorysalesinvoice_finaldisc=='' || isNaN(inventorysalesinvoice_finaldisc)){inventorysalesinvoice_finaldisc = 0;}
		
		var inventorysalesinvoice_subtotalafterdisc = parseFloat(inventorysalesinvoice_subtotal-inventorysalesinvoice_totaldisc-inventorysalesinvoice_finaldisc);
		document.getElementById('inventorysalesinvoice_subtotalafterdisc').value= inventorysalesinvoice_subtotalafterdisc.toFixed(2);
		
		var inventorysalesinvoice_receiveamount = parseFloat(document.getElementById("inventorysalesinvoice_receiveamount").value);
		if(inventorysalesinvoice_receiveamount=='' || isNaN(inventorysalesinvoice_receiveamount)){inventorysalesinvoice_receiveamount = 0;}		
		
		var inventorysalesinvoicecollection_amount = parseFloat(document.getElementById("inventorysalesinvoicecollection_amount").value);
		if(inventorysalesinvoicecollection_amount=='' || isNaN(inventorysalesinvoicecollection_amount)){inventorysalesinvoicecollection_amount = 0;}
		
		var inventorysalesinvoice_due = parseFloat(document.getElementById("inventorysalesinvoice_due").value);
		if(inventorysalesinvoice_due=='' || isNaN(inventorysalesinvoice_due)){inventorysalesinvoice_due = 0;}
		
		//var inventorysalesinvoice_due = parseFloat(inventorysalesinvoice_subtotalafterdisc - inventorysalesinvoice_receiveamount-inventorysalesinvoicecollection_amount);
		//document.getElementById('inventorysalesinvoice_due').value=inventorysalesinvoice_due.toFixed(2);			
	
	var inventorysalesinvoice_currentdue = parseFloat(inventorysalesinvoice_due - inventorysalesinvoicecollection_amount  - inventorysalesinvoice_finaldisc);
		document.getElementById('inventorysalesinvoice_currentdue').value=inventorysalesinvoice_currentdue.toFixed(2);
		
	}
	
	function calculate_pctotal(){
		var inventorysalesinvoice_totalpccomission = 0;
		var inventorysalesinvoice_pccomissionarray = document.getElementsByName("inventorysalesinvoice_pccomission[]");
		if(inventorysalesinvoice_pccomissionarray.length>0){
			for(var p=0; p<inventorysalesinvoice_pccomissionarray.length; p++){
				var inventorysalesinvoice_pccomission = parseFloat(inventorysalesinvoice_pccomissionarray[p].value);
				if(inventorysalesinvoice_pccomission=='' || isNaN(inventorysalesinvoice_pccomission)){inventorysalesinvoice_pccomission = 0;}
				inventorysalesinvoice_totalpccomission = parseFloat(inventorysalesinvoice_totalpccomission+inventorysalesinvoice_pccomission);
			}
		}
		
		document.getElementById("inventorysalesinvoice_totalpccomission").value = inventorysalesinvoice_totalpccomission;
		
	}
	
	function check_particular(){
		/*var particular_idlistarray = new Array();
		var particular_id = document.getElementsByName('particular_id[]');
		var particular_count = particular_id.length;
		var particular_priceid = document.getElementsByName('particular_price[]');
		var particular_qtyid = document.getElementsByName('particular_qty[]');
			
		var error_messageid = document.getElementById('errmsg_particular_id');
		error_messageid.innerHTML = '';
		
		for(i = 0; i < particular_count; i++) {
												
			if(particular_id[i].value=='' || particular_id[i].value==0){
				error_messageid.innerHTML = 'Missing Particular Name '+parseInt(i+1);
				particular_id[i].focus();
				returnvalue = false;
			}
			
			if(particular_idlistarray.length>0 && particular_idlistarray.indexOf(particular_id[i].value) != -1){
				error_messageid.innerHTML = 'Dupplicate Particular Name '+i;
				particular_id[i].focus();
				return false;
			}
			else{
				particular_idlistarray[i] = particular_id[i].value;
			}
			
			var particular_priceval = parseInt(particular_priceid[i].value);
			if(isNaN(particular_priceval) || particular_priceval==''){particular_priceval = 0;}
			if(particular_priceval==0){
				error_messageid.innerHTML = 'Missing Price '+Math.floor(i+1);
				particular_priceid[i].focus();
				return false;
			}
										
			var particular_qtyval = parseInt(particular_qtyid[i].value);
			if(isNaN(particular_qtyval) || particular_qtyval==''){particular_qtyval = 0;}							
			if(particular_qtyval==0){
				error_messageid.innerHTML = 'Missing QTY '+Math.floor(i+1);
				particular_qtyid.focus();
				return false;
			}
		}*/
		return true;
	}
	function addnew_particularrow(animate) {
		if(check_particular()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" align=\"left\" width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"4\">"+
							'<tr>'+
								'<td align="right">Item Name</td>'+
								'<td> <input type="text" name="inventorysalesinvoice_item[]" value="" class="tdclass itemname"/></td>'+
								'<input type="hidden" name="inventorysalesinvoice_category[]" value="" class="tdclass"  />'+
								'<td align="right">Rate</td>'+
								"<td> <input type=\"text\" name=\"inventorysalesinvoice_rate[]\"  id=\"inventorysalesinvoice_rate\" value=\"\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/></td>"+											 
								'<td align="right">Qty</td>'+
								"<td> <input type=\"text\" name=\"inventorysalesinvoice_qty[]\"   id=\"inventorysalesinvoice_qty\" value=\"\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/></td>"+
								'<td align="right">Disc%</td>'+
								'<td> <input type="text" name="inventorysalesinvoice_discountp[]" value="" class="tdclasssale" onKeyUp="calculate_discountp();"/></td>'+
								'<td align="right">Disc</td>'+
								"<td> <input type=\"text\" name=\"inventorysalesinvoice_disc[]\" value=\"\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\" /></td>"+
								'<td align="right">P.C</td>'+
								'<td> <input type="text" name="inventorysalesinvoice_pccomission[]" value="" class="tdclasssale" onKeyUp="calculate_pctotal();"  /></td>'+
								'<td align="right">Total</td>'+
								'<td> <input type="text" readonly name="inventorysalesinvoice_total[]"  id="inventorysalesinvoice_total" value="" class="tdclasssale"  /></td>'+												
								'<td>'+
								 "<input type=\"button\" value=\"Cancel\" onClick=\"deletethislistrow('particularlistrowno"+particular_rowcount+"');\" class=\"tdclasssale\"  />"+
								'</td>'+
							  '</tr>'+
						"</table>";
						
			var $newparticularlist = $("<li></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(200); 
			else 
			   $newparticularlist.show();   
			
			$( ".itemname" ).autocomplete({			
				minLength: 1,
				source: itemdata,
				focus: function( event, ui ) {
					//$( "#search_item_number" ).val( ui.item.labelval );
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					
					var inventorysalesinvoice_ratearray = document.getElementsByName("inventorysalesinvoice_rate[]");
					inventorysalesinvoice_ratearray[indexpos].value = ui.item.salesitem_price;
					
					var inventorysalesinvoice_qtyarray = document.getElementsByName("inventorysalesinvoice_qty[]");
					inventorysalesinvoice_qtyarray[indexpos].value = 1;
					
					var inventorysalesinvoice_pccomissionarray = document.getElementsByName("inventorysalesinvoice_pccomission[]");
					inventorysalesinvoice_pccomissionarray[indexpos].value = ui.item.salesitem_pccommission;
					
					var inventorysalesinvoice_categoryarray = document.getElementsByName("inventorysalesinvoice_category[]");
					inventorysalesinvoice_categoryarray[indexpos].value = ui.item.salesitem_category;
	
					calculaterowtotal(indexpos);
					calculate_pctotal();
					
					return false;
				}
			});						
		}
	}
	
	function deletethislistrow(tableidname){
		$("#"+tableidname).parent("li").slideUp(200, function() {
			$(this).remove();
			calculaterowtotal('all');
		});
	}
</script>