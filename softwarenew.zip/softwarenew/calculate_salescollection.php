<script language="JavaScript" type="text/javascript">
	
	var patientdata = <?php echo $patientdata;?>;
	$(document).ready(function($) {
		
		$( "#opregistration_idsearch" ).autocomplete({
 			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
 				 document.getElementById('salescollectioninvoice_name').value = ui.item.labelval;
				 document.getElementById('opregistration_idsearch').value = 'Searching Completed';
				 document.getElementById('opregistration_id').value = ui.item.opregistration_id;
				 document.getElementById('opregistration_code').value = ui.item.opregistration_code;
				 document.getElementById('salescollectioninvoice_number').value = ui.item.opregistration_mobile;
				 document.getElementById('pharmacy_due').value = ui.item.pharmacy_due;
				 document.getElementById('salescollectioninvoice_address').value = ui.item.opregistration_address;
 				return false;
			}
		});
		
			
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
		
	});
	
		
	function calculate_total(){
		
		var pharmacy_due = parseFloat(document.getElementById("pharmacy_due").value);
		if(pharmacy_due=='' || isNaN(pharmacy_due)){pharmacy_due = 0;}
			
		var collection_amount = parseFloat(document.getElementById("collection_amount").value);
		if(collection_amount=='' || isNaN(collection_amount)){collection_amount = 0;}
		
		var final_discount = parseFloat(document.getElementById("final_discount").value);
		if(final_discount=='' || isNaN(final_discount)){final_discount = 0;}
		
		var total_balance = parseFloat(pharmacy_due - collection_amount - final_discount);
		document.getElementById('total_balance').value=	total_balance.toFixed(2);
 		}

function percentToAmount() {
     var pharmacy_due = parseFloat(document.getElementById("pharmacy_due").value) || 0;
     var percent = parseFloat(document.getElementById("final_discountp").value) || 0;
     var amount = (pharmacy_due * percent) / 100;
     document.getElementById("final_discount").value = amount.toFixed(2);
     calculate_total();
}

function amountToPercent() {
     var pharmacy_due = parseFloat(document.getElementById("pharmacy_due").value) || 0;
     var amount = parseFloat(document.getElementById("final_discount").value) || 0;
     var percent = 0;
     if (pharmacy_due > 0) {
        percent = (amount * 100) / pharmacy_due;
    }
     document.getElementById("final_discountp").value = percent.toFixed(2);
     calculate_total();
}

		
		
 function checkcontactform() {
    var total_balance_input = document.getElementById("total_balance");
    var error_total_balance = document.getElementById("error_total_balance");
    
    var salescollectioninvoice_name_input = document.getElementById("salescollectioninvoice_name");
    var error_salescollectioninvoice_name = document.getElementById("error_salescollectioninvoice_name");

    // Clear previous errors
    error_total_balance.innerHTML = '';
    error_salescollectioninvoice_name.innerHTML = '';

    var total_balance = parseFloat(total_balance_input.value) || 0;
    var salescollectioninvoice_name = salescollectioninvoice_name_input.value.trim();

    // Check if salescollectioninvoice_name is empty
    if (salescollectioninvoice_name === '') {
        error_salescollectioninvoice_name.innerHTML = "Please enter a name";
        salescollectioninvoice_name_input.focus();
        return false;
    }

    // Check if total_balance is empty or invalid
    if (total_balance_input.value.trim() === '') {
        error_total_balance.innerHTML = "Please enter an amount";
        total_balance_input.focus();
        return false;
    }

    // Allow submission if total_balance is zero or greater
    if (total_balance < 0) {
        error_total_balance.innerHTML = "Total balance should be zero or greater";
        total_balance_input.focus();
        return false;
    }

    return true; // ✅ Allow form submission
}



</script>