<script language="JavaScript" type="text/javascript">
	
	var salesitemdataarray = <?php echo $salesitemdataarray;?>;
	var salesitemdata = <?php echo $salesitemdata;?>;
	//var patientdata = <?php //echo $patientdata;?>;
	var salesitemarraydata = salesitemdataarray;
		//var itemarraydata = jQuery.parseJSON(itemdataarray);
	$(document).ready(function($) {
		document.getElementsByName("medicine_name[]")[0].focus();

		$( ".salesitemname" ).autocomplete({
			
			minLength: 1,
			source: salesitemdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				var labitem_idarray = document.getElementsByName("labitem_id[]");
				labitem_idarray[indexpos].value = ui.item.labitem_id;
			
				calculaterowtotal(indexpos);
				
				return false;
			}
		});
		
		$( "#labinvoice_patientcode" ).autocomplete({
			
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('labinvoice_patient').value = ui.item.labelval;
				 document.getElementById('labinvoice_patientid').value = ui.item.opregistration_id;
				 document.getElementById('labinvoice_age').value = ui.item.opregistration_age;
				 document.getElementById('labinvoice_gender').value = ui.item.opregistration_gender;
				 document.getElementById('labinvoice_mobile').value = ui.item.opregistration_mobile;
				 document.getElementById('labinvoice_address').value = ui.item.opregistration_address;
				 document.getElementById('labinvoice_pc').value = ui.item.pcname;
				 document.getElementById('labinvoice_mpo').value = ui.item.mpo;
				 document.getElementById('labinvoice_ward').value = ui.item.ward;
				 document.getElementById('labinvoice_previousdue').value = ui.item.due;
				 document.getElementById('previous_labinvoice_totalpccomission').value = ui.item.labinvoice_totalpccomission;
				
				return false;
			}
		});
		
		
		
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
		$( ".medicine_name" ).keypress(function(keyname) {
			if(keyname.which==13){
				var imei = $(this).val();
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				$.each(salesitemarraydata, function(key, value){
					var valuearray = value.split('||');
					if(key==imei){
						document.getElementsByName("labitem_id[]")[indexpos].value = valuearray[0];
						
						calculaterowtotal(indexpos);
						addnew_particularrow(true);
					}
				});
				return false;
			}
		});
	});
	
	
	function calculaterowtotal(indexpos){
		
	}
	
	
	
	
	
	function check_particular(){
		
		return true;
	}
	function addnew_particularrow(animate) {
		if(check_particular()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" style=\"BORDER-COLLAPSE: collapse; border:2px solid #FFF\" bgcolor=\"#c0d2ff\" align=\"left\" width=\"<?php echo $printdata_address3;?>\" border=\"0\" cellspacing=\"1\" cellpadding=\"4\">"+
							'<tr>'+
								'<td align="right">Test Name</td>'+
								'<td><input type="text" name="labinvoice_item[]" class="tdclass itemname labinvoice_item"/></td>'+
								'<input type="hidden" name="labitem_id[]"  id="labitem_id" class="tdclass itemname" />'+
								'<input type="hidden" name="labinvoice_category[]" value="" class="tdclass"  />'+
								'<input type="hidden" name="labinvoice_unit[]" value="" class="tdclass"  />'+
								'<input type="hidden" name="labinvoice_refvalue[]" value="" class="tdclass"  />'+
								'<!--<td align="right">Stock</td>-->'+
								"<input type=\"hidden\" name=\"labinvoice_reagent[]\"  id=\"labinvoice_reagent\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/>"+											 
								'<td align="right">Rate</td>'+
								"<td> <input type=\"text\" name=\"labinvoice_rate[]\"  id=\"labinvoice_rate\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/></td>"+											 
								'<!--<td align="right">Qty</td>-->'+
								"<input type=\"hidden\" name=\"labinvoice_qty[]\"   id=\"labinvoice_qty\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/>"+
								'<td align="right">Disc%</td>'+
								'<td> <input type="text" name="labinvoice_discountp[]" class="tdclasssale" onKeyUp="calculate_discountp();"/></td>'+
								'<td align="right">Disc</td>'+
								"<td> <input type=\"text\" name=\"labinvoice_disc[]\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\" /></td>"+
								'<td align="right">P.C</td>'+
								'<td> <input type="text" name="labinvoice_pccomission[]" class="tdclasssale" onKeyUp="calculate_pctotal();"  /></td>'+
								'<!--<td align="right">Dr.</td>-->'+
								'<td> <input type="hidden" name="labinvoice_drcomission[]" class="tdclasssale" onKeyUp="calculate_pctotal();"  /></td>'+
								'<td align="right">Total</td>'+
								'<td> <input type="text" readonly name="labinvoice_total[]"  id="labinvoice_total" class="tdclasssale"  /></td>'+												
								'<td>'+
								 "<input type=\"button\" value=\"Del\" onClick=\"deletethislistrow('particularlistrowno"+particular_rowcount+"');\" class=\"tdclasssale\"  />"+
								'</td>'+
							  '</tr>'+
						"</table>";
						
			var $newparticularlist = $("<li></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(200); 
			else 
			   $newparticularlist.show();   
			 document.getElementsByName("medicine_name[]")[parseInt(particular_rowcount-1)].focus();
			
			$( ".salesitemname" ).autocomplete({			
				minLength: 1,
				source: salesitemdata,
				focus: function( event, ui ) {
					//$( "#search_item_number" ).val( ui.item.labelval );
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					
					var labitem_idarray = document.getElementsByName("labitem_id[]");
					labitem_idarray[indexpos].value = ui.item.labitem_id;
			
					
					calculaterowtotal(indexpos);
					
					return false;
				}
			});	

			$( ".medicine_name" ).keypress(function(keyname) {
			if(keyname.which==13){
				var imei = $(this).val();
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				$.each(salesitemarraydata, function(key, value){
					var valuearray = value.split('||');
					if(key==imei){
						document.getElementsByName("labitem_id[]")[indexpos].value = valuearray[0];
						
						calculaterowtotal(indexpos);
						addnew_particularrow(true);
					}
				});
				return false;
			}
		});				
		}
	}
	
	function deletethislistrow(tableidname){
		$("#"+tableidname).parent("li").slideUp(200, function() {
			$(this).remove();
			calculaterowtotal('all');
		});
	}
	

// prevent multi times save

function funcSaveBill1()
{
	
	var varUserChoice; 
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet); 
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		document.frmsales.submit();
		//return true;
	}
}		
</script>