<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>A.A.S Payment</title>
	<style>
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        h1 {
            font-size: 24px;
            margin-bottom: 5px;
        }
        
        .message-container {
            padding: 10px 20px;
        }
        
        .messageerror {
            background: #ffebee;
            color: #c62828;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            border-left: 4px solid #c62828;
        }
        
        .red12bold {
            background: #e8f5e9;
            color: #2e7d32;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            border-left: 4px solid #2e7d32;
        }
        
        .form-container {
            padding: 5px;
        }
        
        .form-group {
            margin-bottom: 5px;
            display: flex;
            align-items: center;
        }
        
        .form-group label {
            width: 200px;
            font-weight: 600;
            color: #096B7F;
            text-align: right;
            padding-right: 15px;
        }
        
        .form-control {
            flex: 1;
            padding: 5px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #096B7F;
            box-shadow: 0 0 0 2px rgba(9, 107, 127, 0.2);
        }
        
        textarea.form-control {
            min-height: 30px;
            resize: vertical;
        }
        
        select.form-control {
            background: white;
        }
        
        .required::after {
            content: " *";
            color: #e74c3c;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .btn-primary {
            background: #096B7F;
            color: white;
        }
        
        .btn-primary:hover {
            background: #075566;
        }
        
        .btn-reset {
            background: #95a5a6;
            color: white;
            margin-left: 10px;
        }
        
        .btn-reset:hover {
            background: #7f8c8d;
        }
        
        .form-actions {
            text-align: center;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
        
        .input-with-icon {
            display: flex;
            align-items: center;
        }
        
        .input-with-icon input {
            flex: 1;
            border-top-right-radius: 0;
            border-bottom-right-radius: 0;
        }
        
        .input-icon {
            background: #096B7F;
            color: white;
            padding: 10px;
            border-top-right-radius: 5px;
            border-bottom-right-radius: 5px;
            cursor: pointer;
        }
        
        .info-text {
            font-size: 12px;
            color: #7f8c8d;
            margin-top: 5px;
            margin-left: 215px;
        }
        
        @media (max-width: 768px) {
            .form-group {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .form-group label {
                width: 100%;
                text-align: left;
                padding-right: 0;
                margin-bottom: 5px;
            }
            
            .info-text {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
<?php
 	 
	$empdata = array();
	$regformid='';
	$sqlst = "select * from expense GROUP BY expense_mobile order by expense_name asc";
	$stquery = mysqli_query($conn, $sqlst);
	if($stquery && mysqli_num_rows($stquery)>0){
		while ($strow = mysqli_fetch_array($stquery)){
			$expense_name = $strow['expense_name'];
			$expense_mobile = $strow['expense_mobile'];
			$empdata[] =array( 'labelval' => $expense_name,
								'label' => $expense_name.'#'. $expense_mobile,
								'expense_name'=>$expense_name,
								'expense_mobile'=>$expense_mobile
							);
		}
	}
	$empdata = json_encode($empdata);
?>
<link rel="stylesheet" href="autocomplete/jquery-ui.css">
    <script src="autocomplete/jquery-ui.min.js"></script>
    <script language="JavaScript" type="text/javascript">
        var empdata = <?php echo $empdata;?>;
        $(document).ready(function($) {
        $( "#expense_name" ).autocomplete({
                minLength: 1,
                source: empdata,
                focus: function( event, ui ) {
                    return false;
                },
                select: function( event, ui ) {
                    $(this).val( ui.item.label );
                        document.getElementById('expense_name').value = ui.item.labelval;
                        document.getElementById('expense_name').value = ui.item.expense_name;
                        document.getElementById('expense_mobile').value = ui.item.expense_mobile;
                    return false;
                }
            });
            
        });

         

 function calculate_total(){

    var aamount  = parseFloat(document.getElementById("aamount").value);
    if(isNaN(aamount)) aamount = 0;

    var asamount = parseFloat(document.getElementById("asamount").value);
    if(isNaN(asamount)) asamount = 0;

    var samount  = parseFloat(document.getElementById("samount").value);
    if(isNaN(samount)) samount = 0;

     // 👉 Total calculation
    var aastotal = aamount + asamount + samount;

    // 👉 Show total (input field)
    document.getElementById("aastotal").value = aastotal.toFixed(2);
}

    </script>
    <div class="container">
        <header style=" background:#89C5C5; color:#fff; padding:10px;">
            <h1 align="center">A.A.S Payment</h1>
        </header>
        
        <div class="message-container">
            <!-- PHP messages will appear here -->
           <?php if(isset($_GET['message'])) {
            $message = $_GET['message'];
            if($message == 'duplicate-prevented') {
                echo "<div class=\"messageerror\">Duplicate invoice detected.Go to statement for printing previous bill</div>";
            }
			elseif(isset($_GET['message']) && $_GET['message']=='save-successfully'){
				echo "<p class=\"red12bold\">Information insert successfully. Click Print Button To Print or View Previous Bill <td align=\"center\" ><a onclick=\"PrintDiv();\"><input type=\"button\" name=\"user\" id=\"user\" required value=\"Print\" class=\"tdclass\"  /></a></td></p>";   
			}
		}
		  $opregistration_id = '';
                $opregistration_name = '';
		if(isset($_GET['opregistration_id'])){
        $opregistration_id = $_GET['opregistration_id'];
        $labinvoicedetails_sql = "select opregistration_name,opregistration_id from opregistration where opregistration_id = $opregistration_id";
        $labinvoicedetailsquery = mysqli_query($conn, $labinvoicedetails_sql);
        if($labinvoicedetailsquery && mysqli_num_rows($labinvoicedetailsquery)>0){
            while($strow = mysqli_fetch_array($labinvoicedetailsquery)){
                $opregistration_id = $strow['opregistration_id'];
                $opregistration_name = $strow['opregistration_name'];
                
            }
        }
    }
		?>
        </div>
        <div class="form-container">
            <form action="save_aaspayment.php" name="frmcontact" id="frmcontact" onsubmit="return checkcontactform();" method="post" enctype="multipart/form-data">
               <input type="hidden" name="user" id="user" required value="<?php echo $_SESSION['fullname'];?>" class="tdclass" />
                <input type="hidden" name="section" id="section" value="AAS Paid">
                 
                 <div class="form-group">
                    <label for="expense_month">PID</label>
                    <input type="text" name="pid" id="pid" value="<?php echo $opregistration_id;?>" class="form-control" />
                 
                    <label for="expense_date">Patient Name</label>
                    <input type="text" readonly name="patient" placeholder="From Patient List" value="<?php echo $opregistration_name;?>" class="form-control" />
                 </div>
                
                <div class="form-group">
                    <label for="expense_month">Month</label>
                    <input type="text" name="expense_month" id="expense_month" value="" class="form-control" />
                 
                    <label for="expense_date">Payment Date</label>
                     <input type="text" readonly name="expense_date" id="expense_date" value="" class="form-control" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('expense_date')" style="cursor:pointer"/>
                 </div>
                
                <div class="form-group">
                    <label for="expense_name">Surgeon Name</label>
                    <input type="text" required name="sname" id="sname" class="form-control" autocomplete="off" />
                 
                    <label for="expense_amount" class="required">Surgeon Amount</label>
                    <input type="number" name="samount" id="samount" required onKeyUp="calculate_total();" class="form-control" autocomplete="off" step="0.01" />
                </div>
                
                <div class="form-group">
                    <label for="expense_mobile">Anaesthesia Name</label>
                    <input type="text" name="aname" id="aname" class="form-control" autocomplete="off" />
                 
                    <label for="expense_amount" class="required">Anaesthesia Amount</label>
                    <input type="number" name="aamount" id="aamount" required class="form-control" onKeyUp="calculate_total();" autocomplete="off" step="0.01" />
                </div>
                
                <div class="form-group">
                    <label for="expense_voucher">Assist Name</label>
                    <input type="text" name="asname" id="asname" class="form-control" autocomplete="off" />
                 
                    <label for="expense_amount" class="required">Assist Amount</label>
                    <input type="number" name="asamount" id="asamount" required class="form-control" onKeyUp="calculate_total();" autocomplete="off" step="0.01" />
                </div>
                
                   <div class="form-group">
                    <label for="expense_description">Note</label>
                    <textarea name="note" id="note" class="form-control"></textarea>
                </div>
                
                
                
                <div class="form-group">
                    <label for="expense_amount" class="required">Total Paid Amount</label>
                    <input type="number" readonly name="aastotal" id="aastotal" required class="form-control" onKeyUp="calculate_total();" autocomplete="off" step="0.01" />
                </div>
                 
                	<input type="hidden" name="auto_number" id="auto_number" value="0">
                 <div class="form-actions">
                    <button type="submit" class="btn btn-primary" name="submit_invoice">Save Payment</button>
                 </div>
            </form>
        </div>
    </div>

    <script>
       // // Initialize the form with current date and month
        document.addEventListener('DOMContentLoaded', function() {
            const now = new Date();
            const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            
            // Set current month and year
            document.getElementById('expense_month').value = months[now.getMonth()] + ' ' + now.getFullYear();
            
            // Set current date
            const formattedDate = now.toISOString().substring(0, 10);
            document.getElementById('expense_date').value = formattedDate;
             
        });
        
        // Form validation
        function checkcontactform() {
            const requiredFields = [
                'expense_name', 
                 'expense_amount'
            ];
            
            for (const field of requiredFields) {
                const input = document.getElementById(field);
                if (!input.value.trim()) {
                    alert(`Please fill in the ${input.labels[0].textContent} field`);
                    input.focus();
                    return false;
                }
            }
            
            // Amount validation
            const amount = document.getElementById('aamount').value;
            if (parseFloat(amount) <= 0) {
                alert('Please enter a valid expense amount');
                document.getElementById('aamount').focus();
                return false;
            }
            
            return true;
        }
        
        // Prevent form resubmission
         
    </script>
    
</body>
</html>


<div id="divToPrint" style="display:none;">
<style>
@media print {
    body { background:#fff; }
    .bottomcontent { margin:0; padding:0; }
}

.invoice-wrap{
    width:94%;
    margin:0 auto;
    font-family:Arial, Helvetica, sans-serif;
    font-size:12px;
    color:#000;
}

.invoice-header{
    border:1px solid #000;
    padding:8px;
}

.invoice-title{
    font-size:15px;
    font-weight:bold;
}

.invoice-info{
    border:1px solid #000;
    border-top:none;
    padding:6px;
}

.invoice-table{
    width:100%;
    border-collapse:collapse;
}

.invoice-table th,
.invoice-table td{
    border:1px solid #666;
    padding:6px;
    text-align:center;
}

.invoice-table th{
    background:#f2f2f2;
    font-weight:bold;
}

.amount-row{
    background:#fafafa;
    font-weight:bold;
}

.total-row td{
    font-weight:bold;
    font-size:13px;
    background:#eaeaea;
}

.sign-table td{
    padding-top:40px;
    text-align:center;
}

.footer{
    text-align:center;
    font-size:11px;
    margin-top:10px;
}
</style>
<?php
		  if(isset($_GET['auto_number'])){
          	$auto_number = $_GET['auto_number'];
            $labinvoicedetails_sql = "select * from aaspayment where auto_number = $auto_number order by auto_number desc";
            $labinvoicedetailsquery = mysqli_query($conn, $labinvoicedetails_sql);
            if($labinvoicedetailsquery && mysqli_num_rows($labinvoicedetailsquery)>0){
               $i=0;
			    while($strow = mysqli_fetch_array($labinvoicedetailsquery)){
                   $i++;
                    $auto_number = $strow['auto_number'];
                    $pid = $strow['pid'];
                    $patient = $strow['patient'];
                    $sname = $strow['sname'];
					$user = $strow['user'];
                    $aname = $strow['aname'];
                    $asname = $strow['asname'];
                    $samount = $strow['samount'];
					$aamount = $strow['aamount'];
					$asamount = $strow['asamount'];
                    $aastotal = $strow['aastotal'];
                    $note = $strow['note'];
                    $expense_date = $strow['expense_date'];
					$expense_month = $strow['expense_month'];
				
		 	 ?>
<div class="invoice-wrap">

<?php if($heading=='Yes'){ ?>
<div class="invoice-header">
    <table width="100%">
        <tr>
            <?php if($hospitaldata_logo!=''){ ?>
            <td width="70">
                <img src="logo_images/<?php echo $hospitaldata_logo; ?>" width="60">
            </td>
            <?php } ?>
            <td>
                <div class="invoice-title"><?php echo $hospitaldata_name;?></div>
                <div><?php echo $hospitaldata_address1;?></div>
            </td>
        </tr>
    </table>
</div>
<?php } ?>

<div class="invoice-info">
<table width="100%">
<tr>
<td>
    <strong>Invoice No:</strong> <?php echo $auto_number;?><br>
    <strong>Patient:</strong> <?php echo $patient;?><br>
    <strong>ID:</strong> <?php echo $pid;?>
</td>
<td align="right">
    <strong>AAS Payment</strong><br>
    Bill No: <?php echo $auto_number;?><br>
    Date: <?php echo $expense_date;?>
</td>
</tr>
</table>
</div>

<table class="invoice-table">
<tr>
    <th>SL</th>
    <th>Surgeon</th>
    <th>Anaesthesia</th>
    <th>Assist</th>
</tr>
<tr>
    <td><?php echo $i;?></td>
    <td><?php echo $sname;?></td>
    <td><?php echo $aname;?></td>
    <td><?php echo $asname;?></td>
</tr>
<tr class="amount-row">
    <td></td>
    <td><?php echo number_format($samount,2);?></td>
    <td><?php echo number_format($aamount,2);?></td>
    <td><?php echo number_format($asamount,2);?></td>
</tr>
<tr class="total-row">
    <td colspan="3" align="right">Total</td>
    <td><?php echo number_format($aastotal,2);?></td>
</tr>
</table>

<p style="margin-top:10px;">
<?php include("convert_currency_to_words.php");
echo covert_currency_to_words($aastotal); ?>
</p>

<table class="sign-table" width="100%">
<tr>
<td>Receiver</td>
<td>Director</td>
<td>Accounts</td>
<td>Manager</td>
<td>Chairman/MD</td>
</tr>
</table>

<div>Prepared By: <?php echo $user;?></div>

<div class="footer">
Software by: Betasofts.com
</div>
 <?php
      		}
	  	 }
	  }
      ?>
</div>


</div>