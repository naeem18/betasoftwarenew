<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$message = '';
if(isset($_POST) && array_key_exists('btnAttUpload', $_POST)){
	$message = '<p>There is an error for submit this file.</p>';
	$entry = $out = $update = $empInsert = 0;
	$created_date = $modified_date  = time();
	require_once 'ExcelLibrary/PHPExcel.php';
	//require_once dirname(__FILE__) . '/ExcelLibrary/Classes/PHPExcel/IOFactory.php';
	
	$uploadfile = basename($_FILES['attendance_file']['name']);
	$upload_filearray = explode('.', $uploadfile);				
	$fileextension = $upload_filearray[floor(count($upload_filearray)-1)];
	$tempFile = $_FILES['attendance_file']['tmp_name'];
	$object = PHPExcel_IOFactory::load($tempFile);
	
	$employeeArray = array();
	$empObj = mysqli_query($conn, "SELECT e_id FROM employee WHERE publish = 1");
	if($empObj){
		while($empOneRow=mysqli_fetch_array($empObj)){
			$employeeArray[] = $empOneRow['e_id'];
		}
	}
	
	$eIds = array();
	foreach($object->getWorksheetIterator() as $worksheet){
		$highestRow = $worksheet->getHighestRow();
		$highestColumn = $worksheet->getHighestColumn();
		//var_dump($highestColumn);
		for($row=2; $row<=$highestRow; $row++){
			$Department = $worksheet->getCellByColumnAndRow(0, $row)->getValue();
			$Name = $worksheet->getCellByColumnAndRow(1, $row)->getValue();
			$IdNo = intval($worksheet->getCellByColumnAndRow(2, $row)->getValue());
			$DateTime = $worksheet->getCellByColumnAndRow(3, $row)->getValue();
			$bnname = $worksheet->getCellByColumnAndRow(4, $row)->getValue();
			$father = $worksheet->getCellByColumnAndRow(5, $row)->getValue();
			//var_dump($DateTime);
	
			if($IdNo>0){
				if(!in_array($IdNo, $eIds)){
					$eIds[] = $IdNo;
				}
				if(!in_array($IdNo, $employeeArray)){
					$employeeArray[] = $IdNo;
					
					$insertid  = mysqli_query($conn, "INSERT INTO employee SET `e_id`='$IdNo', `bnname`='$bnname', `father`='$father', `Department`='$Department', `name`='$Name', `created_date`='$modified_date', `modified_date`='$modified_date'");
					if($insertid){
						$entry++;
					}
					$empInsert++;
				}
				
				$date = date('Y-m-d', strtotime($DateTime));
				$time = date('H:i:s', strtotime($DateTime));
				$xlsData[] = array(
					'Department'=>$Department,
					'Name'=>$Name,
					'IdNo'=>$IdNo,
					'Date'=>$date,
					'created_date'=>$created_date,
					'father'=>$father,
					'Time'=>$time);
			}
		}
	}
	//print_r($xlsData);
	$dptData = 0;
	if(!empty($xlsData)){
		
		$updated_date = time();
		$t=0;
		foreach($xlsData as $oneEmployeeData){
			$t++;
			$e_id = $oneEmployeeData['IdNo'];
			$startEndDate = $oneEmployeeData['Date'];
			$startEndTime = $oneEmployeeData['Time'];
			
			$dptObj = mysqli_query($conn, "SELECT id FROM machine_data WHERE e_id = '$e_id' AND entry_date = '$startEndDate' AND entry_time = '$startEndTime'");
			$dptCount = mysqli_num_rows($dptObj);
			$dptData += $dptCount;
			if($dptCount==0){
				
				$inOutObj = mysqli_query($conn, "SELECT id, in_out FROM machine_data WHERE e_id = '$e_id' AND entry_date = '$startEndDate'");
				$inOutCount = mysqli_num_rows($inOutObj);
				
				$in_out = 0;
				if($inOutCount==0){$in_out = 1;}
				elseif($inOutCount==1){$in_out = 2;}
				else{
					$in_out = 2;
					while($inOutRow=mysqli_fetch_array($inOutObj)){
						if($inOutRow['in_out']==2){
							mysqli_query($conn, "UPDATE machine_data SET `in_out`=0 WHERE id=$inOutRow[id]");
						}
					}
				}
				
				$insertid  = mysqli_query($conn, "INSERT INTO machine_data SET `e_id`=$e_id, `entry_date`='$startEndDate', `entry_time`='$startEndTime', `in_out`='$in_out'");
				if($insertid){
					$entry++;
				}
			}						
		}
	}
	
	$message = "<p>Total $dptData Duplicate found and $entry saved</p>";
	if($empInsert>0){
		$message .= "<br>Total $empInsert employee added. Please work on employee setting first then update new Employee information.";
	}
}
?>
<header class="header_tittle">
    <h3>Attendance Import Information</h3>
</header>

<form action="index.php?p=employenameentry2" enctype="multipart/form-data" onSubmit="return checkFile();" method="post" accept-charset="utf-8">
    <table cellpadding="5" cellspacing="0" width="100%">
    	<?php
        if($message !=''){
			echo $message;
		}
		?>
        <tr>
        	<td width="200">
            	<label>Attendance Import File*:</label>
            </td>
            <td>
            	<input required class="bordernone" type="file" name="attendance_file" id="attendance_file" accept=".xls,.xlsx" />
      			<span class="errormsg" id="errmsg_attendance_file"></span>
            </td>
        </tr>
        <tr>
        	<td width="200">&nbsp;</td>
            <td>
            	<input type="submit" name="btnAttUpload" id="btnAttUpload" class="btn btn-primary backlink" value=" Upload and View " />
		        <input type="button" onClick="resetform();" value="Cancel" class="hidediv btn btn-warning mleft10" />
            </td>
        </tr>
    </table>
</form>

<script type="text/javascript">
    function checkFile(){
        var elementmessage = document.getElementById('errmsg_attendance_file');
        elementmessage.innerHTML = '';
        
        var ext = $('#attendance_file').val().split('.').pop().toLowerCase();
        var allow = new Array('xls','xlsx');
        if(jQuery.inArray(ext, allow) == -1) {
            elementmessage.innerHTML = 'File type is invalid. Only <strong>.xls/.xlsx</strong> file types are allowed.';
            $('#attendance_file').focus();
			
			return false;
        }
        return true;
    }

    function resetform(){
        document.frmImportCustomers.instance_id.value = 0;
        $('#attendance_file').val('');
        $("#formtitle").html('Attendance Import Information');
        $("#btnAttUpload").val(' Upload and View ');                                                
    }
</script>
<table align="left" width="100%" border="1" style="BORDER-COLLAPSE: collapse;" cellspacing="1" cellpadding="3">
      <tr>
        <td colspan="100%" bgcolor="#0033FF" align="center" style="color:#fff; border:1px solid #03F;">
             <strong>In-Out Information </strong>
        </td>
      </tr>
      <tr bgcolor="#ccc" align="center">
        <td>ID</td>
        <td>Name</td>
        <td>In Time</td>
       <td>Out Time</td>
      </tr>
    
<?php
$mdObj = mysqli_query($conn, "SELECT * FROM machine_data, employee WHERE employee.e_id = machine_data.e_id AND machine_data.in_out>0 LIMIT 0,500");
$mdCount = mysqli_num_rows($mdObj);
if($mdCount>0){
	$attendanceData = $employeeDate = array();
	while($mdOneRow=mysqli_fetch_array($mdObj)){
		$employeeDate[$mdOneRow['e_id']][$mdOneRow['entry_date']] = $mdOneRow['name'];
		$attendanceData[$mdOneRow['entry_date']][] = array($mdOneRow['entry_date'], $mdOneRow['entry_time'], $mdOneRow['in_out']);
	}
	ksort($employeeDate);
	if(!empty($employeeDate)){
		foreach($employeeDate as $e_id=>$dateInfo){			
			foreach($dateInfo as $date=>$name){
				
				$inTime = $outTime = '';
				
				$empAttInfo = array();
				if(array_key_exists($date, $attendanceData)){$empAttInfo = $attendanceData[$date];}
				if(!empty($empAttInfo)){
					foreach($empAttInfo as $attOneRow){
						$entry_date = $attOneRow[0];
						$entry_time = $attOneRow[1];
						$in_out = $attOneRow[2];
						if($in_out==1){
							$inTime = "$entry_date $entry_time";
						}
						elseif($in_out==2){
							$outTime = "$entry_date $entry_time";
						}
					}
				}?>
				<tr bgcolor="#fff" align="center">
                    <td><?php echo $e_id; ?></td>
                    <td><?php echo $name; ?></td>
                    <td><?php echo $inTime; ?></td>
                  <td><?php echo $outTime; ?></td>
                    </tr>
			
			<?php
            }			
		}
	}
}

?>
  </table>