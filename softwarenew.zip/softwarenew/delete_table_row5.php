<?php
session_start();
if(isset($_GET['idvalue'])){	
	//$labinvoice_id = $_POST['labcollection_id'];
	
	$idvalue = $_GET['idvalue'];
	if($idvalue>0){
		require('labdd.php');
		
		$str2 = "DELETE from hospitalinvoicecollection where auto_number = '$idvalue'";
		$userquery = mysqli_query($conn, $str2);
		
		
		$str3 = "DELETE from dailytransection_lab where section='H Collection' AND labinvoice_id = '$idvalue'";
		//echo $str3;
		$userquery = mysqli_query($conn, $str3);
		
		
		if($userquery){			
			header("location:index.php?p=statementbydailyhospitalcollection&message=remove-successfully");			
		}
		else{
			header("location:index.php?p=$returnpage&message=couldnotremove");
		}
	}
	else{
		header("location:index.php?p=statementbydailyhospitalcollection&message=incorrect_id");
	}
}
?>