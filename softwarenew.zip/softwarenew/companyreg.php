        <article class="bottomcontent">
        <h4 align="center">Company Registration</h4>
            <content>
            <?php
            $company_id = 0;
            $company_name = '';
            $company_mobile = '';
            $company_due = '';
            $company_address = '';
            $company_gender = '';
            $company_blood = '';
            $company_date = '';
            $company_father ='';
            $company_mother = '';
                    
        if(isset($_GET['company_id'])){
            $company_id = $_GET['company_id'];
            $sqlst = "select * from company where company_id = $company_id";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery){
                while($strow = mysqli_fetch_array($stquery)){
                    $company_id = $strow['company_id'];
                    $company_name = $strow['company_name'];
                    $company_mobile = $strow['company_mobile'];
                    $company_due = $strow['company_due'];
                    $company_address = $strow['company_address'];
                    $company_gender = $strow['company_gender'];
                    $company_blood = $strow['company_blood'];
                    $company_date = $strow['company_date'];
                    $company_father = $strow['company_father'];
                    $company_mother = $strow['company_mother'];
                }
            }
        }
        ?>
            
 	<form action="save_companyreg.php" name="frmcontact" onsubmit="return checkcontactform();" method="post" enctype="multipart/form-data">
       
            <table width="50%" align="center" border="1" style="BORDER-COLLAPSE: collapse;" bgcolor="#D6FEE1" cellpadding="2">
     		<tr>
                    <td width="120"><label> Date*</label></td>
                    <td>
                        <input type="text" name="company_date" id="company_date" value="<?php echo date('Y-m-d');?>"  class="textfieldcssmem"  />
                    </td>
                </tr>
                
                 <tr>
                    <td width="120"><label> Company Name*</label></td>
                    <td>
                        <input type="text" required name="company_name" id="company_name" value="<?php echo $company_name;?>"  class="textfieldcssmem"  />
                    </td>
                </tr>
                
                 <tr>
                    <td><label>Authorise Person</label></td>
                    <td>
                        <input type="text" name="company_father" value="<?php echo $company_father;?>" id="company_father" class="textfieldcssmem"  />
                    </td>
                </tr>
                <tr>
                    <td><label>Owner Person</label></td>
                    <td>
                        <input type="text" name="company_mother" id="company_mother" value="<?php echo $company_mother;?>" class="textfieldcssmem"  />
                    </td>
                </tr>
                 <tr>
                    <td width="120"><label>Business Address</label></td>
                    <td width="310">
                        <textarea  name="company_address" id="company_address" value="" class="textfieldcssmem" ><?php echo $company_address;?></textarea>
                    </td>
                </tr>
                
                
                 <tr>
                    <td><label>Mobile *</label></td>
                    <td>
                        <input type="text" name="company_mobile" id="company_mobile" value="<?php echo $company_mobile;?>"  class="textfieldcssmem"  />
                    </td>
                </tr>
               
               
                 <tr>
                    <td><label>Due *</label></td>
                    <td><input type="text" name="company_due" id="company_due" value="<?php echo $company_due;?>"  class="textfieldcssmem"  />
                    </td>
                </tr>
               
                 <tr>
                 <td></td>
                    <td>
                        <input type="hidden" name="company_id" id="company_id" value="<?php echo $company_id;?>">
                        <input type="submit" value=" Save " name="submit_opreg" id="submit_opreg" class="submitbuttoncss" />
                    </td>
                 </tr>
          </table>
      </form>
      
      
      
	<?php
    $searchstr='';
    if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
    {
        $transactiondatefrom = $_REQUEST['ADate1'];
        $transactiondateto = $_REQUEST['ADate2'];
        
        $company_name = $_REQUEST['company_name'];
        if($company_name !=''){
            $searchstr .= " and company_name like '%$company_name%'";
        }
    }
    else
    {
        $transactiondatefrom = date('Y-m-d', strtotime('-1 year'));
        $transactiondateto = date('Y-m-d');
    }
    ?>
 <table width="100%" border="0" cellspacing="0" cellpadding="2">
   <tr>
    <td valign="top" align="center">
    	<form name="cbform1" method="post" action="index.php?p=companyreg">
            <table width="100%" border="0" align="center" cellpadding="4" cellspacing="0" bordercolor="#666666" style="border-collapse: collapse">
              <tbody>
                <tr bgcolor="#011E6A">
                  <td colspan="10" bgcolor="#CCCCCC"><strong>Search Date / Company Wise</strong></td>
                </tr>           
                <tr>
                    <td class="bodytext31" width="10%" valign="center" align="right" bgcolor="#FFFFFF">Date From:</td>
                    <td width="14%" align="left" valign="center" bgcolor="#FFFFFF">
                        <input name="ADate1" id="ADate1" style="border: 1px solid #001E6A" value="<?php echo $transactiondatefrom; ?>" size="10"  readonly="readonly" onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
                    </td>
                    <td width="10%" align="right" valign="center" bgcolor="#FFFFFF">Date To:</td>
                    <td width="14%" align="left" valign="center" bgcolor="#FFFFFF">
                         <input name="ADate2" id="ADate2" style="border: 1px solid #001E6A" value="<?php echo $transactiondateto; ?>" size="10" readonly="readonly" onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate2')" style="cursor:pointer"/>
                     </td>
                    <td width="10%" align="right" valign="center" bgcolor="#FFFFFF">By Name</td>
            	    <td bgcolor="#FFFFFF"> <input type="text" name="company_name" id="company_name"/></td>
                    <td align="left" valign="center" bgcolor="#FFFFFF">
                        <input style="border: 1px solid #001E6A" type="submit" value="Search" name="Submit" />
                        <input name="resetbutton" type="reset" id="resetbutton" style="border: 1px solid #001E6A" value="Reset" />
                    </td>
                    <td width="10%" align="right" valign="center" bgcolor="#FFFFFF">
                       <input name="print" type="button" id="print"  style="border: 1px solid #001E6A" value="Print" onClick="PrintDiv();" />
                    </td>
                </tr>
              </tbody>
            </table>
		</form>
       
   	</td>
</tr>

		<td>
 		<?php 
 		$datetime1 = new DateTime($transactiondatefrom);
		$datetime2 = new DateTime($transactiondateto);
		$interval = $datetime1->diff($datetime2);
		$totaldays = $interval->format('%a');
		if($datetime1<$datetime2){
			$fromdate = $transactiondatefrom;
			$todate = $transactiondateto;
		}
		else{
			$fromdate = $transactiondateto;
			$todate = $transactiondatefrom;
		}
		?>
       <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1" cellspacing="0" cellpadding="2">
        <tbody>
         <tr>
            <td colspan="19" bgcolor="#FFF" align="center" style="color:#000; border:1px solid #000;">
            	<strong><?php echo $hospitaldata_name;?></strong><br>
                Company List :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?>
            </td>
          </tr>
             <tr>
                <td><strong>SL No.</strong></td>
                <td><strong>Date</strong></td>
                <td><strong>Company Code</strong></td>
                <td><strong>Name/Business Name</strong></td> 
                <td><strong>Address</strong></td> 
                <td><strong>Authorise Name</strong></td>
                <td><strong>Owner Name</strong></td>            
                <td><strong> Mobile</strong></td>  
                <td><strong>Total Due Taka</strong></td>  
                <td><strong>Edit/Remove</strong></td>
            </tr>
			<?php
			$company_dueT='0.00';
			$s='';
 			$sqlst = "select * from company order by company_id desc";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery &&  mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery)) {
					$company_id = $strow['company_id'];
                    $company_code = $strow['company_code'];
                    $company_name = $strow['company_name'];
                    $company_mobile = $strow['company_mobile'];
                    $company_due = $strow['company_due'];
                    $company_address = $strow['company_address'];
                    $company_gender = $strow['company_gender'];
                    $company_blood = $strow['company_blood'];
                    $company_date = $strow['company_date'];
					$company_father = $strow['company_father'];
                    $company_mother = $strow['company_mother'];

		$action1 = "<a href=\"index.php?p=printidcard&company_id=$company_id\" target=\"_blank\">Print</a>";
		$action = "<a href=\"index.php?p=companyreg&company_id=$company_id\">Edit</a> |
				   <a href=\"javascript:void(0)\" onclick=\"removetablerow('company', $company_id, 'companyreg')\">Remove</a>";
					
					$company_dueT=$company_dueT+$company_due;
					?>
				
              	 <tr bgcolor="#fff">
                    <td><?php echo $s=$s+1; ?></td>
                    <td><?php echo $company_date; ?></td>
                    <td><?php echo $company_code; ?></td>
                    <td><?php echo $company_name; ?></td>
                    <td><?php echo $company_address; ?></td>
                    <td><?php echo $company_father; ?></td>
                    <td> <?php echo $company_mother; ?></td>
                    <td> <?php echo $company_mobile; ?></td>
                    <td> <?php echo $company_due; ?></td>
                    <td><?php if($_SESSION['employeename']=='ADMINISTRATOR') { echo $action;} if($_SESSION['employeename']=='SUPERADMINISTRATOR'){ echo $action; } ?></td>
               	</tr>
                <?php
                	}
				}
 			?>
        	<tr>
            <td colspan="8"></td>
             <td><?php echo $company_dueT; ?></td>
            </tr>
           <tbody>
        </table>
       </td>
      
	<td align="center" id="divToPrint" style="display:none">
 		<?php 
 		$datetime1 = new DateTime($transactiondatefrom);
		$datetime2 = new DateTime($transactiondateto);
		$interval = $datetime1->diff($datetime2);
		$totaldays = $interval->format('%a');
		if($datetime1<$datetime2){
			$fromdate = $transactiondatefrom;
			$todate = $transactiondateto;
		}
		else{
			$fromdate = $transactiondateto;
			$todate = $transactiondatefrom;
		}
		?>
        
    <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1" cellspacing="0" cellpadding="2">
    <tbody>
     <tr>
        <td colspan="19" bgcolor="#FFF" align="center" style="color:#000; border:1px solid #000;">
            <strong><?php echo $hospitaldata_name;?></strong><br>
            Company List :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?>
        </td>
      </tr>
         <tr>
            <td><strong>SL No.</strong></td>
            <td><strong>Date</strong></td>
            <td><strong>Company Code </strong></td>
            <td><strong>Name/Business Name</strong></td> 
            <td><strong>Address</strong></td> 
            <td><strong>Authorise Name</strong></td>
            <td><strong>Owner Name</strong></td>            
            <td><strong> Mobile</strong></td>  
            <td><strong>Total Due Taka</strong></td>             
          </tr>
			<?php
			$totalsumexpense_amount='0.00';
			$s='';
			for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
			$sqlst = "select * from company where company_id!= '' and company_date between '$newfromdate' and '$newtodate' $searchstr order by company_id ASC";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery &&  mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery)) {
					$company_id = $strow['company_id'];
                    $company_code = $strow['company_code'];
                    $company_name = $strow['company_name'];
                    $company_mobile = $strow['company_mobile'];
                    $company_due = $strow['company_due'];
                    $company_address = $strow['company_address'];
                    $company_gender = $strow['company_gender'];
                    $company_blood = $strow['company_blood'];
                    $company_date = $strow['company_date'];
					$company_father = $strow['company_father'];
                    $company_mother = $strow['company_mother'];
 					?>
                     <tr>
                        <td><?php echo $s=$s+1; ?></td>
                        <td><?php echo $company_date; ?></td>
                        <td><?php echo $company_code; ?></td>                    
                        <td><?php echo $company_name; ?></td>
                        <td><?php echo $company_address; ?></td>
                        <td><?php echo $company_father; ?></td>
                        <td><?php echo $company_mother; ?></td>
                        <td><?php echo $company_mobile; ?></td>
                        <td><?php echo $company_due; ?></td>
                    </tr>
                <?php
                	}
				}
			}
			?>
            <tbody>
        </table>
      </td>
</table>     
</content>
</article>