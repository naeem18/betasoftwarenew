<?php
if(isset($_GET['labinvoice_id'])){
		$labinvoice_id = $_GET['labinvoice_id'];
		$sqlst = "select * from labinvoice where labinvoice_id = $labinvoice_id";
		$stquery = mysqli_query($conn, $sqlst);
		if($stquery){
			while($strow = mysqli_fetch_array($stquery)){
				$labinvoice_id = $strow['labinvoice_id'];
				$labinvoice_patientid = $strow['labinvoice_patientid'];
				$labinvoice_patient = $strow['labinvoice_patient'];
				$labinvoice_age = $strow['labinvoice_age'];
				$labinvoice_gender = $strow['labinvoice_gender'];
				$labinvoice_mobile = $strow['labinvoice_mobile'];
				$labinvoice_address = $strow['labinvoice_address'];
				$labinvoice_doctor = $strow['labinvoice_doctor'];
				$labinvoice_ward = $strow['labinvoice_ward'];
				$labinvoice_pc = $strow['labinvoice_pc'];
				$labinvoice_date = $strow['labinvoice_date'];
				$labinvoice_duesholder = $strow['labinvoice_duesholder'];
				$labinvoice_description = $strow['labinvoice_description'];
			}
		}
	}
   
   
if(isset($_GET['reportname'])){
	$reportname = $_GET['reportname'];
	$labinvoicedetails_sample = $_GET['labinvoicedetails_sample'];
	$labinvoicedetails_category = $_GET['labinvoicedetails_category'];
	$machine_name = $_GET['machine_name'];
	$sqlst1 = "select * from labinvoicedetails where reportname = $reportname";
	//$sqlst = "select * from labinvoice where labinvoice_id = $labinvoice_id";
	$stquery1 = mysqli_query($conn, $sqlst1);
	if($stquery1){
		while($strow = mysqli_fetch_array($stquery)){
			 $reportname = $strow['reportname'];
			 $labinvoicedetails_sample = $strow['labinvoicedetails_sample'];
			 $labinvoicedetails_category = $strow['labinvoicedetails_category'];
			 $machine_name = $strow['machine_name'];
			}
		}
	}

date_default_timezone_set('Asia/Dhaka');
$selectname_list = '';
/*$patientdata = '';
$sqlopregistration = "select * from labinvoice order by labinvoice_id desc Limit 0,100";
$opregistrationquery = mysqli_query($conn, $sqlopregistration);
if($opregistrationquery && mysqli_num_rows($opregistrationquery)>0){
	
	while ($opregistrationrow = mysqli_fetch_array($opregistrationquery)){
		$labinvoice_id = $opregistrationrow['labinvoice_id'];
		$labinvoice_patientid = $opregistrationrow['labinvoice_patientid'];
		$labinvoice_patient = $opregistrationrow['labinvoice_patient'];
		$labinvoice_age = $opregistrationrow['labinvoice_age'];
		$labinvoice_gender = $opregistrationrow['labinvoice_gender'];
		$labinvoice_mobile = $opregistrationrow['labinvoice_mobile'];
		$labinvoice_doctor = $opregistrationrow['labinvoice_doctor'];
		$labinvoice_address = $opregistrationrow['labinvoice_address'];
		$patientdata[] =array( 'labelval' => $labinvoice_patient,
							'label' => $labinvoice_id,
							'labinvoice_id'=>$labinvoice_id,
							'labinvoice_patientid'=>$labinvoice_patientid,
							'labinvoice_age'=>$labinvoice_age,
							'labinvoice_gender'=>$labinvoice_gender,
							'labinvoice_mobile'=>$labinvoice_mobile,
							'labinvoice_doctor'=>$labinvoice_doctor,
							'labinvoice_address'=>$labinvoice_address
							);
	}
}
$patientdata = json_encode($patientdata);
*/

$drdata = '';
$sqldr = "select * from doctorentry where doctor_category='doctor' order by doctor_name asc";
$opregistrationquery2 = mysqli_query($conn, $sqldr);
if($opregistrationquery2 && mysqli_num_rows($opregistrationquery2)>0){

	while ($opregistrationrow = mysqli_fetch_array($opregistrationquery2)){
		$doctor_id = $opregistrationrow['doctor_id'];
		$doctor_name = $opregistrationrow['doctor_name'];
		$drdata[] =array( 'labelval' => $doctor_name,
							'label' => $doctor_name,
							'doctor_name'=>$doctor_name
							);
		}
	}
$drdata = json_encode($drdata);

?>

<link rel="stylesheet" href="autocomplete/jquery-ui.css">
<script src="autocomplete/jquery-ui.min.js"></script>

<script language="JavaScript" type="text/javascript">
function disableEnterKey(e)
	{
	var evt = e || window.event; 
		var key = evt.keyCode;
		//alert (key);
		if(key == 13) // if enter key press
		{
			//alert ("Enter Key Press");
			return false;
		}
	}
</script>	
<style type="text/css">
.ui-autocomplete { height:auto !important; max-height:300px; overflow:auto; background:#FFF; border:1px solid #CCC;
 border-radius-bottom-left:4px; width:200px;}
.search_row{text-align:left;}
.ui-autocomplete li{ min-height:30px; border-bottom:1px dotted #CCC; padding:10px; text-align:left;}
</style>

<?php include("calculate-stoolre.php");?>
<?php include("labdataquery.php");?>

<article class="bottomcontent">
  <h3>Stool RE Examination Test Report Entry</h3>
   <content>
	<?php
		if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
		echo "<p class=\"red12bold\">You have missing Something</p>";
		}
		elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
		echo "<p class=\"red12bold\">Error occured! Could not insert.</p>";   
		}
		elseif(isset($_GET['message']) && $_GET['message']=='save-successfully'){
		echo "<p class=\"red12bold\">Information insert successfully. Click Print Button To Print or View Previous Bill <td width=\"30\" align=\"center\" ><a onclick=\"PrintDiv();\"><input type=\"button\" name=\"user\" id=\"user\" required value=\"Print\" class=\"tdclass\"  /></a></td></p>";   
		}
    ?>          
<form action="save_testreport_stoolre.php" name="frmcontact" onsubmit="return checkcontactform();" onKeyDown="return disableEnterKey(event)" method="post" enctype="multipart/form-data">
<table class="tableclass" border="0" bgcolor="#89C5C5" cellpadding="2">
  <tr>
    <input type="hidden" name="user" id="user" required value="<?php echo $_SESSION['fullname'];?>" class="tdclass" />
    <td width="150" align="right">Patient Name</td>
    <td><input type="text" name="labreport_patient" id="labreport_patient" value="<?php echo $labinvoice_patient;?>" required class="tdclass" /></td>
     <td>Patient ID</td>
     <td><input type="text" name="labreport_patientid" id="labreport_patientid" value="<?php echo $labinvoice_patientid;?>" required  class="tdclass" /></td>
    <td align="right">Age </td>
    <td><input type="text" name="labreport_age" id="labreport_age" value="<?php echo $labinvoice_age;?>" required class="tdclass2" /></td>
    <td align="right">Gender </td>
    <td><input type="text" name="labreport_gender" id="labreport_gender" value="<?php echo $labinvoice_gender;?>" class="tdclass2" /></td>
    <td align="right">Mobile </td>
    <td><input type="text" name="labreport_mobile" id="labreport_mobile" value="<?php echo $labinvoice_mobile;?>" class="tdclass" />
    <input type="hidden" name="labreport_ward" id="labreport_ward" value="<?php echo $labinvoice_ward;?>" class="tdclass" /></td>
  </tr>
  <td></td>
  <tr>
    <td align="right"><b>Invoice No. </b></td>
    <td><input type="text" placeholder="Search by Bill No." value="<?php echo $labinvoice_id;?>" name="labreport_labinvoiceid" id="labreport_labinvoiceid" class="tdclass2" /></td>
    
    <td width="120" align="right">Ref. Doctor </td>
    <td><input type="text" name="labreport_doctor" id="labreport_doctor" value="<?php echo $labinvoice_doctor;?>" class="tdclass2"  /></td>
    
    <td align="right">Date </td>
    <td><input type="text" name="labreport_date" readonly id="labreport_date" value="<?php echo date('Y-m-d');?>" class="tdclass2"  /></td>
    
    <td align="right">Delivery </td>
    <td><input type="text" name="labreport_deliverydate" id="labreport_deliverydate" placeholder="12.12.2015" class="tdclass2" /></td>
    <td align="right">Address </td>
    <td><textarea type="text" name="labreport_address" id="labreport_address" value="<?php echo $labinvoice_address;?>" class="tdclass" /></textarea></td>
      <input type="hidden" name="machine_name" id="machine_name" value="<?php echo $machine_name;?>">
      <input type="hidden" name="sample" id="sample" value="<?php echo $labinvoicedetails_sample;?>">
    </tr>
</table>
 
     <table class="tableclass"  style=" border:2px solid #FFF;" bgcolor="#c0d2ff" cellpadding="1">
      <tr ><td><strong>PHYSICAL EXAMINATION</strong></td></tr>
        <tr>
        <td>Item Name</td>
        <td>Result Value</td>
       </tr>
		 <?php
   
	$sqllabitem = "select * from labitem where labitem_category='STOOL RE' AND labitem_sub_category='PHYSICAL EXAMINATION'order by labitem_id asc";
	  	$labitemquery = mysqli_query($conn, $sqllabitem);
			if($labitemquery && mysqli_num_rows($labitemquery)>0){
				while ($labitemrow = mysqli_fetch_array($labitemquery))
			
			 {
               		
				$labitem_id = $labitemrow['labitem_id'];
				$labitem_category = $labitemrow['labitem_category'];
				$labitem_sub_category = $labitemrow['labitem_sub_category'];
				$labitem_name = $labitemrow['labitem_name'];
				$labitem_unit = $labitemrow['labitem_unit'];
				$labitem_refvalue = $labitemrow['labitem_refvalue'];
					
			?>
           <tr>
             <td width="322"><input type="text" name="labreport_item[]"  id="labreport_item" required  value="<?php echo $labitem_name;?>"  class="tdclass itemname" />
                            <input type="hidden" name="labitem_id[]"  id="labitem_id"   value="<?php echo $labitem_id; ?>"  class="tdclass" />
                            <input type="hidden" name="labreport_category[]"  value="<?php echo $labitem_category; ?>" class="tdclass"  />
                            <input type="hidden" name="labreport_sub_category[]"  value="<?php echo $labitem_sub_category; ?>" class="tdclass"  />
                            <input type="hidden" name="reportname" id="reportname"  value="STOOL RE" class="tdclass"  />
           	</td>
             <td width="187">
             <textarea name="labreport_result[]" id="labreport_result[]"><?php echo $labitem_refvalue; ?></textarea>
             </td>
            <td></td>
          </tr>
          <?php
			}
		}
        ?>
     </table>
     
      <table class="tableclass"  style=" border:2px solid #FFF;" bgcolor="#c0d2ff" cellpadding="1">
        <tr><td><strong>CHEMICAL EXAMINATION</strong></td></tr>
        <tr>
            <td>Item Name</td>
            <td>Result Value</td>
         </tr>
		<?php
		$sqllabitem = "select * from labitem where labitem_category='STOOL RE' AND  labitem_sub_category='CHEMICAL EXAMINATION' order by labitem_id asc";
	  	$labitemquery = mysqli_query($conn, $sqllabitem);
			if($labitemquery && mysqli_num_rows($labitemquery)>0){
				while ($labitemrow = mysqli_fetch_array($labitemquery))
			 	{
				$labitem_id = $labitemrow['labitem_id'];
				$labitem_category = $labitemrow['labitem_category'];
				$labitem_sub_category = $labitemrow['labitem_sub_category'];
				$labitem_name = $labitemrow['labitem_name'];
				$labitem_unit = $labitemrow['labitem_unit'];
				$labitem_refvalue = $labitemrow['labitem_refvalue'];
			?>
            <tr>
             <td width="322">
                <input type="text" name="labreport_item[]" id="labreport_item" required value="<?php echo $labitem_name;?>"  class="tdclass itemname" />
                <input type="hidden" name="labitem_id[]" id="labitem_id" value="<?php echo $labitem_id; ?>"  class="tdclass" />
                <input type="hidden" name="labreport_category[]" value="<?php echo $labitem_category; ?>" class="tdclass"  />
                <input type="hidden" name="labreport_sub_category[]" value="<?php echo $labitem_sub_category; ?>" class="tdclass"  />
             </td>
             <td width="187">
             <textarea name="labreport_result[]" id="labreport_result[]"><?php echo $labitem_refvalue; ?></textarea>
             </td><td>
             </td>
          </tr>
          <?php
			}
		}
        ?>
     </table>
     
     <table class="tableclass"  style=" border:2px solid #FFF;" bgcolor="#c0d2ff" cellpadding="1">
        <tr><td><strong>MICROSCOPIC EXAMINATION</strong></td></tr>
        <tr>
            <td>Item Name</td>
            <td>Result Value</td>
        </tr>
	<?php
	$sqllabitem = "select * from labitem where labitem_category='STOOL RE' AND  labitem_sub_category='MICROSCOPIC EXAMINATION' order by labitem_id asc";
	  	$labitemquery = mysqli_query($conn, $sqllabitem);
			if($labitemquery && mysqli_num_rows($labitemquery)>0){
				while ($labitemrow = mysqli_fetch_array($labitemquery))
			 	{
				$labitem_id = $labitemrow['labitem_id'];
				$labitem_category = $labitemrow['labitem_category'];
				$labitem_sub_category = $labitemrow['labitem_sub_category'];
				$labitem_name = $labitemrow['labitem_name'];
				$labitem_unit = $labitemrow['labitem_unit'];
				$labitem_refvalue = $labitemrow['labitem_refvalue'];
			?>
            <tr>
             <td width="322"><input type="text" name="labreport_item[]" id="labreport_item" required value="<?php echo $labitem_name;?>"  class="tdclass itemname" />
                            <input type="hidden" name="labitem_id[]" id="labitem_id" value="<?php echo $labitem_id; ?>" class="tdclass" />
                            <input type="hidden" name="labreport_category[]"  value="<?php echo $labitem_category; ?>" class="tdclass"  />
                            <input type="hidden" name="labreport_sub_category[]"  value="<?php echo $labitem_sub_category; ?>" class="tdclass"  />
          	</td>
             <td width="187"><textarea name="labreport_result[]" id="labreport_result[]"><?php echo $labitem_refvalue; ?></textarea></td>
            <td>
           </td>
          </tr>
          <?php
			}
		}
        ?>
     </table>
     
     <table class="tableclass" style=" border:2px solid #FFF;" bgcolor="#c0d2ff" cellpadding="1">
      <tr><td><strong>OVA  OF</strong></td></tr>
        <tr>
        <td>Item Name</td>
        <td>Result Value</td>
        </tr>
		 <?php
		$sqllabitem = "select * from labitem where labitem_category='STOOL RE' AND  labitem_sub_category='OVA OF' order by labitem_id asc";
	  	$labitemquery = mysqli_query($conn, $sqllabitem);
			if($labitemquery && mysqli_num_rows($labitemquery)>0){
				while ($labitemrow = mysqli_fetch_array($labitemquery))
			 	{
				$labitem_id = $labitemrow['labitem_id'];
				$labitem_category = $labitemrow['labitem_category'];
				$labitem_sub_category = $labitemrow['labitem_sub_category'];
				$labitem_name = $labitemrow['labitem_name'];
				$labitem_unit = $labitemrow['labitem_unit'];
				$labitem_refvalue = $labitemrow['labitem_refvalue'];
			?>
            <tr>
             <td width="322"> <input type="text" name="labreport_item[]"  id="labreport_item" required  value="<?php echo $labitem_name;?>"  class="tdclass itemname" />
              <input type="hidden" name="labitem_id[]"  id="labitem_id"   value="<?php echo $labitem_id; ?>"  class="tdclass" />
            	<input type="hidden" name="labreport_category[]"  value="<?php echo $labitem_category; ?>" class="tdclass"  />
             <input type="hidden" name="labreport_sub_category[]"  value="<?php echo $labitem_sub_category; ?>" class="tdclass"  />
          </td>
             <td width="187">
             <textarea name="labreport_result[]" id="labreport_result[]"><?php echo $labitem_refvalue; ?></textarea>
             </td>
            <td>
             </td>
          </tr>
          <?php
                }
            }
        ?>
     </table>
     
     <table class="tableclass"  style=" border:2px solid #FFF;" bgcolor="#c0d2ff" cellpadding="1">
     <tr><td><strong>ON REQUEST</strong></td></tr>
        <tr>
            <td>Item Name</td>
            <td>Result Value</td>
       </tr>
	<?php
	$sqllabitem = "select * from labitem where labitem_category='STOOL RE' AND  labitem_sub_category='ON REQUEST' order by labitem_id asc";
	  	$labitemquery = mysqli_query($conn, $sqllabitem);
			if($labitemquery && mysqli_num_rows($labitemquery)>0){
				while ($labitemrow = mysqli_fetch_array($labitemquery))
			 	{
				$labitem_id = $labitemrow['labitem_id'];
				$labitem_category = $labitemrow['labitem_category'];
				$labitem_sub_category = $labitemrow['labitem_sub_category'];
				$labitem_name = $labitemrow['labitem_name'];
				$labitem_unit = $labitemrow['labitem_unit'];
				$labitem_refvalue = $labitemrow['labitem_refvalue'];
			?>
            <tr>
             <td width="322"> 
                <input type="text" name="labreport_item[]"  id="labreport_item" required  value="<?php echo $labitem_name;?>"  class="tdclass itemname" />
                <input type="hidden" name="labitem_id[]"  id="labitem_id"   value="<?php echo $labitem_id; ?>"  class="tdclass" />
                <input type="hidden" name="labreport_category[]"  value="<?php echo $labitem_category; ?>" class="tdclass"  />
                <input type="hidden" name="labreport_sub_category[]"  value="<?php echo $labitem_sub_category; ?>" class="tdclass"  />
          	</td>
             <td width="187">
             <textarea name="labreport_result[]" id="labreport_result[]"><?php echo $labitem_refvalue; ?></textarea>
             </td>
            <td>
             </td>
          </tr>
          <?php
			}
		}
        ?>
     </table>
     
     <table class="tableclass"  style=" border:2px solid #FFF;" bgcolor="#c0d2ff" cellpadding="1">
              <tr><td><strong>OTHERS</strong></td></tr>
        <tr>
            <td>Item Name</td>
            <td>Result Value</td>
        </tr>
	<?php
	$sqllabitem = "select * from labitem where labitem_category='STOOL RE' AND  labitem_sub_category='OTHERS' order by labitem_id asc";
	  	$labitemquery = mysqli_query($conn, $sqllabitem);
			if($labitemquery && mysqli_num_rows($labitemquery)>0){
				while ($labitemrow = mysqli_fetch_array($labitemquery))
			 	{
				$labitem_id = $labitemrow['labitem_id'];
				$labitem_category = $labitemrow['labitem_category'];
				$labitem_sub_category = $labitemrow['labitem_sub_category'];
				$labitem_name = $labitemrow['labitem_name'];
				$labitem_unit = $labitemrow['labitem_unit'];
				$labitem_refvalue = $labitemrow['labitem_refvalue'];
			?>
            <tr>
                <td width="322"> 
                <input type="text" name="labreport_item[]"  id="labreport_item" required  value="<?php echo $labitem_name;?>"  class="tdclass itemname" />
                <input type="hidden" name="labitem_id[]"  id="labitem_id"   value="<?php echo $labitem_id; ?>"  class="tdclass" />
                <input type="hidden" name="labreport_category[]"  value="<?php echo $labitem_category; ?>" class="tdclass"  />
                <input type="hidden" name="labreport_sub_category[]"  value="<?php echo $labitem_sub_category; ?>" class="tdclass"  />
                </td>
             <td width="187">
             <textarea name="labreport_result[]" id="labreport_result[]"><?php echo $labitem_refvalue; ?></textarea>
             </td>
            <td>
             </td>
          </tr>
          <?php
			}
		}
        ?>
     </table>
     
   <table class="tableclass"  style=" border:2px solid #FFF;" bgcolor="#c0d2ff" cellpadding="1">
    <tr>
	 <td>
         <input type="hidden" name="labreport_id" id="labreport_id" value="<?php echo $labreport_id;?>">
         <input type="submit" value=" save " name="submit_labtestreport" id="submit_labtestreport" class="tdclass" />
         &emsp;
         <input type="button" name="patient" id="patient" value="Cancel" class="tdclass"/>
     </td>
  	</tr>
</table>
</form>         
          
</content>
</article>

<div id="divToPrint" style="display:none; ">
 <article class="bottomcontent" style=" width:94%; margin:0 auto; height:840px;font-family:Cambria, 'Hoefler Text', 'Liberation Serif', Times, 'Times New Roman', serif;">
	<?php
		$labreport_id = $_GET['labreport_id'];
        $labreport_sql = "select * from labreport where labreport_id = $labreport_id order by labreport_id desc";
        $labreportquery = mysqli_query($conn, $labreport_sql);
        if($labreportquery && mysqli_num_rows($labreportquery)>0){
            while ($onerow = mysqli_fetch_array($labreportquery)){
               	$labreport_id = $onerow['labreport_id'];
                $labreport_labinvoiceid = $onerow['labreport_labinvoiceid'];
                $labreport_patientid = $onerow['labreport_patientid'];
                $labreport_patient = $onerow['labreport_patient'];
                $labreport_age = $onerow['labreport_age'];
                $labreport_gender = $onerow['labreport_gender'];
                $labreport_address = $onerow['labreport_address'];
                $labreport_ward = $onerow['labreport_ward'];
              	$labreport_doctor = $onerow['labreport_doctor'];
              	$labreport_category = $onerow['labreport_category'];
              	$reportname = $onerow['reportname'];
              	$machine_name = $onerow['machine_name'];		
                $user = $onerow['user'];		
                $labreport_mobile = $onerow['labreport_mobile'];
                $labreport_date=$onerow['labreport_date'];
				$method= $onerow['method'];
				$sample= $onerow['sample'];
			?>
            <?php include('labtop.php');?>
            <table width="98%" align="center" style="padding:20px 0 40px 0;font-size:17px;">
                <tr height="20">
               	 <td style="text-align:center;"><strong style="border:2px solid">STOOL RE EXAMINATION REPORT</strong> </td>
                </tr>
            </table>
           <div style=" float:left; width:700px">              
          <table width="350" align="left" style=" line-height:15px;font-size:15px;">
                     
            <tr><td width="110" align="left" style=" font-size:13px; padding: 0 0 15px 0">
             <strong style=" border-bottom:2px solid">PHYSICAL EXAMINATION</strong> </td></tr>
             
            <?php
            $labreportdetails_sql = "select * from labreport_details where labreport_id = $labreport_id and labreportdetails_category='STOOL RE' AND labreportdetails_sub_category='PHYSICAL EXAMINATION' order by auto_number asc";
            $labreportdetailsquery = mysqli_query($conn, $labreportdetails_sql);
            if($labreportdetailsquery && mysqli_num_rows($labreportdetailsquery)>0){
                $i=0;
                while($page_inforow = mysqli_fetch_array($labreportdetailsquery)){
                    $i++;
                    $auto_number = $page_inforow['auto_number'];
                    $labreportdetails_item = $page_inforow['labreportdetails_item'];
                    $labreportdetails_unit = $page_inforow['labreportdetails_unit'];
                    $labreportdetails_refvalue = $page_inforow['labreportdetails_refvalue'];
                    $labreportdetails_result = $page_inforow['labreportdetails_result'];
                     ?>
                   		<tr>
                           <td width="80"> <?php echo $labreportdetails_item;?></td>
                            <td width="80">: <?php echo $labreportdetails_result;?></td>
                         </tr>
                    <?php
                }
            }
            ?>
           </table>
           <table width="350" align="right" style=" line-height:15px;font-size:15px;">
           <tr><td width="110" style=" font-size:13px; padding: 0 0 15px 0"><strong style=" border-bottom:2px solid">CHEMICAL EXAMINATION</strong> </td></tr>
                <?php
                $labreportdetails_sql = "select * from labreport_details where labreport_id = $labreport_id and labreportdetails_category='STOOL RE' AND labreportdetails_sub_category='CHEMICAL EXAMINATION' order by auto_number asc";
                $labreportdetailsquery = mysqli_query($conn, $labreportdetails_sql);
                if($labreportdetailsquery && mysqli_num_rows($labreportdetailsquery)>0){
                    $i=0;
                    while($page_inforow = mysqli_fetch_array($labreportdetailsquery)){
                        $i++;
                        $auto_number = $page_inforow['auto_number'];
                        $labreportdetails_item = $page_inforow['labreportdetails_item'];
                        $labreportdetails_unit = $page_inforow['labreportdetails_unit'];
                        $labreportdetails_refvalue = $page_inforow['labreportdetails_refvalue'];
                        $labreportdetails_result = $page_inforow['labreportdetails_result'];
                         ?>
                        <tr>
                           <td width="80"> <?php echo $labreportdetails_item;?></td>
                            <td width="80">: <?php echo $labreportdetails_result;?></td>
                         </tr>
                        <?php
						}
					}
                ?>
               
               </table>
               </div>
              <br> 
        <div style=" float:left;width:700px">              
          <table width="350" align="left" style=" line-height:15px;font-size:15px;">
            <tr><td width="110" align="left" style=" font-size:13px; padding: 0 0 15px 0">
             <strong style=" border-bottom:2px solid">MICROSCOPIC EXAMINATION</strong> </td></tr>
            <?php
           $labreportdetails_sql = "select * from labreport_details where labreport_id = $labreport_id and labreportdetails_category='STOOL RE' AND labreportdetails_sub_category='MICROSCOPIC EXAMINATION' order by auto_number asc";
            $labreportdetailsquery = mysqli_query($conn, $labreportdetails_sql);
            if($labreportdetailsquery && mysqli_num_rows($labreportdetailsquery)>0){
                $i=0;
                while($page_inforow = mysqli_fetch_array($labreportdetailsquery)){
                    $i++;
                    $auto_number = $page_inforow['auto_number'];
                    $labreportdetails_item = $page_inforow['labreportdetails_item'];
                    $labreportdetails_unit = $page_inforow['labreportdetails_unit'];
                    $labreportdetails_refvalue = $page_inforow['labreportdetails_refvalue'];
                    $labreportdetails_result = $page_inforow['labreportdetails_result'];
                     ?>
                    <tr>
                       <td width="80"> <?php echo $labreportdetails_item;?></td>
                        <td width="80">: <?php echo $labreportdetails_result;?></td>
                     </tr>
                    <?php
					}
				}
            	?>
           </table>
           <table width="350" align="right" style=" line-height:15px;font-size:15px;">
           <tr><td width="110" style=" font-size:13px; padding: 0 0 15px 0"><strong style=" border-bottom:2px solid">OVA OF</strong> </td></tr>
                <?php
                $labreportdetails_sql = "select * from labreport_details where labreport_id = $labreport_id and labreportdetails_category='STOOL RE' AND labreportdetails_sub_category='OVA OF' order by auto_number asc";
                $labreportdetailsquery = mysqli_query($conn, $labreportdetails_sql);
                if($labreportdetailsquery && mysqli_num_rows($labreportdetailsquery)>0){
                    $i=0;
                    while($page_inforow = mysqli_fetch_array($labreportdetailsquery)){
                        $i++;
                        $auto_number = $page_inforow['auto_number'];
                        $labreportdetails_item = $page_inforow['labreportdetails_item'];
                        $labreportdetails_unit = $page_inforow['labreportdetails_unit'];
                        $labreportdetails_refvalue = $page_inforow['labreportdetails_refvalue'];
                        $labreportdetails_result = $page_inforow['labreportdetails_result'];
                         ?>
                        <tr>
                           <td width="80"> <?php echo $labreportdetails_item;?></td>
                            <td width="80">: <?php echo $labreportdetails_result;?></td>
                         </tr>
                        <?php
						}
					}
                ?>
               
               </table>
               </div>
              
            <div style=" float:left;width:700px"> 
            <table width="350" align="left" style=" line-height:15px;font-size:15px;">
           <tr><td width="110" style=" font-size:13px; padding: 0 0 15px 0"><strong style=" border-bottom:2px solid">ON REQUEST</strong> </td></tr>
               <?php
                $labreportdetails_sql = "select * from labreport_details where labreport_id = $labreport_id and labreportdetails_category='STOOL RE' AND labreportdetails_sub_category='ON REQUEST' order by auto_number asc";
                $labreportdetailsquery = mysqli_query($conn, $labreportdetails_sql);
                if($labreportdetailsquery && mysqli_num_rows($labreportdetailsquery)>0){
                    $i=0;
                    while($page_inforow = mysqli_fetch_array($labreportdetailsquery)){
                        $i++;
                        $auto_number = $page_inforow['auto_number'];
                        $labreportdetails_item = $page_inforow['labreportdetails_item'];
                        $labreportdetails_unit = $page_inforow['labreportdetails_unit'];
                        $labreportdetails_refvalue = $page_inforow['labreportdetails_refvalue'];
                        $labreportdetails_result = $page_inforow['labreportdetails_result'];
                         ?>
                       <tr>
                           <td width="80"> <?php echo $labreportdetails_item;?></td>
                            <td width="80">: <?php echo $labreportdetails_result;?></td>
                         </tr>
                        <?php
                    }
                }
                ?>
            </table>
            <table width="350" align="right" style=" line-height:15px;font-size:15px;">
           <tr><td width="110" style=" font-size:13px; padding: 0 0 15px 0"><strong style=" border-bottom:2px solid">OTHERS</strong> </td></tr>
               <?php
                $labreportdetails_sql = "select * from labreport_details where labreport_id = $labreport_id and labreportdetails_category='STOOL RE' AND labreportdetails_sub_category='OTHERS' order by auto_number asc";
                $labreportdetailsquery = mysqli_query($conn, $labreportdetails_sql);
                if($labreportdetailsquery && mysqli_num_rows($labreportdetailsquery)>0){
                    $i=0;
                    while($page_inforow = mysqli_fetch_array($labreportdetailsquery)){
                        $i++;
                        $auto_number = $page_inforow['auto_number'];
                        $labreportdetails_item = $page_inforow['labreportdetails_item'];
                        $labreportdetails_unit = $page_inforow['labreportdetails_unit'];
                        $labreportdetails_refvalue = $page_inforow['labreportdetails_refvalue'];
                        $labreportdetails_result = $page_inforow['labreportdetails_result'];
                         ?>
                       <tr>
                           <td width="80"> <?php echo $labreportdetails_item;?></td>
                            <td width="80">: <?php echo $labreportdetails_result;?></td>
                         </tr>
                        <?php
                    }
                }
                ?>
            </table>
                 </div>    
			<?php
            }
        }
    ?>

</article>
    <?php include('labbottom.php'); ?>
</div>