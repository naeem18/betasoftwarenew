<script type="text/javascript" language="javascript">
	function removetablerow7(idvalue){
		var conf = confirm("Do you sure want to delete this ID="+idvalue+" from this Table ");
		if(conf)
			window.location='delete_table_row7.php?idvalue='+idvalue;
		}
</script>

<?php
$searchstr='';
if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
{
	$transactiondatefrom = $_REQUEST['ADate1'];
	$transactiondateto = $_REQUEST['ADate2'];
	
	$name = $_REQUEST['name'];
	$type = $_REQUEST['type'];
	$ward = $_REQUEST['ward'];
	
	if($name !=''){
		$searchstr .= " and name like '%$name%'";
	}
 	elseif($ward !=''){
		$searchstr .= " and ward like '%$ward%'";
	}
	elseif($type !=''){
		$searchstr .= " and type like '%$type%'";
	}
 }
else
{
	$transactiondatefrom = date('Y-m-d', strtotime('-0 day'));
	$transactiondateto = date('Y-m-d');
}
?>

<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td valign="top" align="center">
    	<form name="cbform1" method="post" action="index.php?p=advcollectionreport">
            <table width="100%" border="1" align="center" cellpadding="1" cellspacing="0" bordercolor="#666666" style="border-collapse: collapse">
              <tbody>
                <tr bgcolor="#011E6A">
                  <td colspan="16" bgcolor="#CCCCCC" align="center"><strong>Search Date </strong></td>
                </tr>           
                <tr>
                    <td>From:</td>
                    <td>
                        <input name="ADate1" id="ADate1" style="border: 1px solid #001E6A" value="<?php echo $transactiondatefrom; ?>" size="6" readonly onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
                    </td>
                    <td>To:</td>
                    <td>
                        <input name="ADate2" id="ADate2" style="border: 1px solid #001E6A" value="<?php echo $transactiondateto; ?>" size="6" readonly onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate2')" style="cursor:pointer"/>
                    </td>
                    
                    
                    <td>Name</td>
            	    <td><input size="12" type="text" name="name" id="name" /></td>
                  
                    <td>Ward</td>
            	    <td><input size="12" type="text" name="ward" id="ward" /></td>
                    
                    <td>Type</td>
            	    <td><input type="text" size="12" name="type" id="type" /></td>
                   
                    <td><input style="border: 1px solid #001E6A" type="submit" value="Search" name="Submit" /></td>
                    <td><input name="print" type="button" id="print" style="border: 1px solid #001E6A" value="Print" onClick="PrintDiv();" />
                    </td>
                </tr>
              </tbody>
            </table>
		</form>
    </td>
</tr>

	<td>
 		<?php 
 		$datetime1 = new DateTime($transactiondatefrom);
		$datetime2 = new DateTime($transactiondateto);
		$interval = $datetime1->diff($datetime2);
		$totaldays = $interval->format('%a');
		if($datetime1<$datetime2){
			$fromdate = $transactiondatefrom;
			$todate = $transactiondateto;
		}
		else{
			$fromdate = $transactiondateto;
			$todate = $transactiondatefrom;
		}
		?>
        
       <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1" cellspacing="0" cellpadding="2">
        <tbody>
         <tr>
            <td colspan="14" bgcolor="#f2f2f2" align="center" style="color:#03F; border:1px solid #03F;">
            	<strong><?php echo $hospitaldata_name;?></strong><br>
                <b>Admission/Advanced Collection Report:: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></b>
            </td>
          </tr>
            <tr bgcolor="#77F7AA">
                <td>Print</td>
                <td>Type</td>
                <td>Received Date</td>
                <td>Bill No.</td>
                <td>P.ID</td>
                <td>Patient Code</td>
                <td>Name</td>
                <td>Cabin</td>
                <td>Received Amount</td>
                <td>Note</td>
                <td>User</td>
                <td>Updated User </td>
                <td>Updated Date </td>
                <td>Action</td>              
              </tr>
		
		<?php
		$totaladvanced='0.00';
 		for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
	  	$labinvoice_sql = "select * from advanced where advanced_date between '$newfromdate' and '$newtodate' $searchstr order by advanced_id asc";
        $labinvoicequery = mysqli_query($conn, $labinvoice_sql);
        if($labinvoicequery && mysqli_num_rows($labinvoicequery)>0){
            while ($onerow = mysqli_fetch_array($labinvoicequery)){
               	$opregistration_id = $onerow['opregistration_id'];
              	$opregistration_code = $onerow['opregistration_code'];
              	$advanced_id = $onerow['advanced_id'];
                $advanced = $onerow['advanced'];
                $ward = $onerow['ward'];
                $note = $onerow['note'];
                $advanced_date = $onerow['advanced_date'];
				$advanced_update = $onerow['advanced_update'];
				$name = $onerow['name'];
                $user = $onerow['user'];	
				$updateuser = $onerow['updateuser'];	
				$type = $onerow['type'];	
				
				$sqlop = "select status, opregistration_id from opregistration where status !='Relesed' AND opregistration_id = $opregistration_id";
				$exec3 = mysqli_query($conn, $sqlop) or die ("Error in Query3".mysql_error());
				$onerow = mysqli_fetch_array($exec3);
 					$status = $onerow['status'];
 					
				$action = "<a href=\"index.php?p=advancedcollectionedit&advanced_id=$advanced_id\" target=\"_blank\">Advanced Update</a> 
				<a href=\"javascript:void(0)\" onclick=\"removetablerow66($advanced_id)\"></a>";
 				
				$actionAd = "<a href=\"index.php?p=admissionamtedit&advanced_id=$advanced_id\" target=\"_blank\">Admission Fee Update</a>";
 				$action2 = "<a href=\"index.php?p=printadvancedinvoice&advanced_id=$advanced_id\" target=\"_blank\">print</a>";
				$totaladvanced  = $totaladvanced + $advanced;
				?>
                <tr bgcolor="#fff">
                    <td><?php echo $action2;?></td>
                    <td><?php echo $type; ?></td>
                    <td><?php echo $advanced_date; ?></td>
                    <td><?php echo $advanced_id; ?></td>
                    <td><?php echo $opregistration_id; ?></td>
                    <td><?php echo $opregistration_code; ?></td>
                    <td><?php echo $name; ?></td>
                    <td><?php echo $ward; ?></td>
                    <td><?php echo $advanced; ?></td>
                    <td><?php echo $note; ?></td>
                    <td><?php echo $user; ?></td>
                    <td><?php echo $updateuser; ?></td>
                    <td><?php echo $advanced_update; ?></td>
                    <td><?php if($_SESSION['employeename']=='ADMINISTRATOR' or $_SESSION['employeename']=='SUPERADMINISTRATOR' && $type=='Advanced'){ echo $action; }?>
                    <?php if($_SESSION['employeename']=='ADMINISTRATOR' or $_SESSION['employeename']=='SUPERADMINISTRATOR' && $type=='Admission Fee'){ echo $actionAd; }?></td>
              	</tr>
                <?php
                	}
				}
			}
		?>
        	<tr bgcolor="#f2f2f2">
              <td colspan="8" valign="center"  align="right"><strong>Total : </strong></td>
              <td colspan="5" valign="center" >
              <strong><?php echo number_format($totaladvanced, 2, '.', ''); ?></strong></td>
            </tr>
           <tbody>
        </table>
        </td>
      
	<td align="center" id="divToPrint" style="display:none">
		<?php 
		$datetime1 = new DateTime($transactiondatefrom);
		$datetime2 = new DateTime($transactiondateto);
		$interval = $datetime1->diff($datetime2);
		$totaldays = $interval->format('%a');
		if($datetime1<$datetime2){
			$fromdate = $transactiondatefrom;
			$todate = $transactiondateto;
		}
		else{
			$fromdate = $transactiondateto;
			$todate = $transactiondatefrom;
		}
		?>
        
        <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1" cellspacing="0" cellpadding="2">
        <tbody>
         <tr>
            <td colspan="14" bgcolor="#f2f2f2" align="center" style="color:#03F; border:1px solid #03F;">
            	<strong><?php echo $hospitaldata_name;?></strong><br>
                <b>Advanced Collection Report:: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></b>
            </td>
          </tr>
            <tr bgcolor="#77F7AA">
                <td>Type</td>
                <td>Date</td>
                <td>Bill No.</td>
                <td>P.ID</td>
                <td>Patient Code</td>
                <td>Name</td> <td>Cabin</td>
                <td>Advanced Amount</td>
                <td>Note</td>
                <td>User</td>
                <td>Update User </td>
             </tr>
		
		<?php
		$totaladvanced='0.00';
 		for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
	  	$labinvoice_sql = "select * from advanced where advanced_date between '$newfromdate' and '$newtodate' $searchstr order by advanced_id asc";
        $labinvoicequery = mysqli_query($conn, $labinvoice_sql);
        if($labinvoicequery && mysqli_num_rows($labinvoicequery)>0){
            while ($onerow = mysqli_fetch_array($labinvoicequery)){
               	$opregistration_id = $onerow['opregistration_id'];
              	$opregistration_code = $onerow['opregistration_code'];
              	$advanced_id = $onerow['advanced_id'];
                $advanced = $onerow['advanced'];
                $ward = $onerow['ward'];
                $note = $onerow['note'];
                $advanced_date = $onerow['advanced_date'];
				$advanced_update = $onerow['advanced_update'];
				$name = $onerow['name'];
                $user = $onerow['user'];	
				$type = $onerow['type'];	
				
				$sqlop = "select status, opregistration_id from opregistration where status !='Relesed' AND opregistration_id = $opregistration_id";
				$exec3 = mysqli_query($conn, $sqlop) or die ("Error in Query3".mysql_error());
				$onerow = mysqli_fetch_array($exec3);
			
					$status = $onerow['status'];
					
				if($status !='Released'){	
				$action = "<a href=\"index.php?p=advancedcollectionedit&advanced_id=$advanced_id\">Edit</a> | 
				<a href=\"javascript:void(0)\" onclick=\"removetablerow66($advanced_id)\">Remove</a>";
				}
				
				$action2 = "<a href=\"index.php?p=printadvancedinvoice&advanced_id=$advanced_id\" target=\"_blank\">print</a>";
				$totaladvanced  = $totaladvanced + $advanced;
				?>
                <tr bgcolor="#fff">
                     <td><?php echo $type; ?></td>
                    <td><?php echo $advanced_date; ?></td>
                    <td><?php echo $advanced_id; ?></td>
                    <td><?php echo $opregistration_id; ?></td>
                    <td><?php echo $opregistration_code; ?></td>
                    <td><?php echo $name; ?></td>
                    <td><?php echo $ward; ?></td>
                    <td><?php echo $advanced; ?></td>
                    <td><?php echo $note; ?></td>
                    <td><?php echo $user; ?></td>
                    <td><?php echo $advanced_update; ?></td>
               	</tr>
                <?php
                	}
				}
			}
		?>
        	<tr bgcolor="#f2f2f2">
              <td colspan="7" valign="center"  align="right"><strong>Total : </strong></td>
              <td colspan="5" valign="center" >
              <strong><?php echo number_format($totaladvanced, 2, '.', ''); ?></strong></td>
            </tr>
           <tbody>
        </table>
        </td>
</table>