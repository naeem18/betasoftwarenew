<?php
require('labdd.php'); // DB connection
require 'mailAttached/PHPMailer/PHPMailer.php'; // make sure PHPMailer is included
 require 'phpmailer/phpmailer';

date_default_timezone_set("Asia/Dhaka");

// 🔍 Filter
$from = isset($_GET['from']) && !empty($_GET['from']) ? $_GET['from'] : date('Y-m-d');
$to   = isset($_GET['to']) && !empty($_GET['to']) ? $_GET['to'] : date('Y-m-d');

// 📤 Email settings
$recipient = "nazir121212@gmail.com"; // CHANGE to your recipient
$subject = "Lab Invoice Report: $from to $to";
$body = "Please find attached the lab invoice report for $from to $to.";

// 🧾 Generate CSV content
$sql = "SELECT labinvoice_id, labinvoice_patient, labinvoice_mobile, labinvoice_subtotal, labinvoice_totaldisc, labinvoice_subtotalafterdisc, labinvoice_receiveamount, labinvoice_due
        FROM labinvoice
        WHERE dstatus != 'Deleted' AND txstatus != 'Deleted' AND DATE(labinvoice_date) BETWEEN '$from' AND '$to'
        ORDER BY labinvoice_id ASC";
$res = mysqli_query($conn, $sql);

$csv = "Invoice ID,Patient,Mobile,Gross,Disc,Net,Cash,Due\n";
while ($row = mysqli_fetch_assoc($res)) {
    $csv .= "{$row['labinvoice_id']},\"{$row['labinvoice_patient']}\",\"{$row['labinvoice_mobile']}\",{$row['labinvoice_subtotal']},{$row['labinvoice_totaldisc']},{$row['labinvoice_subtotalafterdisc']},{$row['labinvoice_receiveamount']},{$row['labinvoice_due']}\n";
}

// Save CSV to file
$filename = "lab_invoice_{$from}_to_{$to}.csv";
file_put_contents($filename, $csv);

// 📧 Send using PHPMailer
$mail = new PHPMailer();
$mail->setFrom("noreply@example.com", "Lab System");
$mail->addAddress($recipient);
$mail->Subject = $subject;
$mail->Body = $body;
$mail->addAttachment($filename);

// Send and handle result
if ($mail->send()) {
    echo "✅ Email sent successfully to $recipient";
} else {
    echo "❌ Email failed: " . $mail->ErrorInfo;
}

// Cleanup
unlink($filename);
