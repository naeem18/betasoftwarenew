<script language="JavaScript" type="text/javascript">
	
	var itemdata = <?php echo $itemdata;?>;
	var patientdata = <?php echo $patientdata;?>;
	$(document).ready(function($) {
		document.getElementsByName("hospitalinvoiceot_item")[0].focus();

		$( ".itemname" ).autocomplete({
			
			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				document.getElementById('hospitalinvoiceot_rate').value = ui.item.hospitalitem_price;
				document.getElementById('hospitalinvoiceot_qty').value =1;
				 
				calculaterowtotal();
				
				return false;
			}
		});
		
		
		$( "#hospitalinvoiceot_patientcode" ).autocomplete({
			
			minLength: 1,
			source: patientdata,
			
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('hospitalinvoiceot_patient').value = ui.item.labelval;
				 document.getElementById('hospitalinvoiceot_patientid').value = ui.item.opregistration_id;
				 document.getElementById('hospitalinvoiceot_age').value = ui.item.opregistration_age;
				 document.getElementById('hospitalinvoiceot_cabin').value = ui.item.ward;
				 document.getElementById('hospitalinvoiceot_gender').value = ui.item.opregistration_gender;
				 document.getElementById('hospitalinvoiceot_mobile').value = ui.item.opregistration_mobile;
				 document.getElementById('hospitalinvoiceot_address').value = ui.item.opregistration_address;
				 document.getElementById('hospitalinvoiceot_admissiondate').value = ui.item.opregistration_date;
				
				return false;
			}
		});
		
		
		
		
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
	});
	
	function calculaterowtotal(){
		
		var hospitalinvoiceot_rate = parseFloat(document.getElementById("hospitalinvoiceot_rate").value);
		if(hospitalinvoiceot_rate=='' || isNaN(hospitalinvoiceot_rate)){hospitalinvoiceot_rate = 0;}
		
		var hospitalinvoiceot_qty = parseFloat(document.getElementById("hospitalinvoiceot_qty").value);
		if(hospitalinvoiceot_qty=='' || isNaN(hospitalinvoiceot_qty)){hospitalinvoiceot_qty = 0;}
		
		
		var hospitalinvoiceot_total = parseFloat(hospitalinvoiceot_rate*hospitalinvoiceot_qty);
		document.getElementById("hospitalinvoiceot_total").value = hospitalinvoiceot_total.toFixed(0);
		
	}
	
	
function funcSaveBill1()
{
	
	var varUserChoice; 
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet); 
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		document.frmsales.submit();
		//return true;
	}
}	
	
</script>