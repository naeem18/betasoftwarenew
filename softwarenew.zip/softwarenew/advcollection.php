<style>
body{
    background:#f4f7fb;
    font-family:Tahoma, Arial, sans-serif;
}

.bottomcontent{
    width:800px;
    margin:8px auto;
}

.card{
    background:#fff;
    border-radius:10px;
    box-shadow:0 3px 12px rgba(0,0,0,.15);
    overflow:hidden;
}

.card-header{
    background:#72959c;
    color:#fff;
    padding:5px;
    text-align:center;
    font-size:18px;
    font-weight:bold;
}

.card-body{
    padding:7px;
}

.successmsg{
    background:#d4edda;
    color:#155724;
    border:1px solid #c3e6cb;
    padding:5px;
    margin-bottom:5px;
    border-radius:5px;
}

.errormsg{
    background:#f8d7da;
    color:#721c24;
    border:1px solid #f5c6cb;
    padding:5px;
    margin-bottom:5px;
    border-radius:5px;
}

.formtable{
    width:100%;
    border-collapse:collapse;
}

.formtable td{
    padding:4px;
}

.label{
    width:220px;
    font-weight:bold;
    text-align:right;
}

input[type=text],
select,
textarea{
    width:100%;
    padding:4px;
    border:1px solid #bbb;
    border-radius:4px;
    box-sizing:border-box;
    font-size:14px;
}

textarea{
    height:30px;
}

input[readonly]{
    background:#f2f2f2;
}

.sectiontitle{
    background:#72959c;
    color:#fff;
    padding:5px;
    margin-top:10px;
    margin-bottom:10px;
    font-weight:bold;
}

.savebtn{
    background:#28a745;
    color:#fff;
    border:none;
    padding:10px 30px;
    font-size:16px;
    border-radius:4px;
    cursor:pointer;
}

.savebtn:hover{
    background:#218838;
}

.printbtn{
    background:#0d6efd;
    color:#fff;
    border:none;
    padding:8px 20px;
    border-radius:4px;
    cursor:pointer;
}

.highlight{
    background:#fff8dc;
    font-weight:bold;
    color:#d32f2f;
}

@media(max-width:900px){

.bottomcontent{
    width:98%;
}

.label{
    width:140px;
}

}
</style>
<?php
$patientdata = '';
$sqlopregistration = "select * from opregistration where status!= 'Released' order by opregistration_id asc";
$opregistrationquery = mysqli_query($conn, $sqlopregistration);
if($opregistrationquery && mysqli_num_rows($opregistrationquery)>0){

	while ($oprow = mysqli_fetch_array($opregistrationquery))
	{
		$opregistration_id = $oprow['opregistration_id'];
		$opregistration_code = $oprow['opregistration_code'];
		$opregistration_name = $oprow['opregistration_name'];
		$ward = $oprow['ward'];
		$advanced = $oprow['advanced'];
		$admissionfee = $oprow['admissionfee'];
		$opregistration_mobile = $oprow['opregistration_mobile'];
		$opregistration_address = $oprow['opregistration_address'];
		$patientdata[] =array( 'labelval' => $opregistration_name,
							'label' => 'ID:'.$opregistration_id. ' Code:'. $opregistration_code.' Name:'. $opregistration_name,
							'opregistration_id'=>$opregistration_id,
							'opregistration_code'=>$opregistration_code,
							'advanced'=>$advanced,
							'admissionfee'=>$admissionfee,
							'ward'=>$ward,
							'opregistration_mobile'=>$opregistration_mobile,
							'opregistration_address'=>$opregistration_address
							);
		}
	}
$patientdata = json_encode($patientdata);
?>
<link rel="stylesheet" href="autocomplete/jquery-ui.css">
<script src="autocomplete/jquery-ui.min.js"></script>
<script language="JavaScript" type="text/javascript">
	
	var patientdata = <?php echo $patientdata;?>;
	$(document).ready(function($) {
		
		
		$( "#opregistration_idsearch" ).autocomplete({
			 
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
 				document.getElementById('labcollection_name').value = ui.item.labelval;
				document.getElementById('labcollection_number').value = ui.item.opregistration_mobile;
				document.getElementById('opregistration_idsearch').value = ui.item.opregistration_id;
				document.getElementById('opregistration_id').value = ui.item.opregistration_id;
				document.getElementById('opregistration_code').value = ui.item.opregistration_code;
				document.getElementById('labcollection_ward').value = ui.item.ward;
				document.getElementById('advanced').value = ui.item.advanced;
				document.getElementById('admissionfee').value = ui.item.admissionfee;
				document.getElementById('labcollection_address').value = ui.item.opregistration_address;
 				return false;
			}
		});
		
			
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
	});
	
		
	 
		
function calculate_total(){

    var type = document.getElementById("type").value;

    var advanced = parseFloat(document.getElementById("advanced").value) || 0;

    var admissionfee = parseFloat(document.getElementById("admissionfee").value) || 0;

    var collection = parseFloat(document.getElementById("collection_amount").value) || 0;

    if(type=="Admission Fee"){
        document.getElementById("total_balance").value =
            (admissionfee + collection).toFixed(2);
    }
    else{
        document.getElementById("total_balance").value =
            (advanced + collection).toFixed(2);
    }
}
		
	function funcSaveBill1()
	{
	var varUserChoice;
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet);
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		document.frmcontact.submit();
		//return true;
	}
}	
</script>

<article class="bottomcontent">

<div class="card">

<div class="card-header">
Admission Fee / Advance Collection
</div>

<div class="card-body">
<?php
if(isset($_GET['message']) && $_GET['message']=='field-missing1')
{
    echo '<div class="errormsg">
    Please fill all required information.
    </div>';
}

elseif(isset($_GET['message']) && $_GET['message']=='error-insert')
{
    echo '<div class="errormsg">
    Error! Information could not be saved.
    </div>';
}

elseif(isset($_GET['message']) && $_GET['message']=='insert-successfully')
{
    echo '<div class="successmsg">
     Information Saved Successfully.

    <input type="button"
           value="Print Receipt"
           class="printbtn"
           onclick="PrintDiv();">

    </div>';
}
?>

<form action="save_advanced.php"
      method="post"
      name="frmcontact"
      id="frmcontact"
      enctype="multipart/form-data"
      onsubmit="return checkcontactform();"
      onkeydown="return disableEnterKey(event);">

<input type="hidden"
       name="uniqid"
       value="<?php echo rand(10000,99999); ?>">

<input type="hidden"
       name="user"
       value="<?php echo $_SESSION['fullname'];?>">

<div class="sectiontitle">
Patient Information
</div>

<table class="formtable">

<tr>

<td class="label">
Collection Type
</td>

<td>

<select name="type"
        id="type"
        required>

<option value="">Select</option>

<option value="Admission Fee">
Admission Fee
</option>

<option value="Advanced">
Advance
</option>

</select>

</td>

</tr>


<tr>
    <td class="label">
        Search Patient
    </td>
    <td>
        <input type="text"
               required
               name="opregistration_idsearch"
               id="opregistration_idsearch"
               placeholder="Search by Patient ID / Code / Name">
    </td>
</tr>

<tr>
    <td class="label">
        Patient ID
    </td>
    <td>

        <input type="hidden"
               name="opregistration_code"
               id="opregistration_code">

        <input type="text"
               readonly
               name="opregistration_id"
               id="opregistration_id">

    </td>
</tr>

<tr>
    <td class="label">
        Patient Name
    </td>
    <td>
        <input type="text"
               readonly
               name="labcollection_name"
               id="labcollection_name">
    </td>
</tr>

<tr>
    <td class="label">
        Mobile Number
    </td>
    <td>
        <input type="text"
               readonly
               name="labcollection_number"
               id="labcollection_number">
    </td>
</tr>

<tr>
    <td class="label">
        Ward
    </td>
    <td>

        <input type="text"
               readonly
               name="labcollection_ward"
               id="labcollection_ward">

        <input type="hidden"
               name="labcollection_address"
               id="labcollection_address">

    </td>
</tr>

<tr>
    <td class="label">
        Collection Date
    </td>
    <td>

        <input type="text"
               readonly
               name="labcollection_date"
               id="labcollection_date"
               value="<?php echo date('Y-m-d H:i:s');?>">

        <input type="hidden"
               name="labcollection_update"
               id="labcollection_update">

    </td>
</tr>

</table>

<div class="sectiontitle">
Remarks
</div>

<table class="formtable">

<tr>

<td class="label">
Note
</td>

<td>

<textarea
name="note"
id="note"
placeholder="Write note here if necessary..."></textarea>

</td>

</tr>

</table>

<div class="sectiontitle">
Collection Summary
</div>

<table class="formtable">

<tr>

<td class="label">

Current Advance Paid

</td>

<td>

<input
type="text"
readonly
id="advanced"
name="advanced"
onkeyup="calculate_total();">

</td>

</tr>

<tr>

<td class="label">

Admission Fee Due

</td>

<td>

<input
type="text"
readonly
id="admissionfee"
name="admissionfee"
class="numeric">

</td>

</tr>

<tr>

<td class="label">

Collection Amount

</td>

<td>

<input
type="text"
required
id="collection_amount"
name="collection_amount"
class="numeric"
placeholder="Enter Collection Amount"
onkeyup="calculate_total();">

</td>

</tr>

<tr>

<td class="label">

Total Balance

</td>

<td>

<input
type="text"
readonly
id="total_balance"
name="total_balance"
class="highlight">

</td>

</tr>

<tr>

<td></td>

<td>

<input
type="hidden"
name="advanced_id"
id="advanced_id"
value="<?php echo $advanced_id;?>">

<input
type="submit"
name="submit_invoice"
id="submit_invoice"
value="💾 Save Collection"
class="savebtn"
onclick="return funcSaveBill1();">

</td>

</tr>

</table>

</form>

</div>

</div>

</article>

<div id="divToPrint" style="display:none;">

<article style="width:700px;margin:0 auto;
font-family:Tahoma,Arial,sans-serif;
color:#000;">

<?php

$advanced_id = $_GET['advanced_id'];

$sql = "SELECT * FROM advanced
        WHERE advanced_id='$advanced_id'";

$query = mysqli_query($conn,$sql);

if($query && mysqli_num_rows($query)>0){

while($row=mysqli_fetch_assoc($query)){

$opregistration_id=$row['opregistration_id'];
$name=$row['name'];
$advanced=$row['advanced'];
$ward=$row['ward'];
$advanced_date=$row['advanced_date'];
$user=$row['user'];
$note=$row['note'];
$type=$row['type'];

$sql2="SELECT opregistration_mobile,
              opregistration_doctor
       FROM opregistration
       WHERE opregistration_id='$opregistration_id'";

$q2=mysqli_query($conn,$sql2);

$r2=mysqli_fetch_assoc($q2);

$mobile=$r2['opregistration_mobile'];
$doctor=$r2['opregistration_doctor'];

?>

<!-- Hospital Header -->

<table width="100%"
border="0"
style="border-bottom:2px solid #1976d2;
margin-bottom:10px;">

<tr>

<td align="center">

<div style="font-size:28px;
font-weight:bold;
color:#1976d2;">

<?php echo $hospitaldata_name;?>

</div>

<div>

<?php echo $hospitaldata_address1;?>

</div>

<div>

Phone :
<?php echo $hospitaldata_mobile;?>

</div>

</td>

</tr>

</table>

<table width="100%"
style="margin-bottom:15px;">

<tr>

<td>

<b>Patient ID :</b>

<?php echo $opregistration_id;?>

<br>

<b>Patient :</b>

<?php echo $name;?>

<br>

<b>Ward :</b>

<?php echo $ward;?>

<br>

<b>Doctor :</b>

<?php echo $doctor;?>

</td>

<td align="right">

<b>Invoice :</b>

<?php echo $advanced_id;?>

<br>

<b>Date :</b>

<?php echo $advanced_date;?>

<br>

<b>Mobile :</b>

<?php echo $mobile;?>

</td>

</tr>

</table>

<table width="100%"
border="1"
cellpadding="8"
style="border-collapse:collapse;">

<tr
style="background:#1976d2;
color:#fff;">

<th>

Particular

</th>

<th width="180">

Amount

</th>

</tr>

<tr>

<td>

<?php echo $type;?>

</td>

<td align="right">

<strong>

<?php echo number_format($advanced,2);?>

</strong>

</td>

</tr>

<tr>

<td align="right">

<strong>Total</strong>

</td>

<td align="right">

<strong>

<?php echo number_format($advanced,2);?>

</strong>

</td>

</tr>

</table>

<br>

<table width="100%">

<tr>

<td>

<?php

include("convert_currency_to_words.php");

echo "<b>In Words :</b> ";

echo covert_currency_to_words($advanced);

?>

</td>

</tr>

</table>

<?php

if($note!=''){

?>

<br>

<table width="100%"
border="1"
cellpadding="8"
style="border-collapse:collapse;">

<tr>

<td>

<b>Note :</b>

<?php echo $note;?>

</td>

</tr>

</table>

<?php

}

?>

<br><br>

<table width="100%">

<tr>

<td>

Prepared By

<br><br>

____________________

<br>

<?php echo $user;?>

</td>

<td align="right">

Received By

<br><br>

____________________

</td>

</tr>

</table>

<hr>

<div align="center"
style="font-size:11px;
color:#666;">

Software Developed By

<b>Betasofts.com</b>

</div>

<?php

}

}

?>

</article>

</div>