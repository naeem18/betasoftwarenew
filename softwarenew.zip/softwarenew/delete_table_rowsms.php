<?php
session_start();
if(isset($_GET['idvalue'])){	
	$idvalue = $_GET['idvalue'];
	
	if($idvalue>0){
		require('labdd.php');
		//require('smsdata233.php');
		 
			$sqlst2 = "select labinvoice_mobile, labinvoice_patient, labinvoice_subtotal, labinvoice_receiveamount,
			labinvoice_due,labinvoice_totaldisc from labinvoice where labinvoice_id='$idvalue'";
				$exec3 = mysqli_query($conn, $sqlst2) or die ("Error in Query3".mysql_error());
				$onerow = mysqli_fetch_array($exec3);
					$labinvoice_mobile = $onerow['labinvoice_mobile'];
					$labinvoice_subtotal = $onerow['labinvoice_subtotal'];
 					$labinvoice_receiveamount = $onerow['labinvoice_receiveamount'];
 					$labinvoice_due = $onerow['labinvoice_due'];
 					$labinvoice_totaldisc = $onerow['labinvoice_totaldisc'];
 					$labinvoice_patient = $onerow['labinvoice_patient'];
 			
			 $str2 = "update labinvoice set `sms` = '1'
					where `labinvoice_id` = '$idvalue'";
					$userquery=mysqli_query($conn, $str2);
		
				/*if($labinvoice_mobile){
					if (class_exists('CommonCls')) {
						$CommonCls = new CommonCls();
						$mobile = $labinvoice_mobile;
						$message = 'Dear '.$labinvoice_patient.', Your Report is Completed. Please collect from report desk. Thanks from Nova Trauma Center.';		
						$returnInfo = $CommonCls->sendSMS($mobile, $message);
						echo $returnInfo;
 					
					$sql = "insert into smscount set `section`='Report',
												`mobile`='$labinvoice_mobile',
												`number`='1'";
									mysqli_query($conn, $sql);
			 						mysqli_insert_id($conn);
					}
 				}*/
				
				

		if($userquery){			
			header("location:index.php?p=reportsms&message=Sent-successfully");			
		}
		else{
			header("location:index.php?p=$reportsms&message=couldnotsent");
		}
	}
	else{
		header("location:index.php?p=reportsms&message=incorrect_id");
	}
}
?>