<?php
require 'labdd.php';

header('Content-Type: application/json; charset=utf-8');

$term = isset($_GET['term']) ? trim($_GET['term']) : '';

if ($term == '') {
    echo json_encode(array());
    exit;
}

$search = $term . "%";

$sql = "
SELECT
    salesitem_id,
    salesitem_name,
    salesitem_category,
    salesitem_group,
    salesitem_pack,
    salesitem_purchase_rate,
    salesitem_price,
    salesitem_tax,
    salesitem_stock,
    stock_limitation,
    salesitem_location,
    bar,
    expire
FROM salesitem
WHERE salesitem_name LIKE ?
   OR bar LIKE ?
ORDER BY salesitem_name
LIMIT 20
";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Prepare Error : " . $conn->error);
}

$stmt->bind_param("ss", $search, $search);

if (!$stmt->execute()) {
    die("Execute Error : " . $stmt->error);
}

$stmt->bind_result(
    $salesitem_id,
    $salesitem_name,
    $salesitem_category,
    $salesitem_group,
    $salesitem_pack,
    $salesitem_purchase_rate,
    $salesitem_price,
    $salesitem_tax,
    $salesitem_stock,
    $stock_limitation,
    $salesitem_location,
    $bar,
    $expire
);

$data = array();

while ($stmt->fetch()) {

    $data[] = array(
        "label"                    => $salesitem_name . " #Bar " . $bar,
        "value"                    => $salesitem_name,
        "salesitem_id"             => $salesitem_id,
        "salesitem_category"       => $salesitem_category,
        "salesitem_group"          => $salesitem_group,
        "salesitem_pack"           => $salesitem_pack,
        "salesitem_purchase_rate"  => $salesitem_purchase_rate,
        "salesitem_price"          => $salesitem_price,
        "salesitem_tax"            => $salesitem_tax,
        "salesitem_stock"          => $salesitem_stock,
        "stock_limitation"         => $stock_limitation,
        "salesitem_location"       => $salesitem_location,
        "bar"                      => $bar,
        "expire"                   => $expire
    );
}

$stmt->close();
$conn->close();

echo json_encode($data);