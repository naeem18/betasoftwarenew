<?php
session_start();
include ("labdd.php");

if (isset($_REQUEST["category"])) { $category = $_REQUEST["category"]; } else { $category = ""; }
//$customersearch = $_REQUEST["customersearch"];
//$customersearch = strtoupper($customersearch);
$searchresult = '';

$query2 = "select * from labitem where category = '$labitem_category' order by labitem_id";
$exec2 = mysqli_query($conn, $query2) or die ("Error in Query2".mysql_error());
while ($res2 = mysqli_fetch_array($exec2))
{
	$res2anum = $res2['labitem_id'];
	$itemname = $res2["labitem_name"];
	$unitname = $res2["labitem_unit"];
	$referencevalue = $res2["labitem_refvalue"];
	
	if ($searchresult == '')
	{
		$searchresult = ''.$labitem_name.'||'.$labitem_unit.'||'.$labitem_refvalue.'';
	}
	else
	{
		$searchresult = $searchresult.'||^||'.$labitem_name.'||'.$labitem_unit.'||'.$labitem_refvalue.'';
	}
	
}

if ($searchresult != '')
{
	echo $searchresult;
}

?>