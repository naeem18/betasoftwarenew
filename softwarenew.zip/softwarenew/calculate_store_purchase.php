<script language="JavaScript" type="text/javascript">
	
	var itemdataarray = <?php echo $itemdataarray;?>;
	var itemdata = <?php echo $itemdata;?>;
	var patientdata = <?php echo $patientdata;?>;
	var itemarraydata = itemdataarray;
	
	$(document).ready(function($) {
		document.getElementsByName("purchaseinvoice_item[]")[0].focus();

		$( ".itemname" ).autocomplete({

			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();

				var storeitem_idarray = document.getElementsByName("storeitem_id[]");
				storeitem_idarray[indexpos].value = ui.item.storeitem_id;

				var purchaseinvoice_qtyarray = document.getElementsByName("purchaseinvoice_qty[]");
				purchaseinvoice_qtyarray[indexpos].value = 1;

				calculaterowtotal(indexpos);

				return false;
			}
		});
		
		
		$( "#purchaseinvoice_patient" ).autocomplete({
			
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				 document.getElementById('purchaseinvoice_patientid').value = ui.item.labelval;
				 document.getElementById('purchaseinvoice_mobile').value = ui.item.company_mobile;
				 document.getElementById('purchaseinvoice_address').value = ui.item.company_address;
				return false;
			}
		});
		
		
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
		$( ".purchaseinvoice_item" ).keypress(function(keyname) {
			if(keyname.which==13){
				var imei = $(this).val();
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				$.each(itemarraydata, function(key, value){
					var valuearray = value.split('||');
					if(key==imei){
						document.getElementsByName("storeitem_id[]")[indexpos].value = valuearray[0];
						document.getElementsByName("purchaseinvoice_qty[]")[indexpos].value = 1;
						calculaterowtotal(indexpos);
						addnew_particularrow(true);
					}
				});
				return false;
			}
		});
		
	});
	
	function calculate_discountp(){}
	
	function calculaterowtotal(indexpos){
		if(indexpos=='all'){
			var purchaseinvoice_purchase_ratearray = document.getElementsByName("purchaseinvoice_purchase_rate[]");
			var purchaseinvoice_qtyarray = document.getElementsByName("purchaseinvoice_qty[]");
			var purchaseinvoice_totalarray = document.getElementsByName("purchaseinvoice_total[]");
			
			if(purchaseinvoice_purchase_ratearray.length>0){
				for(var p=0; p<purchaseinvoice_purchase_ratearray.length; p++){
					var purchaseinvoice_purchase_rate = parseFloat(purchaseinvoice_purchase_ratearray[p].value);
					if(purchaseinvoice_purchase_rate=='' || isNaN(purchaseinvoice_purchase_rate)){purchaseinvoice_purchase_rate = 0;}
					
					var purchaseinvoice_qty = parseFloat(purchaseinvoice_qtyarray[p].value);
					if(purchaseinvoice_qty=='' || isNaN(purchaseinvoice_qty)){purchaseinvoice_qty = 0;}
				
					var total = parseFloat(purchaseinvoice_purchase_rate*purchaseinvoice_qty);
					var total = parseFloat(total);
					
					purchaseinvoice_totalarray[p].value = total.toFixed(2);
				}
			}
			
		}
		else{
			var purchaseinvoice_purchase_ratearray = document.getElementsByName("purchaseinvoice_purchase_rate[]");
			var purchaseinvoice_purchase_rate = parseFloat(purchaseinvoice_purchase_ratearray[indexpos].value);
			if(purchaseinvoice_purchase_rate=='' || isNaN(purchaseinvoice_purchase_rate)){purchaseinvoice_purchase_rate = 0;}
			
			var purchaseinvoice_qtyarray = document.getElementsByName("purchaseinvoice_qty[]");
			var purchaseinvoice_qty = parseFloat(purchaseinvoice_qtyarray[indexpos].value);
			if(purchaseinvoice_qty=='' || isNaN(purchaseinvoice_qty)){purchaseinvoice_qty = 0;}
			
			var total = parseFloat(purchaseinvoice_purchase_rate*purchaseinvoice_qty);
			
			var total = parseFloat(total);
			
			var purchaseinvoice_totalarray = document.getElementsByName("purchaseinvoice_total[]");
			purchaseinvoice_totalarray[indexpos].value = total.toFixed(2);
		}
		
		calculate_total();
	}
	
	function calculate_total(){
		var purchaseinvoice_subtotal = 0;
		var purchaseinvoice_totalarray = document.getElementsByName("purchaseinvoice_total[]");
		if(purchaseinvoice_totalarray.length>0){
			for(var p=0; p<purchaseinvoice_totalarray.length; p++){
				var purchaseinvoice_total = parseFloat(purchaseinvoice_totalarray[p].value);
				if(purchaseinvoice_total=='' || isNaN(purchaseinvoice_total)){purchaseinvoice_total = 0;}
				purchaseinvoice_subtotal = parseFloat(purchaseinvoice_subtotal+purchaseinvoice_total);
			}
		}
		//subtotal calculation
		document.getElementById("purchaseinvoice_subtotal").value = purchaseinvoice_subtotal.toFixed(2);
		
		var purchaseinvoice_purchase_ratetotal = 0;
		var purchaseinvoice_purchase_ratearray = document.getElementsByName("purchaseinvoice_purchase_rate[]");
		if(purchaseinvoice_purchase_ratearray.length>0){
			for(var p=0; p<purchaseinvoice_purchase_ratearray.length; p++){
				var purchaseinvoice_purchase_rate = parseFloat(purchaseinvoice_purchase_ratearray[p].value);
				if(purchaseinvoice_purchase_rate=='' || isNaN(purchaseinvoice_purchase_rate)){purchaseinvoice_purchase_rate = 0;}
				purchaseinvoice_purchase_ratetotal = parseFloat(purchaseinvoice_purchase_ratetotal+purchaseinvoice_purchase_rate);
			}
		}
		//subtotal calculation
		document.getElementById("purchaseinvoice_subtotal").value = purchaseinvoice_subtotal.toFixed(2);
		
		var purchaseinvoice_subtotalafterdisc = parseFloat(purchaseinvoice_subtotal);
		document.getElementById('purchaseinvoice_subtotalafterdisc').value= purchaseinvoice_subtotalafterdisc.toFixed(2);
			
		var purchaseinvoice_receiveamount = parseFloat(document.getElementById("purchaseinvoice_receiveamount").value);
		if(purchaseinvoice_receiveamount=='' || isNaN(purchaseinvoice_receiveamount)){purchaseinvoice_receiveamount = 0;}
		
		var purchaseinvoice_due = parseFloat(purchaseinvoice_subtotalafterdisc-purchaseinvoice_receiveamount);
		document.getElementById('purchaseinvoice_due').value=purchaseinvoice_due.toFixed(2);		
		
		}
	
		function check_particular(){
		return true;
	}

	function addnew_particularrow(animate) {
		if(check_particular()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" align=\"left\" width=\"700\" cellspacing=\"1\" cellpadding=\"1\">"+
							'<tr>'+
								'<td align="right">Item Name</td>'+
								'<td> <input type="text" name="purchaseinvoice_item[]" class="tdclass itemname purchaseinvoice_item"/>'+
								'<input type="hidden" name="storeitem_id[]" id="storeitem_id" class="tdclass"/></td>'+
								
								'<td align="right">Purchase Rate</td>'+
								"<td> <input type=\"text\" name=\"purchaseinvoice_purchase_rate[]\"  id=\"purchaseinvoice_purchase_rate\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/></td>"+											 
								'<td align="right">Qty</td>'+
								"<td> <input type=\"text\" name=\"purchaseinvoice_qty[]\" id=\"purchaseinvoice_qty\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/></td>"+
								
								'<td align="right">Total</td>'+
								'<td> <input type="text" readonly name="purchaseinvoice_total[]" id="purchaseinvoice_total" value="" class="tdclasssale"/></td>'+												
								'<td>'+
								 "<input type=\"button\" value=\"Del \" onClick=\"deletethislistrow('particularlistrowno"+particular_rowcount+"');\" class=\"tdclasssales\"/>"+
								'</td>'+
							  '</tr>'+
						"</table>";
						
			var $newparticularlist = $("<li></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(300); 
			else 
			   $newparticularlist.show();   
				document.getElementsByName("purchaseinvoice_item[]")[parseInt(particular_rowcount-1)].focus();
			
			
			$( ".itemname" ).autocomplete({
			
			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				var storeitem_idarray = document.getElementsByName("storeitem_id[]");
				storeitem_idarray[indexpos].value = ui.item.storeitem_id;
				
				var purchaseinvoice_qtyarray = document.getElementsByName("purchaseinvoice_qty[]");
				purchaseinvoice_qtyarray[indexpos].value = 1;
					
				calculaterowtotal(indexpos);
				
				return false;
			}
		});
		
			$( ".purchaseinvoice_item" ).keypress(function(keyname) {
			if(keyname.which==13){
				var imei = $(this).val();
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				$.each(itemarraydata, function(key, value){
					var valuearray = value.split('||');
					if(key==imei){
						document.getElementsByName("storeitem_id[]")[indexpos].value = valuearray[0];
						document.getElementsByName("purchaseinvoice_qty[]")[indexpos].value = 1;
						calculaterowtotal(indexpos);
						addnew_particularrow(true);
					}
				});
				return false;
			}
		});
							
		}
	}
	
	function deletethislistrow(tableidname){
		$("#"+tableidname).parent("li").slideUp(200, function() {
			$(this).remove();
			calculaterowtotal('all');
		});
	}
</script>