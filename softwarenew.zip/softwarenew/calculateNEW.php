<script>
// Initialize global variables
var itemdataarray = <?php echo $itemdataarray; ?>;
var itemdata = <?php echo $itemdata; ?>;
var apdata = <?php echo $apdata; ?>;
var iddata = <?php echo $iddata; ?>;
var empdata = <?php echo $empdata; ?>;
var patientdata = <?php echo $patientdata; ?>;
var patientdatainvoice = <?php echo $patientdatainvoice; ?>;
var pcdata = <?php echo $pcdata; ?>;
var drdata = <?php echo $drdata; ?>;
var itemarraydata = itemdataarray;

$(document).ready(function() {
    // Focus on patient field on page load
    $("input[name='labinvoice_patient']").focus();

    // Initialize autocomplete fields
    initAutocompleteFields();
    
    // Numeric input handling
    initNumericInputs();
    
    // Add first row automatically
    addnew_particularrow(false);
});

function initAutocompleteFields() {
    // Item autocomplete
    $(".itemname").autocomplete({
        minLength: 1,
        source: itemdata,
        focus: function(event, ui) {
            return false;
        },
        select: function(event, ui) {
            return handleItemSelection(this, ui);
        }
    });

    // Patient search autocomplete
    $("#searchpatientid").autocomplete({
        minLength: 1,
        source: patientdata,
        focus: function(event, ui) {
            return false;
        },
        select: function(event, ui) {
            return handlePatientSelection(ui);
        }
    });

    // ID holder autocomplete
    $("#labinvoice_mobile").autocomplete({
        minLength: 1,
        source: iddata,
        focus: function(event, ui) {
            return false;
        },
        select: function(event, ui) {
            return handleIdHolderSelection(ui);
        }
    });

    // Appointment autocomplete
    $("#labinvoice_patient").autocomplete({
        minLength: 1,
        source: apdata,
        focus: function(event, ui) {
            return false;
        },
        select: function(event, ui) {
            return handleAppointmentSelection(ui);
        }
    });

    // Invoice patient data autocomplete
    $("#labinvoice_address").autocomplete({
        minLength: 1,
        source: patientdatainvoice,
        focus: function(event, ui) {
            return false;
        },
        select: function(event, ui) {
            return handleInvoicePatientSelection(ui);
        }
    });

    // PC search autocomplete
    $("#labinvoice_pc").autocomplete({
        minLength: 1,
        source: pcdata,
        focus: function(event, ui) {
            return false;
        },
        select: function(event, ui) {
            return handlePcSelection(ui);
        }
    });

    // Doctor search autocomplete
    $("#labinvoice_doctor").autocomplete({
        minLength: 1,
        source: drdata,
        focus: function(event, ui) {
            return false;
        },
        select: function(event, ui) {
            return handleDoctorSelection(ui);
        }
    });

    // Dues holder autocomplete
    $("#labinvoice_duesholder").autocomplete({
        minLength: 1,
        source: empdata,
        focus: function(event, ui) {
            return false;
        },
        select: function(event, ui) {
            return handleDuesHolderSelection(ui);
        }
    });
}

function initNumericInputs() {
    $(".numeric").on({
        focus: function() {
            if ($(this).val() == 0) $(this).val('');
        },
        blur: function() {
            if ($(this).val() == '') $(this).val(0);
        },
        keyup: function() {
            var price = $(this).val();
            var ValidChars = "-.0123456789";
            var validint = '';
            
            for (var i = 0; i < price.length; i++) { 
                var Char = price.charAt(i);
                if (!(i == 0 && Char == 0) && ValidChars.indexOf(Char) != -1) {
                    validint += Char;
                }
            }
            $(this).val(validint);
        }
    });
}



// Item selection handler
function handleItemSelection(element, ui) {
    var indexpos = $(element).closest('li').index();
    var itemIdArray = $("input[name='labitem_id[]']");
    
    // Check for duplicate items
    for (var l = 0; l < itemIdArray.length; l++) {
        if (itemIdArray[l].value != '' && ui.item.labitem_id == itemIdArray[l].value) {
            $(element).val('').focus();
            alert("Duplicate item found.");
            return false;
        }
    }
    
    // Set all field values
    $(element).val(ui.item.labelval);
    $("input[name='labitem_id[]']").eq(indexpos).val(ui.item.labitem_id);
    $("input[name='labinvoice_item[]']").eq(indexpos).val(ui.item.labitem_name);
    $("textarea[name='labinvoice_rate[]']").eq(indexpos).val(ui.item.labitem_price);
    $("input[name='labinvoice_qty[]']").eq(indexpos).val(1);
    $("textarea[name='labinvoice_gpccomission[]']").eq(indexpos).val(ui.item.labitem_pccommission);
    $("input[name='labinvoice_drcomission[]']").eq(indexpos).val(ui.item.labitem_drcommission);
    $("input[name='labinvoice_group[]']").eq(indexpos).val(ui.item.labitem_group);
    $("input[name='labinvoice_category[]']").eq(indexpos).val(ui.item.labitem_category);
    $("input[name='labitem_reagent[]']").eq(indexpos).val(ui.item.labitem_reagent);
    $("input[name='labitem_reagentid[]']").eq(indexpos).val(ui.item.labitem_reagentid);
    $("input[name='reagentqty[]']").eq(indexpos).val(ui.item.reagentqty);
    
    calculaterowtotal(indexpos);
    addnew_particularrow(true);
    return false;
}

// Patient selection handler
function handlePatientSelection(ui) {
    $(this).val(ui.item.label);
    $("#labinvoice_patient").val(ui.item.labelval);
    $("#searchpatientid").val('Success');
    $("#labinvoice_patientid").val(ui.item.opregistration_id);
    $("#labinvoice_patientcode").val(ui.item.opregistration_code);
    $("#labinvoice_age").val(ui.item.opregistration_age);
    $("#age").val(ui.item.age);
    $("#labinvoice_gender").val(ui.item.opregistration_gender);
    $("#labinvoice_mobile").val(ui.item.opregistration_mobile);
    $("#labinvoice_address").val(ui.item.opregistration_address);
    $("#labinvoice_pc").val(ui.item.pcname);
    $("#labinvoice_mpo").val(ui.item.mpo);
    $("#bar").val(ui.item.bar);
    $("#labinvoice_description").val(ui.item.remark);
    $("#labinvoice_ward").val(ui.item.ward);
    $("#labinvoice_previousdue").val(ui.item.lab_due);
    $("#previous_labinvoice_totalpccomission").val(ui.item.labinvoice_totalpccomission);
    return false;
}

// Other selection handlers (similar structure)
function handleIdHolderSelection(ui) { /* ... */ }
function handleAppointmentSelection(ui) { /* ... */ }
function handleInvoicePatientSelection(ui) { /* ... */ }
function handlePcSelection(ui) { /* ... */ }
function handleDoctorSelection(ui) { /* ... */ }
function handleDuesHolderSelection(ui) { /* ... */ }

// Calculation functions
function calculaterowtotal(indexpos) {
    if (indexpos == 'all') {
        $("input[name='labinvoice_total[]']").each(function(i) {
            calculateSingleRow(i);
        });
    } else {
        calculateSingleRow(indexpos);
    }
    calculate_total();
}

function calculateSingleRow(index) {
    var rate = parseFloat($("textarea[name='labinvoice_rate[]']").eq(index).val()) || 0;
    var qty = parseFloat($("input[name='labinvoice_qty[]']").eq(index).val()) || 0;
    var gpccomission = parseFloat($("textarea[name='labinvoice_gpccomission[]']").eq(index).val()) || 0;
    var disc = parseFloat($("textarea[name='labinvoice_disc[]']").eq(index).val()) || 0;
    
    var pctotal = (gpccomission * qty) - disc;
    var total = (rate * qty) - disc;
    
    $("textarea[name='labinvoice_pccomission[]']").eq(index).val(pctotal.toFixed(2));
    $("input[name='labinvoice_total[]']").eq(index).val(total.toFixed(2));
}

function calculate_total() {
    var subtotal = 0;
    $("input[name='labinvoice_total[]']").each(function() {
        subtotal += parseFloat($(this).val()) || 0;
    });
    
    $("#labinvoice_subtotal").val(subtotal.toFixed(2));
    
    // Calculate emergency charge if any
    var emergencyp = parseFloat($("#emergencyp").val()) || 0;
    var emergency = emergencyp > 0 ? subtotal * emergencyp * 0.01 : 0;
    $("#emergency").val(emergency.toFixed(2));
    
    // Calculate discount if any
    var discp = parseFloat($("#labinvoice_totaldiscp").val()) || 0;
    var disc = discp > 0 ? subtotal * discp * 0.01 : 0;
    $("#labinvoice_totaldisc").val(disc.toFixed(2));
    
    // Calculate subtotal after discount
    var subtotalAfterDisc = subtotal - disc + emergency;
    $("#labinvoice_subtotalafterdisc").val(subtotalAfterDisc.toFixed(2));
    $("#tdShowTotalAmount1").text(subtotalAfterDisc.toFixed(2));
    
    // Calculate due amount
    var receiveAmount = parseFloat($("#labinvoice_receiveamount").val()) || 0;
    $("#labinvoice_due").val((subtotalAfterDisc - receiveAmount).toFixed(2));
    
    // Calculate PC commission
    var pcCommission = 0;
    $("textarea[name='labinvoice_pccomission[]']").each(function() {
        pcCommission += parseFloat($(this).val()) || 0;
    });
    pcCommission = pcCommission - (disc / 2);
    $("#labinvoice_totalpccomission").val(pcCommission.toFixed(2));
    
    // Calculate PC commission percentage
    var pcCommissionPercent = subtotal > 0 ? (pcCommission * 100) / subtotal : 0;
    $("#labinvoice_totalpccomission_percent").val(pcCommissionPercent.toFixed(2));
    
    // Calculate DR commission
    var drCommission = 0;
    $("input[name='labinvoice_drcomission[]']").each(function() {
        drCommission += parseFloat($(this).val()) || 0;
    });
    $("#labinvoice_totaldrcomission").val(drCommission.toFixed(2));
}

// Row management functions
function addnew_particularrow(animate) {
    var rowCount = $("#particularlist li").length + 1;
    var newRow = `
        <li>
            <table id="particularlistrowno${rowCount}" class="invoice-row" style=\"BORDER-COLLAPSE: collapse; border:2px solid #FFF\" bgcolor=\"#c0d2ff\" align=\"left\" width=\"1200\" border=\"0\" cellspacing=\"1\" cellpadding=\"4\">
                <tr>
                    <td align="right">Test Name</td>
                    <td><input type="text" name="labinvoice_itemT[]" class="itemname tdclasss" autocomplete="off" /></td>
                    <input type="hidden" name="labinvoice_item[]">
                    <input type="hidden" name="labitem_id[]">
                    <input type="hidden" name="labinvoice_group[]">
                    <input type="hidden" name="labinvoice_category[]">
                    <input type="hidden" name="labitem_reagent[]">
                    <input type="hidden" name="labitem_reagentid[]">
                    <input type="hidden" name="reagentqty[]">
                    
                    <td align="right">Rate</td>
                    <td><textarea style=\"height:16px; width:60px;\" name="labinvoice_rate[]" class="numeric" onkeyup="calculaterowtotal('all')"></textarea></td>
                    
                    <input type="hidden" name="labinvoice_qty[]" value="1">
                    
                    <td align="right">RfCG</td>
                    <td><textarea readonly style=\"height:16px; width:60px;\" name="labinvoice_gpccomission[]"></textarea></td>
                    
                    <td align="right">Disc%</td>
                    <td><textarea style=\"height:16px; width:60px;\" name="labinvoice_discountp[]" onkeyup="calculate_discountp()"></textarea></td>
                    
                    <td align="right">Disc</td>
                    <td><textarea style=\"height:16px; width:60px;\" name="labinvoice_disc[]" onkeyup="calculaterowtotal('all')"></textarea></td>
                    
                    <td align="right">RfC</td>
                    <td><textarea style=\"height:16px; width:60px;\" readonly name="labinvoice_pccomission[]"></textarea></td>
                    
                    <input type="hidden" name="labinvoice_drcomission[]">
                    
                    <td align="right">Total</td>
                    <td><input type="text" readonly name="labinvoice_total[]" class="tdclasssale"></td>
                    
                    <td align="right">R.Date
                        <input type="text" size="6" name="labinvoice_reportdate[]" value="<?php echo date('Y-m-d'); ?>">
                    </td>
                    
                    <td><input type="text" size="5" name="labinvoice_reporttime[]" value="<?php echo date('h:i:s'); ?>"></td>
                    
                    <td><input type="button" value="Del" onclick="deletethislistrow('particularlistrowno${rowCount}')" class="tdclasssale"></td>
                </tr>
            </table>
        </li>`;
    
    var $newRow = $(newRow).hide();
    $("#particularlist").append($newRow);
    
    if (animate) {
        $newRow.slideDown(200);
    } else {
        $newRow.show();
    }
    
    // Initialize autocomplete for the new row
    $newRow.find(".itemname").autocomplete({
        minLength: 1,
        source: itemdata,
        focus: function(event, ui) {
            return false;
        },
        select: function(event, ui) {
            return handleItemSelection(this, ui);
        }
    });
    
    $newRow.find(".itemname").focus();
}

function deletethislistrow(tableidname) {
    $("#" + tableidname).closest("li").slideUp(200, function() {
        $(this).remove();
        calculaterowtotal('all');
    });
}

// Form validation
function checkcontactform() {
    var mobile = $("#labinvoice_mobile").val();
    var errorMobile = $("#error_labinvoice_mobile");
    
    errorMobile.empty();
    
    if (!mobile) {
        errorMobile.text("Number is missing.");
        $("#labinvoice_mobile").focus();
        return false;
    } else if (mobile.length < 10) {
        errorMobile.text("Number should be at least 10 digits.");
        $("#labinvoice_mobile").focus();
        return false;
    }
    
    var pcCommission = parseFloat($("#labinvoice_totalpccomission").val()) || 0;
    if (pcCommission < 0) {
        $("#error_labinvoice_totalpccomission").text("Discount amount should not exceed PC amount");
        $("#labinvoice_totalpccomission").focus();
        return false;
    }
    
    return true;
}
</script>