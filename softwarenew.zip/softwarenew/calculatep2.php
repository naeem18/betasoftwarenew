<script type="text/javascript">

/*=====================================================
    GLOBAL VARIABLES
=====================================================*/

var empdata = <?php echo $empdata;?>;
var patientdata = <?php echo $patientdata;?>;
	//console.log(patientdata);
var itemCache = {};
var ajaxRequest = null;


/*=====================================================
    HELPER FUNCTIONS
=====================================================*/

function getRowIndex(obj){
    return $(obj).closest("li").index();
}

function onlyNumber(val){
    var ValidChars="-.0123456789";
    var out="";

    for(var i=0;i<val.length;i++){
        if(ValidChars.indexOf(val.charAt(i))!=-1){
            out+=val.charAt(i);
        }
    }
    return out;
}

function loadItemToRow(indexpos,ui){

    document.getElementsByName("salesitem_id[]")[indexpos].value = ui.item.sii;
    document.getElementsByName("salesinvoice_item[]")[indexpos].value = ui.item.salesitem_name;
    document.getElementsByName("itembar[]")[indexpos].value = ui.item.bar;
    document.getElementsByName("salesinvoice_purchase_rate[]")[indexpos].value = ui.item.sipr;
    document.getElementsByName("salesinvoice_rate[]")[indexpos].value = ui.item.sisp;
    document.getElementsByName("salesitem_pack[]")[indexpos].value = ui.item.sip;
    document.getElementsByName("salesinvoice_qty[]")[indexpos].value = '';
    document.getElementsByName("salesinvoice_category[]")[indexpos].value = ui.item.sic;
    document.getElementsByName("salesinvoice_group[]")[indexpos].value = ui.item.sig;
    document.getElementsByName("salesinvoice_stock[]")[indexpos].value = ui.item.sis;
    document.getElementsByName("salesitem_location[]")[indexpos].value = ui.item.sisl;

    calculateCurrentRowTotal(indexpos);
    addnew_particularrow(true);
}

</script>

<script type="text/javascript">

/*=====================================================
    ITEM AUTOCOMPLETE
=====================================================*/

$(document).on("focus",".itemname",function(){

    if($(this).hasClass("ac_loaded")){
        return;
    }
    $(this).addClass("ac_loaded");

    $(this).autocomplete({

        minLength:2,
        delay:150,

        source:function(request,response){

            var term = $.trim(request.term);

            if(term.length < 2){
                response([]);
                return;
            }

            if(itemCache[term]){
                response(itemCache[term]);
                return;
            }

            if(ajaxRequest){
                ajaxRequest.abort();
            }

            ajaxRequest = $.ajax({
                url: "ajax_item_search.php",
                type: "GET",
                dataType: "json",
                cache: true,
                data: { term: term },

                success: function(data){
                    itemCache[term] = data;
                    response(data);
                },

                error: function(){
                    response([]);
                }
            });
        },

        focus: function(){
            return false;
        },

        select: function(event, ui){

            var indexpos = $(this).closest("li").index();
            loadItemToRow(indexpos, ui);

            return false;
        }
    });
});


/*=====================================================
    EMPLOYEE AUTOCOMPLETE
=====================================================*/

$("#employenameentry_name").autocomplete({

    minLength: 1,
    source: empdata,

    focus: function(){
        return false;
    },

    select: function(event, ui){

        $(this).val(ui.item.label);

        $("#employenameentry_name").val(ui.item.labelval);
        $("#employenameentry_id").val(ui.item.employenameentry_id);

        return false;
    }
});


/*=====================================================
    PATIENT AUTOCOMPLETE
=====================================================*/
 
$("#salesinvoice_patientid").autocomplete({

    minLength: 1,
    source: patientdata,

    focus: function(){
        return false;
    },

   select:function(event,ui){

    $("#salesinvoice_patientid").val(ui.item.opregistration_id);
    $("#salesinvoice_patient").val(ui.item.labelval);
    $("#salesinvoice_patientcode").val(ui.item.opregistration_code);

    $("#bar").val(ui.item.bar);
    $("#salesinvoice_previousdue").val(ui.item.pharmacy_due);
    $("#salesinvoice_mobile").val(ui.item.opregistration_mobile);
    $("#salesinvoice_address").val(ui.item.opregistration_address);
    $("#ward").val(ui.item.ward);

    return false;
}


});

</script>

<script type="text/javascript">

/*=====================================================
    NUMERIC INPUT CONTROL
=====================================================*/

$(document).on("focus",".numeric",function(){

    if($(this).val() == 0){
        $(this).val('');
    }

});

$(document).on("blur",".numeric",function(){

    if($(this).val() == ''){
        $(this).val(0);
    }

});

$(document).on("keyup",".numeric",function(){

    $(this).val(onlyNumber($(this).val()));

});


/*=====================================================
    ENTER KEY → AUTOCOMPLETE SEARCH
=====================================================*/

$(document).on("keypress",".salesinvoice_item",function(e){

    if(e.which != 13){
        return;
    }

    e.preventDefault();
    $(this).autocomplete("search");

});


/*=====================================================
    ROW CALCULATION TRIGGER
=====================================================*/

$(document).on("keyup",".sirow input.ccrt",function(){

    var index = getRowIndex(this);
    calculateCurrentRowTotal(index);

});


/*=====================================================
    DELETE ROW
=====================================================*/

$(document).on("click",".deletethislistrow",function(){

    $(this).closest("li").slideUp(200,function(){

        $(this).remove();
        calculateGrandTotal();

    });

});

</script>

<script type="text/javascript">

/*=====================================================
    CALCULATE CURRENT ROW TOTAL
=====================================================*/

function calculateCurrentRowTotal(indexpos){

    var purchase_rate = parseFloat(document.getElementsByName("salesinvoice_purchase_rate[]")[indexpos].value);
    if(isNaN(purchase_rate)) purchase_rate = 0;

    var sale_rate = parseFloat(document.getElementsByName("salesinvoice_rate[]")[indexpos].value);
    if(isNaN(sale_rate)) sale_rate = 0;

    var pack = parseFloat(document.getElementsByName("salesitem_pack[]")[indexpos].value);
    if(isNaN(pack)) pack = 0;

    var pqty = parseFloat(document.getElementsByName("salesinvoice_pqty[]")[indexpos].value);
    if(isNaN(pqty)) pqty = 0;


    var qty = 0;

    if(pack == 0 || pqty == 0){

        qty = parseFloat(document.getElementsByName("salesinvoice_qty[]")[indexpos].value);
        if(isNaN(qty)) qty = 0;

    }else{

        qty = pack * pqty;
        document.getElementsByName("salesinvoice_qty[]")[indexpos].value = qty.toFixed(2);
    }


    var sale_total = sale_rate * qty;
    var purchase_total = purchase_rate * qty;


    var disc_p = parseFloat(document.getElementsByName("salesinvoice_discountp[]")[indexpos].value);
    if(isNaN(disc_p)) disc_p = 0;


    var disc = 0;

    if(disc_p == 0){

        disc = parseFloat(document.getElementsByName("salesinvoice_disc[]")[indexpos].value);
        if(isNaN(disc)) disc = 0;

    }else{

        disc = sale_total * disc_p / 100;
        document.getElementsByName("salesinvoice_disc[]")[indexpos].value = disc.toFixed(2);
    }


    var net_total = sale_total - disc;

    document.getElementsByName("salesinvoice_total[]")[indexpos].value = net_total.toFixed(2);
    document.getElementsByName("purchaseinvoice_total[]")[indexpos].value = purchase_total.toFixed(2);


    calculateGrandTotal();
}

</script>


<script type="text/javascript">

/*=====================================================
    CALCULATE CURRENT ROW TOTAL
=====================================================*/

function calculateCurrentRowTotal(indexpos){

    var purchase_rate = parseFloat(document.getElementsByName("salesinvoice_purchase_rate[]")[indexpos].value);
    if(isNaN(purchase_rate)) purchase_rate = 0;

    var sale_rate = parseFloat(document.getElementsByName("salesinvoice_rate[]")[indexpos].value);
    if(isNaN(sale_rate)) sale_rate = 0;

    var pack = parseFloat(document.getElementsByName("salesitem_pack[]")[indexpos].value);
    if(isNaN(pack)) pack = 0;

    var pqty = parseFloat(document.getElementsByName("salesinvoice_pqty[]")[indexpos].value);
    if(isNaN(pqty)) pqty = 0;


    var qty = 0;

    if(pack == 0 || pqty == 0){

        qty = parseFloat(document.getElementsByName("salesinvoice_qty[]")[indexpos].value);
        if(isNaN(qty)) qty = 0;

    }else{

        qty = pack * pqty;
        document.getElementsByName("salesinvoice_qty[]")[indexpos].value = qty.toFixed(2);
    }


    var sale_total = sale_rate * qty;
    var purchase_total = purchase_rate * qty;


    var disc_p = parseFloat(document.getElementsByName("salesinvoice_discountp[]")[indexpos].value);
    if(isNaN(disc_p)) disc_p = 0;


    var disc = 0;

    if(disc_p == 0){

        disc = parseFloat(document.getElementsByName("salesinvoice_disc[]")[indexpos].value);
        if(isNaN(disc)) disc = 0;

    }else{

        disc = sale_total * disc_p / 100;
        document.getElementsByName("salesinvoice_disc[]")[indexpos].value = disc.toFixed(2);
    }


    var net_total = sale_total - disc;

    document.getElementsByName("salesinvoice_total[]")[indexpos].value = net_total.toFixed(2);
    document.getElementsByName("purchaseinvoice_total[]")[indexpos].value = purchase_total.toFixed(2);


    calculateGrandTotal();
}

</script>

<script type="text/javascript">
/*=====================================================
    CALCULATE GRAND TOTAL
=====================================================*/

function calculateGrandTotal(){

    /*-------------------------------
        SALES SUBTOTAL
    -------------------------------*/

    var salesinvoice_totalarray=document.getElementsByName("salesinvoice_total[]");
    var salesinvoice_subtotal=0;

    for(var i=0;i<salesinvoice_totalarray.length;i++){

        var total=parseFloat(salesinvoice_totalarray[i].value);

        if(isNaN(total)){
            total=0;
        }

        salesinvoice_subtotal+=total;

    }

    $("#salesinvoice_subtotal").val(salesinvoice_subtotal.toFixed(2));


    /*-------------------------------
        PURCHASE SUBTOTAL
    -------------------------------*/

    var purchaseinvoice_totalarray=document.getElementsByName("purchaseinvoice_total[]");
    var salesinvoice_purchasesubtotal=0;

    for(var j=0;j<purchaseinvoice_totalarray.length;j++){

        var ptotal=parseFloat(purchaseinvoice_totalarray[j].value);

        if(isNaN(ptotal)){
            ptotal=0;
        }

        salesinvoice_purchasesubtotal+=ptotal;

    }

    $("#salesinvoice_purchasesubtotal").val(salesinvoice_purchasesubtotal.toFixed(2));


    /*-------------------------------
        INVOICE DISCOUNT
    -------------------------------*/

    var salesinvoice_totaldiscp=parseFloat($("#salesinvoice_totaldiscp").val());

    if(isNaN(salesinvoice_totaldiscp)){
        salesinvoice_totaldiscp=0;
    }

    var salesinvoice_totaldisc=parseFloat($("#salesinvoice_totaldisc").val());

    if(isNaN(salesinvoice_totaldisc)){
        salesinvoice_totaldisc=0;
    }

    if(salesinvoice_totaldiscp>0){

        salesinvoice_totaldisc=(salesinvoice_subtotal*salesinvoice_totaldiscp)/100;

        $("#salesinvoice_totaldisc").val(salesinvoice_totaldisc.toFixed(2));

    }


    /*-------------------------------
        SUBTOTAL AFTER DISCOUNT
    -------------------------------*/

    var salesinvoice_subtotalafterdisc=salesinvoice_subtotal-salesinvoice_totaldisc;

    $("#salesinvoice_subtotalafterdisc").val(salesinvoice_subtotalafterdisc.toFixed(2));


    /*-------------------------------
        RECEIVE AMOUNT
    -------------------------------*/

    var salesinvoice_receiveamount=parseFloat($("#salesinvoice_receiveamount").val());

    if(isNaN(salesinvoice_receiveamount)){
        salesinvoice_receiveamount=0;
    }


    /*-------------------------------
        DUE
    -------------------------------*/

    var salesinvoice_due=salesinvoice_subtotalafterdisc-salesinvoice_receiveamount;

    $("#salesinvoice_due").val(salesinvoice_due.toFixed(2));


    /*-------------------------------
        CASH RETURN
    -------------------------------*/

    var cashreceive=parseFloat($("#cashreceive").val());

    if(isNaN(cashreceive)){
        cashreceive=0;
    }

    var cashreturn=cashreceive-salesinvoice_receiveamount;

    $("#cashreturn").val(cashreturn.toFixed(2));

}
</script>


<script type="text/javascript">

/*=====================================================
    CHECK BLANK ROW
=====================================================*/

function check_blankrow(){

    return true; // এখন basic version (validation চাইলে পরে add করা যাবে)

}


/*=====================================================
    ADD NEW PARTICULAR ROW
=====================================================*/

function addnew_particularrow(animate){

    if(check_blankrow() == false){
        return false;
    }

    $("#errmsg_particular_id").html('');

    var rowcount = $("ul#particularlist").children().length + 1;


    var newrow = 
    "<table id='particularlistrowno"+rowcount+"' align='center' width='960' cellpadding='1'>" +

    "<tbody><tr><tr>" +

    /* ITEM NAME */
    "<td align='center' width='130'>" +
    "<input type='text' name='salesinvoice_item[]' class='tdclass ccrt itemname salesinvoice_item'/>" +
    "<input type='hidden' name='salesitem_id[]'/>" +
    "<input type='hidden' name='salesinvoice_category[]'/>" +
    "<input type='hidden' name='salesinvoice_group[]'/>" +
    "</td>" +

    /* BARCODE */
    "<td align='center' width='130'>" +
    "<input type='text' name='itembar[]' class='tdclass salesinvoice_item'/>" +
    "</td>" +

    /* LOCATION */
    "<td align='center' width='95'>" +
    "<input type='text' name='salesitem_location[]' class='tdclasssale numeric ccrt'/>" +
    "</td>" +

    /* QTY */
    "<td align='center' width='95'>" +
    "<input type='text' name='salesinvoice_qty[]' class='tdclasssale numeric ccrt' required/>" +
    "</td>" +

    /* STOCK */
    "<td align='center' width='95'>" +
    "<input type='text' name='salesinvoice_stock[]' class='tdclasssale'/>" +
    "</td>" +

    /* PURCHASE RATE */
    "<td align='center' width='95'>" +
    "<input type='text' name='salesinvoice_purchase_rate[]' class='tdclasssale'/>" +
    "</td>" +

    /* SALES RATE */
    "<td align='center' width='95'>" +
    "<input type='text' name='salesinvoice_rate[]' class='tdclasssale numeric ccrt'/>" +
    "</td>" +

    /* PACK */
    "<td align='center' width='95'>" +
    "<input type='text' name='salesitem_pack[]' class='tdclasssale numeric ccrt'/>" +
    "</td>" +

    /* P QTY */
    "<td align='center' width='95'>" +
    "<input type='text' name='salesinvoice_pqty[]' class='tdclasssale numeric ccrt'/>" +
    "</td>" +

    /* DISCOUNT % */
    "<td align='center' width='95'>" +
    "<input type='text' name='salesinvoice_discountp[]' class='tdclasssale numeric ccrt'/>" +
    "</td>" +

    /* DISCOUNT AMOUNT */
    "<td align='center' width='95'>" +
    "<input type='text' name='salesinvoice_disc[]' class='tdclasssale numeric ccrt'/>" +
    "</td>" +

    /* TOTAL */
    "<td align='center' width='95'>" +
    "<input type='text' name='salesinvoice_total[]' class='tdclasssale numeric ccrt' readonly/>" +
    "</td>" +

    /* PURCHASE TOTAL (hidden) */
    "<input type='hidden' name='purchaseinvoice_total[]'/>" +

    /* DELETE BUTTON */
    "<td>" +
    "<input type='button' value='Del' class='tdclasssales deletethislistrow'/>" +
    "</td>" +

    "</tr></tbody></table>";


    var $row = $("<li class='sirow'></li>").html(newrow);

    $("#particularlist").append($row.hide());

    if(animate){
        $row.slideDown(300);
    }else{
        $row.show();
    }


    /* focus new row item */
    document.getElementsByName("salesinvoice_item[]")[rowcount - 1].focus();

}

</script>


<script type="text/javascript">

/*=====================================================
    SAFE EVENT HANDLING (NO DUPLICATE BINDING ISSUE)
=====================================================*/

/* numeric filter (extra safety layer) */
$(document).on("keyup",".numeric",function(){
    $(this).val(onlyNumber($(this).val()));
});


/*=====================================================
    ROW INPUT → AUTO CALCULATION
=====================================================*/

$(document).on("keyup",".sirow input.ccrt",function(){

    var index = $(this).closest("li").index();
    calculateCurrentRowTotal(index);

});


/*=====================================================
    DELETE ROW (SAFE + RECALC)
=====================================================*/

$(document).on("click",".deletethislistrow",function(){

    $(this).closest("li").slideUp(150,function(){

        $(this).remove();
        calculateGrandTotal();

    });

});


/*=====================================================
    ENTER KEY TRIGGER SEARCH (ITEM)
=====================================================*/

$(document).on("keypress",".salesinvoice_item",function(e){

    if(e.which != 13){
        return;
    }

    e.preventDefault();

    $(this).autocomplete("search");

});


/*=====================================================
    ROW FOCUS AUTO CALC ON CHANGE (EXTRA SAFETY)
=====================================================*/

$(document).on("change",".sirow input",function(){

    var index = $(this).closest("li").index();
    calculateCurrentRowTotal(index);

});


/*=====================================================
    PREVENT MULTIPLE AUTOCOMPLETE RE-BIND ISSUE FIX
=====================================================*/

function initItemAutocomplete(el){

    if($(el).hasClass("ac_loaded")){
        return;
    }

    $(el).addClass("ac_loaded");

    $(el).autocomplete({

        minLength: 2,
        delay: 150,

        source: function(request, response){

            var term = $.trim(request.term);

            if(term.length < 2){
                response([]);
                return;
            }

            if(itemCache[term]){
                response(itemCache[term]);
                return;
            }

            if(ajaxRequest){
                ajaxRequest.abort();
            }

            ajaxRequest = $.ajax({

                url: "ajax_item_search.php",
                type: "GET",
                dataType: "json",
                data: { term: term },

                success: function(data){
                    itemCache[term] = data;
                    response(data);
                },

                error: function(){
                    response([]);
                }

            });

        },

        focus: function(){
            return false;
        },

        select: function(event, ui){

            var index = $(this).closest("li").index();
            loadItemToRow(index, ui);

            return false;
        }
    });
}


/*=====================================================
    GLOBAL ITEM AUTOCOMPLETE INIT
=====================================================*/

$(document).on("focus",".itemname",function(){
    initItemAutocomplete(this);
});


/*=====================================================
    CASH / RECEIVE LIVE UPDATE SAFETY HOOK
=====================================================*/

$(document).on("keyup","#salesinvoice_receiveamount,#cashreceive",function(){
    calculateGrandTotal();
});

</script>


<script type="text/javascript">

/*=====================================================
    SAFE EVENT HANDLING (NO DUPLICATE BINDING ISSUE)
=====================================================*/

/* numeric filter (extra safety layer) */
$(document).on("keyup",".numeric",function(){
    $(this).val(onlyNumber($(this).val()));
});


/*=====================================================
    ROW INPUT → AUTO CALCULATION
=====================================================*/

$(document).on("keyup",".sirow input.ccrt",function(){

    var index = $(this).closest("li").index();
    calculateCurrentRowTotal(index);

});


/*=====================================================
    DELETE ROW (SAFE + RECALC)
=====================================================*/

$(document).on("click",".deletethislistrow",function(){

    $(this).closest("li").slideUp(150,function(){

        $(this).remove();
        calculateGrandTotal();

    });

});


/*=====================================================
    ENTER KEY TRIGGER SEARCH (ITEM)
=====================================================*/

$(document).on("keypress",".salesinvoice_item",function(e){

    if(e.which != 13){
        return;
    }

    e.preventDefault();

    $(this).autocomplete("search");

});


/*=====================================================
    ROW FOCUS AUTO CALC ON CHANGE (EXTRA SAFETY)
=====================================================*/

$(document).on("change",".sirow input",function(){

    var index = $(this).closest("li").index();
    calculateCurrentRowTotal(index);

});


/*=====================================================
    PREVENT MULTIPLE AUTOCOMPLETE RE-BIND ISSUE FIX
=====================================================*/

function initItemAutocomplete(el){

    if($(el).hasClass("ac_loaded")){
        return;
    }

    $(el).addClass("ac_loaded");

    $(el).autocomplete({

        minLength: 2,
        delay: 150,

        source: function(request, response){

            var term = $.trim(request.term);

            if(term.length < 2){
                response([]);
                return;
            }

            if(itemCache[term]){
                response(itemCache[term]);
                return;
            }

            if(ajaxRequest){
                ajaxRequest.abort();
            }

            ajaxRequest = $.ajax({

                url: "ajax_item_search.php",
                type: "GET",
                dataType: "json",
                data: { term: term },

                success: function(data){
                    itemCache[term] = data;
                    response(data);
                },

                error: function(){
                    response([]);
                }

            });

        },

        focus: function(){
            return false;
        },

        select: function(event, ui){

            var index = $(this).closest("li").index();
            loadItemToRow(index, ui);

            return false;
        }
    });
}


/*=====================================================
    GLOBAL ITEM AUTOCOMPLETE INIT
=====================================================*/

$(document).on("focus",".itemname",function(){
    initItemAutocomplete(this);
});


/*=====================================================
    CASH / RECEIVE LIVE UPDATE SAFETY HOOK
=====================================================*/

$(document).on("keyup","#salesinvoice_receiveamount,#cashreceive",function(){
    calculateGrandTotal();
});

</script>