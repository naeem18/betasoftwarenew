<!--depseek-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Appointment System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
                
        .header {
            background: #4a6fc0;
            color: white;
            padding: 25px 30px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 28px;
            margin-bottom: 5px;
        }
        
        .header p {
            opacity: 0.9;
        }
        
        .content {
            display: flex;
            flex-wrap: wrap;
        }
        
        .form-container {
            flex: 1;
            min-width: 350px;
            padding: 30px;
            background: #f9fafc;
        }
        
        .info-container {
            flex: 1;
            min-width: 350px;
            padding: 30px;
            background: #4a6fc0;
            color: white;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #2c3e50;
        }
        
        input, select {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #ddd;
            border-radius: 6px;
            font-size: 16px;
            transition: border 0.3s;
        }
        
        input:focus, select:focus {
            border-color: #4a6fc0;
            outline: none;
        }
        
        button {
            background: #4a6fc0;
            color: white;
            border: none;
            padding: 14px 20px;
            width: 100%;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        button:hover {
            background: #3b5aa6;
        }
        
        .serial-display {
            text-align: center;
            margin-top: 25px;
            padding: 20px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
        }
        
        .serial-number {
            font-size: 32px;
            font-weight: 700;
            letter-spacing: 2px;
            margin: 15px 0;
            color: #ffdd59;
        }
        
        .info-list {
            list-style: none;
            margin-top: 25px;
        }
        
        .info-list li {
            margin-bottom: 15px;
            display: flex;
            align-items: flex-start;
        }
        
        .info-list i {
            margin-right: 12px;
            margin-top: 4px;
            font-size: 18px;
        }
        
        h3 {
            margin-bottom: 20px;
            font-size: 22px;
            position: relative;
            padding-bottom: 10px;
        }
        
        h3:after {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 50px;
            height: 3px;
            background: #ffdd59;
        }
        
        .info-container h3:after {
            left: 50%;
            transform: translateX(-50%);
        }
        
        .period-info {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
            flex-wrap: wrap;
        }
        
        .period-card {
            background: rgba(255, 255, 255, 0.1);
            padding: 15px;
            border-radius: 8px;
            width: calc(50% - 10px);
            margin-bottom: 15px;
            text-align: center;
        }
        
        .period-card h4 {
            margin-bottom: 8px;
            font-size: 16px;
        }
        
        .custom-options {
            display: none;
            margin-top: 15px;
            padding: 15px;
            background: #e8eeff;
            border-radius: 8px;
        }
        
        .checkbox-group {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 10px;
        }
        
        .day-option, .date-option {
            display: flex;
            align-items: center;
            background: white;
            padding: 8px 12px;
            border-radius: 6px;
            border: 1px solid #ddd;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .day-option:hover, .date-option:hover {
            background: #f0f5ff;
        }
        
        .day-option input, .date-option input {
            width: auto;
            margin-right: 8px;
        }
        
        .date-option.selected {
            background: #4a6fc0;
            color: white;
            border-color: #3b5aa6;
        }
        
        .date-option.selected label {
            color: white;
        }
        
        .radio-group {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 10px;
        }
        
        .date-radio {
            display: flex;
            align-items: center;
            background: white;
            padding: 8px 12px;
            border-radius: 6px;
            border: 1px solid #ddd;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .date-radio:hover {
            background: #f0f5ff;
        }
        
        .date-radio input {
            width: auto;
            margin-right: 8px;
        }
        
        .date-radio.selected {
            background: #4a6fc0;
            color: white;
            border-color: #3b5aa6;
        }
        
        .date-radio.selected label {
            color: white;
        }
        
        @media (max-width: 900px) {
            .content {
                flex-direction: column;
            }
            
            .period-card {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-stethoscope"></i> Doctor Appointment System</h1>
            <p>Manage appointment serial numbers based on custom day or date periods</p>
        </div>
        
        <div class="content">
            <div class="form-container">
                <h3>Appointment Details</h3>
                
                <div class="form-group">
                    <label for="doctor">Doctor</label>
                    <select id="doctor">
                        <option value="">Select a doctor</option>
                        <option value="dr_john">Dr. John Smith (Cardiologist)</option>
                        <option value="dr_emma">Dr. Emma Wilson (Neurologist)</option>
                        <option value="dr_michael">Dr. Michael Brown (Orthopedist)</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="patient">Patient Name</label>
                    <input type="text" id="patient" placeholder="Enter patient name">
                </div>
                
                <div class="form-group">
                    <label for="date">Appointment Date</label>
                    <input type="date" id="date">
                </div>
                
                <div class="form-group">
                    <label for="period">Serial Period Type</label>
                    <select id="period">
                        <option value="daily">Daily Serial</option>
                        <option value="weekly">Weekly Serial (Saturday Start)</option>
                        <option value="biweekly">15-Day Serial</option>
                        <option value="monthly">Monthly Serial</option>
                        <option value="custom_day">Custom Day (e.g., Every Sunday, Tuesday)</option>
                        <option value="custom_date">Custom Date (e.g., 10th, 15th, 20th)</option>
                    </select>
                </div>
                
                <div id="customDayOptions" class="custom-options">
                    <label>Select Days (Multiple Selection):</label>
                    <div class="checkbox-group">
                        <div class="day-option">
                            <input type="checkbox" id="sunday" value="0">
                            <label for="sunday">Sunday</label>
                        </div>
                        <div class="day-option">
                            <input type="checkbox" id="monday" value="1">
                            <label for="monday">Monday</label>
                        </div>
                        <div class="day-option">
                            <input type="checkbox" id="tuesday" value="2">
                            <label for="tuesday">Tuesday</label>
                        </div>
                        <div class="day-option">
                            <input type="checkbox" id="wednesday" value="3">
                            <label for="wednesday">Wednesday</label>
                        </div>
                        <div class="day-option">
                            <input type="checkbox" id="thursday" value="4">
                            <label for="thursday">Thursday</label>
                        </div>
                        <div class="day-option">
                            <input type="checkbox" id="friday" value="5">
                            <label for="friday">Friday</label>
                        </div>
                        <div class="day-option">
                            <input type="checkbox" id="saturday" value="6">
                            <label for="saturday">Saturday</label>
                        </div>
                    </div>
                </div>
                
                <div id="customDateOptions" class="custom-options">
                    <label>Select a Date (Single Selection):</label>
                    <div class="radio-group" id="dateRadios">
                        <!-- Date radio buttons will be generated by JavaScript -->
                    </div>
                </div>
                
                <button onclick="generateSerial()">Generate Serial Number</button>
                
                <div class="serial-display">
                    <p>Your serial number will appear here</p>
                    <div class="serial-number" id="serialResult">#00000</div>
                    <p id="serialInfo">Select a doctor and date to generate serial</p>
                </div>
            </div>
            
            <div class="info-container">
                <h3>How Serial Numbers Work</h3>
                
                <div class="period-info">
                    <div class="period-card">
                        <h4><i class="fas fa-calendar-day"></i> Daily</h4>
                        <p>Starts from 1 each day</p>
                    </div>
                    
                    <div class="period-card">
                        <h4><i class="fas fa-calendar-week"></i> Weekly</h4>
                        <p>Resets every Saturday</p>
                    </div>
                    
                    <div class="period-card">
                        <h4><i class="fas fa-calendar-alt"></i> 15-Day</h4>
                        <p>Resets on 1st and 16th of each month</p>
                    </div>
                    
                    <div class="period-card">
                        <h4><i class="fas fa-calendar"></i> Monthly</h4>
                        <p>Resets on 1st of each month</p>
                    </div>
                </div>
                
                <div class="period-info">
                    <div class="period-card">
                        <h4><i class="fas fa-calendar-day"></i> Custom Day</h4>
                        <p>Resets on selected days (e.g., Every Sunday, Tuesday)</p>
                    </div>
                    
                    <div class="period-card">
                        <h4><i class="fas fa-calendar-alt"></i> Custom Date</h4>
                        <p>Resets on selected date (e.g., 10th, 15th, 20th)</p>
                    </div>
                </div>
                
                <ul class="info-list">
                    <li>
                        <i class="fas fa-info-circle"></i>
                        <div>For custom dates, only one date can be selected at a time. Selecting a new date will automatically uncheck the previous selection.</div>
                    </li>
                    <li>
                        <i class="fas fa-user-md"></i>
                        <div>Each doctor has their own independent serial number sequence.</div>
                    </li>
                    <li>
                        <i class="fas fa-database"></i>
                        <div>The system automatically tracks the last serial number for each period.</div>
                    </li>
                    <li>
                        <i class="fas fa-code"></i>
                        <div>Serial numbers are formatted as # followed by 5 digits (e.g., #00042).</div>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <script>
        // Generate date radio buttons (1-31)
        const dateRadiosContainer = document.getElementById('dateRadios');
        for (let i = 1; i <= 31; i++) {
            const dateRadio = document.createElement('div');
            dateRadio.className = 'date-radio';
            dateRadio.innerHTML = `
                <input type="radio" id="date${i}" name="dateSelection" value="${i}">
                <label for="date${i}">${i}</label>
            `;
            dateRadiosContainer.appendChild(dateRadio);
            
            // Add click event to style the selected radio
            dateRadio.addEventListener('click', function() {
                document.querySelectorAll('.date-radio').forEach(el => {
                    el.classList.remove('selected');
                });
                this.classList.add('selected');
                this.querySelector('input').checked = true;
            });
        }

        // Mock database of existing appointments for demonstration
        const existingAppointments = [
            { doctor: 'dr_john', date: '2023-06-15', period: 'daily', serial: 5 },
            { doctor: 'dr_john', date: '2023-06-17', period: 'weekly', serial: 3 }, // Saturday
            { doctor: 'dr_john', date: '2023-06-18', period: 'weekly', serial: 1 }, // Sunday
            { doctor: 'dr_john', date: '2023-06-19', period: 'weekly', serial: 2 }, // Monday
            { doctor: 'dr_emma', date: '2023-06-15', period: 'weekly', serial: 12 },
            { doctor: 'dr_michael', date: '2023-06-10', period: 'monthly', serial: 21 },
            // Custom day examples
            { doctor: 'dr_john', date: '2023-06-04', period: 'custom_day_0', serial: 2 }, // Sunday
            { doctor: 'dr_john', date: '2023-06-11', period: 'custom_day_0', serial: 3 }, // Sunday
            { doctor: 'dr_john', date: '2023-06-06', period: 'custom_day_2', serial: 1 }, // Tuesday
            { doctor: 'dr_john', date: '2023-06-13', period: 'custom_day_2', serial: 2 }, // Tuesday
            { doctor: 'dr_john', date: '2023-06-09', period: 'custom_day_5', serial: 4 }, // Friday
            { doctor: 'dr_john', date: '2023-06-16', period: 'custom_day_5', serial: 5 }, // Friday
            // Custom date examples
            { doctor: 'dr_john', date: '2023-06-10', period: 'custom_date_10', serial: 3 },
            { doctor: 'dr_john', date: '2023-06-15', period: 'custom_date_15', serial: 2 },
            { doctor: 'dr_john', date: '2023-06-20', period: 'custom_date_20', serial: 4 },
        ];
        
        // Show/hide custom options based on period selection
        document.getElementById('period').addEventListener('change', function() {
            document.getElementById('customDayOptions').style.display = 'none';
            document.getElementById('customDateOptions').style.display = 'none';
            
            if (this.value === 'custom_day') {
                document.getElementById('customDayOptions').style.display = 'block';
            } else if (this.value === 'custom_date') {
                document.getElementById('customDateOptions').style.display = 'block';
            }
        });
        
        // Auto-select date when calendar date changes
        document.getElementById('date').addEventListener('change', function() {
            const date = new Date(this.value);
            const dateOfMonth = date.getDate();
            
            // Select the corresponding date radio button
            const dateRadio = document.getElementById(`date${dateOfMonth}`);
            if (dateRadio) {
                // Unselect all first
                document.querySelectorAll('.date-radio').forEach(el => {
                    el.classList.remove('selected');
                    el.querySelector('input').checked = false;
                });
                
                // Select the new one
                dateRadio.checked = true;
                dateRadio.parentElement.classList.add('selected');
            }
        });
        
        function generateSerial() {
            const doctor = document.getElementById('doctor').value;
            const dateString = document.getElementById('date').value;
            const periodType = document.getElementById('period').value;
            
            if (!doctor || !dateString) {
                alert('Please select a doctor and date');
                return;
            }
            
            const date = new Date(dateString);
            let period = periodType;
            let maxSerial = 0;
            
            // Handle custom day selection
            if (periodType === 'custom_day') {
                const selectedDays = Array.from(document.querySelectorAll('#customDayOptions input:checked'))
                    .map(checkbox => parseInt(checkbox.value));
                
                if (selectedDays.length === 0) {
                    alert('Please select at least one day for custom day serial');
                    return;
                }
                
                // Check if selected date matches any selected day
                const dayOfWeek = date.getDay();
                if (!selectedDays.includes(dayOfWeek)) {
                    alert('Selected date does not match any of the chosen days');
                    return;
                }
                
                // Create a unique period identifier for this day of week
                period = `custom_day_${dayOfWeek}`;
            }
            
            // Handle custom date selection
            if (periodType === 'custom_date') {
                const selectedDate = document.querySelector('input[name="dateSelection"]:checked');
                
                if (!selectedDate) {
                    alert('Please select a date for custom date serial');
                    return;

                }
                
                const selectedDateValue = parseInt(selectedDate.value);
                
                // Check if selected date matches the chosen date
                const dateOfMonth = date.getDate();
                if (selectedDateValue !== dateOfMonth) {
                    alert('Selected date does not match the chosen date');
                    return;
                }
                
                // Create a unique period identifier for this date of month
                period = `custom_date_${dateOfMonth}`;
            }
            
            // In a real application, this would be a database query
            // For demo, we're filtering our mock data
            for (const app of existingAppointments) {
                if (app.doctor !== doctor) continue;
                
                const appDate = new Date(app.date);
                let isSamePeriod = false;
                
                switch (periodType) {
                    case 'daily':
                        isSamePeriod = isSameDay(date, appDate);
                        break;
                    case 'weekly':
                        isSamePeriod = isSameWeek(date, appDate);
                        break;
                    case 'biweekly':
                        isSamePeriod = isSameBiweekly(date, appDate);
                        break;
                    case 'monthly':
                        isSamePeriod = isSameMonth(date, appDate);
                        break;
                    case 'custom_day':
                        // For custom day, we compare based on the specific day of week
                        isSamePeriod = (app.period === period);
                        break;
                    case 'custom_date':
                        // For custom date, we compare based on the specific date of month
                        isSamePeriod = (app.period === period);
                        break;
                }
                
                if (isSamePeriod && app.serial > maxSerial) {
                    maxSerial = app.serial;
                }
            }
            
            const newSerial = maxSerial + 1;
            const formattedSerial = '#' + newSerial.toString().padStart(5, '0');
            
            document.getElementById('serialResult').textContent = formattedSerial;
            
            // Update information text based on period
            let infoText = '';
            switch (periodType) {
                case 'daily':
                    infoText = `Daily serial for ${formatDate(date)}`;
                    break;
                case 'weekly':
                    infoText = `Weekly serial (week starting ${getSaturday(date)})`;
                    break;
                case 'biweekly':
                    infoText = `15-day serial (${getBiweeklyPeriod(date)})`;
                    break;
                case 'monthly':
                    infoText = `Monthly serial for ${date.toLocaleString('default', { month: 'long', year: 'numeric' })}`;
                    break;
                case 'custom_day':
                    const dayName = date.toLocaleString('default', { weekday: 'long' });
                    infoText = `Custom day serial for ${dayName}`;
                    break;
                case 'custom_date':
                    const dateWithSuffix = getDateWithSuffix(date.getDate());
                    infoText = `Custom date serial for ${dateWithSuffix}`;
                    break;
            }
            
            document.getElementById('serialInfo').textContent = infoText;
        }
        
        // Date helper functions
        function isSameDay(d1, d2) {
            return d1.toDateString() === d2.toDateString();
        }
        
        function isSameWeek(d1, d2) {
            const saturday1 = getSaturday(d1);
            const saturday2 = getSaturday(d2);
            return saturday1.toDateString() === saturday2.toDateString();
        }
        
        function isSameBiweekly(d1, d2) {
            const period1 = getBiweeklyPeriod(d1);
            const period2 = getBiweeklyPeriod(d2);
            return period1 === period2;
        }
        
        function isSameMonth(d1, d2) {
            return d1.getFullYear() === d2.getFullYear() && d1.getMonth() === d2.getMonth();
        }
        
        function getSaturday(date) {
            const d = new Date(date);
            const day = d.getDay(); // 0 = Sunday, 6 = Saturday
            const diff = d.getDate() - day + (day === 6 ? 0 : (day === 0 ? -6 : 6 - day));
            return new Date(d.setDate(diff));
        }
        
        function getBiweeklyPeriod(date) {
            const day = date.getDate();
            return day <= 15 ? '1-15' : '16-' + new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
        }
        
        function formatDate(date) {
            return date.toLocaleDateString('en-US', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
            });
        }
        
        function getDateWithSuffix(date) {
            if (date > 3 && date < 21) return date + 'th';
            switch (date % 10) {
                case 1: return date + 'st';
                case 2: return date + 'nd';
                case 3: return date + 'rd';
                default: return date + 'th';
            }
        }
        
        // Set default date to today
        const today = new Date();
        document.getElementById('date').valueAsDate = today;
        
        // Auto-select today's date
        const dateOfMonth = today.getDate();
        const dateRadio = document.getElementById(`date${dateOfMonth}`);
        if (dateRadio) {
            dateRadio.checked = true;
            dateRadio.parentElement.classList.add('selected');
        }
        
        // Pre-select some common options for demo
        document.getElementById('sunday').checked = true;
        document.getElementById('tuesday').checked = true;
        document.getElementById('friday').checked = true;
    </script>
</body>
</html>