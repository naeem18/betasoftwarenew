 <?php
session_start();
require('labdd.php');
date_default_timezone_set("Asia/Dhaka");
if($_SESSION['employeename']=='ADMINISTRATOR' or $_SESSION['employeename']=='SUPERADMINISTRATOR'){
// --- Input Filters ---
$from = $_POST['ADate1'];
$to   = $_POST['ADate2'];

$labinvoice_id        = $_POST['labinvoice_id'];
$labinvoice_patient   = $_POST['labinvoice_patient'];
$labinvoice_mobile   = $_POST['labinvoice_mobile'];
$labinvoice_patientid = $_POST['labinvoice_patientid'];
$labinvoice_doctor    = $_POST['labinvoice_doctor'];
$labinvoice_pc        = $_POST['labinvoice_pc'];
$labinvoice_mpo       = $_POST['labinvoice_mpo'];
$bar                  = $_POST['bar'];
$user                 = $_POST['user'];

//$searchstr = " AND dstatus != 'Deleted' AND txstatus != 'Deleted' ";
$searchstr = " AND dstatus != 'Deleted' ";

// --- Date / ID Filter ---
$labinvoice_id_from = isset($_POST['labinvoice_id_from']) ? (int)$_POST['labinvoice_id_from'] : 0;
$labinvoice_id_to   = isset($_POST['labinvoice_id_to']) ? (int)$_POST['labinvoice_id_to'] : 0;

if ($labinvoice_id_from > 0 && $labinvoice_id_to > 0) {
    $searchstr .= " AND labinvoice_id BETWEEN $labinvoice_id_from AND $labinvoice_id_to ";
} elseif ($labinvoice_id_from > 0) {
    $searchstr .= " AND labinvoice_id >= $labinvoice_id_from ";
} elseif ($labinvoice_id_to > 0) {
    $searchstr .= " AND labinvoice_id <= $labinvoice_id_to ";
} elseif (!empty($labinvoice_id)) {
    $searchstr .= " AND labinvoice_id = '".intval($labinvoice_id)."' ";
} else {
    $searchstr .= " AND DATE(labinvoice_date) BETWEEN '$from' AND '$to' ";
}

// --- Other Filters ---
if (!empty($labinvoice_patient)) $searchstr .= " AND labinvoice_patient LIKE '%".mysqli_real_escape_string($conn, $labinvoice_patient)."%'";
if (!empty($labinvoice_mobile)) $searchstr .= " AND labinvoice_mobile LIKE '%".mysqli_real_escape_string($conn, $labinvoice_mobile)."%'";
if (!empty($labinvoice_patientid)) $searchstr .= " AND labinvoice_patientid LIKE '%".mysqli_real_escape_string($conn, $labinvoice_patientid)."%'";
if (!empty($labinvoice_doctor)) $searchstr .= " AND labinvoice_doctor LIKE '%".mysqli_real_escape_string($conn, $labinvoice_doctor)."%'";
if (!empty($labinvoice_pc)) $searchstr .= " AND labinvoice_pc LIKE '%".mysqli_real_escape_string($conn, $labinvoice_pc)."%'";
if (!empty($labinvoice_mpo)) $searchstr .= " AND labinvoice_mpo LIKE '%".mysqli_real_escape_string($conn, $labinvoice_mpo)."%'";
if (!empty($bar)) $searchstr .= " AND bar LIKE '%".mysqli_real_escape_string($conn, $bar)."%'";
if (!empty($user)) $searchstr .= " AND user LIKE '%".mysqli_real_escape_string($conn, $user)."%'";

// --- Main Query ---
$sql = "SELECT * FROM labinvoice WHERE 1=1 $searchstr ORDER BY labinvoice_id DESC";
$res = mysqli_query($conn, $sql);

if (!$res || mysqli_num_rows($res) == 0) {
    echo "<p style='color:red'>❗ No records found for the selected filters.</p>";
    exit;
}

// --- Table Header ---
echo "<table border='1' cellpadding='5' cellspacing='0' width='100%'>
<thead>
<tr>
    <th>SL</th>
    <th>Date</th>
    <th>Print Memo</th>
    <th>Bill No.</th>
    <th>Patient</th>
    <th>Test Name(s)</th>
    <th>BarCode</th>
    <th>Mobile</th>
    <th>Gross</th>
    <th>Disc.</th>
    <th>Net</th>
    <th>Cash</th>
    <th>F.Disc.</th>
    <th>Collection</th>
    <th>Due</th>
    <th>Ref. Dr.</th>
    <th>MPO</th>
    <th>P.C Name</th>
    <th>P.C Com Due</th>
    <th>Note</th>
    <th>User</th>
    <th>Updated User</th>
    <th>Info. Update</th>
	<th>Bill Update</th>
</tr>
</thead>
<tbody>";

$sl = 1;
$gross = $disc = $net = $fdisc = $collection = $cash = $due = $pccash= $pccashtotal=0;

while ($row = mysqli_fetch_assoc($res)) {
    // --- Patient Info ---
    $patient = !empty($row['labinvoice_patientid']) 
        ? "<b>".htmlspecialchars($row['labinvoice_patient'])." (".htmlspecialchars($row['labinvoice_patientid']).")</b>" 
        : htmlspecialchars($row['labinvoice_patient']);

    // --- Test Names (Serial) ---
    $test_sql = "SELECT labinvoicedetails_item FROM labinvoicedetails WHERE dstatus!='Deleted' AND labinvoice_id = {$row['labinvoice_id']} ORDER BY auto_number ASC";
    $test_q = mysqli_query($conn, $test_sql);
    $testList = "";
    $counter = 1;
    while ($t = mysqli_fetch_assoc($test_q)) {
        $testList .= $counter.". ".htmlspecialchars($t['labinvoicedetails_item'])."<br>";
        $counter++;
    }

    // --- Action Links ---
     $action = "<a href='printlabinvoiceduplicate.php?&labinvoice_id={$row['labinvoice_id']}' target='_blank'>Print</a>";
 	//$actioninfo = "<a href='index.php?p=labinvoiceinfoupdate&labinvoice_id={$row['labinvoice_id']}' target='_blank'>Info.Update</a>";
	$actioninfo = ''; // default empty
	if ($_SESSION['employeename'] == 'SUPERADMINISTRATOR') {
    $actioninfo = "<a href='index.php?p=labinvoiceinfoupdate&labinvoice_id={$row['labinvoice_id']}' target='_blank'>Info.Update</a>";
	}
	
	
	$actionedit = "<a href='index.php?p=labinvoiceedit&labinvoice_id={$row['labinvoice_id']}' target='_blank'>Edit</a>";
	//$actioninv = "<a href=\"index.php?p=labinvoiceedititem&labinvoice_id=$labinvoice_id\" target=\"_blank\">Update</a>";
	//$actionupdate = "<a href=\"index.php?p=labinvoiceinfoupdate&labinvoice_id=$labinvoice_id\" target=\"_blank\">Info. Update</a>";
	$actionremove = "<a href=\"javascript:void(0)\" onclick=\"removetablerow2({$row['labinvoice_id']})\">Remove</a>";
	$actionhide = "<a href=\"index.php?p=labinvoicehide&labinvoice_id=$labinvoice_id\">Hide</a>";
 			
    //--- Table Row ---
    echo "<tr>
        <td>{$sl}</td>
        <td>{$row['labinvoice_date']}</td>
        <td>{$action}</td>
        <td>{$row['labinvoice_id']}</td>
        <td>{$patient}</td>
        <td>{$testList}</td>
        <td>{$row['bar']}</td>
        <td>{$row['labinvoice_mobile']}</td>
        <td>{$row['labinvoice_subtotal']}</td>
        <td>{$row['labinvoice_totaldisc']}</td>
        <td>{$row['labinvoice_subtotalafterdisc']}</td>
        <td><b>{$row['labinvoice_receiveamount']}</b></td>
        <td>{$row['labinvoice_finaldisc']}</td>
        <td>{$row['collection_amount']}</td>
        <td><strong>{$row['labinvoice_due']}</strong></td>
        <td>{$row['labinvoice_doctor']}</td>
        <td>{$row['labinvoice_mpo']}</td>
        <td>{$row['labinvoice_pc']}</td>
        <td>{$row['totalpcamt']}</td>
        <td>{$row['labinvoice_totalpccomission']}</td>
        <td>{$row['labinvoice_description']}</td>
        <td>{$row['user']}</td>
        <td>{$row['update_user']}</td>
        <td>{$actioninfo}</td>
		<td>{$actionedit}</td>
		<td>{$actionremove}</td>
    </tr>";

    // --- Total Calculation ---
    $sl++;
    $gross      += $row['labinvoice_subtotal'];
    $disc       += $row['labinvoice_totaldisc'];
    $fdisc      += $row['labinvoice_finaldisc'];
    $collection += $row['collection_amount'];
    $net        += $row['labinvoice_subtotalafterdisc'];
    $cash       += $row['labinvoice_receiveamount'];
    $due        += $row['labinvoice_due'];
	$pccash     += $row['labinvoice_totalpccomission'];
	$pccashtotal     += $row['totalpcamt'];
}

// --- Total Row ---
echo "<tr style='font-weight:bold; background:#f9f9f9'>
    <td colspan='8' align='right'>Total</td>
    <td>Gross: {$gross}</td>
    <td>Disc: {$disc}</td>
    <td>Net: {$net}</td>
    <td>Cash: {$cash}</td>
    <td>F.disc: {$fdisc}</td>
    <td>Collection: {$collection}</td>
    <td>Due: {$due}</td>
	<td colspan='3'></td>
	<td>PC: {$pccash}</td>
    <td colspan='4'></td>
</tr>";

echo "</tbody></table>";
?>
<?php }?>