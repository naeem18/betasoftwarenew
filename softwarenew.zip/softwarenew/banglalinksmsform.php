<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Send SMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <h2 class="text-center">Send SMS via Banglalink API</h2>
    <div class="card p-4 shadow-sm">
        <form action="send_sms.php" method="post">
            <div class="mb-3">
                <label for="msisdn" class="form-label">Recipient Number (MSISDN)</label>
                <input type="text" class="form-control" id="msisdn" name="msisdn" required placeholder="8801XXXXXXXXX">
            </div>
            <div class="mb-3">
                <label for="message" class="form-label">Message</label>
                <textarea class="form-control" id="message" name="message" required placeholder="Enter your SMS message"></textarea>
            </div>
            <button type="submit" class="btn btn-primary w-100">Send SMS</button>
        </form>
    </div>
</div>
</body>
</html>
