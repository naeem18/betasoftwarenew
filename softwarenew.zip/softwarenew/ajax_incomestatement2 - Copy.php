<?php
date_default_timezone_set('Asia/Dhaka');
require('labdd.php');

// Optional hospital name
//$hospitaldata_name = "Your Hospital Name"; // You can set dynamically if needed

// ========== FUNCTIONS ==========

// Get date parameters safely
function getDateParameters() {
    if (isset($_REQUEST['ADate1']) && $_REQUEST['ADate1'] != '' && 
        isset($_REQUEST['ADate2']) && $_REQUEST['ADate2'] != '') {
        return array(
            'from' => $_REQUEST['ADate1'],
            'to' => $_REQUEST['ADate2']
        );
    } else {
        return array(
            'from' => date('Y-m-d', strtotime('-1 month')),
            'to' => date('Y-m-d')
        );
    }
}

// Validate & correct date order
function validateDates($date1, $date2) {
    $datetime1 = new DateTime($date1);
    $datetime2 = new DateTime($date2);
    if ($datetime1 < $datetime2) {
        return array('from' => $date1, 'to' => $date2);
    } else {
        return array('from' => $date2, 'to' => $date1);
    }
}

// Sum a column from a query
function sumQueryResult($conn, $query, $column) {
    $total = 0.00;
    $result = mysqli_query($conn, $query);
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_array($result)) {
            $total += round($row[$column]);
        }
    }
    return $total;
}

// Main calculation
function calculateDailyTotals($conn, $dateFrom, $dateTo) {
    $totals = array(
        'purchase_receive'=>0, 'purchase_paid'=>0, 'appointment'=>0,
        'dental_cash'=>0, 'dental_collection'=>0, 'lab_cash'=>0,
        'lab_return'=>0, 'lab_collection'=>0, 'hospital_cash'=>0,
        'hospital_collection'=>0, 'icu_cash'=>0, 'icu_collection'=>0,
        'expense'=>0, 'lab_pc_paid'=>0, 'hospital_pc_paid'=>0,
        'salary_paid'=>0, 'inventory_sales'=>0, 'bank_deposit'=>0,
        'bank_withdrawal'=>0, 'loan_deposit'=>0, 'loan_received'=>0,
        'emergency_cash'=>0, 'emergency_collection'=>0,
        'advanced'=>0, 'admission'=>0, 'ambulance'=>0
    );

    $totals['purchase_receive'] = sumQueryResult($conn, "SELECT purchaseinvoice_receiveamount FROM storepurchaseinvoice WHERE purchaseinvoice_date BETWEEN '$dateFrom' AND '$dateTo' AND purchaseinvoice_receiveamount>0", 'purchaseinvoice_receiveamount');
    $totals['purchase_paid'] = sumQueryResult($conn, "SELECT purchaseinvoicepaid_amount FROM storepurchaseinvoicepaid WHERE purchaseinvoicepaid_date BETWEEN '$dateFrom' AND '$dateTo' AND purchaseinvoicepaid_amount>0", 'purchaseinvoicepaid_amount');
    $totals['appointment'] = sumQueryResult($conn, "SELECT appointmententry_amount FROM appointmententry WHERE appointmententry_date BETWEEN '$dateFrom' AND '$dateTo' AND appointmententry_amount>0", 'appointmententry_amount');
    $totals['dental_cash'] = sumQueryResult($conn, "SELECT labinvoice_receiveamount FROM dentalinvoice WHERE labinvoice_date BETWEEN '$dateFrom' AND '$dateTo' AND labinvoice_receiveamount>0", 'labinvoice_receiveamount');
    $totals['dental_collection'] = sumQueryResult($conn, "SELECT collection_amount FROM dentalcollection WHERE labinvoice_date BETWEEN '$dateFrom' AND '$dateTo' AND collection_amount>0", 'collection_amount');
    $totals['lab_cash'] = sumQueryResult($conn, "SELECT labinvoice_receiveamount FROM labinvoice WHERE dstatus!='Deleted' AND labinvoice_date BETWEEN '$dateFrom' AND '$dateTo' AND labinvoice_receiveamount>0", 'labinvoice_receiveamount');
    $totals['lab_return'] = sumQueryResult($conn, "SELECT labinvoice_receiveamount FROM labinvoice_return WHERE labinvoice_date BETWEEN '$dateFrom' AND '$dateTo' AND labinvoice_receiveamount>0", 'labinvoice_receiveamount');
    $totals['lab_collection'] = sumQueryResult($conn, "SELECT collection_amount FROM labcollection WHERE status!='Deleted' AND labcollection_date BETWEEN '$dateFrom' AND '$dateTo' AND collection_amount>0", 'collection_amount');
    $totals['hospital_cash'] = sumQueryResult($conn, "SELECT hospitalinvoice_receiveamount FROM hospitalinvoice WHERE status!='Deleted' AND hospitalinvoice_deliverydate BETWEEN '$dateFrom' AND '$dateTo' AND hospitalinvoice_receiveamount>0", 'hospitalinvoice_receiveamount');
    $totals['hospital_collection'] = sumQueryResult($conn, "SELECT hospitalinvoicecollection_amount FROM hospitalinvoicecollection WHERE hospitalinvoicecollection_date BETWEEN '$dateFrom' AND '$dateTo' AND hospitalinvoicecollection_amount>0", 'hospitalinvoicecollection_amount');
    $totals['icu_cash'] = sumQueryResult($conn, "SELECT hospitalinvoiceicu_receiveamount FROM hospitalinvoiceicu WHERE status!='Deleted' AND hospitalinvoiceicu_deliverydate BETWEEN '$dateFrom' AND '$dateTo' AND hospitalinvoiceicu_receiveamount>0", 'hospitalinvoiceicu_receiveamount');
    $totals['icu_collection'] = sumQueryResult($conn, "SELECT hospitalinvoiceicucollection_amount FROM hospitalinvoiceicucollection WHERE hospitalinvoiceicucollection_date BETWEEN '$dateFrom' AND '$dateTo' AND hospitalinvoiceicucollection_amount>0", 'hospitalinvoiceicucollection_amount');
    $totals['expense'] = sumQueryResult($conn, "SELECT expense_amount FROM expense WHERE expense_date BETWEEN '$dateFrom' AND '$dateTo' AND expense_amount<>0", 'expense_amount');
    $totals['lab_pc_paid'] = sumQueryResult($conn, "SELECT labpcpaid_amount FROM labpcpaid WHERE labpcpaid_date BETWEEN '$dateFrom' AND '$dateTo' AND labpcpaid_amount<>0", 'labpcpaid_amount');
    $totals['hospital_pc_paid'] = sumQueryResult($conn, "SELECT hospitalpcpaid_amount FROM hospitalpcpaid WHERE hospitalpcpaid_date BETWEEN '$dateFrom' AND '$dateTo' AND hospitalpcpaid_amount<>0", 'hospitalpcpaid_amount');
    $totals['salary_paid'] = sumQueryResult($conn, "SELECT salaryentry_paid FROM salaryentry WHERE salaryentry_date BETWEEN '$dateFrom' AND '$dateTo' AND salaryentry_paid<>0", 'salaryentry_paid');
    $totals['inventory_sales'] = sumQueryResult($conn, "SELECT inventorysalesinvoice_receiveamount FROM inventorysalesinvoice WHERE inventorysalesinvoice_date BETWEEN '$dateFrom' AND '$dateTo' AND inventorysalesinvoice_receiveamount<>0", 'inventorysalesinvoice_receiveamount');
    $totals['bank_deposit'] = sumQueryResult($conn, "SELECT deposite_amount FROM bankinvoice WHERE bankinvoice_date BETWEEN '$dateFrom' AND '$dateTo' AND deposite_amount<>0", 'deposite_amount');
    $totals['bank_withdrawal'] = sumQueryResult($conn, "SELECT withdrawal_amount FROM bankinvoice WHERE bankinvoice_date BETWEEN '$dateFrom' AND '$dateTo' AND withdrawal_amount<>0", 'withdrawal_amount');
    $totals['loan_deposit'] = sumQueryResult($conn, "SELECT deposite_amount FROM loaninvoice WHERE loaninvoice_date BETWEEN '$dateFrom' AND '$dateTo' AND deposite_amount>0", 'deposite_amount');
    $totals['loan_received'] = sumQueryResult($conn, "SELECT withdrawal_amount FROM loaninvoice WHERE loaninvoice_date BETWEEN '$dateFrom' AND '$dateTo' AND withdrawal_amount>0", 'withdrawal_amount');
    $totals['emergency_cash'] = sumQueryResult($conn, "SELECT emergencyinvoice_receiveamount FROM emergencyinvoice WHERE emergencyinvoice_date BETWEEN '$dateFrom' AND '$dateTo' AND emergencyinvoice_receiveamount>0", 'emergencyinvoice_receiveamount');
    $totals['emergency_collection'] = sumQueryResult($conn, "SELECT collection_amount FROM emergencycollection WHERE emergencyinvoice_date BETWEEN '$dateFrom' AND '$dateTo' AND collection_amount>0", 'collection_amount');
    $totals['advanced'] = sumQueryResult($conn, "SELECT advanced FROM advanced WHERE type!='Admission Fee' AND advanced_date BETWEEN '$dateFrom' AND '$dateTo' AND advanced>0", 'advanced');
    $totals['admission'] = sumQueryResult($conn, "SELECT labinvoice_receiveamount FROM dailytransection_lab WHERE section='Admission Fee' AND dailytransection_lab_date BETWEEN '$dateFrom' AND '$dateTo' AND labinvoice_receiveamount>0", 'labinvoice_receiveamount');
    $totals['ambulance'] = sumQueryResult($conn, "SELECT received FROM ambulance WHERE created_date BETWEEN '$dateFrom' AND '$dateTo' AND received>0", 'received');
    return $totals;
}

function hasTransactions($totals) {
    foreach ($totals as $v) if ($v != 0) return true;
    return false;
}
function calculateGrossReceipt($t) {
    return $t['lab_cash'] + $t['ambulance'] + $t['advanced'] + $t['admission'] +
           $t['lab_collection'] + $t['appointment'] + $t['dental_cash'] +
           $t['dental_collection'] + $t['hospital_cash'] + $t['hospital_collection'] +
           $t['icu_cash'] + $t['icu_collection'] + $t['bank_withdrawal'] +
           $t['emergency_cash'] + $t['emergency_collection'] + $t['inventory_sales'] + 
           $t['loan_received'];
}
function calculateTotalPayment($t) {
    return $t['expense'] + $t['lab_return'] + $t['lab_pc_paid'] + 
           $t['hospital_pc_paid'] + $t['purchase_receive'] + $t['purchase_paid'] + 
           $t['salary_paid'] + $t['bank_deposit'] + $t['loan_deposit'];
}

// ========== MAIN ==========
$params = getDateParameters();
$valid = validateDates($params['from'], $params['to']);
$fromdate = $valid['from'];
$todate = $valid['to'];

$d1 = new DateTime($fromdate);
$d2 = new DateTime($todate);
$interval = $d1->diff($d2);
$totaldays = $interval->format('%a');

$summary = array_fill_keys(array(
    'lab_cash','lab_collection','appointment','dental_cash','dental_collection','ambulance','admission','advanced',
    'hospital_cash','hospital_collection','icu_cash','icu_collection','emergency_cash','emergency_collection',
    'inventory_sales','loan_received','bank_withdrawal','expense','lab_return','lab_pc_paid','hospital_pc_paid',
    'purchase_receive','purchase_paid','salary_paid','loan_deposit','bank_deposit'
), 0);

$total_receipt = 0;

// ========== OUTPUT TABLE ==========
?>
<table align="center" width="100%" border="1" style="border-collapse:collapse" cellpadding="1">
<tr>
  <td align="center" colspan="100%" bgcolor="#011E6A" style="color:#FFF;">
    <strong><?php //echo $hospitaldata_name; ?></strong><br>
    <strong>Receipt Payment Report :: date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate)); ?></strong>
  </td>
</tr>
<tr bgcolor="#176EBF" style="color:#000">
  <td>Date</td><td>Lab Inv Cash</td><td>Lab Coll</td><td>Dr. Visit</td><td>Dental Cash</td><td>Dental Coll</td>
  <td>Ambulance</td><td>Admission</td><td>Advanced</td><td>Hospital Cash</td><td>Hospital Coll</td>
  <td>ICU Cash</td><td>ICU Coll</td><td>Emergency</td><td>Emerg. Coll</td><td>Asset Sold</td>
  <td>Loan Received</td><td>Bank Withdraw</td><td><b>Receipt</b></td><td>Expense</td><td>Lab Return</td>
  <td>Lab PC</td><td>Hosp PC</td><td>Inv Purchase</td><td>Inv Due Pay</td><td>Salary</td>
  <td>Loan Paid</td><td>Bank Deposit</td><td><b>Payment</b></td><td><b>Cash In Hand</b></td>
</tr>
<?php
for ($i=0; $i <= $totaldays; $i++) {
    $currentDate = date('Y-m-d', strtotime($fromdate) + ($i*86400));
    $dateFrom = $currentDate.' 00:00:00';
    $dateTo = $currentDate.' 23:59:59';
    $daily = calculateDailyTotals($conn, $dateFrom, $dateTo);
    if (hasTransactions($daily)) {
        $gross = calculateGrossReceipt($daily);
        $payment = calculateTotalPayment($daily);
        $cashInHand = $gross - $payment;
        foreach ($daily as $k=>$v) $summary[$k]+=$v;
        $total_receipt += $gross;
        echo "<tr bgcolor='#fff'>
            <td>".date('d.m.y',strtotime($currentDate))."</td>
            <td>{$daily['lab_cash']}</td><td>{$daily['lab_collection']}</td><td>{$daily['appointment']}</td>
            <td>{$daily['dental_cash']}</td><td>{$daily['dental_collection']}</td><td>{$daily['ambulance']}</td>
            <td>{$daily['admission']}</td><td>{$daily['advanced']}</td><td>{$daily['hospital_cash']}</td>
            <td>{$daily['hospital_collection']}</td><td>{$daily['icu_cash']}</td><td>{$daily['icu_collection']}</td>
            <td>{$daily['emergency_cash']}</td><td>{$daily['emergency_collection']}</td><td>{$daily['inventory_sales']}</td>
            <td>{$daily['loan_received']}</td><td>{$daily['bank_withdrawal']}</td>
            <td><b>$gross</b></td><td>{$daily['expense']}</td><td>{$daily['lab_return']}</td>
            <td>{$daily['lab_pc_paid']}</td><td>{$daily['hospital_pc_paid']}</td>
            <td>{$daily['purchase_receive']}</td><td>{$daily['purchase_paid']}</td>
            <td>{$daily['salary_paid']}</td><td>{$daily['loan_deposit']}</td><td>{$daily['bank_deposit']}</td>
            <td><b>$payment</b></td><td>$cashInHand</td>
        </tr>";
    }
}
$summary_exp_total = $summary['expense'] + $summary['purchase_receive'] + $summary['purchase_paid'];
$summary_payment_total = $summary_exp_total + $summary['lab_return'] + $summary['lab_pc_paid'] + 
                         $summary['hospital_pc_paid'] + $summary['salary_paid'] + $summary['bank_deposit'] + 
                         $summary['loan_deposit'];
$summary_cash_in_hand = $total_receipt - $summary_payment_total;
?>
<tr bgcolor="#EDEDED">
  <td><b>Total:</b></td>
  <td>Lab Cash: <b><?php echo $summary['lab_cash']; ?></b></td>
  <td>Lab Coll: <b><?php echo $summary['lab_collection']; ?></b></td>
  <td>Dr: <b><?php echo $summary['appointment']; ?></b></td>
  <td>Dental: <b><?php echo $summary['dental_cash']; ?></b></td>
  <td>Dental Coll: <b><?php echo $summary['dental_collection']; ?></b></td>
  <td>Ambulance: <b><?php echo $summary['ambulance']; ?></b></td>
  <td>Admission: <b><?php echo $summary['admission']; ?></b></td>
  <td>Advance: <b><?php echo $summary['advanced']; ?></b></td>
  <td>Hosp Cash: <b><?php echo $summary['hospital_cash']; ?></b></td>
  <td>Hosp Coll: <b><?php echo $summary['hospital_collection']; ?></b></td>
  <td>ICU Cash: <b><?php echo $summary['icu_cash']; ?></b></td>
  <td>ICU Coll: <b><?php echo $summary['icu_collection']; ?></b></td>
  <td>Emerg: <b><?php echo $summary['emergency_cash']; ?></b></td>
  <td>Emerg Coll: <b><?php echo $summary['emergency_collection']; ?></b></td>
  <td>Asset: <b><?php echo $summary['inventory_sales']; ?></b></td>
  <td>Loan Rcv: <b><?php echo $summary['loan_received']; ?></b></td>
  <td>Bank W: <b><?php echo $summary['bank_withdrawal']; ?></b></td>
  <td><b>Receipt: <?php echo $total_receipt; ?></b></td>
  <td>Expense: <b><?php echo $summary['expense']; ?></b></td>
  <td>Lab Return: <b><?php echo $summary['lab_return']; ?></b></td>
  <td>Lab PC: <b><?php echo $summary['lab_pc_paid']; ?></b></td>
  <td>Hosp PC: <b><?php echo $summary['hospital_pc_paid']; ?></b></td>
  <td>Inv Purchase: <b><?php echo $summary['purchase_receive']; ?></b></td>
  <td>Inv Paid: <b><?php echo $summary['purchase_paid']; ?></b></td>
  <td>Salary: <b><?php echo $summary['salary_paid']; ?></b></td>
  <td>Loan Paid: <b><?php echo $summary['loan_deposit']; ?></b></td>
  <td><b>Bank Dep: <?php echo number_format($summary['bank_deposit'],2,'.',''); ?></b></td>
  <td><b>Total Pay: <?php echo number_format($summary_payment_total,2,'.',''); ?></b></td>
  <td><b>Cash: <?php echo number_format($summary_cash_in_hand,2,'.',''); ?></b></td>
</tr>
</table>
