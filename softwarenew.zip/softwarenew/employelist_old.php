<script language="JavaScript" type="text/javascript">
 function calculatepack(){
 		var houserent = parseFloat(document.getElementById("houserent").value);
		if(houserent=='' || isNaN(houserent)){houserent = 0;}
		
		var dpsfound = parseFloat(document.getElementById("dpsfound").value);
		if(dpsfound=='' || isNaN(dpsfound)){dpsfound = 0;}
		
		 
		var monthlysalary = parseFloat(document.getElementById("monthlysalary").value);
		if(monthlysalary=='' || isNaN(monthlysalary)){monthlysalary = 0;}
  		
		var netsalary = parseFloat(monthlysalary-houserent-dpsfound);
		document.getElementById("netsalary").value = netsalary.toFixed(2);
		
 		var workingday = parseFloat(document.getElementById("workingday").value);
		if(workingday=='' || isNaN(workingday)){workingday = 0;}
		
		var perdaysalary = parseFloat(netsalary/workingday);
		document.getElementById("perdaysalary").value = perdaysalary.toFixed(2);
		
  	}
</script>

        <header class="header_tittle">
            <h3> Add New Item</h3>
        </header>
					
		<?php
			if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
			echo "<h2 class=\"red12bold\">You have missing Something</h2>";
			}
			elseif(isset($_GET['message']) && $_GET['message']=='duplicatename'){
			echo "<h2 class=\"red12bold\">This Item  already exists. Please try with different item .</h2>";   
			}
			elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
			echo "<h2 class=\"red12bold\">Error occured! Could not insert.</h2>";   
			}
			elseif(isset($_GET['message']) && $_GET['message']=='insert-successfully'){
			echo "<h2 class=\"red12bold\">Item insert successfully</h2>";   
			}
  			$employenameentry_id = 0;
			$empname = '';
			$netsalary = '';
			$payablesalary = '';
			$workingday = '';
			$houserent = '';
			$netsalary = '';
			$dpsfound = '';
			$monthlysalary = '';
			$perdaysalary='';
			$employenameentry_photo='';
			$address='';
			$designation='';
			$father='';
			$advanced ='';
							
        if(isset($_GET['employenameentry_id'])){
            $employenameentry_id = $_GET['employenameentry_id'];
            $sqlsalesitem = "select * from employenameentry where employenameentry_id = $employenameentry_id";
            $salesitemquery = mysqli_query($conn, $sqlsalesitem);
            if($salesitemquery){
                while($srow = mysqli_fetch_array($salesitemquery)){
                    $employenameentry_id = $srow['employenameentry_id'];
                    $empname = $srow['empname'];
					$netsalary = $srow['netsalary'];
					$payablesalary = $srow['payablesalary'];
					$workingday = $srow['workingday'];
					$houserent = $srow['houserent'];
				 	$netsalary = $srow['netsalary'];
				 	$dpsfound = $srow['dpsfound'];
				 	$monthlysalary = $srow['monthlysalary'];
				 	$perdaysalary = $srow['perdaysalary'];
				 	$employenameentry_photo = $srow['employenameentry_photo'];
					$address = $srow['address'];
					$advanced = $srow['advanced'];
					$designation = $srow['designation'];
					$father = $srow['father'];
 					}
				}
			}
        ?>        
                            
		<form action="save_employenameentry.php" name="frmcontact" onsubmit="return checkcontactform();" method="post" enctype="multipart/form-data">
       
            <table width="70%" border="1" style="border-collapse:collapse" bgcolor="#fff">
               
                <tr>
                    <td width="220">Photo </td>
                    <td>
                        <input type="file" size="10" name="employenameentry_photo" id="employenameentry_photo" class="textfieldcssmem"  />
                    </td>
                </tr>
               
                  <tr>
                    <td>Name*</td>
                    <td>
                        <input type="text" required name="empname" id="empname" value="<?php echo $empname;?>" class="textfieldcssmem"  />
                    </td>
                </tr>
                
                  <tr>
                    <td>Father*</td>
                    <td>
                        <input type="text" required name="father" id="father" value="<?php echo $father;?>" class="textfieldcssmem"  />
                    </td>
                </tr>
                
                <tr>
                    <td>Designation*</td>
                    <td>
                        <input type="text" required name="designation" id="designation" value="<?php echo $designation;?>" class="textfieldcssmem"  />
                    </td>
                </tr>
                
                 <tr>
                    <td>Address*</td>
                    <td>
                       <textarea type="text" required name="address" id="address" class="textfieldcssmem" ><?php echo $address;?></textarea>
                    </td>
                </tr>
                
                <tr>
                    <td><strong>Monthly Initiate Salary</strong>*</td>
                    <td>
                        <input type="text" name="monthlysalary" id="monthlysalary" onKeyUp="calculatepack();" value="<?php echo $monthlysalary;?>" class="textfieldcssmem" />
                    </td>
                 </tr>
               
                 <tr>
                    <td><strong>House Rent(-)</strong>*</td>
                    <td>
                        <input type="text" name="houserent" id="houserent" onKeyUp="calculatepack();" value="<?php echo $houserent;?>" class="textfieldcssmem" />
                    </td>
                 </tr>
                 
                 <tr>
                    <td><strong>DPS/Provident Found</strong>*</td>
                    <td>
                        <input type="text" name="dpsfound" id="dpsfound" onKeyUp="calculatepack();" value="<?php echo $dpsfound;?>" class="textfieldcssmem" />
                    </td>
                 </tr>
                 
                 <tr>
                    <td><strong>Monthly Net Salary</strong>*</td>
                    <td>
                        <input type="text" name="netsalary" onKeyUp="calculatepack();" id="netsalary" value="<?php echo $netsalary;?>" class="textfieldcssmem"  />
                    </td>
                 </tr>
                 
                 
                  <tr>
                    <td>Working Day/Month</td>
                    <td>
                        <input type="text" name="workingday" id="workingday" onKeyUp="calculatepack();" value="<?php echo $workingday;?>" class="textfieldcssmem" />
                    </td>
                </tr>
                
                <tr>
                    <td><strong>Salary Per Day</strong></td>
                    <td>
                        <input readonly type="text" name="perdaysalary" id="perdaysalary" onKeyUp="calculatepack();" value="<?php echo $perdaysalary;?>" class="textfieldcssmem" />
                    </td>
                </tr>
                
                <tr>
                    <td><strong>Advanced Paid</strong>*</td>
                    <td>
                        <input type="text" name="advanced" id="advanced" value="<?php echo $advanced;?>" class="textfieldcssmem" />
                    </td>
                </tr>
                
                 <tr>
                    <td><strong>Payable Salary</strong>*</td>
                    <td>
                        <input type="text" name="payablesalary" onKeyUp="calculatepack();" id="payablesalary" value="<?php echo $payablesalary;?>" class="textfieldcssmem" />
                    </td>
                </tr>
                
                <tr>
                    <td>&nbsp;</td>
                    <td>
                        <input type="hidden" name="employenameentry_id" id="employenameentry_id" value="<?php echo $employenameentry_id;?>">
                        <input type="submit" value=" Save " name="submit_salesitem" id="submit_salesitem" class="submitbuttoncss" />
                    </td>
                </tr>
          </table>
      </form>
      
<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td valign="top" align="center">
        <table width="100%" border="0" align="center" cellpadding="1" cellspacing="0" bordercolor="#666666" style="border-collapse: collapse">
          <tbody>
            <tr>
            <td width="10%" align="right" valign="center" bgcolor="#FFFFFF">
               <input name="print" type="button" id="print" style="border: 1px solid #001E6A" value="Print" onClick="PrintDiv();" />
            </td>
            </tr>
          </tbody>
        </table>
   	</td>
</tr>
  
<td>
<table width="100%" bgcolor="#FFF" style="border-collapse:collapse" border="1">
  <tr>
    <td colspan="19" width="100%" align="center" bgcolor="#C17172"><strong> Employee Profile & salary Sheet</strong></td>
  </tr>
          
  <tr bgcolor="#0099FF">
    <td><strong>SL No.</strong></td>
    <td><strong>Name</strong></td>
    <td><strong>Photo</strong></td>
    <td><strong>Designation</strong></td>
    <td><strong>Father Name</strong></td>
    <td><strong>Address</strong></td>
    <td><strong>Monthly Gross Salary</strong></td>
    <td><strong>House Rent</strong></td>
    <td><strong>DPS</strong></td>
    <td><strong>Monthly Net Salary</strong></td>
    <td><strong>Day/Month</strong></td>
    <td><strong>Salary Per Day</strong></td>
     <!--<td><strong>Pharmacy Due</strong></td>
    <td><strong>Lab Due</strong></td>-->
    <td><strong>Advanced Paid</strong></td>
    <td><strong>Payable Salary</strong></td>
    <td><strong>Edit/Delete</strong></td>
  </tr>
  <?php
  $i='';
  $totalnetsalary='0.00';
  $totalpayablesalary='0.00';
   $total_salesitem_purchase_rate='';
   $total_salesitem_price = '';
	$sqlsalesitem = "select * from employenameentry order by employenameentry_id asc";
            $salesitemquery = mysqli_query($conn, $sqlsalesitem);
            if($salesitemquery){
                while($srow = mysqli_fetch_array($salesitemquery)){
                    $employenameentry_id = $srow['employenameentry_id'];
                    $empname = $srow['empname'];
					$monthlysalary = $srow['monthlysalary'];
					$netsalary = $srow['netsalary'];
					$payablesalary = $srow['payablesalary'];
					$workingday = $srow['workingday'];
					$houserent = $srow['houserent'];
				 	$netsalary = $srow['netsalary'];
				 	$dpsfound = $srow['dpsfound'];
				 	$perdaysalary = $srow['perdaysalary'];
				 	$employenameentry_photo = $srow['employenameentry_photo'];
					$address = $srow['address'];
					$designation = $srow['designation'];
					$father = $srow['father'];
					$pdue = $srow['pdue'];
					$ldue = $srow['ldue'];
					$advanced = $srow['advanced'];
					
					$action = "<a href=\"index.php?p=employenameentry&employenameentry_id=$employenameentry_id\">Edit</a> | 
				<a href=\"javascript:void(0)\" onclick=\"removetablerow('employenameentry', $employenameentry_id, 'employenameentry')\">Remove</a>";
			$totalnetsalary=$totalnetsalary+$netsalary;
			$totalpayablesalary=$totalpayablesalary+$payablesalary;
			?>
                <tr>
                <td width="15"><?php echo $i=$i+1;?></td>
                <td><?php echo $empname;?></td>
              	<td><img src="empphoto_images/<?php echo $employenameentry_photo; ?>" title="<?php echo $employenameentry_photo;?>" height="60" width="60"/></td>
         		<td><?php echo $designation;?></td>
              	 <td><?php echo $father;?></td>
              	 <td><?php echo $address;?></td>
              	<td><?php echo $monthlysalary;?></td>
				<td><?php echo $houserent;?></td>
				<td><?php echo $dpsfound;?></td>
				<td><?php echo $netsalary;?></td>
				
                <td ><?php echo $perdaysalary;?></td>
              	<td ><?php echo $workingday;?></td>
                 <?php /*?><td><?php echo $pdue;?></td>
				<td><?php echo $ldue;?></td><?php */?>
				<td><?php echo $advanced;?></td>
				<td><?php echo $payablesalary;?></td>
				<td><?php echo $action;?></td>
              </tr>
                <?php
				
                }
            }
        ?>
       <tr bgcolor="#ccc">
       <td colspan="6"></td>
       <td><strong>Total Salary:</strong> <?php echo $totalnetsalary;?></td>
		<td><strong>Payable Salary:</strong> <?php echo $totalpayablesalary;?></td>
        <td bgcolor="#ccc" colspan="8"></td>
	</tr>
  
</table>
</td>	
   
   
   <td align="center" id="divToPrint" style="display:none">
   <table width="100%" bgcolor="#FFF" style="border-collapse:collapse" border="1">
   <tr>
    <td colspan="19" width="100%"  align="center" bgcolor="#C17172"><strong> Employee Profile & Salary Sheet</strong></td>
   </tr>
          
  <tr bgcolor="#f2f2f2">
        <td><strong>SL No.</strong></td>
        <td><strong>Name</strong></td>
        <td><strong>Photo</strong></td>
        <td><strong>Designation</strong></td>
        <td><strong>Father Name</strong></td>
        <td><strong>Address</strong></td>
        <td><strong>Monthly Salary</strong></td>
        <td><strong>Salary per Day</strong></td>
        <td><strong>Day For This Month</strong></td>
        <td><strong>Working Day</strong></td>
        <td><strong>Pharmacy Due</strong></td>
        <td><strong>Lab Due</strong></td>
        <td><strong>Advanced Paid</strong></td>
        <td><strong>Payable Salary</strong></td>
   </tr>
  	<?php
		$i='';
		$totalnetsalary='0.00';
		$totalpayablesalary='0.00';
		$total_salesitem_purchase_rate='';
		$total_salesitem_price = '';
			$sqlsalesitem = "select * from employenameentry order by employenameentry_id asc";
            $salesitemquery = mysqli_query($conn, $sqlsalesitem);
            if($salesitemquery){
                while($srow = mysqli_fetch_array($salesitemquery)){
                    $employenameentry_id = $srow['employenameentry_id'];
                    $empname = $srow['empname'];
					$netsalary = $srow['netsalary'];
					$payablesalary = $srow['payablesalary'];
					$workingday = $srow['workingday'];
					$houserent = $srow['houserent'];
				 	$netsalary = $srow['netsalary'];
				 	$dpsfound = $srow['dpsfound'];
				 	$perdaysalary = $srow['perdaysalary'];
				 	$employenameentry_photo = $srow['employenameentry_photo'];
					$address = $srow['address'];
					$designation = $srow['designation'];
					$father = $srow['father'];
					$pdue = $srow['pdue'];
					$ldue = $srow['ldue'];

					$action = "<a href=\"index.php?p=employenameentry&employenameentry_id=$employenameentry_id\">Edit</a> | 
				<a href=\"javascript:void(0)\" onclick=\"removetablerow('employenameentry', $employenameentry_id, 'employenameentry')\">Remove</a>";
				$totalnetsalary=$totalnetsalary+$netsalary;
				$totalpayablesalary=$totalpayablesalary+$payablesalary;
			?>
              <tr>
                <td width="15"><?php echo $i=$i+1;?></td>
                <td><?php echo $empname;?></td>
              	<td><img src="empphoto_images/<?php echo $employenameentry_photo; ?>" title="<?php echo $employenameentry_photo;?>" height="60" width="60"/></td>
         		<td><?php echo $designation;?></td>
              	<td><?php echo $father;?></td>
              	<td><?php echo $address;?></td>
              	<td><?php echo $netsalary;?></td>
				<td><?php echo $perdaysalary;?></td>
              	<td><?php echo $workingday;?></td>
                <td><?php echo $workingday;?></td>
                <td><?php echo $pdue;?></td>
				<td><?php echo $ldue;?></td>
				<td><?php echo $advanced;?></td>
				<td><?php echo $payablesalary;?></td>
               </tr>
                <?php
                 }
            }
        ?>
       <tr bgcolor="#ccc">
       <td colspan="6"></td>
       <td><strong>Total Salary:</strong> <?php echo $totalnetsalary;?></td>
	   <td><strong>Payable Salary:</strong> <?php echo $totalpayablesalary;?></td>
       <td colspan="6"></td>
	</tr>
 </table>
</td>     
</table>