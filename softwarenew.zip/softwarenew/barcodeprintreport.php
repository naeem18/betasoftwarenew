<?php
$searchstr='';
if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
{
	$transactiondatefrom = $_REQUEST['ADate1'];
	$transactiondateto = $_REQUEST['ADate2'];
	
	$labinvoice_id = $_REQUEST['labinvoice_id'];
	$labinvoice_patientid = $_REQUEST['labinvoice_patientid'];
	$bar = $_REQUEST['bar'];
	 
	 if($labinvoice_id !=''){
		$searchstr .= " and labinvoice_id like '%$labinvoice_id%'";
	}
	elseif($bar !=''){
		$searchstr .= " and bar like '%$bar%'";
	}
	elseif($labinvoice_patientid !=''){
		$searchstr .= " and labinvoice_patientid like '%$labinvoice_patientid%'";
	}
	 
}
else
{
	$transactiondatefrom = date('Y-m-d', strtotime('-0 day'));
	$transactiondateto = date('Y-m-d');
}

	$datetime1 = new DateTime($transactiondatefrom);
	$datetime2 = new DateTime($transactiondateto);
	$interval = $datetime1->diff($datetime2);
	$totaldays = $interval->format('%a');
	if($datetime1<$datetime2){
		$fromdate = $transactiondatefrom;
		$todate = $transactiondateto;
	}
	else{
		$fromdate = $transactiondateto;
		$todate = $transactiondatefrom;
	}
?>
 
<style>
.maincontent {
line-height: 25px;
min-height: 635px;
float: left;
width: 1200px;
padding: 5px;
}
.report-card{
    background:#fff;
    border-radius:10px;
    box-shadow:0 2px 15px rgba(0,0,0,.10);
    overflow:hidden;
    margin-bottom:20px;
}

.report-header{
    background:linear-gradient(135deg,#0d6efd,#084298);
    color:#fff;
    padding:12px 20px;
    font-size:18px;
    font-weight:bold;
}

.report-body{
    padding:15px;
}

.search-table{
    width:100%;
    border-collapse:collapse;
}

.search-table td{
    padding:6px;
}

.form-control{
    width:100%;
    padding:8px 10px;
    border:1px solid #ced4da;
    border-radius:5px;
    box-sizing:border-box;
}

.btn-search{
    background:#198754;
    color:#fff;
    border:none;
    padding:9px 20px;
    border-radius:5px;
    cursor:pointer;
    font-weight:bold;
}

.btn-search:hover{
    background:#157347;
}

.data-table{
    width:100%;
    border-collapse:collapse;
}

.data-table th{
    background:#0d6efd;
    color:#fff;
    padding:10px;
    text-align:center;
    font-size:13px;
}

.data-table td{
    padding:8px;
    border-bottom:1px solid #e9ecef;
}

.data-table tr:nth-child(even){
    background:#f8f9fa;
}

.data-table tr:hover{
    background:#eef5ff;
}

.title-box{
    text-align:center;
    padding:15px;
    font-size:18px;
    font-weight:bold;
    color:#0d6efd;
}

.action-btn{
    display:inline-block;
    padding:6px 10px;
    border-radius:4px;
    text-decoration:none;
    color:#fff !important;
    font-size:12px;
    font-weight:bold;
}

.tube-btn{background:#198754;}
.xray-btn{background:#dc3545;}
.usg-btn{background:#fd7e14;}

.action-btn:hover{
    opacity:.85;
}

@media(max-width:768px){

    .search-table td{
        display:block;
        width:100%;
    }

    .data-table{
        display:block;
        overflow-x:auto;
        white-space:nowrap;
    }
}
</style>

<div class="report-card">

    <div class="report-header">
        🔍 Barcode Search Report
    </div>

    <div class="report-body">

        <form name="cbform1" method="post" action="index.php?p=barcodeprintreport">

            <table class="search-table">

                <tr>

                    <td><strong>From</strong></td>
                    <td>
                        <input class="form-control"
                               name="ADate1"
                               id="ADate1"
                               value="<?php echo $transactiondatefrom;?>"
                               readonly>
                    </td>

                    <td>
                        <img src="images/cal.gif"
                             onclick="javascript:NewCssCal('ADate1')"
                             style="cursor:pointer">
                    </td>

                    <td><strong>To</strong></td>
                    <td>
                        <input class="form-control"
                               name="ADate2"
                               id="ADate2"
                               value="<?php echo $transactiondateto;?>"
                               readonly>
                    </td>

                    <td>
                        <img src="images/cal.gif"
                             onclick="javascript:NewCssCal('ADate2')"
                             style="cursor:pointer">
                    </td>

                </tr>

                <tr>

                    <td><strong>Barcode</strong></td>
                    <td>
                        <input type="text"
                               class="form-control"
                               placeholder="Barcode"
                               name="bar"
                               id="bar">
                    </td>

                    <td><strong>Invoice</strong></td>
                    <td>
                        <input type="text"
                               class="form-control"
                               name="labinvoice_id"
                               id="labinvoice_id">
                    </td>

                    <td><strong>Patient ID</strong></td>
                    <td>
                        <input type="text"
                               class="form-control"
                               name="labinvoice_patientid"
                               id="labinvoice_patientid">
                    </td>

                    <td>
                        <input type="submit"
                               class="btn-search"
                               value="Search"
                               name="Submit">
                    </td>

                </tr>

            </table>

        </form>

    </div>

</div>

<div class="report-card">

    <div class="title-box">
         Label Print Report<br>
        <small>
            <?php echo date('d.m.y',strtotime($fromdate)); ?>
            To
            <?php echo date('d.m.y',strtotime($todate)); ?>
        </small>
    </div>

    <div class="report-body">

        <table class="data-table">

            <tr>
                <th>SL</th>
                <th>Bill No</th>
                <th>ID No</th>
                <th>Barcode</th>
                <th>Tube Label</th>
                <th>Pathology Label</th>
                <th>X-Ray Label</th>
                <th>USG Label</th>
                <th>ECG Label</th>
                <<th>Bill Date</th>
                <th>Patient</th>
                <th>Mobile</th>
            </tr>

<?php
$s=0;

for($i=0;$i<=$totaldays;$i++){

    $newfromdate=date('Y-m-d 00:00:00',strtotime($fromdate)+($i*86400));
    $newtodate=date('Y-m-d 23:59:59',strtotime($fromdate)+($i*86400));

    $sqlst="SELECT labinvoice_id,bar,labinvoice_patientid,
            labinvoice_patient,labinvoice_mobile,
            labinvoice_date
            FROM labinvoice
            WHERE labinvoice_date BETWEEN '$newfromdate' AND '$newtodate'
            $searchstr
            ORDER BY labinvoice_id ASC";

    $stquery=mysqli_query($conn,$sqlst);

    if($stquery && mysqli_num_rows($stquery)>0){

        while($strow=mysqli_fetch_array($stquery)){

            $labinvoice_id=$strow['labinvoice_id'];

            $action1="<a class='action-btn tube-btn'
            target='_blank'
            href='printlevelbar.php?labinvoice_id=$labinvoice_id'>
            Tube Print</a>";

            $actionX="<a class='action-btn xray-btn'
            target='_blank'
            href='printtoken.php?labinvoice_id=$labinvoice_id'>
            X-Ray Print</a>";

            $actionU="<a class='action-btn usg-btn'
            target='_blank'
            href='printtokenusg.php?labinvoice_id=$labinvoice_id'>
            USG Print</a>";
			$actionP="<a class='action-btn usg-btn'
            target='_blank'
            href='printtokenp.php?labinvoice_id=$labinvoice_id'>
            Pathology Print</a>";
			$actionE="<a class='action-btn usg-btn'
            target='_blank'
            href='printtokene.php?labinvoice_id=$labinvoice_id'>
            ECG Print</a>";
?>

<tr>
    <td align="center"><?php echo ++$s;?></td>
    <td><?php echo $strow['labinvoice_id'];?></td>
    <td><?php echo $strow['labinvoice_patientid'];?></td>
    <td><?php echo $strow['bar'];?></td>
    <td><?php echo $action1;?></td>
    <td><?php echo $actionP;?></td>
    <td><?php echo $actionX;?></td>
    <td><?php echo $actionU;?></td>
    <td><?php echo $actionE;?></td>
    <td><?php echo date('d-m-Y',strtotime($strow['labinvoice_date']));?></td>
    <td><?php echo $strow['labinvoice_patient'];?></td>
    <td><?php echo $strow['labinvoice_mobile'];?></td>
</tr>

<?php
        }
    }
}
?>

        </table>

    </div>

</div>