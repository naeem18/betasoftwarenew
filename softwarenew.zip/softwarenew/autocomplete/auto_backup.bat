@echo off
REM ============================
REM Auto Backup Loop for XAMPP
REM ============================

REM Path to XAMPP PHP
set PHP_PATH=G:\Server7.20.2022\xampp\php\php.exe

REM Path to backup script
set SCRIPT_PATH=G:\Server7.20.2022\xampp\htdocs\software\hospitalerp25\backup.php

REM Interval in seconds (3600 = 1/4 hour)
set INTERVAL=3600

:loop
"%PHP_PATH%" "%SCRIPT_PATH%"
timeout /t %INTERVAL% /nobreak
goto loop
