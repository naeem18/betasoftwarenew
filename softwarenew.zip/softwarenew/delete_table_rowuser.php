<?php
session_start();
if(isset($_GET['idvalue'])){	
 	$idvalue = $_GET['idvalue'];
	if($idvalue){
		require('labdd.php');
		
		 $str2 = "DELETE from master_employee where employeecode = '$idvalue'";
		 $userquery = mysqli_query($conn, $str2);
		
		
		 $str3 = "DELETE from master_employeerights where employeecode = '$idvalue'";
		 $userquery = mysqli_query($conn, $str3);
		
  		if($userquery){			
			header("location:index.php?p=userlist&message=remove-successfully");			
		}
		else{
			header("location:index.php?p=$returnpage&message=couldnotremove");
		}
	}
	else{
		header("location:index.php?p=userlist&message=incorrect_id");
	}
}
?>