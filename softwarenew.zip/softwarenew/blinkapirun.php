<?php
$url = "https://corpsms.banglalink.net/bl/api/v1/smsapigw/";
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode > 0) {
    echo "✅ Successfully connected to API (HTTP Code: $httpCode)";
} else {
    echo "❌ Failed to connect to API (HTTP Code: $httpCode)";
}
?>
