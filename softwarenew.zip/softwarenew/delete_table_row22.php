<?php
session_start();
if(isset($_GET['idvalue'])){	
	
	
	$idvalue = $_GET['idvalue'];
	if($idvalue>0){
		require('labdd.php');
		
		$str2 = "DELETE from salesinvoice where salesinvoice_id = '$idvalue'";
		$userquery = mysqli_query($conn, $str2);
		
		 $str = "DELETE from salesinvoicedetails where salesinvoice_id = '$idvalue'";
		$userquery = mysqli_query($conn, $str);
		
		 $str3 = "DELETE from dailytransection where salesinvoice_id = '$idvalue'";
		$userquery = mysqli_query($conn, $str3);
		
		
		if($userquery){			
			header("location:index.php?p=statementbysalesinvoice&message=remove-successfully");			
		}
		else{
			header("location:index.php?p=$returnpage&message=couldnotremove");
		}
	}
	else{
		header("location:index.php?p=statementbysalesinvoice&message=incorrect_id");
	}
}
?>
