<?php
date_default_timezone_set('Asia/Dhaka'); 
$searchstr = '';
if (!empty($_REQUEST['ADate1']) && !empty($_REQUEST['ADate2'])) {
    $transactiondatefrom = $_REQUEST['ADate1'];
    $transactiondateto = $_REQUEST['ADate2'];

    $emergencyinvoice_patientid = $_REQUEST['emergencyinvoice_patientid'];
    $emergencyinvoice_id = $_REQUEST['emergencyinvoice_id'];
    $emergencyinvoicedetails_item = $_REQUEST['emergencyinvoicedetails_item'];
    $emergencyinvoice_patient = $_REQUEST['emergencyinvoice_patient'];

    if ($emergencyinvoicedetails_item != '') {
        $searchstr .= " AND ld.emergencyinvoicedetails_item LIKE '%$emergencyinvoicedetails_item%'";
    }
    if ($emergencyinvoice_id != '') {
        $searchstr .= " AND ld.emergencyinvoice_id LIKE '%$emergencyinvoice_id%'";
    }
    if ($emergencyinvoice_patientid != '') {
        $searchstr .= " AND ld.emergencyinvoice_patientid LIKE '%$emergencyinvoice_patientid%'";
    }
    if ($emergencyinvoice_patient != '') {
        $searchstr .= " AND li.emergencyinvoice_patient LIKE '%$emergencyinvoice_patient%'";
    }
} else {
    $transactiondatefrom = date('Y-m-d', strtotime('-0 day'));
    $transactiondateto = date('Y-m-d');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Emergency Test Report</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 15px;
            background-color: #f8f9fa;
        }
        .report-container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            padding: 20px;
            margin-bottom: 20px;
        }
        .search-form {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .header-blue {
            background-color: #011E6A;
            color: white;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
        }
        .table-responsive {
            overflow-x: auto;
        }
        .table th {
            background-color: #e9ecef;
            white-space: nowrap;
        }
        .total-row {
            font-weight: bold;
            background-color: #f2f2f2 !important;
        }
        .date-input {
            max-width: 120px;
        }
        .search-input {
            max-width: 150px;
        }
        @media print {
            body {
                padding: 0;
                background-color: white;
            }
            .no-print {
                display: none !important;
            }
            .report-container {
                box-shadow: none;
                padding: 0;
            }
            .table-responsive {
                overflow-x: visible;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="report-container">
            <!-- Search Form -->
            <div class="search-form no-print">
                <form name="cbform1" method="post" action="index.php?p=emergencyitemwisereport">
                    <div class="row g-3 align-items-center mb-3">
                        <div class="col-md-12">
                            <h5 class="header-blue text-center">Search Date/Test Wise</h5>
                        </div>
                    </div>
                    <div class="row g-3 align-items-center">
                        <div class="col-md-2 col-6">
                            <label for="ADate1" class="form-label">Date From</label>
                            <div class="input-group">
                                <input type="text" class="form-control date-input" name="ADate1" id="ADate1" value="<?php echo $transactiondatefrom; ?>" readonly>
                                <span class="input-group-text" style="cursor:pointer" onclick="javascript:NewCssCal('ADate1')">
                                    <i class="fas fa-calendar-alt"></i>
                                </span>
                            </div>
                        </div>
                        <div class="col-md-2 col-6">
                            <label for="ADate2" class="form-label">Date To</label>
                            <div class="input-group">
                                <input type="text" class="form-control date-input" name="ADate2" id="ADate2" value="<?php echo $transactiondateto; ?>" readonly>
                                <span class="input-group-text" style="cursor:pointer" onclick="javascript:NewCssCal('ADate2')">
                                    <i class="fas fa-calendar-alt"></i>
                                </span>
                            </div>
                        </div>
                        <div class="col-md-2 col-6">
                            <label for="emergencyinvoice_id" class="form-label">Inv. No.</label>
                            <input type="text" class="form-control search-input" name="emergencyinvoice_id" id="emergencyinvoice_id">
                        </div>
                        <div class="col-md-2 col-6">
                            <label for="emergencyinvoice_patientid" class="form-label">ID No.</label>
                            <input type="text" class="form-control search-input" name="emergencyinvoice_patientid" id="emergencyinvoice_patientid">
                        </div>
                        <div class="col-md-2 col-6">
                            <label for="emergencyinvoice_patient" class="form-label">Patient Name</label>
                            <input type="text" class="form-control search-input" name="emergencyinvoice_patient" id="emergencyinvoice_patient">
                        </div>
                        <div class="col-md-2 col-6">
                            <label for="emergencyinvoicedetails_item" class="form-label">Test</label>
                            <input type="text" class="form-control search-input" name="emergencyinvoicedetails_item" id="emergencyinvoicedetails_item">
                        </div>
                        <div class="col-md-6 col-6 mt-3">
                            <button type="submit" class="btn btn-primary" name="Submit">Search</button>
                            <button type="button" class="btn btn-secondary ms-2" onclick="PrintDiv()">Print</button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Report Table -->
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr class="table-primary">
                            <th>SL</th>
                            <th>Inv No.</th>
                            <th>Test No.</th>
                            <th>Inv Date</th>
                            <th>ID No.</th>
                            <th>Patient Name</th>
                            <th>Doctor Name</th>
                            <th>PC Name</th>
                            <th>Test Name</th>
                            <th>Rate</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $totalsumlabinvoicedetails_rate = '0.00';
                        $s = 0;
                        
                        $datetime1 = new DateTime($transactiondatefrom);
                        $datetime2 = new DateTime($transactiondateto);
                        $interval = $datetime1->diff($datetime2);
                        $totaldays = $interval->format('%a');
                        
                        if($datetime1 < $datetime2){
                            $fromdate = $transactiondatefrom;
                            $todate = $transactiondateto;
                        } else {
                            $fromdate = $transactiondateto;
                            $todate = $transactiondatefrom;
                        }
                        
                        for ($i = 0; $i <= $totaldays; $i++) {
                            $newfromdate = date('Y-m-d 00:00:00', strtotime($fromdate) + ($i * 86400));
                            $newtodate = date('Y-m-d 23:59:59', strtotime($fromdate) + ($i * 86400));
                            
                            $sqlst = "
                                SELECT ld.*, li.emergencyinvoice_patient, li.emergencyinvoice_patientid, li.emergencyinvoice_doctor, li.emergencyinvoice_pc 
                                FROM emergencyinvoicedetails ld 
                                LEFT JOIN emergencyinvoice li ON ld.emergencyinvoice_id = li.emergencyinvoice_id 
                                WHERE ld.dstatus != 'Deleted' 
                                AND ld.emergencyinvoicedetails_date BETWEEN '$newfromdate' AND '$newtodate'
                                $searchstr 
                                ORDER BY ld.auto_number ASC
                            ";
                            
                            $stquery = mysqli_query($conn, $sqlst);
                            if ($stquery && mysqli_num_rows($stquery) > 0) {
                                while ($onerow = mysqli_fetch_array($stquery)) {
                                    $s++;
                                    $emergencyinvoice_id = $onerow['emergencyinvoice_id'];
                                    $emergencyinvoice_patientid = $onerow['emergencyinvoice_patientid'];
                                    $emergencyinvoicedetails_item = $onerow['emergencyinvoicedetails_item'];
                                    $emergencyinvoicedetails_total = $onerow['emergencyinvoicedetails_total'];
                                    $emergencyinvoicedetails_date = $onerow['emergencyinvoicedetails_date'];
                                    $emergencyinvoice_patient = $onerow['emergencyinvoice_patient'];
                                    $emergencyinvoice_doctor = $onerow['emergencyinvoice_doctor'];
                                    $emergencyinvoice_pc = $onerow['emergencyinvoice_pc'];
                                    
                                    $totalsumlabinvoicedetails_rate += $emergencyinvoicedetails_total;
                        ?>
                                    <tr>
                                        <td><?php echo $s; ?></td>
                                        <td><?php echo $emergencyinvoice_id; ?></td>
                                        <td><?php echo $onerow['auto_number']; ?></td>
                                        <td><?php echo date('d.m.y', strtotime($emergencyinvoicedetails_date)); ?></td>
                                        <td><?php echo $emergencyinvoice_patientid; ?></td>
                                        <td><?php echo $emergencyinvoice_patient; ?></td>
                                        <td><?php echo $emergencyinvoice_doctor; ?></td>
                                        <td><?php echo $emergencyinvoice_pc; ?></td>
                                        <td><?php echo $emergencyinvoicedetails_item; ?></td>
                                        <td class="text-end"><?php echo number_format($emergencyinvoicedetails_total, 2); ?></td>
                                    </tr>
                        <?php
                                }
                            }
                        }
                        ?>
                        <tr class="total-row">
                            <td colspan="8" class="text-end"><strong>Total:</strong></td>
                            <td colspan="2" class="text-end"><strong><?php echo number_format($totalsumlabinvoicedetails_rate, 2, '.', ''); ?></strong></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <!-- Report Header -->
            <div class="text-center mb-3">
                <h4><?php echo $hospitaldata_name; ?></h4>
                <h5>Statement By Emergency Test :: Date: <?php echo date('d.m.y', strtotime($fromdate)).' to '.date('d.m.y', strtotime($todate)); ?></h5>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script>
        function PrintDiv() {
            window.print();
        }
        
        function disableEnterKey(e) {
            if (e.keyCode == 13) {
                return false;
            }
        }
    </script>
</body>
</html>