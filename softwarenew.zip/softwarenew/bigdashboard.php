            
<?php if($_SESSION['employeename']=='SUPERADMINISTRATOR'){?>
	<article style=" background:#ccc;width:650px; margin:0 auto">
     <h3 align="center">Dashboard</h3>
	<?php
    date_default_timezone_set('Asia/Dhaka');
    if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
        {
            $transactiondatefrom = $_REQUEST['ADate1'];
            $transactiondateto = $_REQUEST['ADate2'];
        }
        else
        {
            $transactiondatefrom = date('Y-m-d', strtotime('-0 day'));
            $transactiondateto = date('Y-m-d');
        }
    ?>
	<?php 
		$datetime1 = new DateTime($transactiondatefrom);
		$datetime2 = new DateTime($transactiondateto);
		$interval = $datetime1->diff($datetime2);
		$totaldays = $interval->format('%a');
		if($datetime1<$datetime2){
			$fromdate = $transactiondatefrom;
			$todate = $transactiondateto;
		}
		else{
			$fromdate = $transactiondateto;
			$todate = $transactiondatefrom;
		}
		?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tr>
    <td valign="top" align="center">
    	<form name="cbform1" method="post" action="index.php?p=bigdashboard">
            <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" bordercolor="#666666" style="border-collapse: collapse">
              <tbody>
                <tr bgcolor="#011E6A">
                  <td colspan="10" bgcolor="#CCCCCC" align="center"><strong>Search Date Wise</strong></td>
                </tr>           
                <tr>
                    <td align="right">Date From:</td>
                    <td>
                        <input name="ADate1" id="ADate1" style="border: 1px solid #001E6A" value="<?php echo $transactiondatefrom; ?>" size="10" readonly onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
                    </td>
                    <td>Date To:</td>
                    <td>
                        <input name="ADate2" id="ADate2" style="border: 1px solid #001E6A" value="<?php echo $transactiondateto; ?>" size="10" readonly onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate2')" style="cursor:pointer"/>
                    </td>
                      
                    <td><input style="border: 1px solid #001E6A" type="submit" value="Search" name="Submit" /></td>
                    <!--<td><input name="print" type="button" id="print" style="border: 1px solid #001E6A" value="Print" onClick="PrintDiv();" /></td>-->
                </tr>
              </tbody>
            </table>
		</form>
   	</td>
</tr>

		<td>
		<?php	
		for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
			$total_labinvoice_subtotal ='';
			$total_labinvoice_discount ='';
			$total_labinvoice_due ='';
			$total_labinvoice_receiveamount ='';
			$total_labcollection_amount ='';
			
			$query2 = "select labinvoice_subtotal from labinvoice where dstatus!='Deleted' AND labinvoice_date between '$newfromdate' and '$newtodate' order by labinvoice_date asc";
			$exec2 = mysqli_query($conn, $query2);
			if(mysqli_num_rows($exec2)>0){
				while ($onerow = mysqli_fetch_array($exec2)){
					$total_labinvoice_subtotal = round($total_labinvoice_subtotal+$onerow['labinvoice_subtotal']);
				}
			}
			
			$query2 = "select labinvoice_totaldisc from labinvoice where dstatus!='Deleted' AND labinvoice_date between '$newfromdate' and '$newtodate' and labinvoice_totaldisc>0 order by labinvoice_date asc";
			$exec2 = mysqli_query($conn, $query2);
			if(mysqli_num_rows($exec2)>0){
				while ($onerow = mysqli_fetch_array($exec2)){
					$total_labinvoice_discount = round($total_labinvoice_discount+$onerow['labinvoice_totaldisc']);
				}
			}
			
			$query2 = "select labinvoice_due from labinvoice where dstatus!='Deleted' AND labinvoice_date between '$newfromdate' and '$newtodate' and labinvoice_due>0  order by labinvoice_date asc";
			$exec2 = mysqli_query($conn, $query2);
			if(mysqli_num_rows($exec2)>0){
				while ($onerow = mysqli_fetch_array($exec2)){
					$total_labinvoice_due = round($total_labinvoice_due+$onerow['labinvoice_due']);
				}
			}
			
			$query2 = "select labinvoice_receiveamount from labinvoice where dstatus!='Deleted' AND labinvoice_date between '$newfromdate' and '$newtodate' and labinvoice_receiveamount>0  order by labinvoice_date asc";
			$exec2 = mysqli_query($conn, $query2);
			if(mysqli_num_rows($exec2)>0){
				while ($onerow = mysqli_fetch_array($exec2)){
					$total_labinvoice_receiveamount = round($total_labinvoice_receiveamount+$onerow['labinvoice_receiveamount']);
				}
			}
			
			$query2 = "select collection_amount from labcollection where labcollection_date between '$newfromdate' and '$newtodate' and collection_amount>0  order by labcollection_date asc";
			$exec2 = mysqli_query($conn, $query2);
			if(mysqli_num_rows($exec2)>0){
				while ($onerow = mysqli_fetch_array($exec2)){
					$total_labcollection_amount = round($total_labcollection_amount+$onerow['collection_amount']);
				}
			}
		?>
            
   
  <div style="width:120px; height:50px; border-radius:10px; background-color:#66DFE5; text-align:center;  margin:5px; float:left">
   <b style="border-bottom:1px solid #000">Outdoor Invoiced</b><br>
   <?php echo $total_labinvoice_subtotal;?> Tk.
   </div>
   
   <div style="width:120px; height:50px; border-radius:10px; background-color:#66DFE5; text-align:center;  margin:5px; float:left">
   <b style="border-bottom:1px solid #000">Discount</b><br>
   <?php echo $total_labinvoice_discount;?> Tk.
   </div>
   
   <div style="width:120px; height:50px; border-radius:10px; background-color:#66DFE5; text-align:center;  margin:5px; float:left">
   <b style="border-bottom:1px solid #000">Due</b><br>
   <?php echo $total_labinvoice_due;?> Tk.
   </div>
   
   <div style="width:120px; height:50px; border-radius:10px; background-color:#C0C434; text-align:center;  margin:5px; float:left">
   <b style="border-bottom:1px solid #000">Cash Received</b><br>
   <?php echo $total_labinvoice_receiveamount;?> Tk.
   </div>
   
   <div style="width:120px; height:50px; border-radius:10px; background-color: #C0C434; text-align:center;  margin:5px; float:left">
   <b style="border-bottom:1px solid #000">Due Received</b><br>
   <?php echo $total_labcollection_amount;?> Tk.
   </div>


<!--Indoor-->
<?php
	$total_hospitalinvoice_subtotal ='';
	$total_hospitalinvoice_discount ='';
	$total_hospitalinvoice_due ='';
	$total_hospitalinvoice_receiveamount ='';
	$total_hospitalinvoicecollection_amount ='';
	$total_labpcpaid_amount ='';
	$total_hospitalpcpaid_amount ='';
	$total_expense_amount ='';
	
	
	
	$query2 = "select gross from hospitalinvoice where status!='Deleted' AND hospitalinvoice_deliverydate between '$newfromdate' and '$newtodate' and gross>0 order by hospitalinvoice_deliverydate asc";
	$exec2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($exec2)>0){
		while ($onerow = mysqli_fetch_array($exec2)){
			$total_hospitalinvoice_subtotal = round($total_hospitalinvoice_subtotal+$onerow['gross']);
		}
	}
	
	$query2 = "select hospitalinvoice_totaldisc from hospitalinvoice where status!='Deleted' AND hospitalinvoice_deliverydate between '$newfromdate' and '$newtodate' and hospitalinvoice_totaldisc>0 order by hospitalinvoice_deliverydate asc";
	$exec2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($exec2)>0){
		while ($onerow = mysqli_fetch_array($exec2)){
			$total_hospitalinvoice_discount = round($total_hospitalinvoice_discount+$onerow['hospitalinvoice_totaldisc']);
		}
	}
	
	$query2 = "select hospitalinvoice_due from hospitalinvoice where status!='Deleted' AND hospitalinvoice_deliverydate between '$newfromdate' and '$newtodate' and hospitalinvoice_due>0 order by hospitalinvoice_deliverydate asc";
	$exec2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($exec2)>0){
		while ($onerow = mysqli_fetch_array($exec2)){
			$total_hospitalinvoice_due = round($total_hospitalinvoice_due+$onerow['hospitalinvoice_due']);
		}
	}
	
	$query2 = "select hospitalinvoice_receiveamount from hospitalinvoice where status!='Deleted' AND hospitalinvoice_deliverydate between '$newfromdate' and '$newtodate' and hospitalinvoice_receiveamount>0 order by hospitalinvoice_deliverydate asc";
	$exec2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($exec2)>0){
		while ($onerow = mysqli_fetch_array($exec2)){
		$total_hospitalinvoice_receiveamount = round($total_hospitalinvoice_receiveamount+$onerow['hospitalinvoice_receiveamount']);
		}
	}
	
	$query2 = "select hospitalinvoicecollection_amount from hospitalinvoicecollection where hospitalinvoicecollection_date between '$newfromdate' and '$newtodate' and hospitalinvoicecollection_amount>0 order by hospitalinvoicecollection_date asc";
	$exec2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($exec2)>0){
		while ($onerow = mysqli_fetch_array($exec2)){
		$total_hospitalinvoicecollection_amount = round($total_hospitalinvoicecollection_amount+$onerow['hospitalinvoicecollection_amount']);
		}
	}
	
	//lab pc paid
	$query2 = "select labpcpaid_amount from labpcpaid where labpcpaid_date between '$newfromdate' and '$newtodate' and labpcpaid_amount>0 order by labpcpaid_date asc";
	$exec2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($exec2)>0){
		while ($onerow = mysqli_fetch_array($exec2)){
		$total_labpcpaid_amount = round($total_labpcpaid_amount+$onerow['labpcpaid_amount']);
		}
	}
	
	//Hospital pc paid
	$query2 = "select hospitalpcpaid_amount from hospitalpcpaid where hospitalpcpaid_date between '$newfromdate' and '$newtodate' and hospitalpcpaid_amount>0 order by hospitalpcpaid_date asc";
	$exec2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($exec2)>0){
		while ($onerow = mysqli_fetch_array($exec2)){
		$total_hospitalpcpaid_amount = round($total_hospitalpcpaid_amount+$onerow['hospitalpcpaid_amount']);
		}
	}

	//Expense
	$query2 = "select expense_amount from expense where expense_date between '$newfromdate' and '$newtodate' and expense_amount>0 order by expense_date asc";
	$exec2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($exec2)>0){
		while ($onerow = mysqli_fetch_array($exec2)){
		$total_expense_amount = round($total_expense_amount+$onerow['expense_amount']);
		}
	}

	


?>
<div style="width:120px; height:50px; border-radius:10px; background-color:#66DFE5; text-align:center;  margin:5px; float:left">
   <b style="border-bottom:1px solid #000">i.Invoiced</b><br>
   <?php echo $total_hospitalinvoice_subtotal;?> Tk.
   </div>
   
   <div style="width:120px; height:50px; border-radius:10px; background-color:#66DFE5; text-align:center;  margin:5px; float:left">
   <b style="border-bottom:1px solid #000">i.Discount</b><br>
   <?php echo $total_hospitalinvoice_discount;?> Tk.
   </div>
   
   <div style="width:120px; height:50px; border-radius:10px; background-color:#66DFE5; text-align:center;  margin:5px; float:left">
   <b style="border-bottom:1px solid #000">i.Due</b><br>
   <?php echo $total_hospitalinvoice_due;?> Tk.
   </div>
   
   <div style="width:120px; height:50px; border-radius:10px; background-color:#C0C434; text-align:center;  margin:5px; float:left">
   <b style="border-bottom:1px solid #000">i.Cash Received</b><br>
   <?php echo $total_hospitalinvoice_receiveamount;?> Tk.
   </div>
   
   <div style="width:120px; height:50px; border-radius:10px; background-color:#C0C434; text-align:center;  margin:5px; float:left">
   <b style="border-bottom:1px solid #000">i.Due Received</b><br>
   <?php echo $total_hospitalinvoicecollection_amount;?> Tk.
   </div>
   
   
   
   
   <!--pc paid-->
   <div style="width:205px; height:50px; border-radius:10px; background-color: #F48865; text-align:center;  margin:5px; float:left">
   <b style="border-bottom:1px solid #000">Outdoor PC Paid</b><br>
   <?php echo $total_labpcpaid_amount;?> Tk.
   </div>
   
   <!--pc paid-->
   <div style="width:205px; height:50px; border-radius:10px; background-color:#F48865; text-align:center;  margin:5px; float:left">
   <b style="border-bottom:1px solid #000">I.PC Paid</b><br>
   <?php echo $total_hospitalpcpaid_amount;?> Tk.
   </div>
   
   <!--expense-->
   <div style="width:210px; height:50px; border-radius:10px; background-color:#F48865; text-align:center;  margin:5px; float:left">
   <b style="border-bottom:1px solid #000">Expenses</b><br>
   <?php echo $total_expense_amount;?> Tk.
   </div>
   
      
   
   <?php 
    $total_salesinvoice_subtotalafterdisc ='';
	$total_salesinvoice_receiveamount ='';
	$total_salesinvoice_totaldisc ='';
	$total_salesinvoice_due ='';
	$total_collection_amount ='';
	 
   //p.sales amount//
   
	$query2 = "select salesinvoice_subtotal from salesinvoice where salesinvoice_date between '$newfromdate' and '$newtodate' and salesinvoice_subtotal>0 order by salesinvoice_date asc";
	$exec2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($exec2)>0){
		while ($onerow = mysqli_fetch_array($exec2)){
		$total_salesinvoice_subtotalafterdisc = round($total_salesinvoice_subtotalafterdisc+$onerow['salesinvoice_subtotal']);
		}
	}
	
	//p.sales disc
	$query2 = "select salesinvoice_totaldisc from salesinvoice where salesinvoice_date between '$newfromdate' and '$newtodate' and salesinvoice_totaldisc>0 order by salesinvoice_date asc";
	$exec2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($exec2)>0){
		while ($onerow = mysqli_fetch_array($exec2)){
		$total_salesinvoice_totaldisc = round($total_salesinvoice_totaldisc+$onerow['salesinvoice_totaldisc']);
		}
	}
	
	//p.sales due
	$query2 = "select salesinvoice_due from salesinvoice where salesinvoice_date between '$newfromdate' and '$newtodate' and salesinvoice_due>0 order by salesinvoice_date asc";
	$exec2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($exec2)>0){
		while ($onerow = mysqli_fetch_array($exec2)){
		$total_salesinvoice_due = round($total_salesinvoice_due+$onerow['salesinvoice_due']);
		}
	}
	
	//p.sales cash
	$query2 = "select salesinvoice_receiveamount from salesinvoice where salesinvoice_date between '$newfromdate' and '$newtodate' and salesinvoice_receiveamount>0 order by salesinvoice_date asc";
	$exec2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($exec2)>0){
		while ($onerow = mysqli_fetch_array($exec2)){
		$total_salesinvoice_receiveamount = round($total_salesinvoice_receiveamount+$onerow['salesinvoice_receiveamount']);
		}
	}

	//p.sales due received
 	$query2 = "select collection_amount from salescollectioninvoice where salescollectioninvoice_date between '$newfromdate' and '$newtodate' and collection_amount>0 order by salescollectioninvoice_date asc";
	$exec2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($exec2)>0){
		while ($onerow = mysqli_fetch_array($exec2)){
		$total_collection_amount = round($total_collection_amount+$onerow['collection_amount']);
		}
	}
	
   ?>
   <!--pharmacy Sales Cash-->
   <div style="width:120px; height:50px; border-radius:10px; background-color:#45AD57; text-align:center;  margin:5px; float:left">
   <b style="border-bottom:1px solid #000">P.Sales Invoice</b><br>
   <?php echo $total_salesinvoice_subtotalafterdisc;?> Tk.
   </div>
   
    <!--pharmacy Sales Disc-->
   <div style="width:120px; height:50px; border-radius:10px; background-color:#45AD57; text-align:center;  margin:5px; float:left">
   <b style="border-bottom:1px solid #000">P.Sales Disc</b><br>
   <?php echo $total_salesinvoice_totaldisc;?> Tk.
   </div>
   
   <!--pharmacy Sales Due-->
   <div style="width:120px; height:50px; border-radius:10px; background-color:#45AD57; text-align:center;  margin:5px; float:left">
   <b style="border-bottom:1px solid #000">P.Sales Due</b><br>
   <?php echo $total_salesinvoice_due;?> Tk.
   </div>
   
   <!--pharmacy Sales Cash-->
   <div style="width:120px; height:50px; border-radius:10px; background-color:#C0C434; text-align:center;  margin:5px; float:left">
   <b style="border-bottom:1px solid #000">Cash Received</b><br>
   <?php echo $total_salesinvoice_receiveamount;?> Tk.
   </div>
   <!--pharmacy Sales Cash-->
   <div style="width:120px; height:50px; border-radius:10px; background-color:#C0C434; text-align:center;  margin:5px; float:left">
   <b style="border-bottom:1px solid #000">Due Receive</b><br>
   <?php echo $total_collection_amount;?> Tk.
   </div>
   

   <?php 
    $total_purchaseinvoice_subtotalafterdisc ='';
	$total_purchaseinvoice_receiveamount ='';
	$total_purchaseinvoice_totaldisc ='';
	$total_purchaseinvoice_due ='';
	$total_purchaseinvoicepaid_amount ='';
	 
   //p.purchase amount//
   
	$query2 = "select purchaseinvoice_subtotal from purchaseinvoice where purchaseinvoice_date between '$newfromdate' and '$newtodate' and purchaseinvoice_subtotal>0 order by purchaseinvoice_date asc";
	$exec2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($exec2)>0){
		while ($onerow = mysqli_fetch_array($exec2)){
		$total_purchaseinvoice_subtotalafterdisc = round($total_purchaseinvoice_subtotalafterdisc+$onerow['purchaseinvoice_subtotal']);
		}
	}
	
	//p.purchase disc
	$query2 = "select purchaseinvoice_totaldisc from purchaseinvoice where purchaseinvoice_date between '$newfromdate' and '$newtodate' and purchaseinvoice_totaldisc>0 order by purchaseinvoice_date asc";
	$exec2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($exec2)>0){
		while ($onerow = mysqli_fetch_array($exec2)){
		$total_purchaseinvoice_totaldisc = round($total_purchaseinvoice_totaldisc+$onerow['purchaseinvoice_totaldisc']);
		}
	}
	
	//p.purchase due
	$query2 = "select purchaseinvoice_due from purchaseinvoice where purchaseinvoice_date between '$newfromdate' and '$newtodate' and purchaseinvoice_due>0 order by purchaseinvoice_date asc";
	$exec2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($exec2)>0){
		while ($onerow = mysqli_fetch_array($exec2)){
		$total_purchaseinvoice_due = round($total_purchaseinvoice_due+$onerow['purchaseinvoice_due']);
		}
	}
	
	//p.purchase cash
	$query2 = "select purchaseinvoice_receiveamount from purchaseinvoice where purchaseinvoice_date between '$newfromdate' and '$newtodate' and purchaseinvoice_receiveamount>0 order by purchaseinvoice_date asc";
	$exec2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($exec2)>0){
		while ($onerow = mysqli_fetch_array($exec2)){
		$total_purchaseinvoice_receiveamount = round($total_purchaseinvoice_receiveamount+$onerow['purchaseinvoice_receiveamount']);
		}
	}

	//p.purchase due received
 	$query2 = "select purchaseinvoicepaid_amount from purchaseinvoicepaid where purchaseinvoicepaid_date between '$newfromdate' and '$newtodate' and purchaseinvoicepaid_amount>0 order by purchaseinvoicepaid_date asc";
	$exec2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($exec2)>0){
		while ($onerow = mysqli_fetch_array($exec2)){
		$total_purchaseinvoicepaid_amount = round($total_purchaseinvoicepaid_amount+$onerow['purchaseinvoicepaid_amount']);
		}
	}
    ?>
    
    
    <!--pharmacy Purchase Cash-->
   <div style="width:120px; height:50px; border-radius:10px; background-color: #45AD57; text-align:center;  margin:5px; float:left">
   <b style="border-bottom:1px solid #000">P.P Invoice</b><br>
   <?php echo $total_purchaseinvoice_subtotalafterdisc;?> Tk.
   </div>
   
    <!--pharmacy purchase Disc-->
   <div style="width:120px; height:50px; border-radius:10px; background-color:#45AD57; text-align:center;  margin:5px; float:left">
   <b style="border-bottom:1px solid #000">P.P Disc</b><br>
   <?php echo $total_purchaseinvoice_totaldisc;?> Tk.
   </div>
   
   <!--pharmacy purchase Due-->
   <div style="width:120px; height:50px; border-radius:10px; background-color:#45AD57; text-align:center;  margin:5px; float:left">
   <b style="border-bottom:1px solid #000">P.P Due</b><br>
   <?php echo $total_purchaseinvoice_due;?> Tk.
   </div>
   
   <!--pharmacy purchase Cash-->
   <div style="width:120px; height:50px; border-radius:10px; background-color:#F48865; text-align:center;  margin:5px; float:left">
   <b style="border-bottom:1px solid #000">P.P CashPaid</b><br>
   <?php echo $total_purchaseinvoice_receiveamount;?> Tk.
   </div>
   <!--pharmacy purchase Cash-->
   <div style="width:120px; height:50px; border-radius:10px; background-color:#F48865; text-align:center;  margin:5px; float:left">
   <b style="border-bottom:1px solid #000">P.P.Due Receive</b><br>
   <?php echo $total_purchaseinvoicepaid_amount;?> Tk.
   </div>
   
   <?php
   //IP Reg.
    $total_number='';
 	$query2 = "select number from opregistration where opregistration_date between '$newfromdate' and '$newtodate' and number=1 order by opregistration_date asc";
	$exec2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($exec2)>0){
		while ($onerow = mysqli_fetch_array($exec2)){
		$total_number = round($total_number+$onerow['number']);
		}
	}
	
	$total_numberall='';
 	$query2 = "select number from opregistration where status='admitted' and number=1 order by opregistration_date desc";
	$exec2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($exec2)>0){
		while ($onerow = mysqli_fetch_array($exec2)){
		$total_numberall = round($total_numberall+$onerow['number']);
		}
	}
	//released
	$total_numberreleased='';
 	$query2 = "select number from opregistration where ip_releasedate between '$newfromdate' and '$newtodate' AND status='Released' order by ip_releasedate desc";
	$exec2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($exec2)>0){
		while ($onerow = mysqli_fetch_array($exec2)){
		$total_numberreleased = round($total_numberreleased+$onerow['number']);
		}
	}
	
	//appointment
	$total_numberAP='';
 	$query2 = "select number from appointmententry where appointmententry_date between '$newfromdate' and '$newtodate' order by appointmententry_date desc";
	$exec2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($exec2)>0){
		while ($onerow = mysqli_fetch_array($exec2)){
		$total_numberAP = round($total_numberAP+$onerow['number']);
		}
	}
	
	//appointment
	$total_numberAPM='';
 	$query2 = "select number from appointmententry where appointmententry_amount!=0 AND appointmententry_date between '$newfromdate' and '$newtodate' order by appointmententry_date desc";
	$exec2 = mysqli_query($conn, $query2);
	if(mysqli_num_rows($exec2)>0){
		while ($onerow = mysqli_fetch_array($exec2)){
		$total_numberAPM = round($total_numberAPM+$onerow['number']);
		}
	}
	
	?>
   <div style="width:310px; height:150px; padding:2px; border-radius:10px; color:#000; background-color: #fff;margin:5px; float:left">
       <div style="border-bottom:1px solid #000; text-align:center"><strong>Patient Information</strong></div>
       <div style=" text-align:left">Today's IP Admission: <?php echo $total_number;?></div>
       <div style=" text-align:left">Total IPD Patient: <?php echo $total_numberall;?></div>
       <div style=" text-align:left">Today's Released: <?php echo $total_numberreleased;?></div>
       <div style=" text-align:left">Today's Appointment: <?php echo $total_numberAP;?></div>
       <!--<div style=" text-align:left">Visited: <?php //echo $total_numberAPM;?></div>-->
   </div>
   
   <div style="width:311px; height:150px; padding:2px; border-radius:10px; color:#000; background-color: #fff;margin:5px; float:left">
       <div style="border-bottom:1px solid #000; text-align:center"><strong>Balance</strong></div>
       <div style=" text-align:left">Income: <?php echo $total_labinvoice_receiveamount+$total_labcollection_amount+$total_hospitalinvoice_receiveamount+$total_hospitalinvoicecollection_amount+$total_salesinvoice_receiveamount+$total_collection_amount;?></div>
       <div style=" text-align:left">Expense: <?php echo ($total_labpcpaid_amount +$total_hospitalpcpaid_amount +$total_expense_amount+$total_purchaseinvoice_receiveamount+$total_purchaseinvoicepaid_amount);?></div>
       <div style=" text-align:left">Cash: <?php echo $total_labinvoice_receiveamount+$total_labcollection_amount+$total_hospitalinvoice_receiveamount+$total_hospitalinvoicecollection_amount+$total_salesinvoice_receiveamount+$total_collection_amount - ($total_labpcpaid_amount +$total_hospitalpcpaid_amount +$total_expense_amount+$total_purchaseinvoice_receiveamount+$total_purchaseinvoicepaid_amount);?></div>
    </div>
   
   <?php }?>
   
   			<table align="center" bgcolor="#FFFFFF" width="100%" style="border-collapse:collapse;" border="1" cellspacing="1" cellpadding="5">
              <tr>
                <td colspan="12" bgcolor="#f2f2f2" align="center" style=" border-collapse:collapse;color:#03F; border:1px solid #03F; padding-left:15px;">
                     <strong>Doctor Consolidate Report</strong>
                </td>
              </tr>
               
             <tr align="left" bgcolor="#CCCCCC">
               <td>Sl</td>
               <td>Date</td>
               <td><strong>Dr. Name</strong></td>
               <td>Appointment/Serial</td>
               <td>New</td>
               <td>Old</td>
               <td>Total Pt</td>
               <td><strong>Inv. Amount</strong></td>
              </tr>
 			<?php
            $numberSumT='0.00';
            $totallabinvoice_subtotalafterdisc='0.00';
            $s='';
             
        $sqlst = "select *, sum(number) as numberT, sum(labinvoice_totaldrcomission) as labinvoice_totaldrcomissionTotal, sum(labinvoice_subtotalafterdisc) as labinvoice_subtotalafterdiscTotal from labinvoice where labinvoice_doctor!='' And labinvoice_date between '$newfromdate' and '$newtodate' group by labinvoice_doctor, substr(labinvoice_date, 1,10) order by labinvoice_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             {
                $labinvoice_id=	$strow['labinvoice_id'];
				$labinvoice_totaldrcomission = $strow['labinvoice_totaldrcomissionTotal'];
				$labinvoice_doctor = $strow['labinvoice_doctor'];
				$labinvoice_subtotalafterdisc = $strow['labinvoice_subtotalafterdiscTotal'];
                $labinvoice_date=	$strow['labinvoice_date'];
              	$numberSum = $strow['numberT'];
					
			  $sqlst2 = "select sum(number) as numberT,appointmententry_doctor from appointmententry where appointmententry_doctor='$labinvoice_doctor'";
				$exec3 = mysqli_query($conn, $sqlst2) or die ("Error in Query3".mysql_error());
				$onerow = mysqli_fetch_array($exec3);
					$appointmententry_doctor = $onerow['appointmententry_doctor'];
					$number = $onerow['numberT'];
					
					$sqlst2 = "select sum(number) as numberN,appointmententry_doctor from appointmententry where appointmententry_pcategory='New' AND appointmententry_doctor='$labinvoice_doctor'";
					$exec3 = mysqli_query($conn, $sqlst2) or die ("Error in Query3".mysql_error());
					$onerow = mysqli_fetch_array($exec3);
					$appointmententry_doctor = $onerow['appointmententry_doctor'];
					$numberNT = $onerow['numberN'];
					
					$sqlst2 = "select sum(number) as numberO,appointmententry_doctor from appointmententry where appointmententry_pcategory='Old' AND appointmententry_doctor='$labinvoice_doctor'";
					$exec3 = mysqli_query($conn, $sqlst2) or die ("Error in Query3".mysql_error());
					$onerow = mysqli_fetch_array($exec3);
					$appointmententry_doctor = $onerow['appointmententry_doctor'];
					$numberOT = $onerow['numberO'];
					
            $numberSumT= $numberSumT+$numberSum;
            $totallabinvoice_subtotalafterdisc= $totallabinvoice_subtotalafterdisc+$labinvoice_subtotalafterdisc;
            ?>
            
            <tr>
                <td><?php echo $s=$s+1; ?></td>
                <td><?php echo date('d.m.y',strtotime($newfromdate)); ?></td>
                <td><?php echo $labinvoice_doctor; ?></td>
                <td><?php echo $number;?></td>
                <td><?php echo $numberNT;?></td>
                <td><?php echo $numberOT;?></td>
                <td><?php echo $numberSum;?></td>
                <td><?php echo $labinvoice_subtotalafterdisc;?></td>
            </tr>
            <?php
          }
        }
     ?>
         <tr bgcolor="#ccc">
          <td align="right" colspan="6">Total :</td>
          <td align="left"><strong><?php echo ($numberSumT); ?></strong></td>
          <td align="left"><strong><?php echo number_format($totallabinvoice_subtotalafterdisc, 2, '.', ''); ?></strong></td>
         </tr>
    </table>
   
   			<table align="center" bgcolor="#FFFFFF" width="100%" style="border-collapse:collapse;" border="1" cellspacing="1" cellpadding="5">
              <tr>
               <td colspan="7" bgcolor="#f2f2f2" align="center" style="border-collapse:collapse;color:#03F; border:1px solid #03F;">                    <strong>Marketing Report</strong>
                </td>
              </tr>
               
             <tr bgcolor="#CCCCCC" align="left">
                 <td>Sl</td>
                 <td><strong>MPO Name</strong></td>
                 <td><strong>Pts</strong></td>
                 <td><strong>Inv Amount</strong></td>
              </tr>
 			<?php
            $totallabinvoice_totalpccomission='0.00';
            $totallabinvoice_subtotalafterdisc='0.00';
            $totallabinvoice_subtotalafterdisc1='0.00';
            $s='';
 	        
        	$sqlst = "select *, sum(labinvoice_subtotalafterdisc) as labinvoice_subtotalafterdiscT, sum(number) as numberT from labinvoice where labinvoice_mpo!='' And (labinvoice_date between '$newfromdate' and '$newtodate') group by labinvoice_mpo order by labinvoice_date asc";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery && mysqli_num_rows($stquery)>0){
            while ($strow = mysqli_fetch_array($stquery))
             	{
                $labinvoice_id=	$strow['labinvoice_id'];
				$labinvoice_totalpccomission = $strow['labinvoice_totalpccomission'];
				$labinvoice_mpo = $strow['labinvoice_mpo'];
				$labinvoice_subtotalafterdisc = $strow['labinvoice_subtotalafterdiscT'];
                $number = $strow['numberT'];
                $labinvoice_date = $strow['labinvoice_date'];
              
            $totallabinvoice_subtotalafterdisc= $totallabinvoice_subtotalafterdisc+$labinvoice_subtotalafterdisc;
            $totallabinvoice_subtotalafterdisc1= $totallabinvoice_subtotalafterdisc1+$labinvoice_subtotal;
            ?>
             <tr>
                <td><?php //echo $s=$s+1; ?></td>
                <td><?php echo $labinvoice_mpo; ?></td>
                <td><?php echo $number; ?></td>
                <td><?php echo $labinvoice_subtotalafterdisc;?></td>
            </tr>
			<?php
              }
            }
         ?>
      	<tr>
         <td align="right" colspan="2">Total :</td>
         <td><?php echo $totallabinvoice_subtotalafterdisc1; ?></td>
         <td align="left"><strong><?php echo number_format($totallabinvoice_subtotalafterdisc, 2, '.', ''); ?></strong></td>
        </tr>
    </table>
    
    		<table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1" cellspacing="0" cellpadding="2">
        <tbody>
         <tr>
            <td colspan="100%" bgcolor="#f3f3f3" align="center" style="color: #2CD9A1; border:1px solid #000;">
                  (IPD)Indoor Patient Admitted List 
            </td>
          </tr>
             <tr bgcolor="#CCCCCC">
                 <td>SL No.</td>
                <td>Admission Date</td>
                 <td>Patient Name</td>              
                <td>Age</td>              
                 <td>Ward</td>
                 
                <td>Rf. Doctor</td> 
                 
              </tr>
			<?php
			$s='';
 			$sqlst = "select * from opregistration where status= 'admitted' AND section='Indoor' AND opregistration_date between '$newfromdate' and '$newtodate' order by opregistration_id asc";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery &&  mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery)) {
					$opregistration_id = $strow['opregistration_id'];
                    $opregistration_code = $strow['opregistration_code'];
                    $opregistration_mobile = $strow['opregistration_mobile'];
                    $opregistration_name = $strow['opregistration_name'];
                    $opregistration_doctor = $strow['opregistration_doctor'];
                    $opregistration_address = $strow['opregistration_address'];
                    $opregistration_age = $strow['opregistration_age'];
                    $thana = $strow['thana'];
                    $district = $strow['district'];
                    $pcname = $strow['pcname'];
                    $mpo = $strow['mpo'];
                    $bar = $strow['bar'];
                    $ward = $strow['ward'];
					$lab_due = $strow['lab_due'];
					$pharmacy_due = $strow['pharmacy_due'];
					$section = $strow['section'];
					$ip_user = $strow['ip_user'];
					$update_user = $strow['update_user'];
					$opregistration_date = $strow['opregistration_date'];
 				?>
				
                <tr bgcolor="#fff">
                     <td><?php echo $s=$s+1; ?></td>
                    <td><?php echo $opregistration_date; ?></td>
   
                    <td><?php echo $opregistration_name; ?></td>
                    <td><?php echo $opregistration_age; ?></td> 
                    <td><?php echo $ward; ?></td>
                    <td><?php echo $opregistration_doctor; ?></td>
              	</tr>
                <?php
                	}
				}
 			?>
        	
           <tbody>
        </table>
     </td>
     </table>
        
  </article>
<?php }?>