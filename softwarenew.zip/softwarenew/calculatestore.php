<script language="JavaScript" type="text/javascript">
	var itemdataarray = <?php echo $itemdataarray;?>;
	var itemdata = <?php echo $itemdata;?>;
	//var patientdata = <?php //echo $patientdata;?>;
	var itemarraydata = itemdataarray;
	
	$(document).ready(function($) {
		document.getElementsByName("bar[]")[0].focus();

		$( ".itemname" ).autocomplete({
 			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
 				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				var storeitem_idarray = document.getElementsByName("storeitem_id[]");
				storeitem_idarray[indexpos].value = ui.item.storeitem_id;
 				
				var storesalesinvoice_itemarray = document.getElementsByName("storesalesinvoice_item[]");
				storesalesinvoice_itemarray[indexpos].value = ui.item.storeitem_name;
 								
				var storesalesinvoice_qtyarray = document.getElementsByName("storesalesinvoice_qty[]");
				storesalesinvoice_qtyarray[indexpos].value = '';
				
				var unitarray = document.getElementsByName("unit[]");
				unitarray[indexpos].value = ui.item.unit;
					
				var storesalesinvoice_stockyarray = document.getElementsByName("storesalesinvoice_stock[]");
				storesalesinvoice_stockyarray[indexpos].value = ui.item.storeitem_stock;
					
				calculaterowtotal(indexpos);
				//addnew_particularrow(true);
				return false;
			}
		});
		
		
			
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
		$( ".bar" ).keypress(function(keyname) {
			if(keyname.which==13){
				var imei = $(this).val();
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
 				$.each(itemarraydata, function(key, value){
					var valuearray = value.split('||');
					if(key==imei){
						document.getElementsByName("storeitem_id[]")[indexpos].value = valuearray[0];
						document.getElementsByName("storesalesinvoice_item[]")[indexpos].value = valuearray[1];
						document.getElementsByName("storesalesinvoice_stock[]")[indexpos].value = valuearray[1];
						document.getElementsByName("storesalesinvoice_qty[]")[indexpos].value = 1;
						document.getElementsByName("unit[]")[indexpos].value = valuearray[1];
						document.getElementsByName("bar[]")[indexpos].value = valuearray[1];
						calculaterowtotal(indexpos);
						
						addnew_particularrow(true);
					}
				});
				return false;
			}
		});
		
	});
	
	
	
	function calculaterowtotal(indexpos){
		if(indexpos=='all'){
			
			var storesalesinvoice_qtyarray = document.getElementsByName("storesalesinvoice_qty[]");
			
			if(storesalesinvoice_ratearray.length>0){
				for(var p=0; p<storesalesinvoice_ratearray.length; p++){
					
					var storesalesinvoice_qty = parseFloat(storesalesinvoice_qtyarray[p].value);
					if(storesalesinvoice_qty=='' || isNaN(storesalesinvoice_qty)){storesalesinvoice_qty = 0;}
				}
			}
		}
		else{
			
			var storesalesinvoice_qtyarray = document.getElementsByName("storesalesinvoice_qty[]");
			var storesalesinvoice_qty = parseFloat(storesalesinvoice_qtyarray[indexpos].value);
			if(storesalesinvoice_qty=='' || isNaN(storesalesinvoice_qty)){storesalesinvoice_qty = 0;}
		}
		calculate_total();
	}
	
	function calculate_total(){
		var storesalesinvoice_subtotal = 0;
		
	}
	
		function check_particular(){
		return true;
	}

	function addnew_particularrow(animate) {
		if(check_particular()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\"  width=\"75%\"  cellpadding=\"1\" style=\"BORDER-COLLAPSE: collapse; border:2px solid #FFF\" bgcolor=\"#ccc\">"+
							'<tr>'+
								'<td align="right">Bar Code</td>'+
								'<td><input type="text" name="bar[]" required class="tdclass itemname storesalesinvoice_item"/>'+
								
								'<td align="right">Item Name</td>'+
								'<td><input type="text" name="storesalesinvoice_item[]" required class="tdclass itemname storesalesinvoice_item"/>'+
								
								'<input type="hidden" name="storeitem_id[]" id="storeitem_id" class="tdclass itemname"/></td>'+
								'<td align="right">Delivery Qty</td>'+
								"<td><input type=\"text\" required name=\"storesalesinvoice_qty[]\" id=\"storesalesinvoice_qty\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/></td>"+
								'<td align="right">Unit</td>'+
								'<td><input type="text" readonly name="unit[]" id="unit" class="tdclasssale itemname"/></td>'+
								
								'<td align="right">Stock</td>'+
								'<td><input type="text" readonly name="storesalesinvoice_stock[]" id="storesalesinvoice_stock" class="tdclasssale itemname"/></td>'+
								
								'<td>'+
								 "<input type=\"button\" value=\"Del\" onClick=\"deletethislistrow('particularlistrowno"+particular_rowcount+"');\" class=\"tdclasssales\"  />"+
								'</td>'+
							  '</tr>'+
						"</table>";
						
			var $newparticularlist = $("<li></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(300); 
			else 
			   $newparticularlist.show();   
			document.getElementsByName("bar[]")[parseInt(particular_rowcount-1)].focus();
			
			$( ".itemname" ).autocomplete({			
				minLength: 1,
				source: itemdata,
				focus: function( event, ui ) {
					//$( "#search_item_number" ).val( ui.item.saleselval );
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
 						
					var storeitem_idarray = document.getElementsByName("storeitem_id[]");
					storeitem_idarray[indexpos].value = ui.item.storeitem_id;
					
					var storesalesinvoice_itemarray = document.getElementsByName("storesalesinvoice_item[]");
				    storesalesinvoice_itemarray[indexpos].value = ui.item.storeitem_name;
 				
				
					var storesalesinvoice_qtyarray = document.getElementsByName("storesalesinvoice_qty[]");
					storesalesinvoice_qtyarray[indexpos].value = '';
					
					var unitarray = document.getElementsByName("unit[]");
					unitarray[indexpos].value = ui.item.unit;
				
					var storesalesinvoice_stockyarray = document.getElementsByName("storesalesinvoice_stock[]");
					storesalesinvoice_stockyarray[indexpos].value = ui.item.storeitem_stock;
				
					calculaterowtotal(indexpos);
					//addnew_particularrow(true);
					return false;
				}
			});	
			
			$( ".bar" ).keypress(function(keyname) {
				if(keyname.which==13){
					var imei = $(this).val();
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					
					$.each(itemarraydata, function(key, value){
						var valuearray = value.split('||');
						if(key==imei){
							document.getElementsByName("storeitem_id[]")[indexpos].value = valuearray[0];
							document.getElementsByName("storesalesinvoice_item[]")[indexpos].value = valuearray[1];
							document.getElementsByName("storesalesinvoice_stock[]")[indexpos].value = valuearray[2];
							document.getElementsByName("storesalesinvoice_qty[]")[indexpos].value = 1;
							document.getElementsByName("unit[]")[indexpos].value = valuearray[1];
							document.getElementsByName("bar[]")[indexpos].value = valuearray[1];
						
							calculaterowtotal(indexpos);
							addnew_particularrow(true);
						}
					});
					return false;
				}
			});
								
		}
	}
	
	function deletethislistrow(tableidname){
		$("#"+tableidname).parent("li").slideUp(200, function() {
			$(this).remove();
			calculaterowtotal('all');
		});
	}
</script>