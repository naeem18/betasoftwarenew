<?php
date_default_timezone_set('Asia/Dhaka');
$pcdata = '';
$sqlpc = "select * from doctorentry where doctor_category='pc' order by doctor_name asc";
$opregistrationquery1 = mysqli_query($conn, $sqlpc);
if($opregistrationquery1 && mysqli_num_rows($opregistrationquery1)>0){

	while ($opregistrationrow = mysqli_fetch_array($opregistrationquery1)){
		$doctor_id = $opregistrationrow['doctor_id'];
		$doctor_name = $opregistrationrow['doctor_name'];
		$mpo = $opregistrationrow['mpo'];
		$pcdata[] =array( 'labelval' => $doctor_name,
							'label' => $doctor_name,
							'doctor_name'=>$doctor_name,
							'mpo'=>$mpo
							);
		}
	}
$pcdata = json_encode($pcdata);


$drdata = '';
$sqldr = "select * from doctorentry where doctor_category='doctor' order by doctor_name asc";
$opregistrationquery2 = mysqli_query($conn, $sqldr);
if($opregistrationquery2 && mysqli_num_rows($opregistrationquery2)>0){

	while ($opregistrationrow = mysqli_fetch_array($opregistrationquery2)){
		$doctor_id = $opregistrationrow['doctor_id'];
		$doctor_name = $opregistrationrow['doctor_name'];
		$drdata[] =array( 'labelval' => $doctor_name,
							'label' => $doctor_name,
							'doctor_name'=>$doctor_name
							);
		}
	}
$drdata = json_encode($drdata);

$apdata = '';
$sqlar = "select * from appointmententry order by appointmententry_name asc";
$opregistrationquery3 = mysqli_query($conn, $sqlar);
if($opregistrationquery3 && mysqli_num_rows($opregistrationquery3)>0){

	while ($opregistrationrow = mysqli_fetch_array($opregistrationquery3)){
		$appointmententry_id = $opregistrationrow['appointmententry_id'];
		$appointmententry_name = $opregistrationrow['appointmententry_name'];
		$appointmententry_age = $opregistrationrow['appointmententry_age'];
		$appointmententry_gender = $opregistrationrow['appointmententry_gender'];
		$appointmententry_mobile = $opregistrationrow['appointmententry_mobile'];
		$appointmententry_doctor = $opregistrationrow['appointmententry_doctor'];
		$appointmententry_address = $opregistrationrow['appointmententry_address'];
		$apdata[] =array( 'labelval' => $appointmententry_name,
							'label' => $appointmententry_name.'#'.$appointmententry_mobile,
							'appointmententry_name'=>$appointmententry_name,
							'appointmententry_age'=>$appointmententry_age,
							'appointmententry_gender'=>$appointmententry_gender,
							'appointmententry_doctor'=>$appointmententry_doctor,
							'appointmententry_mobile'=>$appointmententry_mobile,
							'appointmententry_address'=>$appointmententry_address
							
							);
		}
	}
$apdata = json_encode($apdata);


$searchstr='';
if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
{
	$transactiondatefrom = $_REQUEST['ADate1'];
	$transactiondateto = $_REQUEST['ADate2'];
	
}
else
{
	$transactiondatefrom = date('Y-m-d', strtotime('-2 day'));
	$transactiondateto = date('Y-m-d');
}
?>

<link rel="stylesheet" href="autocomplete/jquery-ui.css">
<script src="autocomplete/jquery-ui.min.js"></script>
 <script language="JavaScript" type="text/javascript">
	
	var pcdata = <?php echo $pcdata;?>;
	var drdata = <?php echo $drdata;?>;
	var apdata = <?php echo $apdata;?>;
	
	$(document).ready(function($) {
	
	$( "#appointmententry_pc" ).autocomplete({
			
			minLength: 1,
			source: pcdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('appointmententry_pc').value = ui.item.labelval;
				 document.getElementById('appointmententry_mpo').value = ui.item.mpo;
				
				return false;
			}
		});
		
		
	$( "#appointmententry_doctor" ).autocomplete({
			
			minLength: 1,
			source: drdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				 document.getElementById('appointmententry_doctor').value = ui.item.labelval;
				 document.getElementById('appointmententry_doctor').value = ui.item.doctor_name;
				return false;
			}
		});
	
	$( "#appointmententry_name" ).autocomplete({
			
			minLength: 1,
			source: apdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				 document.getElementById('appointmententry_name').value = ui.item.labelval;
				 document.getElementById('appointmententry_age').value = ui.item.appointmententry_age;
				 document.getElementById('appointmententry_gender').value = ui.item.appointmententry_gender;
				 document.getElementById('appointmententry_mobile').value = ui.item.appointmententry_mobile;
				 document.getElementById('appointmententry_address').value = ui.item.appointmententry_address;
				 document.getElementById('appointmententry_doctor').value = ui.item.appointmententry_doctor;
				return false;
			}
		});
	
	});	
</script>

<style type="text/css">
.ui-autocomplete { height:auto !important; max-height:300px; overflow:auto; background:#FFF; border:1px solid #CCC;	width:200px;}
.search_row{text-align:left;}
.ui-autocomplete li{ min-height:30px; border-bottom:1px dotted #CCC; padding:10px; text-align:left;}
</style>

  <article class="bottomcontent">
    <h3 style="background:#77F7AA; text-align:center">Appointment schedule Entry </h3>
   	 <content>
     
        <?php
			if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
				echo "<p class=\"red12bold\">You have missing Something</p>";
			}
			 if(isset($_GET['message']) && $_GET['message']=='update-successfully'){
				echo "<p class=\"red12bold\">updated successfully</p>";
			}
		   
			elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
				echo "<p class=\"red12bold\">Error occured! Could not insert.</p>";   
			}
			elseif(isset($_GET['message']) && $_GET['message']=='save-successfully'){
				echo "<p class=\"red12bold\">Information insert successfully. Click Print Button To Print or View Previous Bill <td align=\"center\" ><a onclick=\"PrintDiv();\"><input type=\"button\" name=\"user\" id=\"user\" required value=\"Print\" class=\"tdclass\"  /></a></td></p>";   
			}
           		
			 $appointmententry_number  ='';
			 $appointmententry_id = 0;

		 	$appointmententry_sql2 = "select appointmententry_number from appointmententry order by appointmententry_id asc";
            $appointmententryquery = mysqli_query($conn, $appointmententry_sql2);
            if($appointmententryquery && mysqli_num_rows($appointmententryquery)>0){
                while($page_inforow = mysqli_fetch_array($appointmententryquery)){
					$appointmententry_number  = $page_inforow['appointmententry_number'];
                }
            }
        ?>        
           
  <form action="save_appointmententry.php" name="frmcontact" onsubmit="return checkcontactform();" method="post" enctype="multipart/form-data">
	<table width="500" align="center" border="1" style="BORDER-COLLAPSE: collapse;" bgcolor="#77F7AA" cellpadding="2">
     <input type="hidden" name="user" id="user"  value="<?php echo $_SESSION['fullname'];?>" class="tdclass"  />
 
    <tr>
        <td align="right">Appointment Date  </td>
        <td><input type="text" name="ADate1" id="ADate1" value="<?php echo date('Y-m-d');?>" class="tdclass"  />
        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
        </td>
    </tr>
    <tr>
        <td align="right">Consultant/Doctor </td>
        <td><input type="text" name="appointmententry_doctor" id="appointmententry_doctor" size="30" /></td>
    </tr>
    
     <?php /*?><tr>
     <td align="right">Consultant/Doctor  </td>
		<td>  
			<select required style="width:125px" id="appointmententry_doctor"  name="appointmententry_doctor" >
				<option value="">Select Dr.</option>
				 <?php
						$query5 = "select * from doctorentry where doctor_category='doctor' order by doctor_name";
						$exec5 = mysqli_query($conn, $query5) or die ("Error in Query5".mysql_error());
						while ($res5 = mysqli_fetch_array($exec5))
						{
							$res5doctorname = trim($res5["doctor_name"]);
							$res5doctorcode = $res5["doctor_id"];
							if($res5doctorname !=''){						
								?>
								<option value="<?php echo $res5doctorname; ?>"><?php echo $res5doctorname; ?></option>
								<?php
							}
						}
					  ?>
			</select>
		</td>
    </tr><?php */?>
     <tr>
    	<td align="right">Patient Name * </td>
    	<td> <input type="text" placeholder="search by name or mobile" required name="appointmententry_name" id="appointmententry_name" size="30"  /></td>
    </tr>
        
    <tr>
    	<td align="right">Age* </td>
    	<td> <input type="text" required name="appointmententry_age" id="appointmententry_age" size="30" /></td>
    </tr>
    
     <tr>
        <td align="right">Gender* </td>
         <td>
            <select required style="width:125px" id="appointmententry_gender" name="appointmententry_gender" >
               <option value=""></option>
                <?php
                $patientarray = array( 'Other', 'Female', 'Male');
                foreach($patientarray as $singleoption){
                    $selected = '';
                    if($singleoption=="$singleoption"){$selected = ' selected="selected"';}
                    echo "<option value=\"$singleoption\"$selected>$singleoption</option>";
                }
                ?>
            </select>
        </td>
    </tr>

    <tr>
        <td align="right">Mobile Number * </td>
        <td> <input type="text"  name="appointmententry_mobile" id="appointmententry_mobile" size="30" /></td>
    </tr>
    
     <tr>
    	<td align="right">Address </td>
    	<td> <textarea type="text"  name="appointmententry_address" id="appointmententry_address" style="width:240px"></textarea></td>
    </tr>
      	
    <tr>
        <td align="right">Patient Category</td>
         <td>
            <select style="width:125px" id="appointmententry_pcategory" name="appointmententry_pcategory" >
                <option value=""></option>
                <?php
                $patientarray = array( 'Old', 'New', 'Report');
                foreach($patientarray as $singleoption){
                    $selected = '';
                    if($singleoption=="$singleoption"){$selected = ' selected="selected"';}
                    echo "<option value=\"$singleoption\"$selected>$singleoption</option>";
                }
                ?>
            </select>
        </td>
    </tr>
         
    <tr>
        <td align="right">Appointment Number  </td>
        <td><input type="text" name="appointmententry_number" id="appointmententry_number" value="<?php echo $appointmententry_number + 1;?>" size="30" />
        </td>
    </tr>
    
    <tr>
        <td align="right">Appointment Time  </td>
        <td><input type="text" name="appointmententry_time" id="appointmententry_time" value="<?php echo date('H:i');?>"  size="30" />
        </td>
    </tr>
          
    <tr>
    	<td align="right">Consultant Fee </td>
    	<td> <input type="text" name="appointmententry_amount" id="appointmententry_amount" size="30" /></td>
    </tr>

	<tr>
    	<td align="right">PC</td>
    	<td> <input type="text" name="appointmententry_pc" id="appointmententry_pc" size="30"/></td>
    </tr>
    
    <tr>
    	<td align="right">MPO </td>
    	<td> <input type="text" name="appointmententry_mpo" id="appointmententry_mpo" size="30" /></td>
    </tr>
    
    <?php /*?><tr>
     <td align="right">Select Ref.  </td>
     <td>  
    	<select style="width:125px" id="appointmententry_pc"  name="appointmententry_pc" >
        <option value="">Select Ref. </option>
		 <?php
            $query5 = "select * from doctorentry where doctor_category='pc' order by doctor_name";
            $exec5 = mysqli_query($conn, $query5) or die ("Error in Query5".mysql_error());
            while ($res5 = mysqli_fetch_array($exec5))
            	{
                $res5doctorname = trim($res5["doctor_name"]);
                $res5doctorcode = $res5["doctor_id"];
                if($res5doctorname !=''){						
				?>
				<option value="<?php echo $res5doctorname; ?>"><?php echo $res5doctorname; ?></option>
				<?php
                }
            }
          ?>
    </select>
    </td>
    </tr><?php */?>
    
   		<td align="right"> </td>
        <td>
        <input type="hidden" name="appointmententry_id" id="appointmententry_id" value="<?php echo $appointmententry_id;?>">
        <input type="submit" value=" SAVE " name="submit_invoice" id="submit_invoice" class="tdclass" />
       
       <a href="index.php?p=appointmententry"><input type="button" name="appointmententry" id="appointmententry" value="Cancel" class="tdclass"/></a>
       </td>
    </tr>
</table>
</form>         

</content>
</article>

<div id="divToPrint" style="display:none;">
 <article class="bottomcontent" style="margin:0 auto;">
		  <?php
		   if(isset($_GET['appointmententry_id'])){
          	$appointmententry_id = $_GET['appointmententry_id'];
            $appointmententry_sql = "select * from appointmententry where appointmententry_id = $appointmententry_id";
            $appointmententryquery = mysqli_query($conn, $appointmententry_sql);
            if($appointmententryquery && mysqli_num_rows($appointmententryquery)>0){
                while($page_inforow = mysqli_fetch_array($appointmententryquery)){
                   $appointmententry_id = $page_inforow['appointmententry_id'];
                   $appointmententry_code = $page_inforow['appointmententry_code'];
                    $appointmententry_name = $page_inforow['appointmententry_name'];
                    $appointmententry_mobile = $page_inforow['appointmententry_mobile'];
					$user = $page_inforow['user'];
                    $day_serial = $page_inforow['day_serial'];
                   $appointmententry_doctor = $page_inforow['appointmententry_doctor'];
                    $appointmententry_time = $page_inforow['appointmententry_time'];
                    $appointmententry_number = $page_inforow['appointmententry_number'];
                    $appointmententry_date = $page_inforow['appointmententry_date'];
				 	$appointmententry_amount = $page_inforow['appointmententry_amount'];
					$appointmententry_pcategory = $page_inforow['appointmententry_pcategory'];
					
					$appointmententry_age = $page_inforow['appointmententry_age'];
				 	$appointmententry_gender = $page_inforow['appointmententry_gender'];
				
		 	 ?>        
               
             <table align="center" width="<?php echo $printdata_mobile; ?>"  style="border:1px solid #999; padding:0 5px; font-size:12px; "  bgcolor="#FFF" cellpadding="0">
                <tr>
                <?php
                if($hospitaldata_logo!=''){
					?>
                    <td width="65">
                    <div align="left" style="font-size:15px;">
                    <img alt="barcode" width="60" height="60" src="logo_images/<?php echo $hospitaldata_logo; ?>"  /></div>
                   </td>
               <?php }?>
                <td width="320" style="border-right:1px solid #666">
                    <div align="left" style="font-size:18px;"><strong><?php echo $hospitaldata_name;?></strong></div>
                    <div align="left"> <?php echo $hospitaldata_address1;?></div>
                    <?php /*?><div align="left"> <?php echo $hospitaldata_mobile;?></div><?php */?>
                </td>
                 <td width="90">
                    <div align="right" style="font-size:14px;"><strong><?php //echo 'Doctor\'s, Appointment'; ?><?php echo 'Contact';?></strong></div>
                    <div align="right"> <?php echo $hospitaldata_mobile;?></div>
                </td>
                 </tr>
            </table>
                       
            <table align="center" width="<?php echo $printdata_mobile; ?>" style="border:1px solid #999;font-size:12px; border-bottom:none; padding:2px 8px 0 8px; margin-top:6px" bgcolor="#FFF" cellpadding="0">
                <tr>
                    <td width="300">
                        <div align="left"><strong>Serial Number : <?php  echo $day_serial;?></strong></div>
                        <div align="left"><strong>Patient: <?php echo $appointmententry_name;?></strong> </div>
                        <div align="left">Gender : <?php echo $appointmententry_gender;?> </div>
                        <div align="left">Age : <?php echo $appointmententry_age;?> Years</div>
                        <div align="left"><strong>Category : <?php echo $appointmententry_pcategory;?></strong></div>
                    </td>
                    <td width="150">
                        <div align="right" style="font-size:14px"><strong>Appointment Slip</strong></div>
                        <div align="right"><strong>Ref No.: <?php echo $appointmententry_id;?></strong></div>
                        <div align="right">Date: <?php  echo $appointmententry_date;?></div>
                      	<div align="right">Time: <?php  echo $appointmententry_time;?></div>
                        <div align="right">Mobile : <?php echo $appointmententry_mobile;?></div>
                  </td>
                 </tr>
                 </table>
                 
                 
                 
            <table align="center" width="<?php echo $printdata_mobile; ?>" style="border:1px solid #999;font-size:12px; padding:0 8px 5px 8px;" bgcolor="#FFF" cellpadding="0">
            <tr><td width="450"><strong>Ref Dr.: <?php echo $appointmententry_doctor;?></strong></td></tr>
            </table>
             <table align="center" width="<?php echo $printdata_mobile; ?>" bgcolor="#FFF" style="
    			padding:0 0 40px;font-size:12px; border:1px #999 solid; border-top:none;" cellspacing="0" cellpadding="0">
                
            <tr height="20">
                <td style="border:1px solid #999;text-align:center;border-top:none;"><strong>Particular</strong></td>
                <td style="border:1px solid #999; text-align:center;border-top:none;"><strong>Paid Amount</strong></td>
            </tr>
            
            <tr>
                <td style=" text-align:center; padding-left:3px" width="250">Consultant Fee</td>
                <td style="text-align:center;"> <?php echo $appointmententry_amount;?></td>
            </tr>
                 
            </table>
                    
                
              <?php
              		}
			  	}
			 }
              ?>
              
        <table width="<?php echo $printdata_mobile; ?>" align="center" style="font-size:12px;">
        <tr> <td><?php include ("convert_currency_to_words.php");
				
			echo 'InWord:';	echo covert_currency_to_words($appointmententry_amount); ?></td></tr>
        </table>
        
        
        
            <table align="center" width="<?php echo $printdata_mobile; ?>" style=" font-size:12px; padding:5px 2px" bgcolor="#FFF" cellpadding="0">
              <tr>
                    <td width="200">
                        <div class="print13">Prepared By: <?php echo $user; ?></div>
                    </td>
                
               
                <td width="200">
                    <div style="padding-bottom:10px" align="right"></div>
                    <div align="right">Authorised Sign</div>
                </td>
             </tr>
             
        </table>
        
  

    <table align="center" width="<?php echo $printdata_mobile; ?>" border="0">
    <tr>
        <td style=" font-size:10px">Software by: Betasofts.com (01757 827474)</td>
      </tr></table>
       
</article>
</div>

<!--<div id="divToPrint" style="display:none;">
 <article class="bottomcontent" style="margin:0 auto;">
   
		  <?php
		   if(isset($_GET['appointmententry_id'])){
          	$appointmententry_id = $_GET['appointmententry_id'];
            $appointmententry_sql = "select * from appointmententry where appointmententry_id = $appointmententry_id";
            $appointmententryquery = mysqli_query($conn, $appointmententry_sql);
            if($appointmententryquery && mysqli_num_rows($appointmententryquery)>0){
                while($page_inforow = mysqli_fetch_array($appointmententryquery)){
                   $appointmententry_id = $page_inforow['appointmententry_id'];
                    $appointmententry_name = $page_inforow['appointmententry_name'];
                    $appointmententry_mobile = $page_inforow['appointmententry_mobile'];
					$user = $page_inforow['user'];
                    $appointmententry_doctor = $page_inforow['appointmententry_doctor'];
                    $appointmententry_time = $page_inforow['appointmententry_time'];
                    $appointmententry_number = $page_inforow['appointmententry_number'];
                   $appointmententry_date = $page_inforow['appointmententry_date'];
				
		 	 ?>        
               <table width="240" align="center"  style="border:1px solid #000;padding:0 10px; font-size:12px; "  bgcolor="#FFF" cellpadding="0">
                <tr>
                    <td width="240">
                        <div class="print13" align="left" style="font-size:14px">[Tocken of  Serial]</div>
                        <div class="print13" align="left" style="font-size:14px"><strong><?php //echo $hospitaldata_name;?></strong></div>
                        <div class="print13" align="left"> <?php //echo $hospitaldata_address1;?></div>
                   		<div class="print13" align="left">Date: <?php  //echo $appointmententry_date ;?></div>
                    </td>
                    
                 </tr>
            </table>
            <table width="240" align="center" style="border:1px solid #000;font-size:12px; padding:0 10px; margin-top:2px" bgcolor="#FFF" cellpadding="0">
                <tr>
                    <td width="240">
                        <div class="print13" align="left"><strong>Serial No.: <?php //echo $appointmententry_number;?></strong></div>
                        <div class="print13" align="left">Paitnt Name: <?php //echo $appointmententry_name;?></div>
                        <div class="print13" align="left">Mobile: <?php //echo $appointmententry_mobile;?></div>
                         <div class="print13" align="left">Consultant.: <?php //echo $appointmententry_doctor;?></div>
                    </td>
                 </tr>
            </table>
                     
        <table width="240" align="center" style=" font-size:12px; padding:12px 1px" bgcolor="#FFF" cellpadding="0">
                <tr>
                    <td width="200">
                        <div class="print13">Prepared By: <?php //echo $user; ?></div>
                    </td>
                 </tr>
            </table>
           

            <table align="center" width="240" border="0">
            <tr>
                <td width="240" style=" font-size:11px">Software by: Betasofts.com (01757 827474)</td>
              </tr></table>
              <?php
              }}}
              ?>
                
</article>
</div>-->