<script language="JavaScript" type="text/javascript">
function checkcontactform(){
 var error_total_balance = document.getElementById("error_total_balance");
  	
	error_total_balance.innerHTML = '';
		if(total_balance.value==''){
			error_total_balance.innerHTML = "0";
			total_balance.focus();
			return false;
		}
			
	else if (total_balance.value< "0")
	{
		error_total_balance.innerHTML = "Receive Amount Should not be bigger than Receivable Amount"
		total_balance.focus();
		return false;
	}
 		return true;
 	}
 
 
 
 	function calculate_total(){
		
		var previous_due = parseFloat(document.getElementById("previous_due").value);
		if(previous_due=='' || isNaN(previous_due)){previous_due = 0;}
		
		var labinvoice_totalpccomission = parseFloat(document.getElementById("labinvoice_totalpccomission").value);
		if(labinvoice_totalpccomission=='' || isNaN(labinvoice_totalpccomission)){labinvoice_totalpccomission = 0;}
		
		var discount_amount = parseFloat(document.getElementById("discount_amount").value);
		if(discount_amount=='' || isNaN(discount_amount)){discount_amount = 0;}
			
		var Tcollection_amount = parseFloat(document.getElementById("Tcollection_amount").value);
		if(Tcollection_amount=='' || isNaN(Tcollection_amount)){Tcollection_amount = '';}
		
		//var labinvoice_totalpccomission_update = parseFloat(labinvoice_totalpccomission - discount_amount/2);
		//document.getElementById('labinvoice_totalpccomission_update').value=labinvoice_totalpccomission_update.toFixed(2);
		
		var labinvoice_totalpccomission_update = parseFloat(labinvoice_totalpccomission - discount_amount);
		document.getElementById('labinvoice_totalpccomission_update').value=labinvoice_totalpccomission_update.toFixed(2);
		
		var total_balance = parseFloat(previous_due - discount_amount - Tcollection_amount);
		document.getElementById('total_balance').value=	total_balance.toFixed(2);
		
		}
	function funcSaveBill1()
{
	
	var varUserChoice; 
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet); 
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		document.frmsales.submit();
		//return true;
	}
}				

</script>