<?php 
$pcdata = array();
$sqlpc = "select * from bloodbank group by opregistration_name order by opregistration_name  asc";
$opregistrationquery1 = mysqli_query($conn, $sqlpc);
if($opregistrationquery1 && mysqli_num_rows($opregistrationquery1)>0){

	while ($oprow = mysqli_fetch_array($opregistrationquery1)){
		$opregistration_mobile = $oprow['opregistration_mobile'];
		$opregistration_name = $oprow['opregistration_name'];
		$opregistration_mother = $oprow['opregistration_mother'];
		$opregistration_father = $oprow['opregistration_father'];
		$remark = $oprow['remark'];
		
		$opregistration_age = $oprow['opregistration_age'];
		$opregistration_gender = $oprow['opregistration_gender'];
		$opregistration_blood = $oprow['opregistration_blood'];
		$opregistration_address = $oprow['opregistration_address'];
		$pcdata[] =array( 'labelval' => $opregistration_name,
							'label' => $opregistration_name.'#'. $opregistration_mobile,
							'opregistration_name'=>$opregistration_name,
							'opregistration_mother'=>$opregistration_mother,
							'opregistration_age'=>$opregistration_age,
							'opregistration_gender'=>$opregistration_gender,
							'opregistration_blood'=>$opregistration_blood,
							'opregistration_mobile'=>$opregistration_mobile,
							'remark'=>$remark,
							'opregistration_address'=>$opregistration_address,
							'opregistration_father'=>$opregistration_father
							);
		}
	}
$pcdata = json_encode($pcdata);

?>

<link rel="stylesheet" href="autocomplete/jquery-ui.css">
<script src="autocomplete/jquery-ui.min.js"></script>
 <script language="JavaScript" type="text/javascript">
	
	var pcdata = <?php echo $pcdata;?>;
	
	$(document).ready(function($) {
	
$( "#opregistration_name" ).autocomplete({
			
			minLength: 1,
			source: pcdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('opregistration_name').value = ui.item.labelval;
				 document.getElementById('opregistration_father').value = ui.item.opregistration_father;
				document.getElementById('opregistration_mother').value = ui.item.opregistration_mother;
				document.getElementById('opregistration_age').value = ui.item.opregistration_age;
				document.getElementById('opregistration_gender').value = ui.item.opregistration_gender;
				document.getElementById('opregistration_blood').value = ui.item.opregistration_blood;
				document.getElementById('opregistration_address').value = ui.item.opregistration_address;
				document.getElementById('opregistration_mobile').value = ui.item.opregistration_mobile;
 				document.getElementById('remark').value = ui.item.remark;
				
				return false;
			}
		});
			
	});
</script>


	<article>
      <h3 style="background:#FFF; text-align:center">Blood Donar Registration</h3>
       <content>
        <?php
			if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
			echo "<h2 class=\"red12bold\">You have missing Something</h2>";
			}
			elseif(isset($_GET['message']) && $_GET['message']=='duplicatename'){
			echo "<h2 class=\"red12bold\">This Item  already exists. Please try with different item .</h2>";   
			}
			 elseif(isset($_GET['message']) && $_GET['message']=='insert-successfully'){
            echo "<p class=\"red12bold\">Information insert successfully. Click Print Button To Print or View Previous Bill <td width=\"30\" align=\"center\" ><a onclick=\"PrintDiv();\"><input type=\"button\" name=\"user\" id=\"user\" required value=\"Print\" class=\"tdclass\"  /></a></td></p>";   
       		}
			elseif(isset($_GET['message']) && $_GET['message']=='insert-successfully'){
			echo "<h2 class=\"red12bold\">information insert successfully</h2>";   
			}
		?>       
                      
		  <form action="save_bloodreg.php" method="post" enctype="multipart/form-data">
            <table width="80%" align="center" border="2" style=" border:1px solid #f2f2f2" bgcolor="#E0E0E0" cellpadding="2">
 				<input type="hidden" name="user" id="user" value="<?php echo $_SESSION['fullname'];?>" class="tdclass"  />
                 <tr>
                    <td><label>Donar Name *</label></td>
                    <td><input type="text" name="opregistration_name" required id="opregistration_name" class="textfieldcssmem" /></td>
               
                    <td><label>Father/Husband</label></td>
                    <td><input type="text" name="opregistration_father" id="opregistration_father" class="textfieldcssmem" /></td>
                </tr>
                
                 <tr bgcolor="#f3f3f3">
                    <td><label>Mother</label></td>
                    <td><input type="text" name="opregistration_mother" id="opregistration_mother" class="textfieldcssmem" /></td>
               
                    <td width="250"><label>Address</label></td>
                    <td><textarea style="width: 167px;"  name="opregistration_address" id="opregistration_address" class="textfieldcssmem" /></textarea></td>
                </tr>
                
                 <tr>
                    <td><label>Age *</label></td>
                    <td><input type="text" name="opregistration_age" required id="opregistration_age" class="textfieldcssmem" /></td>
               
                    <td><label>Mobile *</label></td>
                    <td><input type="text" name="opregistration_mobile" id="opregistration_mobile" class="textfieldcssmem" /></td>
                </tr>
                
               <tr bgcolor="#f3f3f3">
                 <td><label>Gender *</label></td>
                 <td>
                    <select style="width: 170px;" id="opregistration_gender" title="class" name="opregistration_gender" >
                        <option value="">Select Gender</option>
                        <?php
                        $doyouknowarray = array('Male', 'Female', 'Other');
                        foreach($doyouknowarray as $singleoption){
                            $selected = '';
                            if($opregistration_gender=="$singleoption"){$selected = ' selected="selected"';}
                            echo "<option value=\"$singleoption\"$selected>$singleoption</option>";
                        }
                        ?>
                    </select>
                </td>
               
                     <td><label>Blood Group </label></td>
                     <td>
                        <select style="width: 170px;" id="opregistration_blood" title="class" name="opregistration_blood" >
                            <option value="">Select Blood</option>
                            <?php
                            $doyouknowarray = array('A+', 'B+', 'A-', 'B-', 'AB+', 'AB-', 'O+', 'O-');
                            foreach($doyouknowarray as $singleoption){
                                $selected = '';
                                if($opregistration_blood=="$singleoption"){$selected = ' selected="selected"';}
                                echo "<option value=\"$singleoption\"$selected>$singleoption</option>";
                            	}
                            ?>
                        </select>
                    </td>
                </tr>
                
                <tr>
                    <td><label>Maratial Status</label></td>
                     <td>
                        <select style="width: 170px;" id="opregistration_status" title="class" name="opregistration_status" >
                            <option value="">Select Status</option>
                            <?php
                            $doyouknowarray = array('Married', 'Unmarried', 'Single');
                            foreach($doyouknowarray as $singleoption){
                                $selected = '';
                                if($opregistration_status=="$singleoption"){$selected = ' selected="selected"';}
                                echo "<option value=\"$singleoption\"$selected>$singleoption</option>";
                            }
                            ?>
                        </select>
                    </td>
                
                 </tr>

                
                <!--<tr>
                    <td><label>Chief Complaint</label></td>
                    <td><textarea  style="width:166px" name="complain" id="complain" class="textfieldcssmem"/></textarea></td>
                 </tr>-->
                 
                 
            	<tr bgcolor="#f3f3f3">
                    <td><label>Remark</label></td>
                    <td><textarea style="width:166px"  name="remark" id="remark" class="textfieldcssmem" /></textarea></td>
                   
                    <td><label>Upload Photo </label></td>
                    <td><input type="file" name="opregistration_image" id="opregistration_image"  class="textfieldcssmem" /></td>
            	</tr>
                
        <tr>
            
         <td><label><strong>Date Of Birth</strong></label></td>
         <td><input type="text" name="" id="" value="<?php echo date('Y-m-d');?>" class="tdclass" />
         <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
         </td>
         </tr>
          
         <tr bgcolor="#f3f3f3">
            <td><label><strong>Insurance ID</strong></label></td>
            <td><input type="text" style="width:166px"  name="insuranceid" id="insuranceid" class="textfieldcssmem" /></td>
       
            <td bgcolor="#CCCCCC"><label>Code</label></td>
            <td><input type="text" name="opregistration_code" id="opregistration_code" value="<?php //echo $opregistration_code; ?>" readonly class="textfieldcssmem" /></td>
        </tr>
        
        <tr>
            <td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
            <td>
                <input type="hidden" name="bloodbankid" id="bloodbankid" value="<?php echo $bloodbankid;?>">
                <input type="submit" value=" Save " name="submit_opreg" id="submit_opreg" class="submitbuttoncss" />
            </td>
        </tr>
  </table>
</form>
     </content>
</article>

<div id="divToPrint" style="display:none;">
	<article class="bottomcontent" style=" margin:0 auto">
      <?php
	  $bloodbankid = $_GET['bloodbankid'];
        $labinvoice_sql = "select * from bloodbank where bloodbankid = $bloodbankid order by bloodbankid desc";
        $labinvoicequery = mysqli_query($conn, $labinvoice_sql);
        if($labinvoicequery && mysqli_num_rows($labinvoicequery)>0){
            while ($strow = mysqli_fetch_array($labinvoicequery)){
                    $bloodbankid = $strow['bloodbankid'];
                    $opregistration_name = $strow['opregistration_name'];
                    $opregistration_age = $strow['opregistration_age'];
                    $opregistration_code = $strow['opregistration_code'];
                    $opregistration_mother = $strow['opregistration_mother'];
                    $opregistration_address = $strow['opregistration_address'];
                    $opregistration_father = $strow['opregistration_father'];
                    $opregistration_mobile = $strow['opregistration_mobile'];
					$opregistration_gender = $strow['opregistration_gender'];
                    $opregistration_status = $strow['opregistration_status'];
                    $opregistration_blood = $strow['opregistration_blood'];
					$opregistration_date = $strow['opregistration_date'];
 				  }
				}
          ?>
              
     <table width="450" align="center"  style="border:1px solid #CCC;padding:0 10px; font-size:12px;">
        <tr>
            <td width="280">
                <div align="left" style="font-size:14px"><strong><?php echo $hospitaldata_name;?></strong></div>
                <div align="left"> <?php echo $hospitaldata_address1;?></div>
                <div align="left"> <?php echo $hospitaldata_mobile;?></div>
            </td>
            <td width="170">
                <div align="left" style="font-size:14px"><strong>Donar Reg. Card</strong></div>
                <div align="left">Reg.Date:&emsp;<?php  echo $opregistration_date;?></div>
             <!-- <div align="left"><img src="images/barcode.png" width="140" height="30"></div>-->
             </td>
         </tr>
    </table>
           
            <table width="450" align="center" style="border:1px solid #CCC;font-size:12px; padding:0 10px; margin-top:2px">
                <tr>
                    <td width="280">
                        <div align="left"><strong>Donar</strong>:&emsp;<?php echo $opregistration_name;?></div>
                        <div align="left">Age:&emsp; <?php echo $opregistration_age;?></div>
                       <div align="left">Gender:&emsp;<?php echo $opregistration_gender;?></div>
                           
                    </td>
                    <td width="170">
                        <div align="left"><strong>Donar ID:&emsp;<?php echo $bloodbankid;?></strong></div>
                        <div align="left">Mobile:&emsp;<?php echo $opregistration_mobile;?></div>
                        </td>
                 </tr>
                
            </table>
            <table width="450" align="center" style=" font-size:12px; padding:0px 2px">
                 <tr>
                    <td width="300">
                        <div style="padding-bottom:30px" align="right"></div>
                        <div align="right">Authorised Sign</div>
                    </td>
                 </tr>
            </table>
            
            <table width="450" align="center" style="font-size:12px;" cellpadding="1">
            <tr><td>Terms & Conditions: </td></tr>
            <tr><td>1.Please bring this registration card on all hospital visits.</td></tr>
            <tr><td>2.If registration card is lost, please ask for duplicate copy.</td></tr>
            <tr><td>3.Make sure your details mentioned here is correct and updated.</td></tr>
            </table>
       
</article>
</div>