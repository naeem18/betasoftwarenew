<?php
//date wise search
require('labdd.php');
header('Content-Type: text/html; charset=utf-8');

// --- Get filters ---
$transactiondatefrom = isset($_POST['ADate1']) && $_POST['ADate1'] != '' ? $_POST['ADate1'] : date('Y-m-d');
$transactiondateto   = isset($_POST['ADate2']) && $_POST['ADate2'] != '' ? $_POST['ADate2'] : date('Y-m-d');

$labinvoice_id = isset($_POST['labinvoice_id']) ? $_POST['labinvoice_id'] : '';
$labinvoice_patientid = isset($_POST['labinvoice_patientid']) ? $_POST['labinvoice_patientid'] : '';
$bar = isset($_POST['bar']) ? $_POST['bar'] : '';
$labinvoice_mobile = isset($_POST['labinvoice_mobile']) ? $_POST['labinvoice_mobile'] : '';

// --- Build search string ---
$searchstr = "";
if($labinvoice_id != '') $searchstr .= " AND labinvoice_id='".mysqli_real_escape_string($conn,$labinvoice_id)."'";
if($labinvoice_patientid != '') $searchstr .= " AND labinvoice_patientid='".mysqli_real_escape_string($conn,$labinvoice_patientid)."'";
if($bar != '') $searchstr .= " AND bar LIKE '%".mysqli_real_escape_string($conn,$bar)."%'";
if($labinvoice_mobile != '') $searchstr .= " AND labinvoice_mobile LIKE '%".mysqli_real_escape_string($conn,$labinvoice_mobile)."%'";
    
// --- Pagination settings ---
$limit = 20;
$page = isset($_POST['page']) ? (int)$_POST['page'] : 1;
if($page < 1) $page = 1;
$offset = ($page - 1) * $limit;

// --- Count total rows ---
$countSql = "SELECT COUNT(*) AS total FROM labinvoice 
             WHERE labinvoice_date BETWEEN '$transactiondatefrom 00:00:00' AND '$transactiondateto 23:59:59' $searchstr";
$countRes = mysqli_query($conn, $countSql);

if($countRes){
    $countRow = mysqli_fetch_assoc($countRes);
    $totalRows = $countRow['total'];
} else {
    $totalRows = 0;
}
$totalPages = ceil($totalRows / $limit);

// --- Fetch rows ---
$sql = "SELECT uniqid, labinvoice_id, bar, labinvoice_patientid, labinvoice_patient, labinvoice_age, labinvoice_mobile, labinvoice_ward,
        labinvoice_doctor, labinvoice_date 
        FROM labinvoice
        WHERE labinvoice_date BETWEEN '$transactiondatefrom 00:00:00' AND '$transactiondateto 23:59:59'
        $searchstr
        ORDER BY labinvoice_id DESC
        LIMIT $offset, $limit";

$result = mysqli_query($conn, $sql);

// --- Table ---
echo "<table border='1' width='100%' cellspacing='0' cellpadding='4' style='font-size:13px; border-collapse:collapse;'>";
echo "<tr><td colspan='12' align='center' bgcolor='#f4f4f4'>
        <strong>Patient Investigation List :: Date: ".date('d-m-Y', strtotime($transactiondatefrom))." to ".date('d-m-Y', strtotime($transactiondateto))."</strong>
      </td></tr>";
echo "<tr bgcolor='#ccc'>
        <th>SL</th><th>Barcode</th><th>ID</th><th>Bill No.</th><th>Inv Date</th><th>Patient</th>
        <th>Age</th><th>Mobile</th><th>Cabin</th><th>Doctor</th><th>Test Names</th><th>Action</th>
      </tr>";

$sl = $offset;
while($row = mysqli_fetch_assoc($result)){
    $sl++;
    $labinvoice_id = $row['labinvoice_id'];
    $uniqid = $row['uniqid'];
    $bar = htmlspecialchars($row['bar']);
    $pid = htmlspecialchars($row['labinvoice_patientid']);
    $pname = htmlspecialchars($row['labinvoice_patient']);
    $age = htmlspecialchars($row['labinvoice_age']);
    $mobile = htmlspecialchars($row['labinvoice_mobile']);
    $ward = htmlspecialchars($row['labinvoice_ward']);
    $doctor = htmlspecialchars($row['labinvoice_doctor']);
    $date = date('d-m-Y', strtotime($row['labinvoice_date']));
    $action = "<a href='index.php?p=zz_patientinvestigationlist&labinvoice_id=$labinvoice_id' target='_blank'>Report Entry</a>";

    echo "<tr bgcolor='#fff'>
            <td>$sl</td>
            <td>$bar</td>
            <td>$pid</td>
            <td>$labinvoice_id</td>
            <td>$date</td>
            <td>$pname</td>
            <td>$age</td>
            <td>$mobile</td>
            <td>$ward</td>
            <td style='font-size:11px;'>$doctor</td>
            <td style='font-size:11px; line-height:14px;'>";

    // --- Test names ---
    $testsql = "SELECT labinvoicedetails_item, rstatus 
                FROM labinvoicedetails
                WHERE treturn != 'Y' AND dstatus != 'Deleted' AND status != 'Deleted'
                AND labinvoicedetails_category NOT IN ('Tube','X-ray','ECHO','USG','ECG','CT-SCAN','MRI','Mammography','ENDOSCOPY')
                AND labinvoice_id='$labinvoice_id'";
    $testres = mysqli_query($conn, $testsql);
    if($testres && mysqli_num_rows($testres) > 0){
        while($test = mysqli_fetch_assoc($testres)){
            $color = ($test['rstatus']==0) ? '#000' : '#f00';
            echo "<span style='color:$color'>".htmlspecialchars($test['labinvoicedetails_item'])."</span><br>";
        }
    } else {
        echo "<em style='color:#999'>No tests found</em>";
    }

    echo "</td><td>$action</td></tr>";
}
echo "</table>";

// --- Pagination links ---
echo "<div style='padding:10px; text-align:center;'>";
if($page > 1){
    echo "<a href='javascript:void(0)' onclick='fetchPatients(".($page-1).")'>&laquo; Previous</a> ";
}
for($i=1;$i<=$totalPages;$i++){
    if($i==$page){
        echo "<strong>$i</strong> ";
    } else {
        echo "<a href='javascript:void(0)' onclick='fetchPatients($i)'>$i</a> ";
    }
}
if($page < $totalPages){
    echo "<a href='javascript:void(0)' onclick='fetchPatients(".($page+1).")'>Next &raquo;</a>";
}
echo "</div>";
?>
