<?php
//date_default_timezone_set('Asia/Dhaka'); 
$searchstr='';
if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
{
	$transactiondatefrom = $_REQUEST['ADate1'];
	$transactiondateto = $_REQUEST['ADate2'];
	
	$initialcapital_id = $_REQUEST['initialcapital_id'];
	$initialcapital_name = $_REQUEST['initialcapital_name'];
	$initialcapital_head = $_REQUEST['initialcapital_head'];
	if($initialcapital_name !=''){
		$searchstr .= " and initialcapital_name like '%$initialcapital_name%'";
	}
	elseif($initialcapital_id !=''){
		$searchstr .= " and initialcapital_id like '%$initialcapital_id%'";
	}
	elseif($initialcapital_head !=''){
		$searchstr .= " and initialcapital_head like '%$initialcapital_head%'";
	}
}
else
{
	$transactiondatefrom = date('Y-m-d', strtotime('-1 month'));
	$transactiondateto = date('Y-m-d');
}
?>

<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td valign="top" align="center">
    	<form name="cbform1" method="post" action="index.php?p=directorlist">
            <table width="100%" border="1" align="center" cellpadding="4" cellspacing="0" bordercolor="#666666" style="border-collapse:collapse">
              <tbody>
                <tr bgcolor="#011E6A">
                  <td colspan="15" bgcolor="#CCCCCC" align="center"><strong>Search Date Wise</strong></td>
                </tr>           
                <tr>
                    <td>Date From:<input name="ADate1" id="ADate1" size="7" style="border: 1px solid #001E6A" value="<?php echo $transactiondatefrom; ?>" readonly="readonly" onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
                    </td>
                    <td>Date To:
                        <input name="ADate2" id="ADate2" size="7" style="border: 1px solid #001E6A" value="<?php echo $transactiondateto; ?>" readonly="readonly" onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate2')" style="cursor:pointer"/>
                    </td>
                    <td>Name: <input type="text" size="6" name="initialcapital_name" id="initialcapital_name"/></td>
                     <td>By ID: <input type="text" size="5" name="initialcapital_id" id="initialcapital_id"/></td>
                    
                    <td>By Category: <input type="text" size="15" name="initialcapital_head" id="initialcapital_head"/></td>
                    
                    <td><input style="border: 1px solid #001E6A" type="submit" value="Search" name="Submit" /> </td>
                    <td><input name="print" type="button" id="print" style="border: 1px solid #001E6A" value="Print" onClick="PrintDiv();" />
                    </td>
                </tr>
              </tbody>
            </table>
		</form>
    </td>
</tr>

	<td>
 		<?php 
 		$datetime1 = new DateTime($transactiondatefrom);
		$datetime2 = new DateTime($transactiondateto);
		$interval = $datetime1->diff($datetime2);
		$totaldays = $interval->format('%a');
		if($datetime1<$datetime2){
			$fromdate = $transactiondatefrom;
			$todate = $transactiondateto;
		}
		else{
			$fromdate = $transactiondateto;
			$todate = $transactiondatefrom;
		}
		?>
        
        <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1" cellspacing="0" cellpadding="2">
        <tbody>
         <tr>
            <td colspan="100%" bgcolor="#006F6F" align="center" style="color:#fff; border:1px solid #000;">
            	<strong><?php echo $hospitaldata_name;?></strong><br>
              Director/Shareholder List :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?>
            </td>
          </tr>
             <tr bgcolor="#CCCCCC">
                <td><strong>SL No.</strong></td>
                <td><strong>Entry Date</strong></td>
                <td><strong>Category/Type</strong></td> 
                <td><strong>Name</strong></td>              
                <td><strong>Mobile</strong></td>
                <td><strong>NID</strong></td>
                <td><strong>Paid Amount</strong></td>
                <td><strong>Profit Sharing%</strong></td>
                <td><strong>Nominee</strong></td> 
                <td><strong>Note</strong></td> 
                <td><strong>Update</strong></td>
               </tr>
			<?php
			$s='';
			$total='';
			for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
			$sqlst = "select * from initialcapital where  initialcapital_date between '$newfromdate' and '$newtodate' $searchstr order by initialcapital_id asc";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery &&  mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery)) {
					$nid = $strow['nid'];
                    $nominee = $strow['nominee'];
                    $mobile = $strow['mobile'];
                    $profitsharing = $strow['profitsharing'];
                    $initialcapital_name = $strow['initialcapital_name'];
                    $initialcapital_head = $strow['initialcapital_head'];
                    $initialcapital_amount = $strow['initialcapital_amount'];
					$initialcapital_id = $strow['initialcapital_id'];
					$initialcapital_description = $strow['initialcapital_description'];
                    $initialcapital_date = $strow['initialcapital_date'];
                   
				$action1 = "<a href=\"index.php?p=printaddsharecapital&initialcapital_id=$initialcapital_id\" target=\"_blank\">Print</a>";
				$action = "<a href=\"index.php?p=addsharecapital&initialcapital_id=$initialcapital_id\">Update</a>";
 				$total=$initialcapital_amount+$total;
			?>
				
                <tr bgcolor="#fff">
                    <td><?php echo $s=$s+1; ?></td>
                    <td><?php echo $initialcapital_date; ?></td>
                    <td><?php echo $initialcapital_head; ?></td>
                    <td><?php echo $initialcapital_name; ?></td>
                    <td><?php echo $mobile; ?></td>
                    <td><?php echo $nid; ?></td>
                    <td><?php echo $initialcapital_amount; ?></td>
                    <td><?php echo $profitsharing; ?> %</td>
                    <td><?php echo $nominee; ?></td>
                    <td><?php echo $initialcapital_description; ?></td>
                    <td><?php echo $action; ?></td>
               	</tr>
                <?php
                	}
				}
			}
		  ?>
        <tr bgcolor="#f3f3f3">
            <td colspan="6" align="right"><strong>Total Amount:</strong></td>
            <td><strong><?php echo $total; ?></strong></td>
        </tr>
       <tbody>
    </table>
    </td>
      
	<td align="center" id="divToPrint" style="display:none">
 		<?php 
 		$datetime1 = new DateTime($transactiondatefrom);
		$datetime2 = new DateTime($transactiondateto);
		$interval = $datetime1->diff($datetime2);
		$totaldays = $interval->format('%a');
		if($datetime1<$datetime2){
			$fromdate = $transactiondatefrom;
			$todate = $transactiondateto;
		}
		else{
			$fromdate = $transactiondateto;
			$todate = $transactiondatefrom;
		}
		?>
        
        <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1" cellspacing="0" cellpadding="2">
        <tbody>
         <tr>
            <td colspan="100%" bgcolor="#006F6F" align="center" style="color:#fff; border:1px solid #000;">
            	<strong><?php echo $hospitaldata_name;?></strong><br>
              Director/Shareholder List :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?>
            </td>
          </tr>
             <tr bgcolor="#CCCCCC">
                <td><strong>SL No.</strong></td>
                <td><strong>Entry Date</strong></td>
                <td><strong>Category/Type</strong></td> 
                <td><strong>Name</strong></td>              
                <td><strong>Mobile</strong></td>
                <td><strong>NID</strong></td>
                <td><strong>Paid Amount</strong></td>
                <td><strong>Profit Sharing%</strong></td>
                <td><strong>Nominee</strong></td> 
                <td><strong>Note</strong></td> 
                </tr>
			<?php
			$s='';
			$total='';
			for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
			$sqlst = "select * from initialcapital where  initialcapital_date between '$newfromdate' and '$newtodate' $searchstr order by initialcapital_id asc";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery &&  mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery)) {
					$nid = $strow['nid'];
                    $nominee = $strow['nominee'];
                    $mobile = $strow['mobile'];
                    $profitsharing = $strow['profitsharing'];
                    $initialcapital_name = $strow['initialcapital_name'];
                    $initialcapital_head = $strow['initialcapital_head'];
                    $initialcapital_amount = $strow['initialcapital_amount'];
					$initialcapital_id = $strow['initialcapital_id'];
					$initialcapital_description = $strow['initialcapital_description'];
                    $initialcapital_date = $strow['initialcapital_date'];
                   
				 
 				$total=$initialcapital_amount+$total;
			?>
				
                <tr bgcolor="#fff">
                    <td><?php echo $s=$s+1; ?></td>
                    <td><?php echo $initialcapital_date; ?></td>
                    <td><?php echo $initialcapital_head; ?></td>
                    <td><?php echo $initialcapital_name; ?></td>
                    <td><?php echo $mobile; ?></td>
                    <td><?php echo $nid; ?></td>
                    <td><?php echo $initialcapital_amount; ?></td>
                    <td><?php echo $profitsharing; ?> %</td>
                    <td><?php echo $nominee; ?></td>
                    <td><?php echo $initialcapital_description; ?></td>
                </tr>
                <?php
                	}
				}
			}
		  ?>
        <tr>
            <td colspan="6" align="right"><strong>Total Amount:</strong></td>
            <td><strong><?php echo $total; ?></strong></td>
        </tr>
       <tbody>
    </table>
      </td>
</table>