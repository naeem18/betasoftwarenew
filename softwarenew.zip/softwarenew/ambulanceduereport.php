<script type="text/javascript" language="javascript">
	function removetablerow(idvalue){
		var conf = confirm("Do you sure want to delete this ID="+idvalue+" from this Table ");
		if(conf)
			window.location='delete_table_row.php?idvalue='+idvalue;
		}
</script>
<?php
$searchstr='';
if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
{
	$transactiondatefrom = $_REQUEST['ADate1'];
	$transactiondateto = $_REQUEST['ADate2'];
	
	$starting_location = $_REQUEST['starting_location'];
	$destination = $_REQUEST['destination'];
	
	$user = $_REQUEST['user'];
	$name = $_REQUEST['name'];
	$dueholder = $_REQUEST['dueholder'];
	
	if($starting_location !=''){
		$searchstr .= " and starting_location like '%$starting_location%'";
		}
		elseif($destination !=''){
		$searchstr .= " and destination like '%$destination%'";
		}
		elseif($dueholder !=''){
		$searchstr .= " and dueholder like '%$dueholder%'";
		}
		elseif($user !=''){
		$searchstr .= " and user like '%$user%'";
		}
		elseif($name !=''){
		$searchstr .= " and name like '%$name%'";
		}
	}
	else
	{
		$transactiondatefrom = date('Y-m-d', strtotime('-0 day'));
		$transactiondateto = date('Y-m-d');
	}
?>

   	<table width="100%" border="0" cellspacing="0" cellpadding="2">
         <tr>
            <td valign="top" align="center">
                <form name="cbform1" method="post" action="index.php?p=ambulanceduereport">
                    <table width="100%" border="1" align="center" cellpadding="1" cellspacing="0" bordercolor="#666666" style="border-collapse: collapse">
                        <tr bgcolor="#011E6A">
                          <td colspan="16" bgcolor="#CCCCCC" align="center"><strong>Search Date </strong></td>
                        </tr>           
                        <tr bgcolor="#FFFFFF">
                            <td>From:
                                <input name="ADate1" id="ADate1" style="border: 1px solid #001E6A" value="<?php echo $transactiondatefrom; ?>"  size="6"  readonly="readonly" onKeyDown="return disableEnterKey()" />
                                <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
                            </td>
                            <td>To:
                                <input name="ADate2" id="ADate2" style="border: 1px solid #001E6A" value="<?php echo $transactiondateto; ?>"  size="6"  readonly="readonly" onKeyDown="return disableEnterKey()" />
                                <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate2')" style="cursor:pointer"/>
                            </td>
                            
                            <td><input placeholder="Paid To" type="text" size="7" name="name" id="name" /></td>
                            
                            <td>Head <input size="7" type="text" name="starting_location" id="starting_location" /></td>
                            <td>Due Holder <input size="7" type="text" name="dueholder" id="dueholder" /></td>
                            
                            <td>Particular <input type="text" size="7" name="destination" id="destination" /></td>
                            <td>User <input type="text" size="7" name="user" id="user" /></td>
                           
                            <td><input style="border: 1px solid #001E6A" type="submit" value="Search" name="Submit" /></td>
                            <td><input name="print" type="button" id="print"  style="border: 1px solid #001E6A" value="Print" onClick="PrintDiv();" />
                            </td>
                        </tr>
                    </table>
                </form>
            </td>
        </tr>

		<td>
   		<?php 
		$datetime1 = new DateTime($transactiondatefrom);
		$datetime2 = new DateTime($transactiondateto);
		$interval = $datetime1->diff($datetime2);
		$totaldays = $interval->format('%a');
		if($datetime1<$datetime2){
			$fromdate = $transactiondatefrom;
			$todate = $transactiondateto;
		}
		else{
			$fromdate = $transactiondateto;
			$todate = $transactiondatefrom;
		}
		?>
        
        <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1" cellspacing="0" cellpadding="2">
        <tbody>
         <tr>
            <td colspan="100%" bgcolor="#f2f2f2" align="center" style="color:#03F; border:1px solid #03F;">
            	<strong><?php echo $hospitaldata_name;?></strong><br>
                Ambulance Due Report :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?>
            </td>
          </tr>
            <tr bgcolor="#77F7AA">
               	<td><strong>Print</strong></td>
                <td><strong>Date</strong></td>
                <td><strong>Bill No.</strong></td>
              	<td><strong>Type</strong></td> 
                <td><strong>Name</strong></td> 
                <td><strong>Referrer</strong></td>
                <td><strong>From</strong></td>
                <td><strong>To</strong></td>
                <td><strong>Due Holder</strong></td>
                <td><strong>Charge</strong></td> 
                <td><strong>Received</strong></td> 
                <td><strong>Less</strong></td> 
                <td><strong>Due</strong></td> 
                <td><strong>User</strong></td>
                <td><strong>Action</strong></td>
              </tr>
		<?php
		$totalsumcharge='0.00';
		$expenseHeadData = array();
	
		for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
			$sqlst = "select * from ambulance where due>0 and created_date between '$newfromdate' and '$newtodate' $searchstr order by ambulance_id desc";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery &&  mysqli_num_rows($stquery)>0){
			 while ($strow = mysqli_fetch_array($stquery)) {
					$ambulance_id = $strow['ambulance_id'];
                    $name = $strow['name'];
					$user = $strow['user'];
                    $update_user = $strow['update_user'];
                    $mobile = $strow['mobile'];
					$referer = $strow['referer'];
					$starting_location = $strow['starting_location'];
                    $destination = $strow['destination'];
                    $charge = $strow['charge'];
                    $received = $strow['received'];
                    $due = $strow['due'];
                    $less = $strow['less'];
                    $type = $strow['type'];
                    $month = $strow['month'];
                    $description = $strow['description'];
                    $dueholder = $strow['dueholder'];
                    $created_date = $strow['created_date'];
			
				$action = "<a href=\"index.php?p=ambulance_collection&ambulance_id=$ambulance_id\" target=\"_blank\">Collection</a>";
				$action2 = "<a href=\"index.php?p=printambulance&ambulance_id=$ambulance_id\" target=\"_blank\">print</a>";
				
				if(array_key_exists($due, $expenseHeadData)){
					$expenseHeadData[$due] = $expenseHeadData[$due]+$charge;
				}
				else{
					$expenseHeadData[$due] = $charge;
				}

				$totalsumcharge  = $totalsumcharge + $due;
				?>
                <tr align="left">
                 	 <td><?php echo $action2;?></td>
                     <td><?php echo $created_date; ?></td>
                     <td><?php echo $ambulance_id; ?></td>
                     <td><?php echo $type; ?></td>
                     <td><?php echo $name; ?></td>
                     <td><?php echo $referer; ?></td> 
                     <td><?php echo $starting_location; ?></td>
                     <td><?php echo $destination; ?></td>
                     <td><?php echo $dueholder; ?></td>
                     <td><?php echo $charge; ?></td> 
                     <td><?php echo $received; ?></td> 
                     <td><?php echo $less; ?></td> 
                     <td><strong><?php echo $due;?></strong></td> 
                     <td><?php echo $user; ?></td> 
                     <td><?php echo $action; ?></td> 
               	</tr>
                <?php
                	}
				}
			}
			?>
        	<tr bgcolor="#f2f2f2">
              <td colspan="12" valign="center" align="right"><strong>Total : </strong></td>
              <td colspan="3" valign="center" align="left">
              <strong><?php echo number_format($totalsumcharge, 2, '.', ''); ?></strong></td>
            </tr>
           <tbody>
        </table>
        
         <?php
        if(!empty($expenseHeadData) && $totalsumcharge>0){
			$dataPoints = '';
			foreach($expenseHeadData as $label=>$amount){
				$percentage = round(($amount*100)/$totalsumcharge,2);
				$dataPoints[] = array('label'=>$label.' : '.number_format($amount,2), 'y'=>$percentage);
			}
			?>
            <script type="text/javascript">
				window.onload = function() {
					var chart = new CanvasJS.Chart("chartContainer", {
						animationEnabled: true,
						title: {text: "Ambulance Income"},
						subtitles: [{text: "Date Range: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?>"}],
						data: [{
							type: "column",
							yValueFormatString: "#,##0.00\"%\"",
							indexLabel: "{label} ({y})",
							dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
						}]
					});
					chart.render();				 
				}
			</script>
            <div id="chartContainer" style="height: 370px; width: 100%; margin-top:20px;"></div>
			<!--<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>-->
            <script src="js/canvasjs.min.js"></script>
            <?php
		}
		?>
        </td>
      
	<td align="center" id="divToPrint" style="display:none">
		<?php 
		$datetime1 = new DateTime($transactiondatefrom);
		$datetime2 = new DateTime($transactiondateto);
		$interval = $datetime1->diff($datetime2);
		$totaldays = $interval->format('%a');
		if($datetime1<$datetime2){
			$fromdate = $transactiondatefrom;
			$todate = $transactiondateto;
		}
		else{
			$fromdate = $transactiondateto;
			$todate = $transactiondatefrom;
		}
		?>
        
        <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1" cellspacing="0" cellpadding="2">
        <tbody>
         <tr>
            <td colspan="19" bgcolor="#FFF" align="center" style="color:#000; border:1px solid #000; padding-left:15px;">
            	<strong><?php echo $hospitaldata_name;?></strong><br>
                Statement By Expense :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?>
            </td>
          </tr>
             <tr align="left">
               	<td><strong>Date</strong></td>
                <td><strong>Bill No.</strong></td>
              	<td><strong>Paid To</strong></td> 
                <td><strong>Expense Section</strong></td> 
                <td><strong>Expense Head</strong></td> 
                <td><strong>month</strong></td>            
              	<td><strong> Expense Amount</strong></td> 
                <td><strong> User</strong></td>              
              </tr>
		<?php
		$totalsumcharge='0.00';
			
		for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
			$sqlst = "select * from ambulance where due>0 and created_date between '$newfromdate' and '$newtodate' $searchstr order by ambulance_id desc";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery &&  mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery)) {
					 $ambulance_id = $strow['ambulance_id'];
                    $name = $strow['name'];
					$user = $strow['user'];
                    $mobile = $strow['mobile'];
                    $referer = $strow['referer'];
                    $starting_location = $strow['starting_location'];
                    $destination = $strow['destination'];
                    $charge = $strow['charge'];
                    $month = $strow['month'];
                    $description = $strow['description'];
                    $created_date = $strow['created_date'];
					
					$totalsumcharge  = $totalsumcharge + $charge;
                   ?>
                <tr>
                    <td> <?php echo date('d.m.y',strtotime($newfromdate)); ?> </td>
                    <td> <?php echo $ambulance_id; ?> </td>
                    <td> <?php echo $name; ?> </td>
                    <td> <?php echo $referer; ?> </td>
                    <td> <?php echo $starting_location; ?></td>
                    <td> <?php echo $destination; ?> </td>
                    <td> <?php echo $charge; ?> </td>
                    <td> <?php echo $user; ?></td>
              	</tr>
                <?php
                	}
				}
			}
		?>
        	<tr bgcolor="#f2f2f2">
              <td  colspan="5" align="left">&nbsp;</td>
              <td   align="right"><strong>Total : </strong></td>
              <td   align="left" >
              <strong><?php echo number_format($totalsumcharge, 2, '.', ''); ?></strong></td>
              <td   align="left">&nbsp;</td>
          	</tr>
             <tbody>
        </table>
        </td>
</table>