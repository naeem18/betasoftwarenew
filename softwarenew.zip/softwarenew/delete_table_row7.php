<?php
session_start();
if(isset($_GET['idvalue'])){	

	$idvalue = $_GET['idvalue'];
	if($idvalue>0){
		require('labdd.php');
		
		$str2 = "DELETE from salaryentry where salaryentry_id = '$idvalue'";
		$userquery = mysqli_query($conn, $str2);
		
		
		  $str3 = "DELETE from dailytransection_lab where section='Salary Paid' AND labinvoice_id = '$idvalue'";
		//echo $str3;
		$userquery = mysqli_query($conn, $str3);
		
		
		if($userquery){			
			header("location:index.php?p=statementbysalary&message=remove-successfully");			
		}
		else{
			header("location:index.php?p=$returnpage&message=couldnotremove");
		}
	}
	else{
		header("location:index.php?p=statementbysalary&message=incorrect_id");
	}
}
?>
