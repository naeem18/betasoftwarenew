<script type="text/javascript" language="javascript">
	function removetablerow8(idvalue){
		var conf = confirm("Do you sure want to delete this ID="+idvalue+" from this Table ");
		if(conf)
			window.location='delete_table_row8.php?idvalue='+idvalue;
		}
</script>
<?php
$searchstr='';
if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
{
	$transactiondatefrom = $_REQUEST['ADate1'];
	$transactiondateto = $_REQUEST['ADate2'];
	
	$emergencyinvoice_patient = $_REQUEST['emergencyinvoice_patient'];
	$emergencyinvoice_mpo = $_REQUEST['emergencyinvoice_mpo'];
	$emergencyinvoice_id = $_REQUEST['emergencyinvoice_id'];
	$emergencyinvoice_patientid = $_REQUEST['emergencyinvoice_patientid'];
	
	$user = $_REQUEST['user'];
	$emergencyinvoice_doctor = $_REQUEST['emergencyinvoice_doctor'];
	if($emergencyinvoice_patient !=''){
		$searchstr .= " and emergencyinvoice_patient like '%$emergencyinvoice_patient%'";
	}
	elseif($emergencyinvoice_id !=''){
		$searchstr .= " and emergencyinvoice_id like '%$emergencyinvoice_id%'";
	}
	elseif($user !=''){
		$searchstr .= " and user like '%$user%'";
	}
	elseif($emergencyinvoice_patientid !=''){
		$searchstr .= " and emergencyinvoice_patientid like '%$emergencyinvoice_patientid%'";
	}
	elseif($emergencyinvoice_mpo !=''){
		$searchstr .= " and emergencyinvoice_mpo like '%$emergencyinvoice_mpo%'";
	}
	elseif($emergencyinvoice_doctor !=''){
		$searchstr .= " and emergencyinvoice_doctor like '%$emergencyinvoice_doctor%'";
	
		}
	}
	else
	{
		$transactiondatefrom = date('Y-m-d', strtotime('-0 day'));
		$transactiondateto = date('Y-m-d');
	}
	
	$datetime1 = new DateTime($transactiondatefrom);
	$datetime2 = new DateTime($transactiondateto);
	$interval = $datetime1->diff($datetime2);
	$totaldays = $interval->format('%a');
	if($datetime1<$datetime2){
		$fromdate = $transactiondatefrom;
		$todate = $transactiondateto;
	}
	else{
		$fromdate = $transactiondateto;
		$todate = $transactiondatefrom;
	}
?>

<table width="100%" cellpadding="2">
  <tr>
    <td valign="top" align="center">
    	<form name="cbform1" method="post" action="index.php?p=emergencyreport">
            <table width="1050" align="left" cellpadding="3" bordercolor="#666666">
              <tbody>
                <tr bgcolor="#011E6A">
                  <td colspan="18" bgcolor="#CCCCCC"><strong>Search By..</strong></td>
                </tr>           
                <tr bgcolor="#FFFFFF">
                <?php /*?> <?php if($_SESSION['employeename']=='SUPERADMINISTRATOR'){?><?php */?>
                    <td align="right">Date From:</td>
                    <td>
                        <input name="ADate1" id="ADate1" style="border: 1px solid #001E6A; " value="<?php echo $transactiondatefrom; ?>" size="7" readonly onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
                    </td>
                    <td>To:</td>
                    <td>
                        <input name="ADate2" id="ADate2" style="border: 1px solid #001E6A;" value="<?php echo $transactiondateto; ?>" size="7" readonly onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate2')" style="cursor:pointer"/>
                    </td>
                    
                   <?php /*?> <?php } ?><?php */?>
                   
                    <td>Inv</td>
            	    <td><input type="text" style="width:40px" name="emergencyinvoice_id" id="emergencyinvoice_id"/></td>
             		
                    <td>ID</td>
            	    <td><input type="text" style="width:40px" name="emergencyinvoice_patientid" id="emergencyinvoice_patientid" /></td>
             		<td>Name</td>
            	    <td><input type="text" style="width:90px" placeholder="Patient Name" name="emergencyinvoice_patient" id="emergencyinvoice_patient" /></td>
             		
                    <td>Dr.</td>
            	    <td><input type="text" style="width:90px" placeholder="Doctor Name" name="emergencyinvoice_doctor" id="emergencyinvoice_doctor" /></td>
            		<td>MPO</td>
            	    <td><input type="text" style="width:90px" name="emergencyinvoice_mpo" id="emergencyinvoice_mpo" /></td>
            
            		<td>user</td>
            	    <td><input type="text" size="6" placeholder="user" name="user" id="user" /></td>
                 
                 	<td><input style="border: 1px solid #001E6A" type="submit" value="Search" name="Submit" /></td>
                    <td><input name="print" type="button" id="print" style="border: 1px solid #001E6A" value="Print" onClick="PrintDiv();" />
                    </td>
              	</tr>
              </tbody>
            </table>
		</form>
   	</td>
</tr>

	<td align="center">
    
     <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1" cellspacing="0" cellpadding="2">
        <tr>
            <td colspan="26" bgcolor="#ccc" align="center" style="color:#03F; border:1px solid #03F;">
                <strong><?php echo $hospitaldata_name;?></strong><br>
                <strong>Statement By Emergency Invoice :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></strong>
            </td>
        </tr>
      
        <tr bgcolor="#096B7F" style="color:#FFF">
            <td>SL</td>
            <td>INV No.</td>
            <td>Print Inv</td>
            <td>Date</td>
            <td>Patient</td>
            <td>Gross</td>
            <!-- <td>Disc%</td>-->
            <td>Disc</td>
            <td><strong>Nett</strong></td>
            <td style="color:yellow">Inv Cash</td>
            <td style="color:yellow">Due Collection</td>
             <td>Final Disc</td>
            <td style="color:yellow"><strong>Dues</strong></td>
            <td>Ref. Dr.</td>
            <!--<td>MPO</td>
            <td>P.C Name</td>
            <td>P.C Com Due</td>-->
            <td>Description</td>
            <td>User Name</td>
            <td>Updated User</td>
            <td>Edit</td>
            <td>Remove</td>
        </tr>
		<?php
		$s='';
		$totalsumemergencyinvoice_subtotal='0.00';
		$totalsumemergencyinvoice_subtotalafterdisc='0.00';
		$totalsumemergencyinvoice_totaldisc='0.00';
		$totalsumemergencyinvoice_receiveamount='0.00';
		$totalsumemergencyinvoice_due='0.00';
		$totalsumemergencyinvoice_subtotalafterdisc='0.00';
		$totalsumemergencyinvoice_pccommission='0.00';
		$totalsumcollection_amount='0.00';
	
		for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
			$sqlst = "select * from emergencyinvoice where emergencyinvoice_date between '$newfromdate' and '$newtodate' $searchstr order by emergencyinvoice_id asc";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery &&  mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery)) {
					$emergencyinvoice_id = $strow['emergencyinvoice_id'];
                    $emergencyinvoice_patientid = $strow['emergencyinvoice_patientid'];
                    $emergencyinvoice_patient = $strow['emergencyinvoice_patient'];
					$user = $strow['user'];
					$update_user = $strow['update_user'];
                    $emergencyinvoice_age = $strow['emergencyinvoice_age'];
                    $emergencyinvoice_gender = $strow['emergencyinvoice_gender'];
                    $emergencyinvoice_address = $strow['emergencyinvoice_address'];
                    $emergencyinvoice_doctor = $strow['emergencyinvoice_doctor'];
                    $emergencyinvoice_pc = $strow['emergencyinvoice_pc'];
					$emergencyinvoice_mpo = $strow['emergencyinvoice_mpo'];
					$emergencyinvoice_totalpccomission = $strow['emergencyinvoice_totalpccomission'];
					$emergencyinvoice_subtotal = $strow['emergencyinvoice_subtotal'];
					$emergencyinvoice_totaldiscp = $strow['emergencyinvoice_totaldiscp'];
					$emergencyinvoice_totaldisc = $strow['emergencyinvoice_totaldisc'];
					$emergencyinvoice_subtotalafterdisc = $strow['emergencyinvoice_subtotalafterdisc'];
					$emergencyinvoice_receiveamount = $strow['emergencyinvoice_receiveamount'];
					$emergencyinvoice_due = $strow['emergencyinvoice_due'];
					$collection_amount = $strow['collection_amount'];
					$emergencyinvoice_finaldisc = $strow['emergencyinvoice_finaldisc'];
					$emergencyinvoice_description = $strow['emergencyinvoice_description'];
					$emergencyinvoice_date=	$strow['emergencyinvoice_date'];
				 
				$action = "<a href=\"index.php?p=emergencyinvoiceedit&emergencyinvoice_id=$emergencyinvoice_id\" target=\"_blank\">Edit</a>";
				$action6 = "<a href=\"javascript:void(0)\" onclick=\"removetablerow8($emergencyinvoice_id)\">Remove</a>";
				$action1 = "<a href=\"index.php?p=printemergencyinvoice&emergencyinvoice_id=$emergencyinvoice_id\" target=\"_blank\">Print</a>";
				
				$totalsumemergencyinvoice_subtotal  = $totalsumemergencyinvoice_subtotal + $emergencyinvoice_subtotal;
				$totalsumemergencyinvoice_subtotalafterdisc  = $totalsumemergencyinvoice_subtotalafterdisc + $emergencyinvoice_subtotalafterdisc;
				$totalsumemergencyinvoice_totaldisc  = $totalsumemergencyinvoice_totaldisc + $emergencyinvoice_totaldisc;
				$totalsumemergencyinvoice_receiveamount  = $totalsumemergencyinvoice_receiveamount + $emergencyinvoice_receiveamount;
				$totalsumemergencyinvoice_due  = $totalsumemergencyinvoice_due + $emergencyinvoice_due;
				$totalsumemergencyinvoice_pccommission=$totalsumemergencyinvoice_pccommission+$emergencyinvoice_totalpccomission;
				$totalsumcollection_amount=$totalsumcollection_amount+$collection_amount;
		    	?>
                <tr bgcolor="#f5f5f5" >
                    <td><?php echo $s=$s+1;?></td>
                    <td><?php echo $emergencyinvoice_id;?></td>
                    <td><?php echo $action1;?></td>
                    <td><?php echo $emergencyinvoice_date;?></td>
                    <td><?php echo $emergencyinvoice_patient;?></td>
                    <td><?php echo $emergencyinvoice_subtotal;?></td>
                    <?php /*?><td><?php echo $emergencyinvoice_totaldiscp;?></td><?php */?>
                    <td><?php echo $emergencyinvoice_totaldisc;?></td>
                    <td style="color: #00C"><?php echo $emergencyinvoice_subtotalafterdisc;?></td>
                    <td><?php echo $emergencyinvoice_receiveamount;?></td>
                    <td><?php echo $collection_amount;?></td>
                    <td><?php echo $emergencyinvoice_finaldisc;?></td>
                   	<td style="color: #F00"><?php echo $emergencyinvoice_due;?></td>
                    <td><?php echo $emergencyinvoice_doctor;?></td>
                    <?php /*?><td><?php echo $emergencyinvoice_mpo;?></td>
                    <td><?php echo $emergencyinvoice_pc;?></td>
                    <td><?php echo $emergencyinvoice_totalpccomission;?></td><?php */?>
                    <td><?php echo $emergencyinvoice_description;?></td>
                    <td><?php echo $user;?></td>
                    <td style="color:#F00"><?php echo $update_user;?></td>
                   	<td><?php if($_SESSION['employeename']=='ADMINISTRATOR'){ echo $action; } if($_SESSION['employeename']=='SUPERADMINISTRATOR'){ echo $action; }?></td>
                    <td><?php if($_SESSION['employeename']=='SUPERADMINISTRATOR'){ echo $action6; } ?></td>
              	</tr>
                <?php
					}
				}
			}
		?>
        	<tr bgcolor="#F2EBEB">
                <td colspan="4">&nbsp;</td>
                <td><strong>Total:</strong></td>
                <td><strong>Gross: <?php echo number_format($totalsumemergencyinvoice_subtotal); ?></strong></td>
                <td><strong>Disc: <?php echo number_format($totalsumemergencyinvoice_totaldisc, 2, '.', ''); ?></strong></td>
                <td><strong>Nett: <?php echo number_format($totalsumemergencyinvoice_subtotalafterdisc); ?></strong></td>
                <td bgcolor="#F4BABB"><strong>Inv Cash: <?php echo $totalsumemergencyinvoice_receiveamount; ?></strong></td>
                <td><strong>Dues Collection: <?php echo $totalsumcollection_amount; ?></strong></td>
                <td><strong><?php //echo number_format($totalsumemergencyinvoice_subtotalafterdisc, 2, '.', ''); ?></strong></td>
                <td><strong>Dues: <?php echo number_format($totalsumemergencyinvoice_due); ?></strong></td>
                <td colspan="6">&nbsp;</td>
            </tr>
          </table>
        </td>
      <tr>
    
		<td align="center" id="divToPrint" style="display:none">
    		<?php 
            $datetime1 = new DateTime($transactiondatefrom);
            $datetime2 = new DateTime($transactiondateto);
            $interval = $datetime1->diff($datetime2);
            $totaldays = $interval->format('%a');
            if($datetime1<$datetime2){
                $fromdate = $transactiondatefrom;
                $todate = $transactiondateto;
            }
            else{
                $fromdate = $transactiondateto;
                $todate = $transactiondatefrom;
            }
            ?>
            
      
           <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1" cellspacing="0" cellpadding="2">
              <tbody>
              <tr>
            <td colspan="18" bgcolor="#fff" align="center" style="color:#000; border:1px solid #000;">
            	<strong><?php echo $hospitaldata_name; ?></strong><br>
                <samp>Statement By Emergency Invoice :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></samp>
            </td>
          	</tr>
              <tr>
                <td align="left"><strong>SL</strong></td>
                <td align="left"><strong>Bill</strong></td>
                <td align="left"><strong>Date</strong></td>
                <td align="left"><strong>Patient</strong></td>
                <td align="left"><strong>Gross</strong></td>
                <td align="left"><strong>Disc</strong></td>
                <td align="left"><strong>Nett</strong></td>
                <td align="left"><strong>Cash</strong></td>
                <td align="left"><strong>Dues</strong></td>
                <td align="left"><strong>Ref. Dr.</strong></td>
                <td align="left"><strong>MPO Name</strong></td>
                <td align="left"><strong>P.C Name</strong></td>
                <td align="left"><strong>P.C Com</strong></td>
                <td align="left">Description</td>
                <td align="left"><strong>User Name</strong></td>
            </tr>
            <?php
			$s='';
			$totalsumemergencyinvoice_subtotal='0.00';
			$totalsumemergencyinvoice_subtotalafterdisc='0.00';
			$totalsumemergencyinvoice_totaldisc='0.00';
			$totalsumemergencyinvoice_receiveamount='0.00';
			$totalsumemergencyinvoice_due='0.00';
			$totalsumemergencyinvoice_subtotalafterdisc='0.00';
			$totalsumemergencyinvoice_pccommission='0.00';
			
		
            for($i=0; $i<=$totaldays; $i++){
                $newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
                $newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
                
                $sqlst = "select * from emergencyinvoice where emergencyinvoice_date between '$newfromdate' and '$newtodate' $searchstr order by emergencyinvoice_id asc";
                $stquery = mysqli_query($conn, $sqlst);
                if($stquery &&  mysqli_num_rows($stquery)>0){
                while ($strow = mysqli_fetch_array($stquery)) {
                        $emergencyinvoice_id = $strow['emergencyinvoice_id'];
                        $emergencyinvoice_patientid = $strow['emergencyinvoice_patientid'];
						$user = $strow['user'];
                        $emergencyinvoice_patient = $strow['emergencyinvoice_patient'];
                        $emergencyinvoice_age = $strow['emergencyinvoice_age'];
                        $emergencyinvoice_gender = $strow['emergencyinvoice_gender'];
                        $emergencyinvoice_address = $strow['emergencyinvoice_address'];
                        $emergencyinvoice_doctor = $strow['emergencyinvoice_doctor'];
                        $emergencyinvoice_pc = $strow['emergencyinvoice_pc'];
                        $emergencyinvoice_mpo = $strow['emergencyinvoice_mpo'];
                        $emergencyinvoice_totalpccomission = $strow['emergencyinvoice_totalpccomission'];
                        $emergencyinvoice_subtotal = $strow['emergencyinvoice_subtotal'];
                        $emergencyinvoice_totaldiscp = $strow['emergencyinvoice_totaldiscp'];
                        $emergencyinvoice_totaldisc = $strow['emergencyinvoice_totaldisc'];
                        $emergencyinvoice_subtotalafterdisc = $strow['emergencyinvoice_subtotalafterdisc'];
                        $emergencyinvoice_receiveamount = $strow['emergencyinvoice_receiveamount'];
                        $emergencyinvoice_due = $strow['emergencyinvoice_due'];
                        $emergencyinvoice_description = $strow['emergencyinvoice_description'];
                        $emergencyinvoice_date=	$strow['emergencyinvoice_date'];
                         
                      
                        $totalsumemergencyinvoice_subtotal  = $totalsumemergencyinvoice_subtotal + $emergencyinvoice_subtotal;
                        $totalsumemergencyinvoice_subtotalafterdisc  = $totalsumemergencyinvoice_subtotalafterdisc + $emergencyinvoice_subtotalafterdisc;
                        $totalsumemergencyinvoice_totaldisc  = $totalsumemergencyinvoice_totaldisc + $emergencyinvoice_totaldisc;
                        $totalsumemergencyinvoice_receiveamount  = $totalsumemergencyinvoice_receiveamount + $emergencyinvoice_receiveamount;
                        $totalsumemergencyinvoice_due  = $totalsumemergencyinvoice_due + $emergencyinvoice_due;
                        $totalsumemergencyinvoice_pccommission=$totalsumemergencyinvoice_pccommission+$emergencyinvoice_totalpccomission;
                        ?>
                    <tr>
                        <td align="left"><?php echo $s=$s+1;?></td>
                        <td align="left"><?php echo $emergencyinvoice_id;?></td>
                        <td align="left"><?php echo date('d.m.y',strtotime($newfromdate));?></td>
                        <td  align="left"><?php echo $emergencyinvoice_patient;?></td>
                        <td  align="left"><?php echo $emergencyinvoice_subtotal;?></td>
                        <td align="left"><?php echo $emergencyinvoice_totaldisc;?></td>
                        <td align="left"><?php echo $emergencyinvoice_subtotalafterdisc;?></td>
                        <td align="left"><?php echo $emergencyinvoice_receiveamount;?></td>
                        <td align="left"><?php echo $emergencyinvoice_due;?></td>
                        <td  align="left"><?php echo $emergencyinvoice_doctor;?></td>
                    	<td align="left"><?php echo $emergencyinvoice_mpo;?></td>
                        <td  align="left"><?php echo $emergencyinvoice_pc;?></td>
                        <td  align="left"><?php echo $emergencyinvoice_totalpccomission;?></td>
                        <td  align="left"><?php echo $emergencyinvoice_description;?></td>
                        <td align="left"><?php echo $user;?></td>
                    </tr>
                    <?php
                    }
                  }
            	}
            ?>
            
            <tr>
              <td align="left" colspan="3">&nbsp;</td>
              <td align="left"><strong>Total : </strong></td>
              <td align="left"><strong><?php echo number_format($totalsumemergencyinvoice_subtotal, 2, '.', ''); ?></strong></td>
              <td align="left"><strong><?php echo number_format($totalsumemergencyinvoice_totaldisc, 2, '.', ''); ?></strong></td>
              <td align="left"><strong><?php echo number_format($totalsumemergencyinvoice_subtotalafterdisc, 2, '.', ''); ?></strong></td>
              <td align="left"><strong><?php echo number_format($totalsumemergencyinvoice_receiveamount, 2, '.', ''); ?></strong></td>
              <td align="left"><strong><?php echo number_format($totalsumemergencyinvoice_due, 2, '.', ''); ?></strong></td>
              <td  valign="center" colspan="3"  align="left">&nbsp;</td>
              <td align="left"><strong><?php echo number_format($totalsumemergencyinvoice_pccommission, 2, '.', ''); ?></strong></td>
              <td colspan="2" ></td>
              </tr>
              </tbody>
            </table>
        </td>
    </tr>
</table>