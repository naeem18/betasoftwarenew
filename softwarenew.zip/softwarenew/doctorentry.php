  <article class="bottomcontent">
	<script language="JavaScript" type="text/javascript">
	function checkcontactform(){
		var doctor_mobile = document.getElementById("doctor_mobile");
		var error_doctor_mobile = document.getElementById("error_doctor_mobile");
		error_doctor_mobile.innerHTML = '';
		if(doctor_mobile.value==''){
			error_doctor_mobile.innerHTML = "Number is missing.";
			doctor_mobile.focus();
			return false;
		}
		else if(doctor_mobile.value.length<11){
			error_doctor_mobile.innerHTML = "Number should be 11 Digit.";
			doctor_mobile.focus();
			return false;
		}
 		return true;
 	}
	</script>
    <h3 style="background:#ccc; color:#000; text-align:center">Add New Information</h3>
		<content>
		  <?php
			if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
			echo "<h2 class=\"red12bold\">You have missing Something</h2>";
			}
			elseif(isset($_GET['message']) && $_GET['message']=='duplicatename'){
			echo "<h2 class=\"red12bold\">This Item  already exists. Please try with different item .</h2>";   
			}
			elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
			echo "<h2 class=\"red12bold\">Error occured! Could not insert.</h2>";   
			}
			elseif(isset($_GET['message']) && $_GET['message']=='insert-successfully'){
			echo "<h2 class=\"red12bold\">Item insert successfully</h2>";   
			}
			$doctor_id = 0;
			$doctor_category = '';
			$doctor_name = '';
			$doctor_date = '';
			$doctor_address = '';
			$mpo = '';
			$code = '';
			$doctor_mobile = '';
			$doctor_date = '';
			$charge = '';
			$dayall = '';
			
			if(isset($_GET['doctor_id'])){
				$doctor_id = $_GET['doctor_id'];
				$sqldoctor = "select * from doctorentry where doctor_id = $doctor_id";
				$doctorquery = mysqli_query($conn, $sqldoctor);
				if($doctorquery){
					while($doctorrow = mysqli_fetch_array($doctorquery)){
						$doctor_id = $doctorrow['doctor_id'];
						$doctor_category = $doctorrow['doctor_category'];
						$doctor_name = $doctorrow['doctor_name'];
						$mpo = $doctorrow['mpo'];
						$code = $doctorrow['code'];
						$doctor_address = $doctorrow['doctor_address'];
						$doctor_mobile = $doctorrow['doctor_mobile'];
						$doctor_date = $doctorrow['doctor_date'];
 						$charge = $doctorrow['charge'];
						$dayall = $doctorrow['dayall'];
  					}
				}
			}
         ?>        
		<form action="save_doctor.php" name="frmcontact" onsubmit="return checkcontactform();" method="post" enctype="multipart/form-data">
            <table width="600" align="center" border="1" style="BORDER-COLLAPSE: collapse;" bgcolor="#f8f8f8" cellpadding="2">
                 <tr>
                    <td width="200">Select Category*</td>
                     <td >
                        <select style="width:121px" required id="doctor_category" name="doctor_category" >
                            <option value="">Select</option>
                            <?php
                            $doyouknowarray = array('Doctor', 'PC', 'MPO', 'Nurse', 'Surgeon', 'Assist', 'Anaesthetist', 'Diagnosis', 'SR');
                            foreach($doyouknowarray as $singleoption){
                                $selected = '';
                                if($doctor_category=="$singleoption"){$selected = ' selected="selected"';}
                                echo "<option value=\"$singleoption\"$selected>$singleoption</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
				 <tr>
                    <td>Upload Photo</td>
                    <td><input type="file" name="photo" id="photo" /></td>
            	</tr>
                <tr>
                    <td>Name*</td>
                    <td><input size="28" type="text" required name="doctor_name" id="doctor_name" value="<?php echo $doctor_name;?>" /></td>
                </tr>

                 <tr>
                    <td>Code</td>
                    <td><input size="28" name="code" id="code" value="<?php echo $code;?>" /></td>
                 </tr>

                <tr>
                    <td>Address</td>
                    <td><textarea name="doctor_address" id="doctor_address" style="width:203px"/><?php echo $doctor_address;?></textarea> Designation For USG Doctor</td>
                </tr>

                 <tr>
                    <td>Mobile*</td>
                    <td><input size="28" required type="text" name="doctor_mobile" id="doctor_mobile" value="<?php echo $doctor_mobile;?>" /><span id="error_doctor_mobile" style="color:#F00"></span></td>
                 </tr>

                <tr>
                    <td>Duty Date</td>
                    <td><input size="28" type="text" readonly name="doctor_date" id="doctor_date" value="<?php echo date('Y-m-d');?>"/>
                    	<img src="images/cal.gif" onClick="javascript:NewCssCal('doctor_date')" style="cursor:pointer"/>
                    </td>
                </tr>

                <tr>
                    <td>**Duty Time</td>
                    <td><input size="28" type="text" name="dutytime" id="dutytime" value="10 AM to 4 PM" /></td>
                </tr>

                <tr>
                    <td>**Duty Day Combine</td>
                    <td><textarea name="dayall" id="dayall" style="width:203px"/><?php echo $dayall;?></textarea></td>
                </tr>

				<tr>
                    <td>Room No.</td>
                    <td><input size="28" type="text" name="roomno" id="roomno" /></td>
                </tr>
                <tr>
                    <td>**Duty Day Individual</td>
                    <td><select style="width:121px" required id="dday" name="dday" >
                            <option value="Saturday">Saturday</option>
                            <option value="Sunday">Sunday</option>
                            <option value="Monday">Monday</option>
                            <option value="Tuesday">Tuesday</option>
                            <option value="Wednesday">Wednesday</option>
                            <option value="Thursday">Thursday</option>
                            <option value="Friday">Friday</option>
                          </select>
                    </td>
                </tr>

                <tr>
                    <td>**Doctor Category</td>
                    <td><select style="width:121px" required id="doctortype" name="doctortype" >
                            <option value="General">General</option>
                            <option value="USG">USG</option>
                            <option value="Otorhinolaryngology">Otorhinolaryngology</option>
                            <option value="Obstetrics and gynaecology">Obstetrics and gynaecology</option>
                             <option value="General practitioner">General practitioner</option>
                            <option value="Internal medicine">Internal medicine</option>
                            <option value="Family medicine">Family medicine</option>
                            <option value="Pathologist">Pathologist</option>
                            <option value="Rheumatologist">Rheumatologist</option>
                            <option value="Radiologist">Radiologist</option>
                            <option value="Endocrinologist">Endocrinologist</option>
                            <option value="Pediatrics">Pediatrics</option>
                            <option value="Urologist">Urologist</option>
                            <option value="Neurologist">Neurologist</option>
                            <option value="Dermatology">Dermatology</option>
                            <option value="Surgeon">Surgeon</option>
                            <option value="Gastroenterologist">Gastroenterologist</option>
                            <option value="Ophthalmologist">Ophthalmologist</option>
                            <option value="Anesthesiologist">Anesthesiologist</option>
                            <option value="Dermatologist">Dermatologist</option>
                            <option value="Pediatrician">Pediatrician</option>
                            <option value="Ophthalmology">Ophthalmology</option>
                            <option value="Oncologist">Oncologist</option>
                            <option value="Urology">Urology</option>
                            <option value="Endocrinology">Endocrinology</option>
                            <option value="Neurology">Neurology</option>
                        </select>
                    </td>
                </tr>

                <tr>
                    <td>**Consultation Fee</td>
                    <td><input size="28" type="text" name="charge" id="charge" value="<?php echo $charge;?>"/></td>
                </tr>

                <tr>
                    <td>MPO</td>
                    <td><input size="28" type="text" name="mpo" id="mpo" value="<?php echo $mpo;?>"/></td>
                </tr>
                
                <tr>
                    <td>**Active/Inactive</td>
                    <td><select style="width:121px" required id="status" name="status" >
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                           </select>
                    </td>
                </tr>

                <tr>
                    <td>&nbsp;</td>
                    <td>
                        <input type="hidden" name="doctor_id" id="doctor_id" value="<?php echo $doctor_id;?>">
                        <input type="submit" value=" Save " name="submit_doctor" id="submit_doctor" class="submitbuttoncss" />
                    </td>
                </tr>
          </table>
      </form>
 </content>
</article>