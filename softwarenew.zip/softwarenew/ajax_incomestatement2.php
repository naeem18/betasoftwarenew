<?php
date_default_timezone_set('Asia/Dhaka');
require('labdd.php');
//OPAI
// ========== HELPER FUNCTIONS ==========
function getDateRange() {
    $from = isset($_REQUEST['ADate1']) ? $_REQUEST['ADate1'] : date('Y-m-d', strtotime('-1 month'));
    $to   = isset($_REQUEST['ADate2']) ? $_REQUEST['ADate2'] : date('Y-m-d');
    if ($from > $to) list($from, $to) = array($to, $from);
    return array($from, $to);
}

function fetchGroupedSums($conn, $query, $dateField, $amountField) {
    $data = array();
    $res = mysqli_query($conn, $query);
    if ($res && mysqli_num_rows($res) > 0) {
        while ($row = mysqli_fetch_assoc($res)) {
            $d = substr($row[$dateField], 0, 10);
            $a = (float)$row[$amountField];
            if (!isset($data[$d])) $data[$d] = 0;
            $data[$d] += $a;
        }
    }
    return $data;
}

function getSum($map, $date) {
    return isset($map[$date]) ? $map[$date] : 0;
}

// ========== MAIN ==========
list($fromdate, $todate) = getDateRange();
$fromdatetime = $fromdate . " 00:00:00";
$todatetime   = $todate . " 23:59:59";
// ========== PRELOAD TABLES ==========
$tables = array();
$tables['lab_cash'] = fetchGroupedSums($conn, "SELECT labinvoice_date, labinvoice_receiveamount FROM labinvoice WHERE dstatus!='Deleted' AND labinvoice_date BETWEEN '$fromdatetime' AND '$todatetime' AND labinvoice_receiveamount>0", 'labinvoice_date', 'labinvoice_receiveamount');
$tables['lab_return'] = fetchGroupedSums($conn, "SELECT labinvoice_receiveamount, labinvoice_date FROM labinvoice_return WHERE labinvoice_date BETWEEN '$fromdatetime' AND '$todatetime' AND labinvoice_receiveamount>0", 'labinvoice_date', 'labinvoice_receiveamount');
$tables['lab_collection'] = fetchGroupedSums($conn, "SELECT labcollection_date, collection_amount FROM labcollection WHERE status!='Deleted' AND labcollection_date BETWEEN '$fromdatetime' AND '$todatetime' AND collection_amount>0", 'labcollection_date', 'collection_amount');
$tables['appointment'] = fetchGroupedSums($conn, "SELECT appointmententry_date, appointmententry_amount FROM appointmententry WHERE appointmententry_date BETWEEN '$fromdatetime' AND '$todatetime' AND appointmententry_amount>0", 'appointmententry_date', 'appointmententry_amount');
$tables['dental_cash'] = fetchGroupedSums($conn, "SELECT labinvoice_date, labinvoice_receiveamount FROM dentalinvoice WHERE labinvoice_date BETWEEN '$fromdatetime' AND '$todatetime' AND labinvoice_receiveamount>0", 'labinvoice_date', 'labinvoice_receiveamount');
$tables['dental_collection'] = fetchGroupedSums($conn, "SELECT labinvoice_date, collection_amount FROM dentalcollection WHERE labinvoice_date BETWEEN '$fromdatetime' AND '$todatetime' AND collection_amount>0", 'labinvoice_date', 'collection_amount');
$tables['ambulance'] = fetchGroupedSums($conn, "SELECT created_date, received FROM ambulance WHERE created_date BETWEEN '$fromdatetime' AND '$todatetime' AND received>0", 'created_date', 'received');
$tables['admission'] = fetchGroupedSums($conn, "SELECT dailytransection_lab_date, labinvoice_receiveamount FROM dailytransection_lab WHERE section='Admission Fee' AND dailytransection_lab_date BETWEEN '$fromdatetime' AND '$todatetime' AND labinvoice_receiveamount>0", 'dailytransection_lab_date', 'labinvoice_receiveamount');
$tables['advanced'] = fetchGroupedSums($conn, "SELECT advanced_date, advanced FROM advanced WHERE type!='Admission Fee' AND advanced_date BETWEEN '$fromdatetime' AND '$todatetime' AND advanced>0", 'advanced_date', 'advanced');
$tables['hospital_cash'] = fetchGroupedSums($conn, "SELECT hospitalinvoice_deliverydate, hospitalinvoice_receiveamount FROM hospitalinvoice WHERE status!='Deleted' AND hospitalinvoice_deliverydate BETWEEN '$fromdatetime' AND '$todatetime' AND hospitalinvoice_receiveamount>0", 'hospitalinvoice_deliverydate', 'hospitalinvoice_receiveamount');
$tables['hospital_collection'] = fetchGroupedSums($conn, "SELECT hospitalinvoicecollection_date, hospitalinvoicecollection_amount FROM hospitalinvoicecollection WHERE hospitalinvoicecollection_date BETWEEN '$fromdatetime' AND '$todatetime' AND hospitalinvoicecollection_amount>0", 'hospitalinvoicecollection_date', 'hospitalinvoicecollection_amount');
$tables['icu_cash'] = fetchGroupedSums($conn, "SELECT hospitalinvoiceicu_deliverydate, hospitalinvoiceicu_receiveamount FROM hospitalinvoiceicu WHERE status!='Deleted' AND hospitalinvoiceicu_deliverydate BETWEEN '$fromdatetime' AND '$todatetime' AND hospitalinvoiceicu_receiveamount>0", 'hospitalinvoiceicu_deliverydate', 'hospitalinvoiceicu_receiveamount');
$tables['icu_collection'] = fetchGroupedSums($conn, "SELECT hospitalinvoiceicucollection_date, hospitalinvoiceicucollection_amount FROM hospitalinvoiceicucollection WHERE hospitalinvoiceicucollection_date BETWEEN '$fromdatetime' AND '$todatetime' AND hospitalinvoiceicucollection_amount>0", 'hospitalinvoiceicucollection_date', 'hospitalinvoiceicucollection_amount');
$tables['expense'] = fetchGroupedSums($conn, "SELECT expense_date, expense_amount FROM expense WHERE expense_date BETWEEN '$fromdatetime' AND '$todatetime' AND expense_amount<>0", 'expense_date', 'expense_amount');
$tables['lab_pc_paid'] = fetchGroupedSums($conn, "SELECT labpcpaid_date, labpcpaid_amount FROM labpcpaid WHERE labpcpaid_date BETWEEN '$fromdatetime' AND '$todatetime' AND labpcpaid_amount<>0", 'labpcpaid_date', 'labpcpaid_amount');
$tables['hospital_pc_paid'] = fetchGroupedSums($conn, "SELECT hospitalpcpaid_date, hospitalpcpaid_amount FROM hospitalpcpaid WHERE hospitalpcpaid_date BETWEEN '$fromdatetime' AND '$todatetime' AND hospitalpcpaid_amount<>0", 'hospitalpcpaid_date', 'hospitalpcpaid_amount');
$tables['salary_paid'] = fetchGroupedSums($conn, "SELECT salaryentry_date, salaryentry_paid FROM salaryentry WHERE salaryentry_date BETWEEN '$fromdatetime' AND '$todatetime' AND salaryentry_paid<>0", 'salaryentry_date', 'salaryentry_paid');
$tables['inventory_sales'] = fetchGroupedSums($conn, "SELECT inventorysalesinvoice_date, inventorysalesinvoice_receiveamount FROM inventorysalesinvoice WHERE inventorysalesinvoice_date BETWEEN '$fromdatetime' AND '$todatetime' AND inventorysalesinvoice_receiveamount>0", 'inventorysalesinvoice_date', 'inventorysalesinvoice_receiveamount');
$tables['bank_deposit'] = fetchGroupedSums($conn, "SELECT bankinvoice_date, deposite_amount FROM bankinvoice WHERE bankinvoice_date BETWEEN '$fromdatetime' AND '$todatetime' AND deposite_amount<>0", 'bankinvoice_date', 'deposite_amount');
$tables['bank_withdrawal'] = fetchGroupedSums($conn, "SELECT bankinvoice_date, withdrawal_amount FROM bankinvoice WHERE bankinvoice_date BETWEEN '$fromdatetime' AND '$todatetime' AND withdrawal_amount<>0", 'bankinvoice_date', 'withdrawal_amount');
$tables['loan_deposit'] = fetchGroupedSums($conn, "SELECT loaninvoice_date, deposite_amount FROM loaninvoice WHERE loaninvoice_date BETWEEN '$fromdatetime' AND '$todatetime' AND deposite_amount>0", 'loaninvoice_date', 'deposite_amount');
$tables['loan_received'] = fetchGroupedSums($conn, "SELECT loaninvoice_date, withdrawal_amount FROM loaninvoice WHERE loaninvoice_date BETWEEN '$fromdatetime' AND '$todatetime' AND withdrawal_amount>0", 'loaninvoice_date', 'withdrawal_amount');
$tables['purchase_receive'] = fetchGroupedSums($conn, "SELECT purchaseinvoice_date, purchaseinvoice_receiveamount FROM storepurchaseinvoice WHERE purchaseinvoice_date BETWEEN '$fromdatetime' AND '$todatetime' AND purchaseinvoice_receiveamount>0", 'purchaseinvoice_date', 'purchaseinvoice_receiveamount');
$tables['purchase_paid'] = fetchGroupedSums($conn, "SELECT purchaseinvoicepaid_date, purchaseinvoicepaid_amount FROM storepurchaseinvoicepaid WHERE purchaseinvoicepaid_date BETWEEN '$fromdatetime' AND '$todatetime' AND purchaseinvoicepaid_amount>0", 'purchaseinvoicepaid_date', 'purchaseinvoicepaid_amount');
$tables['emergency_cash'] = fetchGroupedSums($conn, "SELECT emergencyinvoice_date, emergencyinvoice_receiveamount FROM emergencyinvoice WHERE emergencyinvoice_date BETWEEN '$fromdatetime' AND '$todatetime' AND emergencyinvoice_receiveamount>0", 'emergencyinvoice_date', 'emergencyinvoice_receiveamount');
$tables['emergency_collection'] = fetchGroupedSums($conn, "SELECT emergencyinvoice_date, collection_amount FROM emergencycollection WHERE emergencyinvoice_date BETWEEN '$fromdatetime' AND '$todatetime' AND collection_amount>0", 'emergencyinvoice_date', 'collection_amount');

// ========== OUTPUT ==========
$tz = new DateTimeZone('Asia/Dhaka');
$d1 = new DateTime($fromdatetime, $tz);
$d2 = new DateTime($todatetime, $tz);

//$d1 = new DateTime($fromdatetime);
//$d2 = new DateTime($todate);
$totaldays = $d1->diff($d2)->format('%a');

// Initialize subtotals
$subtotals = array_fill_keys(array_keys($tables), 0);
$grandReceipt = $grandPayment = 0;

echo "<table border='1' cellpadding='2' cellspacing='0' style='border-collapse:collapse;width:100%;font-size:12px;'>
<tr style='background:#176EBF;color:white;'>
<th>Date</th><th>Lab Cash</th>

<th>Lab Coll</th>
<th>Dr Visit</th>
<th>Dental Cash</th>
<th>Dental Coll</th>
<th>Ambu lance</th>
<th>Admi ssion</th>
<th>Adv anced</th>
<th>Hosp Cash</th>
<th>Hosp Coll</th>
<th>ICU Cash</th>
<th>ICU Coll</th>
<th>Inventory Sales</th>
<th>Emrg Cash</th>
<th>Emrg Coll</th>
<th>Bank W</th>
<th>Loan Rcv</th>
<th>Receipt</th>
<th>Expense</th>
<th>Lab Return</th>
<th>Lab PC</th>
<th>Hosp PC</th>
<th>Inv Purchase</th>
<th>Purchase Paid</th>
<th>Salary</th>
<th>Loan Paid</th>
<th>Bank Dep</th>
<th>Payment</th>
<th>Cash In Hand</th>
</tr>";

for ($i = 0; $i <= $totaldays; $i++) {
    $date = date('Y-m-d', strtotime($fromdatetime) + ($i * 86400));

    // Fetch each column value
    $vals = [];
    foreach ($tables as $key => $map) {
        $vals[$key] = getSum($map, $date);
        $subtotals[$key] += $vals[$key];
    }

    $receipt = $vals['lab_cash'] + $vals['lab_collection'] + $vals['appointment'] + 
               $vals['dental_cash'] + $vals['dental_collection'] + $vals['ambulance'] + $vals['admission'] + 
               $vals['advanced'] + $vals['hospital_cash'] + $vals['hospital_collection'] + $vals['icu_cash'] + 
               $vals['icu_collection'] + $vals['inventory_sales'] + $vals['emergency_cash'] + $vals['emergency_collection'] + 
               $vals['bank_withdrawal'] + $vals['loan_received'];

    $payment = $vals['expense'] + $vals['lab_return'] + $vals['lab_pc_paid'] + $vals['hospital_pc_paid'] + $vals['purchase_receive'] + 
               $vals['purchase_paid'] + $vals['salary_paid'] + $vals['loan_deposit'] + $vals['bank_deposit'];

    $cash = $receipt - $payment;

    if ($receipt > 0 || $payment > 0) {
        echo "<tr>
        <td>".date('d.m.y', strtotime($date))."</td>
        <td>{$vals['lab_cash']}</td>
		
		<td>{$vals['lab_collection']}</td>
		<td>{$vals['appointment']}</td>
        <td>{$vals['dental_cash']}</td>
		<td>{$vals['dental_collection']}</td>
		<td>{$vals['ambulance']}</td>
		<td>{$vals['admission']}</td>
		<td>{$vals['advanced']}</td>
        <td>{$vals['hospital_cash']}</td>
		<td>{$vals['hospital_collection']}</td>
		<td>{$vals['icu_cash']}</td>
		<td>{$vals['icu_collection']}</td>
        <td>{$vals['inventory_sales']}</td>
		<td>{$vals['emergency_cash']}</td>
		<td>{$vals['emergency_collection']}</td>
        <td>{$vals['bank_withdrawal']}</td>
		<td>{$vals['loan_received']}</td>
        <td><b>$receipt</b></td>
        <td>{$vals['expense']}</td>
		<td>{$vals['lab_return']}</td>
		<td>{$vals['lab_pc_paid']}</td>
		<td>{$vals['hospital_pc_paid']}</td>
		<td>{$vals['purchase_receive']}</td>
		<td>{$vals['purchase_paid']}</td>
        <td>{$vals['salary_paid']}</td>
		<td>{$vals['loan_deposit']}</td>
		<td>{$vals['bank_deposit']}</td>
        <td><b>$payment</b></td>
        <td><b>$cash</b></td>
        </tr>";

        $grandReceipt += $receipt;
        $grandPayment += $payment;
    }
}

// Display subtotals row
echo "<tr style='background:#DDD;font-weight:bold;'>
<td>Sub Total</td>
<td>{$subtotals['lab_cash']}</td>

<td>{$subtotals['lab_collection']}</td>
<td>{$subtotals['appointment']}</td>
<td>{$subtotals['dental_cash']}</td>
<td>{$subtotals['dental_collection']}</td>
<td>{$subtotals['ambulance']}</td>
<td>{$subtotals['admission']}</td>
<td>{$subtotals['advanced']}</td>
<td>{$subtotals['hospital_cash']}</td>
<td>{$subtotals['hospital_collection']}</td>
<td>{$subtotals['icu_cash']}</td>
<td>{$subtotals['icu_collection']}</td>
<td>{$subtotals['inventory_sales']}</td>
<td>{$subtotals['emergency_cash']}</td>
<td>{$subtotals['emergency_collection']}</td>
<td>{$subtotals['bank_withdrawal']}</td>
<td>{$subtotals['loan_received']}</td>
<td style=\"color:#f00\"><b>$grandReceipt</b></td>
<td>{$subtotals['expense']}</td>
<td>{$subtotals['lab_return']}</td>
<td>{$subtotals['lab_pc_paid']}</td>
<td>{$subtotals['hospital_pc_paid']}</td>
<td>{$subtotals['purchase_receive']}</td>
<td>{$subtotals['purchase_paid']}</td>
<td>{$subtotals['salary_paid']}</td><td>{$subtotals['loan_deposit']}</td><td>{$subtotals['bank_deposit']}</td>
<td style=\"color:#f00\"><b>$grandPayment</b></td>
<td style=\"color:#f00\"><b>".($grandReceipt-$grandPayment)."</b></td>
</tr>";

// Final grand total row
$grandCash = $grandReceipt - $grandPayment;
echo "<tr style='background:#EEE;font-weight:bold;'>
<td>Total</td><td align=\"right\" colspan='18'>Receipt: $grandReceipt</td>
<td align=\"right\" colspan='10'>Payment: $grandPayment</td><td colspan='2'>Cash: $grandCash</td></tr>";
echo "</table>";
?>
 