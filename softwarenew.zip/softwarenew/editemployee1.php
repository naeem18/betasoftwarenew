<?php
session_start();
/* =========================
   LOGIN CHECK
========================= */
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}

include("labdd.php");

/* =========================
   SETTINGS
========================= */
date_default_timezone_set('Asia/Dhaka');

$ipaddress = $_SERVER['REMOTE_ADDR'];
$updatedatetime = date('Y-m-d H:i:s');

/* FIX SESSION BUG (DO NOT OVERWRITE) */
$sessionusername = $_SESSION['username'];

$errmsg = "";
$bgcolorcode = "";

/* =========================
   FORM FLAG
========================= */
$frmflag1 = "";
if (isset($_REQUEST['frmflag1'])) {
    $frmflag1 = $_REQUEST['frmflag1'];
}

/* =========================
   UPDATE EMPLOYEE
========================= */
if ($frmflag1 == 'frmflag1') {

    $employeecode = $_REQUEST['employeecode'];
    $employeename = $_REQUEST['employeename'];
    $employeename = strtoupper(trim($employeename));

    $username = $_REQUEST['username'];
    $password = $_REQUEST['password'];
    $status = $_REQUEST['status'];
    $fullname = $_REQUEST['fullname'];

    $designation = nl2br(stripslashes(strip_tags(addslashes($_REQUEST['designation']))));

    $reports_daterange_option = $_REQUEST['reports_daterange_option'];
    $option_edit_delete = $_REQUEST['option_edit_delete'];

    /* =========================
       CHECK USER
    ========================= */
    $query2 = "SELECT * FROM master_employee WHERE username='$username'";
    $exec2 = mysqli_query($conn, $query2) or die(mysqli_error($conn));

    $res2 = mysqli_num_rows($exec2);

    if ($res2 != 0) {

        /* =========================
           UPDATE EMPLOYEE
        ========================= */
        $query1 = "UPDATE master_employee SET 
            employeename='$employeename',
            status='$status',
            fullname='$fullname',
            designation='$designation',
            lastupdate='$updatedatetime',
            lastupdateusername='$sessionusername',
            lastupdateipaddress='$ipaddress',
            reports_daterange_option='$reports_daterange_option',
            option_edit_delete='$option_edit_delete'
            WHERE employeecode='$employeecode'
            AND username='$username'";

        mysqli_query($conn, $query1) or die(mysqli_error($conn));

        /* =========================
           DELETE OLD RIGHTS
        ========================= */
        $query33 = "DELETE FROM master_employeerights 
                    WHERE username='$username' 
                    AND employeecode='$employeecode'";
        mysqli_query($conn, $query33) or die(mysqli_error($conn));

        /* =========================
           MAIN MENU RIGHTS
        ========================= */
        for ($i = 0; $i <= 1000; $i++) {

            $cbmainmenu = "";
            if (isset($_REQUEST["cbmainmenu".$i])) {
                $cbmainmenu = $_REQUEST["cbmainmenu".$i];
            }

            if ($cbmainmenu != "") {

                $query5 = "SELECT * FROM master_menumain 
                           WHERE auto_number='$cbmainmenu'";
                $exec5 = mysqli_query($conn, $query5);
                $res5 = mysqli_fetch_array($exec5);

                $mainmenuid = $res5['mainmenuid'];

                $query3 = "INSERT INTO master_employeerights 
                (employeecode, username, mainmenuid, submenuid, lastupdate, lastupdateipaddress, lastupdateusername)
                VALUES
                ('$employeecode','$username','$mainmenuid','',
                '$updatedatetime','$ipaddress','$sessionusername')";

                mysqli_query($conn, $query3);
            }
        }

        /* =========================
           SUB MENU RIGHTS
        ========================= */
        for ($i = 0; $i <= 1000; $i++) {

            $cbsubmenu = "";
            if (isset($_REQUEST["cbsubmenu".$i])) {
                $cbsubmenu = $_REQUEST["cbsubmenu".$i];
            }

            if ($cbsubmenu != "") {

                $query6 = "SELECT * FROM master_menusub 
                           WHERE auto_number='$cbsubmenu'";
                $exec6 = mysqli_query($conn, $query6);
                $res6 = mysqli_fetch_array($exec6);

                $submenuid = $res6['submenuid'];

                $query4 = "INSERT INTO master_employeerights 
                (employeecode, username, mainmenuid, submenuid, lastupdate, lastupdateipaddress, lastupdateusername)
                VALUES
                ('$employeecode','$username','','$submenuid',
                '$updatedatetime','$ipaddress','$sessionusername')";

                mysqli_query($conn, $query4);
            }
        }

        header("Location: index.php?st=success");
        exit;

    } else {
        header("Location: editemployee1.php?st=failed");
        exit;
    }
}

/* =========================
   STATUS MESSAGE
========================= */
$st = "";
if (isset($_REQUEST["st"])) {
    $st = $_REQUEST["st"];
}

if ($st == 'success') {
    $errmsg = "Success. Employee Updated.";
} elseif ($st == 'failed') {
    $errmsg = "Failed. Employee Already Exists.";
}

/* =========================
   LOAD EMPLOYEE DATA
========================= */
$selectemployeecode = "";
if (isset($_REQUEST["selectemployeecode"])) {
    $selectemployeecode = $_REQUEST["selectemployeecode"];
}

$query7 = "SELECT * FROM master_employee WHERE employeecode='$selectemployeecode'";
$exec7 = mysqli_query($conn, $query7) or die(mysqli_error($conn));

$res7 = mysqli_fetch_array($exec7);

$res7employeecode = isset($res7['employeecode']) ? $res7['employeecode'] : '';
$res7employeename = isset($res7['employeename']) ? strtoupper(trim($res7['employeename'])) : '';
$res7username     = isset($res7['username']) ? $res7['username'] : '';
$res7password     = isset($res7['password']) ? $res7['password'] : '';
$res7status       = isset($res7['status']) ? $res7['status'] : '';
$res7fullname     = isset($res7['fullname']) ? $res7['fullname'] : '';
$res7designation  = isset($res7['designation']) ? $res7['designation'] : '';
$res7lastupdate   = isset($res7['lastupdate']) ? $res7['lastupdate'] : '';

?>
 




<script type="text/javascript">
function process1backkeypress1(e)
{
    e = e || window.event;

    var key = e.keyCode || e.which;

    if (key == 8) {
        if (e.preventDefault) e.preventDefault();
        e.returnValue = false;
        return false;
    }
}
</script>

<script type="text/javascript">
function from1submit1()
{
    var form = document.form1;

    if (form.employeename.value == "") {
        alert("Employee Name Cannot Be Empty.");
        form.employeename.focus();
        return false;
    }

    if (form.username.value == "") {
        alert("User Name Cannot Be Empty.");
        form.username.focus();
        return false;
    }

    var data = form.username.value;

    var iChars = "!^+=[];,{}|\\<>?~$'\"#%&*()-_` ";

    for (var i = 0; i < data.length; i++) {
        if (iChars.indexOf(data.charAt(i)) != -1) {
            alert("User Name Has Invalid Characters Or Spaces. Not Allowed.");
            form.username.focus();
            return false;
        }
    }

    if (form.password.value == "") {
        alert("Password Cannot Be Empty.");
        form.password.focus();
        return false;
    }

    return true;
}
</script>

<script type="text/javascript">
function funcEmployeeSelect1()
{
    var el = document.getElementById("selectemployeecode");

    if (el.value == "") {
        alert("Please Select Employee Code To Edit.");
        el.focus();
        return false;
    }

    return true;
}
</script>
 
<script type="text/javascript">
$(document).ready(function () {

    $("#selectall").click(function () {
        $(".updatedone").prop("checked", this.checked);
    });

    $(".updatedone").click(function () {

        if ($(".updatedone:checked").length == $(".updatedone").length) {
            $("#selectall").prop("checked", true);
        } else {
            $("#selectall").prop("checked", false);
        }
    });

});
</script>
<body>
		<?php
          if(isset($_SESSION['auto_number'])){
         
			if ($selectemployeecode != '')
			{
				//include("menu.php");
			}
		?>
<table width="1000" border="0" cellspacing="0" cellpadding="2">

<style>
body {
    font-family: Arial;
}

/* container */
.form-box {
    margin: 20px 0;
    padding: 15px;
    background: #f7f7f7;
    border: 1px solid #ddd;
    width: 600px;
}

/* label */
.form-box strong {
    display: block;
    margin-bottom: 10px;
    font-size: 14px;
}

/* select box */
.form-box select {
    width: 300px;
    padding: 8px;
    border: 1px solid #999;
    border-radius: 4px;
    background: #fff;
    font-size: 14px;
}

/* button */
.form-box input[type="submit"] {
    padding: 7px 15px;
    border: 1px solid #001E6A;
    background: #001E6A;
    color: #fff;
    cursor: pointer;
    margin-left: 10px;
    border-radius: 4px;
}

.form-box input[type="submit"]:hover {
    background: #0033aa;
}

/* error message */
.msg {
    background: #AAFF00;
    padding: 8px;
    margin-bottom: 10px;
    border: 1px solid #88cc00;
}
</style>

<form method="post" action="index.php?p=editemployee1">

<div class="form-box">

<?php if (!empty($errmsg)) { ?>
    <div class="msg">
        <?php echo $errmsg; ?>
    </div>
<?php } ?>

<strong>Select Employee To Edit</strong>

<select name="selectemployeecode" id="selectemployeecode">
    <option value="">Select Employee To Edit</option>

    <?php
    $sessionUser = isset($_SESSION['employeename']) ? $_SESSION['employeename'] : '';

    if ($sessionUser == 'SUPERADMINISTRATOR') {
        $query = "SELECT employeecode, username 
                  FROM master_employee 
                  WHERE status='Active'";
    }
    elseif ($sessionUser == 'ADMINISTRATOR') {
        $query = "SELECT employeecode, username 
                  FROM master_employee 
                  WHERE status='Active' 
                  AND employeename!='SUPERADMINISTRATOR'";
    } else {
        $query = "";
    }

    if ($query != "") {
        $result = mysqli_query($conn, $query);

        while ($row = mysqli_fetch_assoc($result)) {
            echo '<option value="'.$row['employeecode'].'">'
                 .$row['employeecode'].' - '.$row['username'].
                 '</option>';
        }
    }
    ?>
</select>

<input type="submit" value="Submit">

</div>

</form>
	
	
  <tr>
    <td>&nbsp;</td>
    <td valign="top">&nbsp;</td>
    <td valign="top">
</td></tr>
  <tr>
    <td width="1%">&nbsp;</td>
    <td width="2%" valign="top">&nbsp;</td>
    <td width="97%" valign="top">

	<?php
    if ($selectemployeecode != '')
    {
	
    ?>
    
    <style>
.card{
    width:95%;
    margin:auto;
    background:#fff;
    border:1px solid #ddd;
    border-radius:8px;
    box-shadow:0 2px 10px rgba(0,0,0,.08);
}

.card-header{
    background:#011E6A;
    color:#fff;
    padding:12px;
}

.card-header h3{
    margin:0;
}

.form-table{
    width:100%;
    border-collapse:collapse;
}

.form-table td{
    padding:8px;
    border-bottom:1px solid #eee;
}

.form-table input[type=text],
.form-table input[type=password],
.form-table select,
.form-table textarea{
    width:100%;
    padding:7px;
    border:1px solid #ccc;
    border-radius:4px;
}

.menu-row{
    background:#f8f9fa;
}

.btn-save{
    background:#011E6A;
    color:#fff;
    border:none;
    padding:10px 25px;
    border-radius:4px;
    cursor:pointer;
}

.alert-success{
    background:#d4edda;
    color:#155724;
    padding:10px;
    margin:10px;
    border-radius:4px;
}
</style>
    
     <div class="card">
    <div class="card-header">
        <h3>👤 Employee Edit</h3>
    </div>

    <?php if($errmsg!=''){ ?>
    <div class="alert-success">
        <?php echo $errmsg; ?>
    </div>
    <?php } ?>

    <form method="post" action="editemployee1.php" id="form1" onsubmit="return from1submit1();">

    <input type="hidden" name="frmflag1" value="frmflag1">

    <table class="form-table">

        <tr>
            <td>Employee Code</td>
            <td>
                <input type="text" name="employeecode"
                value="<?php echo $res7employeecode; ?>" readonly>
            </td>

            <td>Date Posted</td>
            <td>
                <input type="text" name="dateposted"
                value="<?php echo $updatedatetime; ?>" readonly>
            </td>
        </tr>
        <tr>
    <td>Employee Type</td>
    <td>

<?php
$types = ($_SESSION['employeename']=='SUPERADMINISTRATOR')
?
array('SUPERADMINISTRATOR','ADMINISTRATOR','GENERAL')
:
array('ADMINISTRATOR','GENERAL');
?>

<select name="employeename" required>
<?php
foreach($types as $t){
    $sel=($res7employeename==$t)?'selected':'';
    echo "<option value='$t' $sel>$t</option>";
}
?>
</select>

    </td>

    <td>Status</td>
    <td>
        <select name="status">
            <option value="Active" <?php if($res7status=='Active') echo 'selected'; ?>>Active</option>
            <option value="Deleted" <?php if($res7status=='Deleted') echo 'selected'; ?>>Deleted</option>
        </select>
    </td>
</tr>

<tr>
    <td>User Name</td>
    <td colspan="3">
        <input type="text"
        name="username"
        value="<?php echo $res7username; ?>"
        readonly>
    </td>
</tr>

<tr>
    <td>Password</td>
    <td colspan="3">
        <input type="password"
        name="password"
        value="<?php echo $res7password; ?>"
        <?php if($res7username=='general') echo 'readonly'; ?>>
    </td>
</tr>

<tr>
    <td>Full Name</td>
    <td colspan="3">
        <input type="text"
        name="fullname"
        value="<?php echo $res7fullname; ?>"
        required>
    </td>
</tr>

<tr>
    <td>Designation</td>
    <td colspan="3">
        <textarea name="designation"><?php echo $res7designation; ?></textarea>
    </td>
</tr>

<tr>
    <td colspan="4">
        <hr>
        <h4>🔐 Menu Permissions</h4>

        Check / Uncheck All
        <input type="checkbox" id="selectall">
    </td>
</tr>

<?php

$query2="SELECT * 
FROM master_menumain
WHERE status=''
ORDER BY mainmenuorder";

$exec2=mysqli_query($conn,$query2);

while($res2=mysqli_fetch_array($exec2))
{
    $mainChecked='';

    $chk=mysqli_num_rows(mysqli_query(
    $conn,
    "SELECT auto_number
    FROM master_employeerights
    WHERE employeecode='$selectemployeecode'
    AND mainmenuid='{$res2['mainmenuid']}'"
    ));

    if($chk>0) $mainChecked='checked';
?>

<tr class="menu-row">
    <td colspan="4">
        <label>
            <input type="checkbox"
            class="updatedone"
            name="cbmainmenu<?php echo $res2['auto_number']; ?>"
            value="<?php echo $res2['auto_number']; ?>"
            <?php echo $mainChecked; ?>>

            <strong>
                <?php echo $res2['mainmenutext']; ?>
            </strong>
        </label>
    </td>
</tr>

<?php

$sub=mysqli_query($conn,"
SELECT *
FROM master_menusub
WHERE mainmenuid='{$res2['mainmenuid']}'
AND status=''
ORDER BY submenuorder");

while($res3=mysqli_fetch_array($sub))
{
    $subChecked='';

    $chk2=mysqli_num_rows(mysqli_query(
    $conn,
    "SELECT auto_number
    FROM master_employeerights
    WHERE employeecode='$selectemployeecode'
    AND submenuid='{$res3['submenuid']}'"
    ));

    if($chk2>0) $subChecked='checked';
?>

<tr>
    <td></td>
    <td colspan="3">
        <label>
            <input type="checkbox"
            class="updatedone"
            name="cbsubmenu<?php echo $res3['auto_number']; ?>"
            value="<?php echo $res3['auto_number']; ?>"
            <?php echo $subChecked; ?>>

            <?php echo $res3['submenutext']; ?>
        </label>
    </td>
</tr>

<?php } } ?>

 

<tr>
    <td colspan="4" align="center">
        <br>

        <input type="submit"
        value="💾 Save Employee"
        class="btn-save">

    </td>
</tr>

</table>
</form>
</div>

	<?php
	
	}
	?>
    
</table>

<?php
}
else{
	include('login_form.php');
}
?>
</body>
</html>