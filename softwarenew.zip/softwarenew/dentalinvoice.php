<?php
date_default_timezone_set('Asia/Dhaka');
$selectname_list = '';
$itemdata = '';
$month_serial = 1;
$labinvoice_date='';
		$LabInvYM = substr($labinvoice_date, 0, 7);
		$MSLSql = "SELECT month_serial FROM labinvoice WHERE SUBSTRING(labinvoice_date, 1, 7) = '$LabInvYM' ORDER BY month_serial DESC LIMIT 0, 1";
		$MSLObj = mysqli_query($conn, $MSLSql);
		if($MSLObj && mysqli_num_rows($MSLObj)>0){

			while ($labitemrow = mysqli_fetch_array($MSLObj)){
				$month_serial = $labitemrow['month_serial']+1;
			}
		}
		 $month_serial;
		 
$itemdataarray = array();
$sqllabitem = "select * from labitem where labitem_price!='' order by labitem_id asc";

$labitemquery = mysqli_query($conn, $sqllabitem);
if($labitemquery && mysqli_num_rows($labitemquery)>0){
 	while ($labitemrow = mysqli_fetch_array($labitemquery)){
			$labitem_id = $labitemrow['labitem_id'];
			$labitem_name = $labitemrow['labitem_name'];
			$labitem_group = $labitemrow['labitem_group'];
			$labitem_category = $labitemrow['labitem_category'];
			$category = $labitemrow['category'];
			$note = $labitemrow['note'];
			$orderby = $labitemrow['orderby'];
			$reportname = $labitemrow['reportname'];
			$labitem_sample = $labitemrow['labitem_sample'];
			$machine_name = $labitemrow['machine_name'];
			$labitem_unit = $labitemrow['labitem_unit'];
			$labitem_refvalue = $labitemrow['labitem_refvalue'];
			$labitem_price = $labitemrow['labitem_price'];
			$labitem_reagent = $labitemrow['labitem_reagent'];
			$labitem_pccommission = $labitemrow['labitem_pccommission'];
			$labitem_drcommission = $labitemrow['labitem_drcommission'];
			$labitem_tax = $labitemrow['labitem_tax'];

		$itemdataarray[$labitem_name] = "$labitem_id||$labitem_group||$labitem_category||$reportname||$labitem_sample||$machine_name||$category||$note||$orderby||$labitem_unit||$labitem_refvalue||$labitem_price||$labitem_reagent||$labitem_pccommission||$labitem_drcommission||$labitem_tax";

		$itemdata[] =array( 'labelval' => $labitem_name,
							'label' => $labitem_name,
							'labitem_id'=>$labitem_id,
							'labitem_group'=>$labitem_group,
							'labitem_category'=>$labitem_category,
							'reportname'=>$reportname,
							'labitem_sample'=>$labitem_sample,
							'machine_name'=>$machine_name,
							'category'=>$category,
							'note'=>$note,
							'orderby'=>$orderby,
							'labitem_unit'=>$labitem_unit,
							'labitem_refvalue'=>$labitem_refvalue,
							'labitem_price'=>$labitem_price,
							'labitem_reagent'=>$labitem_reagent,
							'labitem_pccommission'=>$labitem_pccommission,
							'labitem_drcommission'=>$labitem_drcommission,
							'labitem_tax'=>$labitem_tax
							);
			}
		}
$itemdataarray = json_encode($itemdataarray);
$itemdata = json_encode($itemdata);

$patientdata = '';
$sqlopregistration = "select * from opregistration where status!= 'Released' order by opregistration_id asc";
$opregistrationquery = mysqli_query($conn, $sqlopregistration);
if($opregistrationquery && mysqli_num_rows($opregistrationquery)>0){

	while ($opregistrationrow = mysqli_fetch_array($opregistrationquery)){
		$opregistration_id = $opregistrationrow['opregistration_id'];
		$opregistration_code = $opregistrationrow['opregistration_code'];
		$opregistration_name = $opregistrationrow['opregistration_name'];
		$opregistration_age = $opregistrationrow['opregistration_age'];
		$pcname = $opregistrationrow['pcname'];
		$mpo = $opregistrationrow['mpo'];
		$lab_due = $opregistrationrow['lab_due'];
		$ward = $opregistrationrow['ward'];
		$labinvoice_totalpccomission = $opregistrationrow['labinvoice_totalpccomission'];
		$opregistration_gender = $opregistrationrow['opregistration_gender'];
		$opregistration_mobile = $opregistrationrow['opregistration_mobile'];
		$opregistration_address = $opregistrationrow['opregistration_address'];
		$patientdata[] =array( 'labelval' => $opregistration_name,
								'label' => $opregistration_id.'#'. $opregistration_code. '#' .$opregistration_mobile,
								'opregistration_code'=>$opregistration_code,
								'opregistration_id'=>$opregistration_id,
								'opregistration_code'=>$opregistration_code,
								'opregistration_age'=>$opregistration_age,
								'pcname'=>$pcname,
								'mpo'=>$mpo,
								'lab_due'=>$lab_due,
								'ward'=>$ward,
								'labinvoice_totalpccomission'=>$labinvoice_totalpccomission,
								'opregistration_gender'=>$opregistration_gender,
								'opregistration_mobile'=>$opregistration_mobile,
								'opregistration_address'=>$opregistration_address
							);
			}
		}
$patientdata = json_encode($patientdata);

$pcdata = '';
$sqlpc = "select * from doctorentry where doctor_category='pc' order by doctor_name asc";
$opregistrationquery1 = mysqli_query($conn, $sqlpc);
if($opregistrationquery1 && mysqli_num_rows($opregistrationquery1)>0){

	while ($opregistrationrow = mysqli_fetch_array($opregistrationquery1)){
		$doctor_id = $opregistrationrow['doctor_id'];
		$doctor_name = $opregistrationrow['doctor_name'];
		$pc_comission = $opregistrationrow['pc_comission'];
		$mpo = $opregistrationrow['mpo'];
		$pcdata[] =array( 'labelval' => $doctor_name,
							'label' => $doctor_name . $doctor_id,
							'doctor_name'=>$doctor_name,
							'doctor_id'=>$doctor_id,
							'pc_comission'=>$pc_comission,
							'mpo'=>$mpo
							);
		}
	}
$pcdata = json_encode($pcdata);

$drdata = '';
$sqldr = "select * from doctorentry where doctor_category='doctor' order by doctor_name asc";
$opregistrationquery2 = mysqli_query($conn, $sqldr);
if($opregistrationquery2 && mysqli_num_rows($opregistrationquery2)>0){

	while ($opregistrationrow = mysqli_fetch_array($opregistrationquery2)){
		$doctor_id = $opregistrationrow['doctor_id'];
		$doctor_name = $opregistrationrow['doctor_name'];
		$drdata[] =array( 'labelval' => $doctor_name,
							'label' => $doctor_name,
							'doctor_name'=>$doctor_name
							);
		}
	}
$drdata = json_encode($drdata);
?>

<link rel="stylesheet" href="autocomplete/jquery-ui.css">
<script src="autocomplete/jquery-ui.min.js"></script>
<script language="JavaScript" type="text/javascript">
/*function disableEnterKey(e)
{
	var evt = e || window.event; 
		var key = evt.keyCode;
		//alert (key);
		if(key == 13) // if enter key press
		{
			//alert ("Enter Key Press");
			return false;
		}
}*/

function disableEnterKey(e)
	{
	//alert (document.activeElement.name); //To get the current active element.
	///*
	if (document.activeElement.name = "submit_invoice") //To allow multiple lines, enter key enabled.
	{
	
		var evt = e || window.event; 
		var key = evt.keyCode;
		//alert (key);
		if(key == 13) // if enter key press
		{
			//alert ("Enter Key Press");
			return false;
		}
	
	}
}
</script>	
<!--<script type="text/javascript">
	function disableButton(btn){
		document.getElementById(btn.id).disabled = true;
		alert("Button has been disabled.");
	}
</script>-->
<style type="text/css">
.ui-autocomplete { height:auto !important; max-height:300px; overflow:auto; background:#FFF; 
border:1px solid #CCC;	width:200px;}
.search_row{text-align:left;}
.ui-autocomplete li{ min-height:30px; border-bottom:1px dotted #CCC; padding:10px; text-align:left;}
</style>

<script language="JavaScript" type="text/javascript">
	var itemdataarray = <?php echo $itemdataarray;?>;
	var itemdata = <?php echo $itemdata;?>;
	var patientdata = <?php echo $patientdata;?>;
	var pcdata = <?php echo $pcdata;?>;
	var drdata = <?php echo $drdata;?>;
	var itemarraydata = itemdataarray;
	$(document).ready(function($) {
		document.getElementsByName("labinvoice_item[]")[0].focus();

		$( ".itemname" ).autocomplete({
			
			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				var labitem_idarray = document.getElementsByName("labitem_id[]");
				labitem_idarray[indexpos].value = ui.item.labitem_id;

				var labinvoice_ratearray = document.getElementsByName("labinvoice_rate[]");
				labinvoice_ratearray[indexpos].value = ui.item.labitem_price;

				var labinvoice_qtyarray = document.getElementsByName("labinvoice_qty[]");
				labinvoice_qtyarray[indexpos].value = 1;

				var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
				labinvoice_pccomissionarray[indexpos].value = ui.item.labitem_pccommission;

				var labinvoice_drcomissionarray = document.getElementsByName("labinvoice_drcomission[]");
				labinvoice_drcomissionarray[indexpos].value = ui.item.labitem_drcommission;

				var labinvoice_grouparray = document.getElementsByName("labinvoice_group[]");
				labinvoice_grouparray[indexpos].value = ui.item.labitem_group;
				
				var labinvoice_categoryarray = document.getElementsByName("labinvoice_category[]");
				labinvoice_categoryarray[indexpos].value = ui.item.labitem_category;
				
				var reportnamearray = document.getElementsByName("reportname[]");
				reportnamearray[indexpos].value = ui.item.reportname;

				var labinvoice_samplearray = document.getElementsByName("labinvoice_sample[]");
				labinvoice_samplearray[indexpos].value = ui.item.labitem_sample;
				
				var categoryarray = document.getElementsByName("category[]");
				categoryarray[indexpos].value = ui.item.category;
				
				var notearray = document.getElementsByName("note[]");
				notearray[indexpos].value = ui.item.note;
				
				var orderbyarray = document.getElementsByName("orderby[]");
				orderbyarray[indexpos].value = ui.item.orderby;
				
				var machine_namearray = document.getElementsByName("machine_name[]");
				machine_namearray[indexpos].value = ui.item.machine_name;

				var labinvoice_unitarray = document.getElementsByName("labinvoice_unit[]");
				labinvoice_unitarray[indexpos].value = ui.item.labitem_unit;

				var labinvoice_refvaluearray = document.getElementsByName("labinvoice_refvalue[]");
				labinvoice_refvaluearray[indexpos].value = ui.item.labitem_refvalue;

				var labinvoice_reagentarray = document.getElementsByName("labinvoice_reagent[]");
				labinvoice_reagentarray[indexpos].value = ui.item.labitem_reagent;

				calculaterowtotal(indexpos);
				//calculate_pctotal();
				//calculate_drtotal();
				addnew_particularrow(true);
				return false;
			}
		});

		$( "#labinvoice_patientid" ).autocomplete({
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('labinvoice_patient').value = ui.item.labelval;
				 document.getElementById('labinvoice_patientid').value = ui.item.opregistration_id;
				 document.getElementById('labinvoice_patientcode').value = ui.item.opregistration_code;
				 document.getElementById('labinvoice_age').value = ui.item.opregistration_age;
				 document.getElementById('labinvoice_gender').value = ui.item.opregistration_gender;
				 document.getElementById('labinvoice_mobile').value = ui.item.opregistration_mobile;
				 document.getElementById('labinvoice_address').value = ui.item.opregistration_address;
				 document.getElementById('labinvoice_pc').value = ui.item.pcname;
				 document.getElementById('labinvoice_mpo').value = ui.item.mpo;
				 document.getElementById('labinvoice_ward').value = ui.item.ward;
				 document.getElementById('labinvoice_previousdue').value = ui.item.lab_due;
				 document.getElementById('previous_labinvoice_totalpccomission').value = ui.item.labinvoice_totalpccomission;
				
				return false;
			}
		});
		
		// pc search
		$( "#labinvoice_pc" ).autocomplete({
			
			minLength: 1,
			source: pcdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('labinvoice_pc').value = ui.item.labelval;
				 document.getElementById('labinvoice_mpo').value = ui.item.mpo;
				 document.getElementById('doctor_id').value = ui.item.doctor_id;
				 document.getElementById('previous_pc_comission').value = ui.item.pc_comission;
				
				return false;
			}
		});
		
		// dr search
		$( "#labinvoice_doctor" ).autocomplete({
			
			minLength: 1,
			source: drdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('labinvoice_doctor').value = ui.item.labelval;
				 document.getElementById('labinvoice_doctor').value = ui.item.doctor_name;
				return false;
			}
		});
		
		
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
		$( ".labinvoice_item" ).keypress(function(keyname) {
			if(keyname.which==13){
				var imei = $(this).val();
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				$.each(itemarraydata, function(key, value){
					var valuearray = value.split('||');
					if(key==imei){
						document.getElementsByName("labitem_id[]")[indexpos].value = valuearray[0];
						//document.getElementsByName("salesinvoice_item[]")[indexpos].value = valuearray[1];
						document.getElementsByName("labinvoice_category[]")[indexpos].value = valuearray[1];
						document.getElementsByName("labinvoice_unit[]")[indexpos].value = valuearray[2];
						document.getElementsByName("labinvoice_refvalue[]")[indexpos].value = valuearray[3];
						document.getElementsByName("labinvoice_rate[]")[indexpos].value = valuearray[4];
						document.getElementsByName("labinvoice_reagent[]")[indexpos].value = valuearray[5];
						document.getElementsByName("labinvoice_pccomission[]")[indexpos].value = valuearray[6];
						document.getElementsByName("labinvoice_drcomission[]")[indexpos].value = valuearray[7];
						document.getElementsByName("labinvoice_qty[]")[indexpos].value = 1;
						calculaterowtotal(indexpos);
						addnew_particularrow(true);
					}
				});
				return false;
			}
		});
	});
	
	function calculate_discountp(){
		
		var labinvoice_discountparray = document.getElementsByName("labinvoice_discountp[]");
		var labinvoice_discarray = document.getElementsByName("labinvoice_disc[]");
		var labinvoice_ratearray = document.getElementsByName("labinvoice_rate[]");
		var labinvoice_qtyarray = document.getElementsByName("labinvoice_qty[]");
		//var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
			
		if(labinvoice_discountparray.length>0){
			for(var p=0; p<labinvoice_discountparray.length; p++){
				var labinvoice_discountp = parseFloat(labinvoice_discountparray[p].value);
				if(labinvoice_discountp=='' || isNaN(labinvoice_discountp)){labinvoice_discountp = 0;}
				
				var labinvoice_disc = parseFloat(labinvoice_discarray[p].value);
				if(labinvoice_disc=='' || isNaN(labinvoice_disc)){labinvoice_disc = 0;}
				if(labinvoice_discountp>0){
					var labinvoice_rate = parseFloat(labinvoice_ratearray[p].value);
					if(labinvoice_rate=='' || isNaN(labinvoice_rate)){labinvoice_rate = 0;}
					
					var labinvoice_qty = labinvoice_qtyarray[p].value;
					if(labinvoice_qty=='' || isNaN(labinvoice_qty)){labinvoice_qty = 0;}
					
					var total = parseFloat(labinvoice_rate*labinvoice_qty);			
					var labinvoice_disc = parseFloat(total*labinvoice_discountp*0.01);
					
					labinvoice_discarray[p].value = labinvoice_disc.toFixed(2);
				}
				
				calculaterowtotal(p);
			}
		}
	}
	
	function calculaterowtotal(indexpos){
		if(indexpos=='all'){
			var labinvoice_ratearray = document.getElementsByName("labinvoice_rate[]");
			var labinvoice_qtyarray = document.getElementsByName("labinvoice_qty[]");
			var labinvoice_discarray = document.getElementsByName("labinvoice_disc[]");
			var labinvoice_totalarray = document.getElementsByName("labinvoice_total[]");
				var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
			
			if(labinvoice_ratearray.length>0){
				for(var p=0; p<labinvoice_ratearray.length; p++){
					var labinvoice_rate = parseFloat(labinvoice_ratearray[p].value);
					if(labinvoice_rate=='' || isNaN(labinvoice_rate)){labinvoice_rate = 0;}
					
					
					var labinvoice_qty = parseFloat(labinvoice_qtyarray[p].value);
					if(labinvoice_qty=='' || isNaN(labinvoice_qty)){labinvoice_qty = 0;}
					
					var total = parseFloat(labinvoice_rate*labinvoice_qty);
					
					var labinvoice_disc = parseFloat(labinvoice_discarray[p].value);
					if(labinvoice_disc=='' || isNaN(labinvoice_disc)){labinvoice_disc = 0;}
					
					var total = parseFloat(total-labinvoice_disc);
					labinvoice_totalarray[p].value = total.toFixed(2);
					
					
					
				}
			}
		}
		else{
			var labinvoice_ratearray = document.getElementsByName("labinvoice_rate[]");
			var labinvoice_rate = parseFloat(labinvoice_ratearray[indexpos].value);
			if(labinvoice_rate=='' || isNaN(labinvoice_rate)){labinvoice_rate = 0;}
			
				
			var labinvoice_qtyarray = document.getElementsByName("labinvoice_qty[]");
			var labinvoice_qty = parseFloat(labinvoice_qtyarray[indexpos].value);
			if(labinvoice_qty=='' || isNaN(labinvoice_qty)){labinvoice_qty = 0;}
			
			var total = parseFloat(labinvoice_rate*labinvoice_qty);
			
			var labinvoice_discarray = document.getElementsByName("labinvoice_disc[]");
			var labinvoice_disc = parseFloat(labinvoice_discarray[indexpos].value);
			if(labinvoice_disc=='' || isNaN(labinvoice_disc)){labinvoice_disc = 0;}
			
			var total = parseFloat(total-labinvoice_disc);
			
			var labinvoice_totalarray = document.getElementsByName("labinvoice_total[]");
			labinvoice_totalarray[indexpos].value = total.toFixed(2);
			
		}
		
		calculate_total();
	}
	
	function calculate_total(){
		var labinvoice_subtotal = 0;
		var labinvoice_totalarray = document.getElementsByName("labinvoice_total[]");
		if(labinvoice_totalarray.length>0){
			for(var p=0; p<labinvoice_totalarray.length; p++){
				var labinvoice_total = parseFloat(labinvoice_totalarray[p].value);
				if(labinvoice_total=='' || isNaN(labinvoice_total)){labinvoice_total = 0;}
				labinvoice_subtotal = parseFloat(labinvoice_subtotal+labinvoice_total);
			}
		}
		//subtotal calculation
		document.getElementById("labinvoice_subtotal").value = labinvoice_subtotal.toFixed(2);
		
		var labinvoice_totaldiscp = parseFloat(document.getElementById("labinvoice_totaldiscp").value);
		if(labinvoice_totaldiscp=='' || isNaN(labinvoice_totaldiscp)){labinvoice_totaldiscp = 0;}
		
		var labinvoice_totaldisc = parseFloat(document.getElementById("labinvoice_totaldisc").value);
		if(labinvoice_totaldisc=='' || isNaN(labinvoice_totaldisc)){labinvoice_totaldisc = 0;}
		
		if(labinvoice_totaldiscp>0){
			var labinvoice_totaldisc = parseFloat(labinvoice_subtotal*labinvoice_totaldiscp*0.01);
			document.getElementById('labinvoice_totaldisc').value= labinvoice_totaldisc;
		}
		var labinvoice_subtotalafterdisc = parseFloat(labinvoice_subtotal-labinvoice_totaldisc);
		document.getElementById('labinvoice_subtotalafterdisc').value=	labinvoice_subtotalafterdisc.toFixed(2);
			
		var labinvoice_receiveamount = parseFloat(document.getElementById("labinvoice_receiveamount").value);
		if(labinvoice_receiveamount=='' || isNaN(labinvoice_receiveamount)){labinvoice_receiveamount = 0;}
		
		var labinvoice_due = parseFloat(labinvoice_subtotalafterdisc-labinvoice_receiveamount);
		document.getElementById('labinvoice_due').value=labinvoice_due.toFixed(2);		
		
		
		
	var varTDShowTotalAmount1 = document.getElementById("labinvoice_subtotalafterdisc").value;
	document.getElementById("tdShowTotalAmount1").innerHTML = varTDShowTotalAmount1;

		
		//pc comission  percentage...
		
	var labinvoice_totalpccomission = document.getElementById("labinvoice_totalpccomission").value;
	if(labinvoice_totalpccomission=='' || isNaN(labinvoice_totalpccomission)){labinvoice_totalpccomission = 0;}
		
		labinvoice_totalpccomission_percent = ((labinvoice_totalpccomission*100)/labinvoice_subtotal);
		document.getElementById('labinvoice_totalpccomission_percent').value=labinvoice_totalpccomission_percent;
		//pc comission  percentage...
		
		// new 21-08-16
		// discount 50/50
		var labinvoice_totalpccomission = 0;
		var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
		if(labinvoice_pccomissionarray.length>0){
			for(var p=0; p<labinvoice_pccomissionarray.length; p++){
				var labinvoice_pccomission = parseFloat(labinvoice_pccomissionarray[p].value);
				if(labinvoice_pccomission=='' || isNaN(labinvoice_pccomission)){labinvoice_pccomission = 0;}
				labinvoice_totalpccomission = parseFloat((labinvoice_totalpccomission+labinvoice_pccomission));
			//if(labinvoice_totaldiscp>0){
			//var labinvoice_totalpccomission = parseFloat(labinvoice_totalpccomission*labinvoice_totaldiscp*0.01);
			//}
			}
		}
		document.getElementById("labinvoice_totalpccomission").value = labinvoice_totalpccomission-labinvoice_totaldisc;
		
		// 50/50
		//document.getElementById("labinvoice_totalpccomission").value = labinvoice_totalpccomission-labinvoice_totaldisc/2;
		// end 21-08-16
		
		// Discount (dr, pc: 100%)
		var labinvoice_totalpccomission = 0;
		var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
		if(labinvoice_pccomissionarray.length>0){
			for(var p=0; p<labinvoice_pccomissionarray.length; p++){
				var labinvoice_pccomission = parseFloat(labinvoice_pccomissionarray[p].value);
				if(labinvoice_pccomission=='' || isNaN(labinvoice_pccomission)){labinvoice_pccomission = 0;}
				labinvoice_totalpccomission = parseFloat((labinvoice_totalpccomission+labinvoice_pccomission));
			if(labinvoice_totaldiscp>0){
			document.getElementById("labinvoice_totalpccomission").value = labinvoice_totalpccomission-labinvoice_totaldisc;
				}
			}
		}
		// end 21-08-16
		
		// dr comission
		// new 21-08-16
		var labinvoice_totaldrcomission = 0;
		var labinvoice_drcomissionarray = document.getElementsByName("labinvoice_drcomission[]");
		if(labinvoice_drcomissionarray.length>0){
			for(var m=0; m<labinvoice_drcomissionarray.length; m++){
				var labinvoice_drcomission = parseFloat(labinvoice_drcomissionarray[m].value);
				if(labinvoice_drcomission=='' || isNaN(labinvoice_drcomission)){labinvoice_drcomission = 0;}
				
			labinvoice_totaldrcomission = parseFloat((labinvoice_totaldrcomission+labinvoice_drcomission));
			//labinvoice_totalpccomission = parseFloat(labinvoice_totalpccomission);
			if(labinvoice_totaldiscp>0){
			var labinvoice_totaldisc = parseFloat(labinvoice_totaldrcomission*labinvoice_totaldiscp*0.01);
			//document.getElementById('labinvoice_totaldisc').value= labinvoice_totaldisc;
		}}
		}
		document.getElementById("labinvoice_totaldrcomission").value = labinvoice_totaldrcomission;
		// end 21-08-16
		
	
	}
	

	function calculate_pctotal(){
		var labinvoice_totalpccomission = 0;
		var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
		if(labinvoice_pccomissionarray.length>0){
			for(var p=0; p<labinvoice_pccomissionarray.length; p++){
				var labinvoice_pccomission = parseFloat(labinvoice_pccomissionarray[p].value);
				if(labinvoice_pccomission=='' || isNaN(labinvoice_pccomission)){labinvoice_pccomission = 0;}
				labinvoice_totalpccomission = parseFloat(labinvoice_totalpccomission+labinvoice_pccomission);
				}
			}
		document.getElementById("labinvoice_totalpccomission").value = labinvoice_totalpccomission;
		calculate_total();
						
		}
	
	function calculate_drtotal(){
		var labinvoice_totaldrcomission = 0;
		var labinvoice_drcomissionarray = document.getElementsByName("labinvoice_drcomission[]");
		if(labinvoice_drcomissionarray.length>0){
			for(var m=0; m<labinvoice_drcomissionarray.length; m++){
				var labinvoice_drcomission = parseFloat(labinvoice_drcomissionarray[m].value);
				if(labinvoice_drcomission=='' || isNaN(labinvoice_drcomission)){labinvoice_drcomission = 0;}
				labinvoice_totaldrcomission = parseFloat(labinvoice_totaldrcomission+labinvoice_drcomission);
			}
		}
		
		document.getElementById("labinvoice_totaldrcomission").value = labinvoice_totaldrcomission;
		
	}
	
	
	
	function check_particular(){
		
		return true;
	}
	function addnew_particularrow(animate) {
		if(check_particular()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" style=\"BORDER-COLLAPSE: collapse; border:2px solid #FFF\" bgcolor=\"#c0d2ff\" align=\"left\" width=\"1000\" border=\"0\" cellspacing=\"1\" cellpadding=\"4\">"+
							'<tr>'+
								'<td align="right">Test Name</td>'+
								'<td><input type="text" name="labinvoice_item[]" class="tdclasss itemname labinvoice_item"/></td>'+
								'<input type="hidden" name="labitem_id[]" id="labitem_id" class="tdclass itemname" />'+
								'<input type="hidden" name="labinvoice_group[]" class="tdclass" />'+
								'<input type="hidden" name="labinvoice_category[]" class="tdclass" />'+
								'<input type="hidden" name="category[]" class="tdclass" />'+
								'<input type="hidden" name="note[]" class="tdclass" />'+
								'<input type="hidden" name="orderby[]" class="tdclass" />'+
								'<input type="hidden" name="reportname[]" class="tdclass" />'+
								'<input type="hidden" name="labinvoice_sample[]" class="tdclass" />'+
								'<input type="hidden" name="machine_name[]" class="tdclass" />'+
								'<input type="hidden" name="labinvoice_unit[]" class="tdclass" />'+
								'<input type="hidden" name="labinvoice_refvalue[]" class="tdclass" />'+
								'<!--<td align="right">Stock</td>-->'+
								"<input type=\"hidden\" name=\"labinvoice_reagent[]\" id=\"labinvoice_reagent\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/>"+											 
								'<td align="right">Rate</td>'+
								"<td><input type=\"text\" name=\"labinvoice_rate[]\" readonly id=\"labinvoice_rate\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/></td>"+											 
								'<!--<td align="right">Qty</td>-->'+
								"<input type=\"hidden\" name=\"labinvoice_qty[]\" id=\"labinvoice_qty\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/>"+
								'<td align="right">Disc%</td>'+
								'<td><input type="text" name="labinvoice_discountp[]" class="tdclasssale" onKeyUp="calculate_discountp();"/></td>'+
								'<td align="right">Disc</td>'+
								"<td><input type=\"text\" name=\"labinvoice_disc[]\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\" /></td>"+
								'<td align="right">P.C</td>'+
								'<td><input type="text" name="labinvoice_pccomission[]" readonly class="tdclasssale" onKeyUp="calculate_pctotal();" /></td>'+
								'<!--<td align="right">Dr.</td>-->'+
								'<td><input type="hidden" name="labinvoice_drcomission[]" class="tdclasssale" onKeyUp="calculate_pctotal();" /></td>'+
								'<td align="right">Total</td>'+
								'<td><input type="text" readonly name="labinvoice_total[]" id="labinvoice_total" class="tdclasssale" /></td>'+												
								'<td>'+
								 "<input type=\"button\" value=\"Del\" onClick=\"deletethislistrow('particularlistrowno"+particular_rowcount+"');\" class=\"tdclasssale\"  />"+
								'</td>'+
							  '</tr>'+
						"</table>";
						
			var $newparticularlist = $("<li></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(200); 
			else 
			   $newparticularlist.show();   
			 document.getElementsByName("labinvoice_item[]")[parseInt(particular_rowcount-1)].focus();
			
			$( ".itemname" ).autocomplete({			
				minLength: 1,
				source: itemdata,
				focus: function( event, ui ) {
					//$( "#search_item_number" ).val( ui.item.labelval );
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					var labitem_idarray = document.getElementsByName("labitem_id[]");
				labitem_idarray[indexpos].value = ui.item.labitem_id;

				var labinvoice_ratearray = document.getElementsByName("labinvoice_rate[]");
				labinvoice_ratearray[indexpos].value = ui.item.labitem_price;

				var labinvoice_qtyarray = document.getElementsByName("labinvoice_qty[]");
				labinvoice_qtyarray[indexpos].value = 1;

				var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
				labinvoice_pccomissionarray[indexpos].value = ui.item.labitem_pccommission;

				var labinvoice_drcomissionarray = document.getElementsByName("labinvoice_drcomission[]");
				labinvoice_drcomissionarray[indexpos].value = ui.item.labitem_drcommission;

				var labinvoice_grouparray = document.getElementsByName("labinvoice_group[]");
				labinvoice_grouparray[indexpos].value = ui.item.labitem_group;
				
				var labinvoice_categoryarray = document.getElementsByName("labinvoice_category[]");
				labinvoice_categoryarray[indexpos].value = ui.item.labitem_category;
				
				var reportnamearray = document.getElementsByName("reportname[]");
				reportnamearray[indexpos].value = ui.item.reportname;

				var labinvoice_samplearray = document.getElementsByName("labinvoice_sample[]");
				labinvoice_samplearray[indexpos].value = ui.item.labitem_sample;
				
				var categoryarray = document.getElementsByName("category[]");
				categoryarray[indexpos].value = ui.item.category;
				
				var notearray = document.getElementsByName("note[]");
				notearray[indexpos].value = ui.item.note;
				
				var orderbyarray = document.getElementsByName("orderby[]");
				orderbyarray[indexpos].value = ui.item.orderby;
				
				var machine_namearray = document.getElementsByName("machine_name[]");
				machine_namearray[indexpos].value = ui.item.machine_name;

				var labinvoice_unitarray = document.getElementsByName("labinvoice_unit[]");
				labinvoice_unitarray[indexpos].value = ui.item.labitem_unit;

				var labinvoice_refvaluearray = document.getElementsByName("labinvoice_refvalue[]");
				labinvoice_refvaluearray[indexpos].value = ui.item.labitem_refvalue;

				var labinvoice_reagentarray = document.getElementsByName("labinvoice_reagent[]");
				labinvoice_reagentarray[indexpos].value = ui.item.labitem_reagent;
	
					calculaterowtotal(indexpos);
					calculate_pctotal();
					calculate_drtotal();
					addnew_particularrow(true);   //automatic add next row
					return false;
				}
			});	

			$( ".labinvoice_item" ).keypress(function(keyname) {
			if(keyname.which==13){
				var imei = $(this).val();
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();

				$.each(itemarraydata, function(key, value){
					var valuearray = value.split('||');
					if(key==imei){
						document.getElementsByName("labitem_id[]")[indexpos].value = valuearray[0];
						//document.getElementsByName("salesinvoice_item[]")[indexpos].value = valuearray[1];
						document.getElementsByName("labinvoice_category[]")[indexpos].value = valuearray[1];
						document.getElementsByName("labinvoice_unit[]")[indexpos].value = valuearray[2];
						document.getElementsByName("labinvoice_refvalue[]")[indexpos].value = valuearray[3];
						document.getElementsByName("labinvoice_rate[]")[indexpos].value = valuearray[4];
						document.getElementsByName("labinvoice_reagent[]")[indexpos].value = valuearray[5];
						document.getElementsByName("labinvoice_pccomission[]")[indexpos].value = valuearray[6];
						document.getElementsByName("labinvoice_drcomission[]")[indexpos].value = valuearray[7];
						document.getElementsByName("labinvoice_qty[]")[indexpos].value = 1;

						calculaterowtotal(indexpos);
						addnew_particularrow(true);
					}
				});
				return false;
			}
		});				
		}
	}

	function deletethislistrow(tableidname){
		$("#"+tableidname).parent("li").slideUp(200, function() {
			$(this).remove();
			calculaterowtotal('all');
		});
	}
	
// prevent multi times save

function funcSaveBill1()
{
	
	var varUserChoice; 
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet); 
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		document.frmsales.submit();
		//return true;
	}
}

function checkcontactform(){
		/*var labinvoice_mobile = document.getElementById("labinvoice_mobile");
		var error_labinvoice_mobile = document.getElementById("error_labinvoice_mobile");
		error_labinvoice_mobile.innerHTML = '';
		if(labinvoice_mobile.value==''){
			error_labinvoice_mobile.innerHTML = "Number is missing.";
			labinvoice_mobile.focus();
			return false;
		}
		else if(labinvoice_mobile.value.length<10){
			error_labinvoice_mobile.innerHTML = "Number should be 11 Digit.";
			labinvoice_mobile.focus();
			return false;
		}*/
		
		//return true;
		
		var labinvoice_totaldiscp = document.getElementById("labinvoice_totaldiscp");
		var error_labinvoice_totaldiscp = document.getElementById("error_labinvoice_totaldiscp");
		error_labinvoice_totaldiscp.innerHTML = '';
		if(labinvoice_totaldiscp.value==''){
			error_labinvoice_totaldiscp.innerHTML = "Disc is missing.";
			labinvoice_totaldiscp.focus();
			return false;
		}
		else if(labinvoice_totaldiscp.value>50){
			error_labinvoice_totaldiscp.innerHTML = "Disc should be less than 10%";
			labinvoice_totaldiscp.focus();
			return false;
		}
		
		//pc Discount 
		var labinvoice_totaldisc = document.getElementById("labinvoice_totaldisc");
		var error_labinvoice_totaldisc = document.getElementById("error_labinvoice_totaldisc");
		error_labinvoice_totaldisc.innerHTML = '';
		if(labinvoice_totaldisc.value==''){
			error_labinvoice_totaldisc.innerHTML = "Disc is missing.";
			labinvoice_totaldisc.focus();
			return false;
		}
		else if(labinvoice_totaldisc.value>1000){
			error_labinvoice_totaldisc.innerHTML = "Disc should be greater than 1000";
			labinvoice_totaldisc.focus();
			return false;
		}
		
		var labinvoice_totalpccomission = document.getElementById("labinvoice_totalpccomission");
		var error_labinvoice_totalpccomission = document.getElementById("error_labinvoice_totalpccomission");
		error_labinvoice_totalpccomission.innerHTML = '';
		if(labinvoice_totalpccomission.value==''){
			error_labinvoice_totalpccomission.innerHTML = "Disc is missing.";
			labinvoice_totalpccomission.focus();
			return false;
		}
		else if(labinvoice_totalpccomission.value<1){
			error_labinvoice_totalpccomission.innerHTML = "PC comission should be less than 1";
			labinvoice_totalpccomission.focus();
			return false;
		}
				
		return true;

	}
</script>
<article class="bottomcontent">
  <h3 align="center">Dental Invoice Entry</h3>
   <content>
        <?php
		 if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
            echo "<p class=\"red12bold\">You have missing Something</p>";
        }
        elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
            echo "<p class=\"red12bold\">Error occured! Could not insert.</p>";   
        }
        elseif(isset($_GET['message']) && $_GET['message']=='save-successfully'){
            echo "<p class=\"red12bold\">Information insert successfully. Click Print Button To Print or View Previous Bill <td width=\"30\" align=\"center\" >
			<a onclick=\"PrintDiv();\"><input type=\"button\" required value=\"Print\" class=\"tdclass\"  /></a></td></p>";   
        }
		
		if($invoic+1000>=$invoice){
	    ?>          
<form action="save_dentalinvoice.php" name="frmcontact" onsubmit="return checkcontactform();" onsubmit="return checkcontactform2();"  method="post" >
<!--<table width="100%" border="0" bgcolor="#E94F32" cellpadding="1">-->
<table width="100%" border="0" bgcolor="#146F77" style="color:#FFF;" cellpadding="1" cellspacing="7">
      <input type="hidden" name="user" id="user" required value="<?php echo $_SESSION['fullname'];?>" class="tdclass" />
    <tr>
    <td align="right"><strong>Patient</strong>*</td>
    <td><input type="text" autofocus required name="labinvoice_patient" id="labinvoice_patient" size="15" />
    
    <td align="right">Age*</td>
    <td><input type="text" required name="labinvoice_age" id="labinvoice_age" size="7" />
    	<select id="age" name="age" >
		   <?php
            $doyouknowarray = array('', 'Day/s', 'Month/s', 'Year/s');
            foreach($doyouknowarray as $singleoption){
                $selected = '';
                if($section=="$singleoption"){$selected = ' selected="selected"';}
                echo "<option value=\"$singleoption\"$selected>$singleoption</option>";
                }
            ?>
        </select>
    </td>
   
      <td>Gender*</td>
         <td>
            <select required id="labinvoice_gender" name="labinvoice_gender" >
               <?php
                $doyouknowarray = array('', 'Female', 'Male', 'Others');
                foreach($doyouknowarray as $singleoption){
                    $selected = '';
                    if($section=="$singleoption"){$selected = ' selected="selected"';}
                    echo "<option value=\"$singleoption\"$selected>$singleoption</option>";
                	}
                ?>
            </select>
        </td>
    
    <td align="right"><strong>Doctor</strong> </td>
    <td><input type="text" size="20" placeholder="Search by Doctor" name="labinvoice_doctor" id="labinvoice_doctor"/></td>
    
   <td align="right"><strong>P.C</strong> </td>
   <td><input type="text" size="12" placeholder="search by PC" name="labinvoice_pc" id="labinvoice_pc"/>
   		<input type="hidden" size="4" name="doctor_id" id="doctor_id"/>
   </td>
  </tr>
  
  <table width="100%" border="0" bgcolor="#146F77" style="color:#FFF;" cellpadding="1" cellspacing="7">

  <tr>
   	<td align="right" bgcolor="#ccc" style="color:#00C"><strong>Patient ID</strong></td>
    <td><input type="hidden" size="15" name="labinvoice_patientcode" id="labinvoice_patientcode" />
    	<input type="text" size="7" name="labinvoice_patientid" id="labinvoice_patientid" />
    </td>
   
    <td align="right">Mobile*</td>
    <td><input type="text" size="9" name="labinvoice_mobile" id="labinvoice_mobile" /></td>
        <!--<span id="error_labinvoice_mobile" style="color:#F00"></span>-->
        <!--<span id="error_labinvoice_totaldiscp" style="color:#F00"></span>
        <span id="error_labinvoice_totaldisc" style="color:#F00"></span>
        <span id="error_labinvoice_totalpccomission" style="color:#F00"></span>-->
     <td align="right">Address</td>
	 <td><input type="text" name="labinvoice_address" id="labinvoice_address" size="14"/></td>
    <td align="right">Cabin </td>
    <td><input type="text" name="labinvoice_ward" id="labinvoice_ward" size="8"/></td>
     
     <!--<td align="right">Date </td>-->
     <input type="hidden" name="labinvoice_date" size="12" readonly id="labinvoice_date" value="<?php echo date('Y-m-d h:i:s');?>" />
     <td align="right">R.Delivery </td>
     <td><input type="text" name="labinvoice_deliverydate" id="labinvoice_deliverydate" value="<?php echo date('d-m-Y');?>" size="6"/>
     <input type="hidden" name="timecount" id="timecount" value="<?php echo $labinvoice_id;?>" size="10"/></td>
     
    <td align="right">M.P.O </td>
    <td><input type="text" size="12" name="labinvoice_mpo" id="labinvoice_mpo" /></td>
  </tr>
</table>
    <br />
        <div id="errmsg_particular_id"></div>
        <ul id="particularlist" class="ullistnone">
    	<li>
   		<table width="1000" style="BORDER-COLLAPSE: collapse; border:2px solid #FFF;" bgcolor="#c0d2ff" cellpadding="4">
          <tr>
            <td align="right">Test Name</td>
            <td> <input type="text" name="labinvoice_item[]" id="labinvoice_item" required class="tdclasss itemname labinvoice_item" autocomplete="off" />
            	 <input type="hidden" name="labitem_id[]" id="labitem_id" class="tdclass" />
            	 <input type="hidden" name="labinvoice_group[]" class="tdclass" />
                 <input type="hidden" name="labinvoice_category[]" class="tdclass" />
                 <input type="hidden" name="category[]" class="tdclass" />
                 <input type="hidden" name="note[]" class="tdclass" />
                 <input type="hidden" name="orderby[]" class="tdclass" />
        	     <input type="hidden" name="reportname[]" class="tdclass" />
                 <input type="hidden" name="labinvoice_sample[]" class="tdclass" />
                 <input type="hidden" name="machine_name[]" class="tdclass" />
                 <input type="hidden" name="labinvoice_unit[]" class="tdclass" />
                 <input type="hidden" name="labinvoice_refvalue[]" class="tdclass" />
          	</td>
             <!--<td align="right">Stock</td>-->
             <input type="hidden" name="labinvoice_reagent[]" id="labinvoice_reagent" class="tdclasssale numeric" onKeyUp="calculaterowtotal('all');" />

             <td align="right">Rate</td>
             <td><input type="text" required name="labinvoice_rate[]" id="labinvoice_rate" class="tdclasssale numeric" onKeyUp="calculaterowtotal('all');" /></td>

             <!--<td align="right">Qty</td>-->
			 <input type="hidden" name="labinvoice_qty[]" id="labinvoice_qty" class="tdclasssale numeric" onKeyUp="calculaterowtotal('all');" />

             <td align="right">Disc%</td>
             <td><input type="text" name="labinvoice_discountp[]" id="labinvoice_discountp" class="tdclasssale numeric" onKeyUp="calculate_discountp();" /></td>

             <td align="right">Disc</td>
             <td><input type="text" name="labinvoice_disc[]" id="labinvoice_disc" class="tdclasssale numeric" onKeyUp="calculaterowtotal('all');" /></td>

             <td align="right">P.C</td>
             <td><input type="text"  name="labinvoice_pccomission[]" id="labinvoice_pccomission" class="tdclasssale numeric" onKeyUp="calculate_pctotal();" /></td>
             <!-- <td align="right">Dr.</td>-->
             <td><input type="hidden" name="labinvoice_drcomission[]" id="labinvoice_drcomission" class="tdclasssale numeric" onKeyUp="calculate_drtotal();" /></td>

             <td align="right">Total</td>
             <td><input type="text" readonly name="labinvoice_total[]" id="labinvoice_total" class="tdclasssale" /></td>
            
             <td><input type="button" value="Add" onClick="addnew_particularrow(true)" class="tdclasssale" /></td>
          </tr>
     </table>
    </li>
   </ul>
  <br />
  
<table  border="0" width="1000" cellpadding="2" style=" margin-top:20px;" bgcolor="#F3F3F3">
  <tr>
    <td align="right">Note  </td>
    <td><textarea type="text" name="labinvoice_description" id="labinvoice_description" class="tdclass" /></textarea></td>
  	<td align="right">Dues Holder </td>
    <td><textarea type="text" name="labinvoice_duesholder" id="labinvoice_duesholder" class="tdclass" /></textarea></td>
   
    <td align="right">P.C Due </td>
    <td><input type="text" readonly size="6" name="previous_labinvoice_totalpccomission" id="previous_labinvoice_totalpccomission"/></td>
    
    <td align="right">P.C Total </td>
    <td><input type="text" size="6" name="labinvoice_totalpccomission" id="labinvoice_totalpccomission"  onKeyUp="calculate_total();" /></td>
    <td><input type="text" size="6" name="labinvoice_totalpccomission_percent" id="labinvoice_totalpccomission_percent" onKeyUp="calculate_total();" /> %</td>
    <td align="right">Dr. Total </td>
    <td><input type="text" name="labinvoice_totaldrcomission" id="labinvoice_totaldrcomission" size="8" onKeyUp="calculate_total();" /></td>
    
    <td><input type="hidden" name="previous_pc_comission" id="previous_pc_comission"size="8" /></td> 
 </tr>
</table>
	
 <table border="0" width="1000" style="padding-left:300px; margin-top:10px;" bgcolor="#ccc" cellpadding="2">
    <tr>
        <td align="right" style="border-top:1px solid #999;"><strong>Previous Due</strong>: </td>
        <td width="50" style="border-top:1px solid #999;"> 
        <input type="text" readonly name="labinvoice_previousdue" id="labinvoice_previousdue" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
        
        <td align="right"><strong>Total Receivable Amount</strong>: </td>
        <td><input type="text" required readonly name="labinvoice_subtotalafterdisc" id="labinvoice_subtotalafterdisc"  class="tdclass numeric" onKeyUp="calculate_total();" /></td>
    </tr>
    
    <tr>
        <td align="right">Sub Total: </td>
        <td><input type="text" readonly name="labinvoice_subtotal" id="labinvoice_subtotal" class="tdclass" /></td>
        
        <td align="right"><strong style="color: #C11114">Received Amount</strong>: </td>
        <td><input type="text" name="labinvoice_receiveamount" id="labinvoice_receiveamount" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
    </tr>
    
    <tr>
        <td align="right">Discount % : </td>
        <td><input type="text" name="labinvoice_totaldiscp" id="labinvoice_totaldiscp" value="0" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
        
        <td align="right">Dues Amount: </td>
        <td><input type="text" readonly name="labinvoice_due" id="labinvoice_due" class="tdclass" /></td>
    </tr>
    
     <tr>
         <td align="right">Discount (General): </td>
         <td><input type="text" name="labinvoice_totaldisc" id="labinvoice_totaldisc" value="0" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
         <td align="right">Cash Given By patient: </td>
         <td><input type="text" name="cashgiven" id="cashgiven" class="tdclass" /></td>
    </tr>
   
    <tr>
        <td align="right">VAT %: </td>
        <td><input type="text" class="tdclass" />  </td>
        
        <td align="right">Cash To Be Returned To Patient: </td>
        <td><input type="text" readonly name="cashreturn" id="cashreturn" class="tdclass"  />  </td>
     </tr>
    <!--<tr>
     <td align="right">Discount (BOTH): </td>
     <td><input type="text" name="labinvoice_totaldisc2" id="labinvoice_totaldisc2" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
    </tr>-->
    
    <!--<tr> 
        <td colspan="3"></td>
        <td><input type="reset" name="patient" id="patient" value="Cancel" class="tdclass1"/></td>
  	</tr>-->
   
   <tr>
       <td colspan="1"></td><td><input type="reset" name="patient" id="patient" value="Cancel" class="tdclass1"/></td>
       <td align="center" bgcolor="#F3F3F3" style="font-size:20px" id="tdShowTotalAmount1">0.00</td>
       <td>
   
       <input type="hidden" name="labinvoice_id" id="labinvoice_id" value="<?php echo $labinvoice_id;?>">
       <input type="submit" onClick="return funcSaveBill1()" value=" Save " name="submit_invoice" id="submit_invoice" class="tdclass1" />
       </td>
   </tr>

</table>
</form>         
<?php
		}
 		else
		{
		  //echo '<p style="color:#F00;font-size:20px;">Please Contant To 01757827474 or 01795909185 For Update your server.</p>';
		}
		
		if($invoic+1000-$invoice<1000){
			echo '<p style="color:#F00;font-size:15px;">Please contact to Beta Software(01757 827474 / 01795 909185) soon.
			Server should be updated otherwise software will be locked after ';
			 echo $invoic+1000-$invoice; echo ' invoice.'; '</p>';
		}
		else {
 			//echo 3;
		}
    ?> 
</content>
</article>

<div id="divToPrint" style="display:none;">
<script type="text/javascript" language="javascript">
		function printBarcode(barCode, company_name, product_name, pricestr){
			var URL = 'barcodePrint.php?barCode='+barCode;
			var day = new Date();
			var id = day.getTime();
			var w = 500;
			var h = 400;
			var scrl = 1;
			var winl = (screen.width - w) / 2;
			var wint = (screen.height - h) / 2;
			winprops = 'height='+h+',width='+w+',top='+wint+',left='+winl+',scrollbars='+scrl+',toolbar=0,location=0,statusbar=0,menubar=0,resizable=0';
			eval("page" + id + " = window.open(URL, '" + id + "', winprops);");
		}
	</script>
<article class="bottomcontent" style="font-family:Tahoma; margin:0 auto;">
  	<?php
		$labinvoice_id = $_GET['labinvoice_id'];
        $labinvoice_sql = "select * from dentalinvoice where labinvoice_id = $labinvoice_id order by labinvoice_id desc";
        $labinvoicequery = mysqli_query($conn, $labinvoice_sql);
        if($labinvoicequery && mysqli_num_rows($labinvoicequery)>0){
            while ($onerow = mysqli_fetch_array($labinvoicequery)){
               	$labinvoice_id = $onerow['labinvoice_id'];
                $labinvoice_patientid = $onerow['labinvoice_patientid'];
                $labinvoice_patientcode = $onerow['labinvoice_patientcode'];
               	$labinvoice_patient = $onerow['labinvoice_patient'];
                $labinvoice_age = $onerow['labinvoice_age'];
                $labinvoice_gender = $onerow['labinvoice_gender'];
                $labinvoice_address = $onerow['labinvoice_address'];
                $labinvoice_doctor = $onerow['labinvoice_doctor'];
                $labinvoice_pc = $onerow['labinvoice_pc'];
				$labinvoice_ward = $onerow['labinvoice_ward'];
				$user = $onerow['user'];		
                $age = $onerow['age'];		
                $labinvoice_totalpccomission = $onerow['labinvoice_totalpccomission'];
                $labinvoice_subtotal = $onerow['labinvoice_subtotal'];
                $labinvoice_totaldiscp = $onerow['labinvoice_totaldiscp'];
                $labinvoice_totaldisc = $onerow['labinvoice_totaldisc'];
                $labinvoice_subtotalafterdisc = $onerow['labinvoice_subtotalafterdisc'];
                $labinvoice_receiveamount = $onerow['labinvoice_receiveamount'];
                $labinvoice_due = $onerow['labinvoice_due'];
                $labinvoice_description = $onerow['labinvoice_description'];
				$labinvoice_mobile = $onerow['labinvoice_mobile'];
                $labinvoice_date=	$onerow['labinvoice_date'];
				$labinvoice_deliverydate=	$onerow['labinvoice_deliverydate'];
			    ?>
                
              <?php if($heading=='Yes'){ ?>
              <table align="center" width="<?php echo $printdata_mobile; ?>" style=" border-bottom:1px dashed #999; padding:0 5px; font-size:13px;" bgcolor="#FFF" cellpadding="0">
                <tr>
                <?php
                if($hospitaldata_logo!=''){
					?>
                    <td width="65">
                    <div align="left" style="font-size:15px;">
                    <img  width="60" height="60" src="logo_images/<?php echo $hospitaldata_logo; ?>" /></div>
                   </td>
               <?php }?>
                <td width="320">
                    <div align="center" style="font-size:16px;"><b><?php echo $hospitaldata_name;?></b></div>
                    <div align="center"><?php echo $hospitaldata_address1;?></div>
                    <div align="center" style="font-size:13px;">Contact: <?php echo $hospitaldata_mobile;?></div>
                </td>
               </tr>
             </table>
             <?php } ?>
             <table width="<?php echo $printdata_mobile; ?>" align="center" style=" color:#000;border-bottom:1px dashed #999;
              <?php if($heading=='Yes'){ ?> margin-top:2px;<?php }?> <?php if($heading=='No'){ ?> margin-top:80px;<?php }?>" bgcolor="#FFF" cellpadding="0">
                <tr>
                    <td width="350" bgcolor="#f3f3f3">
                        <div align="center" style="font-size:15px;color:#000"><strong>DENTAL INVOICE</strong></div>
                    </td>
                 </tr>
             </table>  

            <table align="center" width="<?php echo $printdata_mobile; ?>" style=" border-bottom:1px dashed #999;font-size:13px; padding:2px 2px 0 2px; margin-top:6px" bgcolor="#FFF" cellpadding="0">
            	<tr>
                    <td>Invoice No.: <strong style="font-size:14px"><?php echo $labinvoice_id;?></strong></td>
                    <td align="right">Date: <?php echo date('d-m-Y h:i:s A');?></td>
				 </tr>
                 <tr>
                     <?php if($labinvoice_patientid>0){ ?><td><strong><?php echo 'Patient ID : '.$labinvoice_patientid;}?> </strong></td>
                     <?php if($labinvoice_ward!=''){ ?><td align="right"><strong><?php echo 'Cabin/Ward: '.$labinvoice_ward;}?></strong></td>
                </tr>
                <tr>
                    <td><strong>Patient: <?php echo $labinvoice_patient;?></strong></td>
                    <td align="right">Age: <?php echo $labinvoice_age;?> <?php echo $age;?></td>
                </tr>
                   
                 <tr>
                    <td>Mobile: <?php echo $labinvoice_mobile;?></td>
                    <td align="right">Gender: <?php echo $labinvoice_gender;?></td>
                    <!--<div align="left">Address : <?php //echo $labinvoice_address;?></div>-->
               </tr>
                 
             </table>
                         
            <table align="center" width="<?php echo $printdata_mobile; ?>" style=" border-bottom:1px dashed #999;font-size:13px; padding:0 8px 5px 0px;" bgcolor="#FFF" cellpadding="0">
            	<tr><td width="450"><strong>Ref by </strong>: <?php echo $labinvoice_doctor;?></td></tr>
            </table>
            
      		<table align="center" width="<?php echo $printdata_mobile; ?>" bgcolor="#FFF" style="padding:0 0 40px 0;font-size:13px;border-bottom:1px dashed #999;" cellspacing="0" cellpadding="0">
              <tr height="20" bgcolor="#f3f3f3">
                <td style="border-bottom:1px dashed #999;"><strong>SL</strong> </td>
                <td style="border-bottom:1px dashed #999;"><strong>Test Name</strong></td>
               <!-- <td style="border:1px solid #999; text-align:center;border-top:none;">Rate</td>-->
                <!-- <td style="border:1px solid #000; text-align:center;">Qty</td>-->
               <!-- <td style="border:1px solid #999; text-align:center;">Disc(%)</td>-->
                <td style="border:1px solid #999; text-align:center;border-top:none;">Less</td>
                <td style="border-bottom:1px dashed #999;" align="right"><strong>Total</strong></td>
              </tr>
                 
                <?php
				 $totalRate=0;
				 $totaldisc=0;
				
                $labinvoicedetails_sql = "select * from dentalinvoicedetails where labinvoice_id = $labinvoice_id order by auto_number asc";
                $labinvoicedetailsquery = mysqli_query($conn, $labinvoicedetails_sql);
                if($labinvoicedetailsquery && mysqli_num_rows($labinvoicedetailsquery)>0){
                    $i=0;
                    while($page_inforow = mysqli_fetch_array($labinvoicedetailsquery)){
                        $i++;
                        $auto_number = $page_inforow['auto_number'];
                        $labinvoicedetails_item = $page_inforow['labinvoicedetails_item'];
                        $labinvoicedetails_rate = $page_inforow['labinvoicedetails_rate'];
                        $labinvoicedetails_qty = $page_inforow['labinvoicedetails_qty'];
                        $labinvoicedetails_discountp = $page_inforow['labinvoicedetails_discountp'];
                        $labinvoicedetails_disc = $page_inforow['labinvoicedetails_disc'];
                        $labinvoicedetails_total = $page_inforow['labinvoicedetails_total'];
                      
					   $totalRate=$totalRate+$labinvoicedetails_rate;
					   $totaldisc=$totaldisc+$labinvoicedetails_disc;
					   
					    ?>
                        <tr>
                            <td style="text-align:left;"><?php echo $i;?></td>
                            <td style=" text-align:left;" width="270"> <?php echo $labinvoicedetails_item;?></td>
                            <?php /*?><td style=" text-align:center;"> <?php echo $labinvoicedetails_rate;?></td><?php */?>
                            <?php /*?> <td style="text-align:center;">  <?php echo $labinvoicedetails_discountp;?>%</td><?php */?>
                            <td style="text-align:center;"> <?php  echo number_format($labinvoicedetails_disc);?></td>
                            <td style="text-align:right;"> <?php echo $labinvoicedetails_total;?></td>
                          </tr>
                 
                        <?php
						}
					}
                ?>
               
            </table>
                    
            <table align="center" width="<?php echo $printdata_mobile; ?>" style="border-bottom:1px dashed #999; border-top:none;font-size:12px"  bgcolor="#FFFFFF" cellpadding="1">

               <?php /*?><?php if($labinvoicedetails_disc>0){?>
                
                <tr>
                 <td align="right" style=" width:500px">Gross Total : </td>
                 <td width="30" style="border:none" > <?php echo number_format($totalRate, 2, '.', '');?></td>
                </tr>
                
                <tr>
                 <td align="right" style=" width:500px">ItemWise Disc Total : </td>
                 <td width="30" style="border:none" > <?php echo number_format($totaldisc, 2, '.', '');?></td>
                </tr>
                <?php };?><?php */?>

                <tr>
                 <td align="right" style=" width:500px">Sub Total : </td>
                 <td width="30" style="border:none" > <?php echo $labinvoice_subtotal;?></td>
                </tr>
                 
                  <?php
                  if($labinvoice_totaldisc>0)
                  echo "<tr>
                 	<td align=\"right\">Discount : </td>
                	<td> $labinvoice_totaldisc</td>
                   </tr>";
                  ?>
                 <tr>
                 <td align="right"><strong>Net Payable Amount</strong> : </td>
                 <td><?php echo $labinvoice_subtotalafterdisc;?></td>
                </tr>
                
                <tr>
                 <td align="right" style="border-top: 1px solid #fff">Total paid Amount : </td>
                 <td><?php echo $labinvoice_receiveamount;?></td>
                </tr>
                <?php if($labinvoice_due>0)
                echo "<tr>
                 <td align=\"right\"><strong>Due Amount :</strong> </td>
                 <td><strong> $labinvoice_due</strong></td>
                </tr>";
                ?>
            </table>
                <?php
				}
			}
        	?>
         <table width="<?php echo $printdata_mobile; ?>" align="center" style="font-size:12px;">
        	<tr><td><?php include ("convert_currency_to_words.php");
			echo 'In-Words:'; echo covert_currency_to_words($labinvoice_receiveamount); ?></td></tr>
        </table>
		<?php if($labinvoice_description!='') {?>
        <table width="<?php echo $printdata_mobile; ?>" align="center" style=" border-bottom:1px dashed #999;border-top:none; font-size:12px; font-weight:bold; font-style:italic">
          <tr><td>Note: <?php echo $labinvoice_description; ?></td></tr>
        </table>
        <?php }?>
        <table align="center" width="<?php echo $printdata_mobile; ?>" style=" font-size:13px; padding:5px 2px" bgcolor="#FFF" cellpadding="0">
            <tr>
                <td width="350">
                    <div align="left">Prepared By: <?php echo $user; ?>  
                    <?php if($labinvoice_due>0){
                        echo "<strong style=\"font-size:22px; padding:0 3px; box-shadow: 0 -1px 3px; margin-left:15px; width:200px\" >Due </strong>";}

                     	else{ echo "<strong style=\"font-size:22px;box-shadow: 0 -1px 3px; margin-left:30px; width:50px\" >Paid </strong>";}
                       ?>
                    </div>
                </td>
                <td width="200">
                    <div style="padding-bottom:10px" align="right"></div>
                    <div align="right">Authorised Sign</div>
                </td>
             </tr>
        </table>
      
    <table align="center" width="<?php echo $printdata_mobile; ?>" border="0">
      <tr>
      	<td width="450" style="font-weight:500; font-size:13px;"><strong><?php echo $labroom_name; ?></strong></td>
      </tr>
    </table>
    
    <table align="center" width="<?php echo $printdata_mobile; ?>" border="0">
       <tr>
        <td style=" font-size:10px">Software by: Betasofts.com</td>
      </tr>
    </table>
  </article>
</div>