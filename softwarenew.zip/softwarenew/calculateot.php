<script language="JavaScript" type="text/javascript">
	
	var itemdata = <?php echo $itemdata;?>;
	var patientdata = <?php echo $patientdata;?>;
	var pcdata = <?php echo $pcdata;?>;
	//var cabin = <?php //echo $cabin;?>;
	$(document).ready(function($) {
		document.getElementsByName("hospitalinvoiceot_item[]")[0].focus();

		$( ".itemname" ).autocomplete({
			
			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				var hospitalinvoiceot_ratearray = document.getElementsByName("hospitalinvoiceot_rate[]");
				hospitalinvoiceot_ratearray[indexpos].value = ui.item.hospitalitem_price;
				
				var hospitalinvoiceot_qtyarray = document.getElementsByName("hospitalinvoiceot_qty[]");
				hospitalinvoiceot_qtyarray[indexpos].value = 1;
				
				
				
				
			var hospitalinvoiceot_surgeoncommissionarray = document.getElementsByName("hospitalinvoiceot_surgeoncommission[]");
			hospitalinvoiceot_surgeoncommissionarray[indexpos].value = ui.item.hospitalitem_surgeoncommission;
			
			var hospitalinvoiceot_cosurgeoncommissionarray = document.getElementsByName("hospitalinvoiceot_cosurgeoncommission[]");
			hospitalinvoiceot_cosurgeoncommissionarray[indexpos].value = ui.item.hospitalitem_cosurgeoncommission;
			
			var hospitalinvoiceot_anaesthesiacommissionarray = document.getElementsByName("hospitalinvoiceot_anaesthesiacommission[]");
			hospitalinvoiceot_anaesthesiacommissionarray[indexpos].value = ui.item.hospitalitem_anaesthesiacommission;
			
				
				
				
				var hospitalinvoiceot_pccomissionarray = document.getElementsByName("hospitalinvoiceot_pccomission[]");
				hospitalinvoiceot_pccomissionarray[indexpos].value = ui.item.hospitalitem_pccommission;
				
				var hospitalinvoiceot_categoryarray = document.getElementsByName("hospitalinvoiceot_category[]");
				hospitalinvoiceot_categoryarray[indexpos].value = ui.item.hospitalitem_category;
				
				var hospitalinvoiceot_unitarray = document.getElementsByName("hospitalinvoiceot_unit[]");
				hospitalinvoiceot_unitarray[indexpos].value = ui.item.hospitalitem_unit;
				
				var hospitalinvoiceot_refvaluearray = document.getElementsByName("hospitalinvoiceot_refvalue[]");
				hospitalinvoiceot_refvaluearray[indexpos].value = ui.item.hospitalitem_refvalue;
				
				calculaterowtotal(indexpos);
				calculate_pctotal();
				calculate_surgeontotal();
					calculate_cosurgeontotal();
					calculate_anaesthesiatotal();
				return false;
			}
		});
		
		
		$( "#hospitalinvoiceot_patientid" ).autocomplete({
			
			minLength: 1,
			source: patientdata,
			
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('hospitalinvoiceot_patient').value = ui.item.labelval;
				 document.getElementById('hospitalinvoiceot_patientid').value = ui.item.opregistration_id;
				 document.getElementById('hospitalinvoiceot_age').value = ui.item.opregistration_age;
				 document.getElementById('hospitalinvoiceot_pc').value = ui.item.pcname;
				 //document.getElementById('hospitalinvoiceot_ot_due').value = ui.item.ot_due;
				 document.getElementById('hospitalinvoiceot_cabin').value = ui.item.ward;
				 document.getElementById('hospitalinvoiceot_gender').value = ui.item.opregistration_gender;
				 document.getElementById('hospitalinvoiceot_mobile').value = ui.item.opregistration_mobile;
				 document.getElementById('hospitalinvoiceot_address').value = ui.item.opregistration_address;
				 document.getElementById('hospitalinvoiceot_admissiondate').value = ui.item.opregistration_date;
				
				return false;
			}
		});
		
		
		// pc search
		$( "#hospitalinvoiceot_pc" ).autocomplete({
			
			minLength: 1,
			source: pcdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('hospitalinvoiceot_pc').value = ui.item.labelval;
				 document.getElementById('hospitalinvoiceot_mpo').value = ui.item.mpo;
				
				return false;
			}
		});
		
		/*$( "#hospitalinvoiceot_patientid" ).autocomplete({
			
			minLength: 1,
			source: cabin,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('hospitalinvoiceot_ward').value = ui.item.labelval;
				
				return false;
			}
		});
		*/
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
	});
	function calculate_discountp(){
		var hospitalinvoiceot_discountparray = document.getElementsByName("hospitalinvoiceot_discountp[]");
		var hospitalinvoiceot_discarray = document.getElementsByName("hospitalinvoiceot_disc[]");
		var hospitalinvoiceot_ratearray = document.getElementsByName("hospitalinvoiceot_rate[]");
		var hospitalinvoiceot_qtyarray = document.getElementsByName("hospitalinvoiceot_qty[]");
		if(hospitalinvoiceot_discountparray.length>0){
			for(var p=0; p<hospitalinvoiceot_discountparray.length; p++){
				var hospitalinvoiceot_discountp = parseFloat(hospitalinvoiceot_discountparray[p].value);
				if(hospitalinvoiceot_discountp=='' || isNaN(hospitalinvoiceot_discountp)){hospitalinvoiceot_discountp = 0;}
				
				var hospitalinvoiceot_disc = parseFloat(hospitalinvoiceot_discarray[p].value);
				if(hospitalinvoiceot_disc=='' || isNaN(hospitalinvoiceot_disc)){hospitalinvoiceot_disc = 0;}
				if(hospitalinvoiceot_discountp>0){
					var hospitalinvoiceot_rate = parseFloat(hospitalinvoiceot_ratearray[p].value);
					if(hospitalinvoiceot_rate=='' || isNaN(hospitalinvoiceot_rate)){hospitalinvoiceot_rate = 0;}
					
					var hospitalinvoiceot_qty = hospitalinvoiceot_qtyarray[p].value;
					if(hospitalinvoiceot_qty=='' || isNaN(hospitalinvoiceot_qty)){hospitalinvoiceot_qty = 0;}
					
					var total = parseFloat(hospitalinvoiceot_rate*hospitalinvoiceot_qty);			
					var hospitalinvoiceot_disc = parseFloat(total*hospitalinvoiceot_discountp*0.01);
					
					hospitalinvoiceot_discarray[p].value = hospitalinvoiceot_disc.toFixed(2);
				}
				
				calculaterowtotal(p);
			}
		}
	}
	
	function calculaterowtotal(indexpos){
		if(indexpos=='all'){
			var hospitalinvoiceot_ratearray = document.getElementsByName("hospitalinvoiceot_rate[]");
			var hospitalinvoiceot_qtyarray = document.getElementsByName("hospitalinvoiceot_qty[]");
			var hospitalinvoiceot_discarray = document.getElementsByName("hospitalinvoiceot_disc[]");
			var hospitalinvoiceot_totalarray = document.getElementsByName("hospitalinvoiceot_total[]");
			
			if(hospitalinvoiceot_ratearray.length>0){
				for(var p=0; p<hospitalinvoiceot_ratearray.length; p++){
					var hospitalinvoiceot_rate = parseFloat(hospitalinvoiceot_ratearray[p].value);
					if(hospitalinvoiceot_rate=='' || isNaN(hospitalinvoiceot_rate)){hospitalinvoiceot_rate = 0;}
					
					var hospitalinvoiceot_qty = parseFloat(hospitalinvoiceot_qtyarray[p].value);
					if(hospitalinvoiceot_qty=='' || isNaN(hospitalinvoiceot_qty)){hospitalinvoiceot_qty = 0;}
					
					var total = parseFloat(hospitalinvoiceot_rate*hospitalinvoiceot_qty);
					
					var hospitalinvoiceot_disc = parseFloat(hospitalinvoiceot_discarray[p].value);
					if(hospitalinvoiceot_disc=='' || isNaN(hospitalinvoiceot_disc)){hospitalinvoiceot_disc = 0;}
					
					var total = parseFloat(total-hospitalinvoiceot_disc);
					
					hospitalinvoiceot_totalarray[p].value = total.toFixed(2);
				}
			}
			
		}
		else{
			var hospitalinvoiceot_ratearray = document.getElementsByName("hospitalinvoiceot_rate[]");
			var hospitalinvoiceot_rate = parseFloat(hospitalinvoiceot_ratearray[indexpos].value);
			if(hospitalinvoiceot_rate=='' || isNaN(hospitalinvoiceot_rate)){hospitalinvoiceot_rate = 0;}
			
			var hospitalinvoiceot_qtyarray = document.getElementsByName("hospitalinvoiceot_qty[]");
			var hospitalinvoiceot_qty = parseFloat(hospitalinvoiceot_qtyarray[indexpos].value);
			if(hospitalinvoiceot_qty=='' || isNaN(hospitalinvoiceot_qty)){hospitalinvoiceot_qty = 0;}
			
			var total = parseFloat(hospitalinvoiceot_rate*hospitalinvoiceot_qty);
			
			var hospitalinvoiceot_discarray = document.getElementsByName("hospitalinvoiceot_disc[]");
			var hospitalinvoiceot_disc = parseFloat(hospitalinvoiceot_discarray[indexpos].value);
			if(hospitalinvoiceot_disc=='' || isNaN(hospitalinvoiceot_disc)){hospitalinvoiceot_disc = 0;}
			
			var total = parseFloat(total-hospitalinvoiceot_disc);
			
			var hospitalinvoiceot_totalarray = document.getElementsByName("hospitalinvoiceot_total[]");
			hospitalinvoiceot_totalarray[indexpos].value = total.toFixed(2);
		}
		
		calculate_total();
	}
	
	function calculate_total(){
		//var hospitalinvoiceot_ot_due = parseFloat(document.getElementById("hospitalinvoiceot_ot_due").value);
		//if(hospitalinvoiceot_ot_due=='' || isNaN(hospitalinvoiceot_ot_due)){hospitalinvoiceot_ot_due = 0;}
		
		
		var hospitalinvoiceot_subtotal = 0;
		var hospitalinvoiceot_totalarray = document.getElementsByName("hospitalinvoiceot_total[]");
		if(hospitalinvoiceot_totalarray.length>0){
			for(var p=0; p<hospitalinvoiceot_totalarray.length; p++){
				var hospitalinvoiceot_total = parseFloat(hospitalinvoiceot_totalarray[p].value);
				if(hospitalinvoiceot_total=='' || isNaN(hospitalinvoiceot_total)){hospitalinvoiceot_total = 0;}
				hospitalinvoiceot_subtotal = parseFloat(hospitalinvoiceot_subtotal+hospitalinvoiceot_total);
			}
		}
		//subtotal calculation
		document.getElementById("hospitalinvoiceot_subtotal").value = (hospitalinvoiceot_subtotal).toFixed(2);
		
		var hospitalinvoiceot_totaldiscp = parseFloat(document.getElementById("hospitalinvoiceot_totaldiscp").value);
		if(hospitalinvoiceot_totaldiscp=='' || isNaN(hospitalinvoiceot_totaldiscp)){hospitalinvoiceot_totaldiscp = 0;}
		
		var hospitalinvoiceot_totaldisc = parseFloat(document.getElementById("hospitalinvoiceot_totaldisc").value);
		if(hospitalinvoiceot_totaldisc=='' || isNaN(hospitalinvoiceot_totaldisc)){hospitalinvoiceot_totaldisc = 0;}
		
		//var hospitalinvoiceot_ot_due = parseFloat(document.getElementById("hospitalinvoiceot_ot_due").value);
		//if(hospitalinvoiceot_ot_due=='' || isNaN(hospitalinvoiceot_ot_due)){hospitalinvoiceot_ot_due = 0;}
		
		
		
		if(hospitalinvoiceot_totaldiscp>0){
			var hospitalinvoiceot_totaldisc = parseFloat(hospitalinvoiceot_subtotal*hospitalinvoiceot_totaldiscp*0.01);
			document.getElementById('hospitalinvoiceot_totaldisc').value= hospitalinvoiceot_totaldisc.toFixed(2);
		}
		
		var service = parseFloat((hospitalinvoiceot_subtotal)*0.00);
		document.getElementById('service').value=	service.toFixed(2);
		
		//var gross = parseFloat(hospitalinvoiceot_ot_due+hospitalinvoiceot_subtotal + service);
		//document.getElementById('gross').value=	gross.toFixed(2);
		
		var gross = parseFloat(hospitalinvoiceot_subtotal + service);
		document.getElementById('gross').value=	gross.toFixed(2);
		
		
		//var hospitalinvoiceot_subtotalafterdisc = parseFloat(hospitalinvoiceot_ot_due+hospitalinvoiceot_subtotal + service-hospitalinvoiceot_totaldisc);
		//document.getElementById('hospitalinvoiceot_subtotalafterdisc').value=	hospitalinvoiceot_subtotalafterdisc.toFixed(2);
		
		var hospitalinvoiceot_subtotalafterdisc = parseFloat(hospitalinvoiceot_subtotal + service-hospitalinvoiceot_totaldisc);
		document.getElementById('hospitalinvoiceot_subtotalafterdisc').value=	hospitalinvoiceot_subtotalafterdisc.toFixed(2);
			
		var hospitalinvoiceot_receiveamount = parseFloat(document.getElementById("hospitalinvoiceot_receiveamount").value);
		if(hospitalinvoiceot_receiveamount=='' || isNaN(hospitalinvoiceot_receiveamount)){hospitalinvoiceot_receiveamount = 0;}
		
		var hospitalinvoiceot_due = parseFloat(hospitalinvoiceot_subtotalafterdisc-hospitalinvoiceot_receiveamount);
		document.getElementById('hospitalinvoiceot_due').value=hospitalinvoiceot_due.toFixed(2);		
		
	}
	
	function calculate_pctotal(){
		var hospitalinvoiceot_totalpccomission = 0;
		var hospitalinvoiceot_pccomissionarray = document.getElementsByName("hospitalinvoiceot_pccomission[]");
		if(hospitalinvoiceot_pccomissionarray.length>0){
			for(var p=0; p<hospitalinvoiceot_pccomissionarray.length; p++){
				var hospitalinvoiceot_pccomission = parseFloat(hospitalinvoiceot_pccomissionarray[p].value);
				if(hospitalinvoiceot_pccomission=='' || isNaN(hospitalinvoiceot_pccomission)){hospitalinvoiceot_pccomission = 0;}
				hospitalinvoiceot_totalpccomission = parseFloat(hospitalinvoiceot_totalpccomission+hospitalinvoiceot_pccomission);
			}
		}
		
		document.getElementById("hospitalinvoiceot_totalpccomission").value = hospitalinvoiceot_totalpccomission.toFixed(2);
		
	}
	


	

function calculate_surgeontotal(){
	var hospitalinvoiceot_totalsurgeoncomission = 0;
	var hospitalinvoiceot_surgeoncommissionarray = document.getElementsByName("hospitalinvoiceot_surgeoncommission[]");
	if(hospitalinvoiceot_surgeoncommissionarray.length>0){
		for(var p=0; p<hospitalinvoiceot_surgeoncommissionarray.length; p++){
			var hospitalinvoiceot_surgeoncommission = parseFloat(hospitalinvoiceot_surgeoncommissionarray[p].value);
			if(hospitalinvoiceot_surgeoncommission=='' || isNaN(hospitalinvoiceot_surgeoncommission)){hospitalinvoiceot_surgeoncommission = 0;}
		hospitalinvoiceot_totalsurgeoncomission = parseFloat(hospitalinvoiceot_totalsurgeoncomission+hospitalinvoiceot_surgeoncommission);
		}
	}
	document.getElementById("hospitalinvoiceot_totalsurgeoncomission").value = hospitalinvoiceot_totalsurgeoncomission.toFixed(2);
	}
	
	
	function calculate_cosurgeontotal(){
		var hospitalinvoiceot_totalcosurgeoncomission = 0;
		var hospitalinvoiceot_cosurgeoncommissionarray = document.getElementsByName("hospitalinvoiceot_cosurgeoncommission[]");
		if(hospitalinvoiceot_cosurgeoncommissionarray.length>0){
			for(var p=0; p<hospitalinvoiceot_cosurgeoncommissionarray.length; p++){
				var hospitalinvoiceot_cosurgeoncommission = parseFloat(hospitalinvoiceot_cosurgeoncommissionarray[p].value);
				if(hospitalinvoiceot_cosurgeoncommission=='' || isNaN(hospitalinvoiceot_cosurgeoncommission)){hospitalinvoiceot_cosurgeoncommission = 0;}
				hospitalinvoiceot_totalcosurgeoncomission = parseFloat(hospitalinvoiceot_totalcosurgeoncomission+hospitalinvoiceot_cosurgeoncommission);
			}
		}
		document.getElementById("hospitalinvoiceot_totalcosurgeoncomission").value = hospitalinvoiceot_totalcosurgeoncomission.toFixed(2);
	}		
	
	
	function calculate_anaesthesiatotal(){
		var hospitalinvoiceot_totalanaesthesiacomission = 0;
		var hospitalinvoiceot_anaesthesiacommissionarray = document.getElementsByName("hospitalinvoiceot_anaesthesiacommission[]");
		if(hospitalinvoiceot_anaesthesiacommissionarray.length>0){
			for(var p=0; p<hospitalinvoiceot_anaesthesiacommissionarray.length; p++){
				var hospitalinvoiceot_anaesthesiacommission = parseFloat(hospitalinvoiceot_anaesthesiacommissionarray[p].value);
				if(hospitalinvoiceot_anaesthesiacommission=='' || isNaN(hospitalinvoiceot_anaesthesiacommission)){hospitalinvoiceot_anaesthesiacommission = 0;}
				hospitalinvoiceot_totalanaesthesiacomission = parseFloat(hospitalinvoiceot_totalanaesthesiacomission+hospitalinvoiceot_anaesthesiacommission);
			}
		}
		
		document.getElementById("hospitalinvoiceot_totalanaesthesiacomission").value = hospitalinvoiceot_totalanaesthesiacomission.toFixed(2);
		
	}
	
		
	
	function check_particular(){
		/*var particular_idlistarray = new Array();
		var particular_id = document.getElementsByName('particular_id[]');
		var particular_count = particular_id.length;
		var particular_priceid = document.getElementsByName('particular_price[]');
		var particular_qtyid = document.getElementsByName('particular_qty[]');
			
		var error_messageid = document.getElementById('errmsg_particular_id');
		error_messageid.innerHTML = '';
		
		for(i = 0; i < particular_count; i++) {
												
			if(particular_id[i].value=='' || particular_id[i].value==0){
				error_messageid.innerHTML = 'Missing Particular Name '+parseInt(i+1);
				particular_id[i].focus();
				returnvalue = false;
			}
			
			if(particular_idlistarray.length>0 && particular_idlistarray.indexOf(particular_id[i].value) != -1){
				error_messageid.innerHTML = 'Dupplicate Particular Name '+i;
				particular_id[i].focus();
				return false;
			}
			else{
				particular_idlistarray[i] = particular_id[i].value;
			}
			
			var particular_priceval = parseInt(particular_priceid[i].value);
			if(isNaN(particular_priceval) || particular_priceval==''){particular_priceval = 0;}
			if(particular_priceval==0){
				error_messageid.innerHTML = 'Missing Price '+Math.floor(i+1);
				particular_priceid[i].focus();
				return false;
			}
										
			var particular_qtyval = parseInt(particular_qtyid[i].value);
			if(isNaN(particular_qtyval) || particular_qtyval==''){particular_qtyval = 0;}							
			if(particular_qtyval==0){
				error_messageid.innerHTML = 'Missing QTY '+Math.floor(i+1);
				particular_qtyid.focus();
				return false;
			}
		}*/
		return true;
	}
	function addnew_particularrow(animate) {
		if(check_particular()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" style=\"BORDER-COLLAPSE: collapse; border:2px solid #FFF\" bgcolor=\"#77F7AA\" align=\"left\" width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"2\">"+
							'<tr>'+
								'<td align="right">Particular</td>'+
								'<td> <input type="text" name="hospitalinvoiceot_item[]" value="" class="tdclass itemname"/></td>'+
								 '<input type="hidden" name="auto_number[]" value=""/>'+ 
								 '<input type="hidden" name="hospitalinvoiceot_category[]" value="" class="tdclass"  />'+
								'<input type="hidden" name="hospitalinvoiceot_unit[]" value="" class="tdclass"  />'+
								'<input type="hidden" name="hospitalinvoiceot_refvalue[]" value="" class="tdclass"  />'+
								'<td align="right">Charge</td>'+
								"<td> <input type=\"text\" name=\"hospitalinvoiceot_rate[]\"  id=\"hospitalinvoiceot_rate\" value=\"\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/></td>"+											 
								'<td align="right">Qty</td>'+
								"<td> <input type=\"text\" name=\"hospitalinvoiceot_qty[]\"   id=\"hospitalinvoiceot_qty\" value=\"\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/></td>"+
								'<!--<td align="right">Disc%</td>-->'+
								'<td> <input type="hidden" name="hospitalinvoiceot_discountp[]" value="" class="tdclasssale" onKeyUp="calculate_discountp();"/></td>'+
								'<!--<td align="right">Disc</td>-->'+
								"<td> <input type=\"hidden\" name=\"hospitalinvoiceot_disc[]\" value=\"\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\" /></td>"+
								
								
								
							'<td align="right">Surgeon</td>'+
							"<td> <input type=\"text\" name=\"hospitalinvoiceot_surgeoncommission[]\" id=\"hospitalinvoiceot_surgeoncommission\"  class=\"tdclasssale\" /></td>"+
							
							'<td align="right">Assist</td>'+
							"<td><input type=\"text\" name=\"hospitalinvoiceot_cosurgeoncommission[]\" id=\"hospitalinvoiceot_cosurgeoncommission\" class=\"tdclasssale\" /></td>"+
							
							'<td align="right">Anaesthesist</td>'+
							"<td> <input type=\"text\" name=\"hospitalinvoiceot_anaesthesiacommission[]\" id=\"hospitalinvoiceot_anaesthesiacommission\" class=\"tdclasssale\" /></td>"+
								
								
								
								
								'<!--<td align="right">P.C</td>-->'+
								'<td> <input type="hidden" name="hospitalinvoiceot_pccomission[]" value="" class="tdclasssale" onKeyUp="calculate_pctotal();"  /></td>'+
								'<td align="right">Total</td>'+
								'<td> <input type="text" readonly name="hospitalinvoiceot_total[]"  id="hospitalinvoiceot_total" value="" class="tdclasssale"  /></td>'+												
								'<td>'+
								 "<input type=\"button\" value=\"Cancel\" onClick=\"deletethislistrow('particularlistrowno"+particular_rowcount+"');\" class=\"tdclasssale\"  />"+
								'</td>'+
							  '</tr>'+
						"</table>";
						
			var $newparticularlist = $("<li></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(200); 
			else 
			   $newparticularlist.show();   
			document.getElementsByName("hospitalinvoiceot_item[]")[parseInt(particular_rowcount-1)].focus();
			
			$( ".itemname" ).autocomplete({			
				minLength: 1,
				source: itemdata,
				focus: function( event, ui ) {
					//$( "#search_item_number" ).val( ui.item.labelval );
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					
					var hospitalinvoiceot_ratearray = document.getElementsByName("hospitalinvoiceot_rate[]");
					hospitalinvoiceot_ratearray[indexpos].value = ui.item.hospitalitem_price;
					
					var hospitalinvoiceot_qtyarray = document.getElementsByName("hospitalinvoiceot_qty[]");
					hospitalinvoiceot_qtyarray[indexpos].value = 1;
					
					
			var hospitalinvoiceot_surgeoncommissionarray = document.getElementsByName("hospitalinvoiceot_surgeoncommission[]");
			hospitalinvoiceot_surgeoncommissionarray[indexpos].value = ui.item.hospitalitem_surgeoncommission;
			
			var hospitalinvoiceot_cosurgeoncommissionarray = document.getElementsByName("hospitalinvoiceot_cosurgeoncommission[]");
			hospitalinvoiceot_cosurgeoncommissionarray[indexpos].value = ui.item.hospitalitem_cosurgeoncommission;
			
			var hospitalinvoiceot_anaesthesiacommissionarray = document.getElementsByName("hospitalinvoiceot_anaesthesiacommission[]");
			hospitalinvoiceot_anaesthesiacommissionarray[indexpos].value = ui.item.hospitalitem_anaesthesiacommission;
			
			
			
					var hospitalinvoiceot_pccomissionarray = document.getElementsByName("hospitalinvoiceot_pccomission[]");
					hospitalinvoiceot_pccomissionarray[indexpos].value = ui.item.hospitalitem_pccommission;
					
					var hospitalinvoiceot_categoryarray = document.getElementsByName("hospitalinvoiceot_category[]");
					hospitalinvoiceot_categoryarray[indexpos].value = ui.item.hospitalitem_category;
					
					var hospitalinvoiceot_unitarray = document.getElementsByName("hospitalinvoiceot_unit[]");
					hospitalinvoiceot_unitarray[indexpos].value = ui.item.hospitalitem_unit;
					
					var hospitalinvoiceot_refvaluearray = document.getElementsByName("hospitalinvoiceot_refvalue[]");
					hospitalinvoiceot_refvaluearray[indexpos].value = ui.item.hospitalitem_refvalue;
				
	
					calculaterowtotal(indexpos);
					calculate_pctotal();
					calculate_surgeontotal();
					calculate_cosurgeontotal();
					calculate_anaesthesiatotal();
					
					return false;
				}
			});						
		}
	}
	
	function deletethislistrow(tableidname){
		$("#"+tableidname).parent("li").slideUp(200, function() {
			$(this).remove();
			calculaterowtotal('all');
		});
	}

function funcSaveBill1()
{
	
	var varUserChoice; 
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet); 
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		document.frmsales.submit();
		//return true;
	}
}	
	
</script>