<script language="JavaScript" type="text/javascript">
	
	var itemdata = <?php echo $itemdata;?>;
	var patientdata = <?php echo $patientdata;?>;
	$(document).ready(function($) {
		document.getElementsByName("purchaseinvoice_item[]")[0].focus();

		$( ".itemname" ).autocomplete({
			
			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.saleselval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				document.getElementsByName("salesitem_id[]")[indexpos].value = ui.item.salesitem_id;
				document.getElementsByName("purchaseinvoice_purchase_rate[]")[indexpos].value = ui.item.salesitem_purchase_rate;
				document.getElementsByName("purchaseinvoice_rate[]")[indexpos].value = ui.item.salesitem_price;				
				document.getElementsByName("purchaseitem_pack[]")[indexpos].value =ui.item.salesitem_pack;
				document.getElementsByName("purchaseinvoice_qty[]")[indexpos].value = 1;					
				document.getElementsByName("purchaseinvoice_category[]")[indexpos].value = ui.item.salesitem_category;
				document.getElementsByName("purchaseinvoice_stock[]")[indexpos].value = ui.item.salesitem_stock;
				
				calculateCurrentRowTotal(indexpos);
				
				return false;
			}
		});
		
		
		$( "#purchaseinvoice_patient" ).autocomplete({
			
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.saleselval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('purchaseinvoice_patientid').value = ui.item.labelval;
				 document.getElementById('purchaseinvoice_previousdue').value = ui.item.company_due;
				document.getElementById('purchaseinvoice_mobile').value = ui.item.company_mobile;
				 document.getElementById('purchaseinvoice_address').value = ui.item.company_address;
				
				return false;
			}
		});
		
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
		$( ".sirow input.ccrt" ).keyup(function() {
			var index = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
			calculateCurrentRowTotal(index);
		});
	});
	
	function calculateCurrentRowTotal(index){
		
		var purchaseinvoice_purchase_rate = parseFloat(document.getElementsByName("purchaseinvoice_purchase_rate[]")[index].value);
		if(purchaseinvoice_purchase_rate=='' || isNaN(purchaseinvoice_purchase_rate)){purchaseinvoice_purchase_rate = 0.00;}
		
		var purchaseitem_pack = parseFloat(document.getElementsByName("purchaseitem_pack[]")[index].value);
		if(purchaseitem_pack=='' || isNaN(purchaseitem_pack)){purchaseitem_pack = 0.00;}
		
		var purchaseinvoice_pqty = parseFloat(document.getElementsByName("purchaseinvoice_pqty[]")[index].value);
		if(purchaseinvoice_pqty=='' || isNaN(purchaseinvoice_pqty)){purchaseinvoice_pqty = 0.00;}
		
		if(purchaseitem_pack==0 || purchaseinvoice_pqty==0){
			var purchaseinvoice_qty = parseFloat(document.getElementsByName("purchaseinvoice_qty[]")[index].value);
			if(purchaseinvoice_qty=='' || isNaN(purchaseinvoice_qty)){purchaseinvoice_qty = 0.00;}
		}
		else{
			var purchaseinvoice_qty = parseFloat(purchaseitem_pack*purchaseinvoice_pqty);
			if(purchaseinvoice_qty=='' || isNaN(purchaseinvoice_qty)){purchaseinvoice_qty = 0.00;}
			document.getElementsByName("purchaseinvoice_qty[]")[index].value = purchaseinvoice_qty.toFixed(2);
		}
		
		var qtyPrice = parseFloat(purchaseinvoice_purchase_rate*purchaseinvoice_qty);
		
		var purchaseinvoice_discountp = parseFloat(document.getElementsByName("purchaseinvoice_discountp[]")[index].value);
		if(purchaseinvoice_discountp=='' || isNaN(purchaseinvoice_discountp)){purchaseinvoice_discountp = 0.00;}
		if(purchaseinvoice_discountp==0){
			var purchaseinvoice_disc = parseFloat(document.getElementsByName("purchaseinvoice_disc[]")[index].value);
			if(purchaseinvoice_disc=='' || isNaN(purchaseinvoice_disc)){purchaseinvoice_disc = 0.00;}
		}
		else{
			var purchaseinvoice_disc = parseFloat(qtyPrice*purchaseinvoice_discountp*0.01);	
			document.getElementsByName("purchaseinvoice_disc[]")[index].value = purchaseinvoice_disc.toFixed(2);
		}
		
		document.getElementsByName("purchaseinvoice_total[]")[index].value = parseFloat(qtyPrice-purchaseinvoice_disc).toFixed(2);
	
		calculateGrandTotal();
	}
	
	function calculateGrandTotal(){
		var purchaseinvoice_totalarray = document.getElementsByName("purchaseinvoice_total[]");
		var purchaseinvoice_subtotal = 0.00;
		for(var r=0; r<purchaseinvoice_totalarray.length; r++){
			var purchaseinvoice_total = parseFloat(purchaseinvoice_totalarray[r].value);
			if(purchaseinvoice_total=='' || isNaN(purchaseinvoice_total)){purchaseinvoice_total = 0.00;}
			purchaseinvoice_subtotal = parseFloat(purchaseinvoice_subtotal+purchaseinvoice_total);
		}
		
		document.getElementById("purchaseinvoice_subtotal").value = purchaseinvoice_subtotal.toFixed(2);
		
		var purchaseinvoice_totaldiscp = parseFloat(document.getElementById("purchaseinvoice_totaldiscp").value);
		if(purchaseinvoice_totaldiscp=='' || isNaN(purchaseinvoice_totaldiscp)){purchaseinvoice_totaldiscp = 0;}
		if(purchaseinvoice_totaldiscp==0){
			var purchaseinvoice_totaldisc = parseFloat(document.getElementById("purchaseinvoice_totaldisc").value);
			if(purchaseinvoice_totaldisc=='' || isNaN(purchaseinvoice_totaldisc)){purchaseinvoice_totaldisc = 0;}
		}
		else{
			var purchaseinvoice_totaldisc = parseFloat(purchaseinvoice_subtotal*purchaseinvoice_totaldiscp*0.01);
			document.getElementById('purchaseinvoice_totaldisc').value= purchaseinvoice_totaldisc.toFixed(2);
		}
		
		// prevoius due
		var purchaseinvoice_previousdue = parseFloat(document.getElementById("purchaseinvoice_previousdue").value);
		if(purchaseinvoice_previousdue=='' || isNaN(purchaseinvoice_previousdue)){purchaseinvoice_previousdue = 0;}
		
		
		var purchaseinvoice_subtotalafterdisc = parseFloat(purchaseinvoice_previousdue+purchaseinvoice_subtotal-purchaseinvoice_totaldisc);
		document.getElementById('purchaseinvoice_subtotalafterdisc').value= purchaseinvoice_subtotalafterdisc.toFixed(2);
			
		var purchaseinvoice_receiveamount = parseFloat(document.getElementById("purchaseinvoice_receiveamount").value);
		if(purchaseinvoice_receiveamount=='' || isNaN(purchaseinvoice_receiveamount)){purchaseinvoice_receiveamount = 0;}
		
		var purchaseinvoice_due = parseFloat(purchaseinvoice_subtotalafterdisc-purchaseinvoice_receiveamount);
		document.getElementById('purchaseinvoice_due').value=purchaseinvoice_due.toFixed(2);		
		
	}
	
	function check_blankrow(){
		var purchaseinvoice_itemArray = document.getElementsByName('purchaseinvoice_item[]');
		var purchaseinvoice_totalArray = document.getElementsByName('purchaseinvoice_total[]');
			
		var error_messageid = document.getElementById('errmsg_particular_id');
		error_messageid.innerHTML = '';
		
		for(r = 0; r < purchaseinvoice_itemArray.length; r++) {
												
			if(purchaseinvoice_itemArray[r].value==''){
				error_messageid.innerHTML = 'Missing item name '+parseInt(r+1);
				purchaseinvoice_itemArray[r].focus();
				return false;
			}
			
			if(purchaseinvoice_totalArray[r].value=='' || purchaseinvoice_totalArray[r].value==0){
				error_messageid.innerHTML = 'Missing item total '+parseInt(r+1);
				purchaseinvoice_totalArray[r].focus();
				return false;
			}
		}
		
		return true;
	}

	function addnew_particularrow(animate) {
		if(check_blankrow()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" align=\"left\" width=\"918\" cellpadding=\"1\">"+
							'<tbody><tr></tr><tr>'+
								'<td align="center" width=\"130\"> <input type="text" name="purchaseinvoice_item[]" value="" class="tdclass itemname"/>'+
								'<input type="hidden" name="salesitem_id[]" id="salesitem_id[]" value="" class="tdclass itemname"/>'+
								'<input type="hidden" name="purchaseinvoice_category[]" value="" class="tdclass"  /></td>'+
								'<td align=\"center\" width=\"95\"> <input type="text" name="purchaseinvoice_stock[]" value=\"\" class="tdclasssale itemname"/></td>'+
								"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"purchaseinvoice_purchase_rate[]\"  value=\"\" class=\"tdclasssale\"/></td>"+											 
								"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"purchaseinvoice_rate[]\" value=\"\" class=\"tdclasssale numeric ccrt\"/></td>"+											 
								
								"<td align=\"center\" width=\"95\"><input type=\"text\" title=\"class\" name=\"purchaseitem_pack[]\" class=\"tdclasssale numeric ccrt\" ></td>"+
								"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"purchaseinvoice_pqty[]\" value=\"\" class=\"tdclasssale numeric ccrt\" /></td>"+
								
								"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"purchaseinvoice_qty[]\" value=\"\" class=\"tdclasssale numeric ccrt\"/></td>"+
								'<td align="center" width=\"95\"><input type="text" name="purchaseinvoice_discountp[]" value="" class="tdclasssale numeric ccrt"/></td>'+
								"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"purchaseinvoice_disc[]\" value=\"\" class=\"tdclasssale numeric  ccrt\" /></td>"+
								'<td align="center" width=\"95\"><input type="text" readonly name="purchaseinvoice_total[]" value="" class="tdclasssale numeric ccrt"  /></td>'+												
								'<td>'+
								 "<input type=\"button\" value=\"Del\" class=\"tdclasssales deletethislistrow\"  />"+
								'</td>'+
							  '</tr></tbody>'+
						"</table>";
						
			var $newparticularlist = $("<li class=\"sirow\"></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(300); 
			else 
			   $newparticularlist.show();   
			
			$( ".itemname" ).autocomplete({			
				minLength: 1,
				source: itemdata,
				focus: function( event, ui ) {
					//$( "#search_item_number" ).val( ui.item.saleselval );
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					document.getElementsByName("salesitem_id[]")[indexpos].value = ui.item.salesitem_id;
					document.getElementsByName("purchaseinvoice_purchase_rate[]")[indexpos].value = ui.item.salesitem_purchase_rate;
					document.getElementsByName("purchaseinvoice_rate[]")[indexpos].value = ui.item.salesitem_price;				
					document.getElementsByName("purchaseitem_pack[]")[indexpos].value =ui.item.salesitem_pack;
					document.getElementsByName("purchaseinvoice_qty[]")[indexpos].value = 1;					
					document.getElementsByName("purchaseinvoice_category[]")[indexpos].value = ui.item.salesitem_category;
					document.getElementsByName("purchaseinvoice_stock[]")[indexpos].value = ui.item.salesitem_stock;
				
					calculateCurrentRowTotal(indexpos);
					
					return false;
				}
			});	
			
								
		
			$( ".sirow input.ccrt" ).keyup(function() {
				var index = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				calculateCurrentRowTotal(index);
			});
			
			$( ".sirow input.deletethislistrow" ).click(function() {
				$(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').slideUp(500, function() {
					$(this).remove();
					calculateGrandTotal();
				});
			});
			
			$( ".numeric" ).keyup(function() {
				var price = $(this).val();
				var ValidChars = "-.0123456789";
				var IsNumber=true;
				var Char;
				var validint = '';
				for (var i = 0; i < price.length && IsNumber == true; i++){ 
					Char = price.charAt(i);
					if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
					else{
						validint = validint+Char;
					}
				}
				$(this).val(validint);
			});
		}
	}
</script>