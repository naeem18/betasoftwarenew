<?php
ob_start();
session_start();
require_once('labdd.php');
ob_end_flush();
date_default_timezone_set('Asia/Dhaka');
$ipaddress      = $_SERVER['REMOTE_ADDR'];
$updatedatetime = date('Y-m-d H:i:s');
$sessionusername = $_SESSION['username'];

$errmsg = '';

$query8 = "SELECT * FROM master_employee";
$exec8  = mysqli_query($conn,$query8) or die(mysqli_error($conn));
$employeecount = mysqli_num_rows($exec8);

 $frmflag1 = isset($_REQUEST['frmflag1']) ? $_REQUEST['frmflag1'] : '';

if($frmflag1=='frmflag1')
{
    $employeecode = $_POST['employeecode'];

    $employeename = strtoupper(trim($_POST['employeename']));
    $username     = trim($_POST['username']);
    $password     = $_POST['password'];

    $fullname     = trim($_POST['fullname']);
    $designation  = nl2br(stripslashes(strip_tags(addslashes($_POST['designation']))));

    $company      = 'betasoft26.0';
    $status       = 'Active';

    $reports_daterange_option =
    $_POST['reports_daterange_option'];

    $option_edit_delete =
    $_POST['option_edit_delete'];

    $checkuser =
    mysqli_query(
        $conn,
        "SELECT *
         FROM master_employee
         WHERE username='$username'"
    );

    if(mysqli_num_rows($checkuser)==0)
    {
        $password = md5($password);

        $insert =
        "INSERT INTO master_employee
        (
            employeecode,
            employeename,
            company,
            username,
            fullname,
            designation,
            password,
            status,
            lastupdate,
            lastupdateusername,
            lastupdateipaddress,
            reports_daterange_option,
            option_edit_delete
        )
        VALUES
        (
            '$employeecode',
            '$employeename',
            '$company',
            '$username',
            '$fullname',
            '$designation',
            '$password',
            '$status',
            '$updatedatetime',
            '$sessionusername',
            '$ipaddress',
            '$reports_daterange_option',
            '$option_edit_delete'
        )";

        mysqli_query($conn,$insert)
        or die(mysqli_error($conn));

        /* MAIN MENU RIGHTS */

        for($i=0;$i<=1000;$i++)
        {
            $cbmainmenu =
            isset($_POST['cbmainmenu'.$i])
            ? $_POST['cbmainmenu'.$i]
            : '';

            if($cbmainmenu!='')
            {
                $main =
                mysqli_fetch_assoc(
                    mysqli_query(
                        $conn,
                        "SELECT *
                         FROM master_menumain
                         WHERE auto_number='$cbmainmenu'"
                    )
                );

                $mainmenuid =
                $main['mainmenuid'];

                mysqli_query(
                    $conn,
                    "INSERT INTO master_employeerights
                    (
                        employeecode,
                        username,
                        mainmenuid,
                        submenuid,
                        lastupdate,
                        lastupdateipaddress,
                        lastupdateusername
                    )
                    VALUES
                    (
                        '$employeecode',
                        '$username',
                        '$mainmenuid',
                        '',
                        '$updatedatetime',
                        '$ipaddress',
                        '$sessionusername'
                    )"
                );
            }
        }

        /* SUB MENU RIGHTS */

        for($i=0;$i<=1000;$i++)
        {
            $cbsubmenu =
            isset($_POST['cbsubmenu'.$i])
            ? $_POST['cbsubmenu'.$i]
            : '';

            if($cbsubmenu!='')
            {
                $sub =
                mysqli_fetch_assoc(
                    mysqli_query(
                        $conn,
                        "SELECT *
                         FROM master_menusub
                         WHERE auto_number='$cbsubmenu'"
                    )
                );

                $submenuid =
                $sub['submenuid'];

                mysqli_query(
                    $conn,
                    "INSERT INTO master_employeerights
                    (
                        employeecode,
                        username,
                        mainmenuid,
                        submenuid,
                        lastupdate,
                        lastupdateipaddress,
                        lastupdateusername
                    )
                    VALUES
                    (
                        '$employeecode',
                        '$username',
                        '',
                        '$submenuid',
                        '$updatedatetime',
                        '$ipaddress',
                        '$sessionusername'
                    )"
                );
            }
        }

        echo "<script>
		window.location='index.php?st=success';
		</script>";
		exit;
    }
    else
    {
       echo "<script>
		window.location='addemployee1.php?st=failed';
		</script>";
		exit;
    }
}

/* MESSAGE */

$st = isset($_GET['st']) ? $_GET['st'] : '';

if($st=='success')
{
    $errmsg =
    'Employee Created Successfully';
}
elseif($st=='failed')
{
    $errmsg =
    'Username Already Exists';
}

/* EMPLOYEE CODE */

$query1 =
"SELECT *
 FROM master_employee
 ORDER BY auto_number DESC
 LIMIT 1";

$exec1 = mysqli_query($conn,$query1);

if(mysqli_num_rows($exec1)==0)
{
    $employeecode='EMP00000001';
}
else
{
    $res1=mysqli_fetch_assoc($exec1);

    $code =
    intval(
        substr(
            $res1['employeecode'],
            3
        )
    ) + 1;

    $employeecode =
    'EMP'.str_pad(
        $code,
        8,
        '0',
        STR_PAD_LEFT
    );
}
?>

<style>
body{
	
	width:50%;
	margin:0 auto;
	
	
	}
.maincontent {     
    width: 38%;
 }
 .content {
    width: 97%;
    float: left;
 }
.main-card{
    background:#fff;
    border-radius:10px;
    box-shadow:0 2px 10px rgba(0,0,0,.1);
    overflow:hidden;
}

.header{
    background:#0d47a1;
    color:#fff;
    padding:15px 20px;
    font-size:20px;
    font-weight:bold;
}

.content{
    padding:14px;
}

.section-title{
    background:#eef3ff;
    border-left:5px solid #0d47a1;
    padding:10px;
    margin-top:15px;
    margin-bottom:15px;
    font-weight:bold;
}

.form-row{
    display:flex;
    flex-wrap:wrap;
    gap:15px;
    margin-bottom:15px;
}

.form-group{
    flex:1;
    min-width:250px;
}

label{
    display:block;
    margin-bottom:5px;
    font-weight:bold;
}

input[type=text],
input[type=password],
textarea,
select{
    width:100%;
    padding:8px;
    border:1px solid #ccc;
    border-radius:5px;
    box-sizing:border-box;
}

textarea{
    height:70px;
}

.message-success{
    background:#d4edda;
    color:#155724;
    padding:10px;
    border-radius:5px;
    margin-bottom:15px;
}

.message-failed{
    background:#f8d7da;
    color:#721c24;
    padding:10px;
    border-radius:5px;
    margin-bottom:15px;
}

.required{
    color:red;
}

</style>

<script>

function from1submit1()
{
    if(document.form1.employeename.value=="")
    {
        alert("Select Employee Type");
        return false;
    }

    if(document.form1.username.value=="")
    {
        alert("User Name Cannot Be Empty");
        return false;
    }

    if(document.form1.password.value=="")
    {
        alert("Password Cannot Be Empty");
        return false;
    }

    return true;
}

</script>

<div class="main-card">

<div class="header">
    User/Employee Management
</div>

<div class="content">

<?php
if($errmsg!='')
{
    if($st=='success')
    {
        echo '<div class="message-success">'.$errmsg.'</div>';
    }
    else
    {
        echo '<div class="message-failed">'.$errmsg.'</div>';
    }
}
?>

<form
name="form1"
method="post"
action=""
onsubmit="return from1submit1();">

<input
type="hidden"
name="frmflag1"
value="frmflag1">

<div class="section-title">
User/Employee Information
</div>

<div class="form-row">

<div class="form-group">
<label>
Employee Code
</label>

<input
type="text"
name="employeecode"
value="<?php echo $employeecode;?>"
readonly>
</div>

<div class="form-group">
<label>
Date Posted
</label>

<input
type="text"
value="<?php echo $updatedatetime;?>"
readonly>
</div>

</div>

<div class="form-row">

    <div class="form-group">
        <label>
            Employee Type
            <span class="required">*</span>
        </label>

        <select
            name="employeename"
            id="employeename"
            required>

            <option value="">
                Select Employee Type
            </option>

            <option value="SUPERADMINISTRATOR">
                SUPERADMINISTRATOR
            </option>

            <option value="ADMINISTRATOR">
                ADMINISTRATOR
            </option>

            <option value="GENERAL">
                GENERAL
            </option>

        </select>
    </div>

</div>

<div class="section-title">
Login Information
</div>

<div class="form-row">

    <div class="form-group">
        <label>
            User Name
            <span class="required">*</span>
        </label>

        <input
            type="text"
            name="username"
            id="username"
            maxlength="20"
            autocomplete="off"
            required>

        <small>
            No spaces or special characters allowed
        </small>
    </div>

    <div class="form-group">
        <label>
            Password
            <span class="required">*</span>
        </label>

        <input
            type="password"
            name="password"
            id="password"
            maxlength="20"
            required>
    </div>

</div>

<div class="section-title">
Personal Information
</div>

<div class="form-row">

    <div class="form-group">
        <label>
            Full Name
            <span class="required">*</span>
        </label>

        <input
            type="text"
            name="fullname"
            id="fullname"
            maxlength="200"
            required>
    </div>

</div>

<div class="form-row">

    <div class="form-group">
        <label>
            Designation
        </label>

        <textarea
            name="designation"
            id="designation"></textarea>
    </div>

</div>

<style>

.permission-box{
    border:1px solid #d9d9d9;
    border-radius:8px;
    margin-bottom:15px;
    overflow:hidden;
    background:#fff;
}

.permission-main{
    background:#f0f5ff;
    padding:10px;
    font-weight:bold;
    border-bottom:1px solid #d9d9d9;
}

.permission-sub{
    padding:10px 20px;
}

.permission-sub label{
    display:block;
    margin-bottom:6px;
    font-weight:normal;
}

.permission-main input,
.permission-sub input{
    margin-right:8px;
}

.menu-header{
    background:#0d47a1;
    color:#fff;
    padding:10px;
    border-radius:5px;
    margin-bottom:15px;
    font-weight:bold;
}

</style>

<div class="section-title">
Menu Permissions
</div>

<div class="menu-header">
âœ“ Select Accessible Menus
</div>

<div class="section-title">
Permission Tools
</div>

<div style="margin-bottom:20px;">

    <button
        type="button"
        onclick="checkAllMenus()"
        class="tool-btn">

        âœ“ Select All

    </button>

    <button
        type="button"
        onclick="uncheckAllMenus()"
        class="tool-btn danger-btn">

        âœ• Unselect All

    </button>

</div>
<?php

$query2 =
"SELECT *
 FROM master_menumain
 WHERE status<>'deleted'
 ORDER BY mainmenuorder";

$exec2 =
mysqli_query($conn,$query2);

while($res2=mysqli_fetch_assoc($exec2))
{

    $mainAuto =
    $res2['auto_number'];

    $mainMenuId =
    $res2['mainmenuid'];

    $mainMenuText =
    $res2['mainmenutext'];

?>

<div class="permission-box">

    <div class="permission-main">

        <label>

            <input
                type="checkbox"
                checked="checked"
                name="cbmainmenu<?php echo $mainAuto;?>"
                value="<?php echo $mainAuto;?>">

            <?php echo $mainMenuText;?>

        </label>

    </div>

    <div class="permission-sub">

<?php

$query3 =
"SELECT *
 FROM master_menusub
 WHERE mainmenuid='$mainMenuId'
 AND status<>'deleted'
 ORDER BY submenuorder";

$exec3 =
mysqli_query($conn,$query3);

while($res3=mysqli_fetch_assoc($exec3))
{

    $subAuto =
    $res3['auto_number'];

    $subMenuText =
    $res3['submenutext'];

?>

<label>

<input
type="checkbox"
checked="checked"
name="cbsubmenu<?php echo $subAuto;?>"
value="<?php echo $subAuto;?>">

<?php echo $subMenuText;?>

</label>

<?php
}
?>

    </div>

</div>

<?php
}
?>

<div class="section-title">
System Options
</div>

<div class="form-row">

    <div class="form-group">

        <label>
            Report Date Range Option
        </label>

        <select
            name="reports_daterange_option"
            id="reports_daterange_option">

            <option
            value="Show Date Range Option"
            selected>

            Show Date Range Option

            </option>

            <option
            value="Hide Date Range Option">

            Hide Date Range Option

            </option>

        </select>

    </div>

    <div class="form-group">

        <label>
            Edit / Delete Permission
        </label>

        <select
            name="option_edit_delete"
            id="option_edit_delete">

            <option
            value="Edit Delete Option Available"
            selected>

            Allow Edit & Delete

            </option>

            <option
            value="Edit Delete Option Denied">

            Deny Edit & Delete

            </option>

        </select>

    </div>

</div>


<div class="section-title">
Permission Tools
</div>

<div style="margin-bottom:20px;">

    <button
        type="button"
        onclick="checkAllMenus()"
        class="tool-btn">

        âœ“ Select All

    </button>

    <button
        type="button"
        onclick="uncheckAllMenus()"
        class="tool-btn danger-btn">

        âœ• Unselect All

    </button>

</div>


<style>

.tool-btn{
    background:#0d47a1;
    color:#fff;
    border:none;
    padding:10px 18px;
    cursor:pointer;
    border-radius:5px;
    margin-right:10px;
    font-weight:bold;
}

.tool-btn:hover{
    opacity:.9;
}

.danger-btn{
    background:#c62828;
}

.save-btn{

    background:#198754;
    color:#fff;

    border:none;

    padding:14px 35px;

    font-size:16px;

    font-weight:bold;

    border-radius:6px;

    cursor:pointer;

    transition:.3s;

}

.save-btn:hover{

    background:#157347;

}

.footer-box{

    text-align:center;

    margin-top:30px;

    padding-top:20px;

    border-top:1px solid #ddd;

}

.note-box{

    background:#fff3cd;

    border:1px solid #ffe69c;

    color:#664d03;

    padding:12px;

    border-radius:5px;

    margin-bottom:20px;

}

</style>


<div class="note-box">

<strong>Note:</strong>

Selected menus and submenus will be assigned
to this employee immediately after saving.

</div>


<div class="footer-box">

    <button
        type="submit"
        class="save-btn">

        ðŸ’¾ Save Employee

    </button>

</div>


</form>

</div>

</div>


<script>

function checkAllMenus()
{
    let boxes =
    document.querySelectorAll(
    'input[type=checkbox]'
    );

    boxes.forEach(function(box)
    {
        box.checked = true;
    });
}


function uncheckAllMenus()
{
    let boxes =
    document.querySelectorAll(
    'input[type=checkbox]'
    );

    boxes.forEach(function(box)
    {
        box.checked = false;
    });
}

</script>


<style>

@media screen and (max-width:768px)
{

    body{
        padding:10px;
    }

    .form-row{
        flex-direction:column;
    }

    .form-group{
        width:100%;
    }

    .permission-sub{
        padding-left:10px;
    }

    .save-btn{
        width:100%;
    }

    .tool-btn{
        width:100%;
        margin-bottom:10px;
    }

}

</style>

</body>
</html>