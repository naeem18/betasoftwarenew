	<script language="JavaScript" type="text/javascript">
	 function calculatepack(){
		var houserent = parseFloat(document.getElementById("houserent").value);
		if(houserent=='' || isNaN(houserent)){houserent = 0;}
		
		var dpsfound = parseFloat(document.getElementById("dpsfound").value);
		if(dpsfound=='' || isNaN(dpsfound)){dpsfound = 0;}
		
		 
		var monthlysalary = parseFloat(document.getElementById("monthlysalary").value);
		if(monthlysalary=='' || isNaN(monthlysalary)){monthlysalary = 0;}
		
		var netsalary = parseFloat(monthlysalary-houserent-dpsfound);
		document.getElementById("netsalary").value = netsalary.toFixed(2);
		
		var workingday = parseFloat(document.getElementById("workingday").value);
		if(workingday=='' || isNaN(workingday)){workingday = 0;}
		
		var perdaysalary = parseFloat(netsalary/workingday);
		document.getElementById("perdaysalary").value = perdaysalary.toFixed(2);
			
		}
	</script>

        <header>
            <h3> Add New Employee</h3>
        </header>
 		<?php
			if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
			echo "<h2 class=\"red12bold\">You have missing Something</h2>";
			}
			elseif(isset($_GET['message']) && $_GET['message']=='duplicatename'){
			echo "<h2 class=\"red12bold\">This Item  already exists. Please try with different item .</h2>";   
			}
			elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
			echo "<h2 class=\"red12bold\">Error occured! Could not insert.</h2>";   
			}
			elseif(isset($_GET['message']) && $_GET['message']=='insert-successfully'){
			echo "<h2 class=\"red12bold\">Item insert successfully</h2>";   
			}
  			$id = 0;
			$name = '';
			$gross = '';
 			 
         if(isset($_GET['id'])){
            $id = $_GET['id'];
            $sqlsalesitem = "select * from employee where id = $id";
            $salesitemquery = mysqli_query($conn, $sqlsalesitem);
            if($salesitemquery){
                while($srow = mysqli_fetch_array($salesitemquery)){
                     $id = $srow['id'];
                    $name = $srow['name'];
					$e_id = $srow['e_id'];
					$gross = $srow['gross'];
 					}
				}
			}
        ?>        
 		<form action="save_employee.php" name="frmcontact" onsubmit="return checkcontactform();" method="post" enctype="multipart/form-data">
             <table width="70%" border="1" style="border-collapse:collapse" bgcolor="#fff">
                <tr>
                    <td width="220">Photo </td>
                    <td>
                        <input type="file" size="10" name="employenameentry_photo" id="employenameentry_photo" class="textfieldcssmem"  />
                    </td>
                </tr>
               
                <tr>
                    <td>Name*</td>
                    <td>
                        <input type="text" required name="name" id="name" value="<?php echo $name;?>" class="textfieldcssmem"  />
                    </td>
                </tr>
                
                <tr>
                    <td>Father*</td>
                    <td>
                        <input type="text" name="father" id="father" value="<?php //echo $father;?>" class="textfieldcssmem"  />
                    </td>
                </tr>
                
                <tr>
                    <td>Designation*</td>
                    <td>
                        <input type="text" name="designation" id="designation" value="<?php //echo $designation;?>" class="textfieldcssmem"  />
                    </td>
                </tr>
                
                 <tr>
                    <td>Address*</td>
                    <td>
                       <textarea type="text" name="address" id="address" class="textfieldcssmem" ><?php //echo $address;?></textarea>
                    </td>
                </tr>
                
                  <tr>
                    <td><strong>Payable Salary</strong>*</td>
                    <td><input type="text" name="gross" id="gross" value="<?php echo $gross;?>" class="textfieldcssmem" /></td>
                  </tr>
                
                <tr>
                    <td>&nbsp;</td>
                    <td>
                        <input type="hidden" name="id" id="id" value="<?php echo $id;?>">
                        <input type="submit" value=" Save " name="submit" id="submit" class="submitbuttoncss" />
                    </td>
                </tr>
          </table>
      </form>
      
<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td valign="top" align="center">
        <table width="100%" border="0" align="center" cellpadding="1" cellspacing="0" bordercolor="#666666" style="border-collapse: collapse">
          <tbody>
            <tr>
            <td width="10%" align="right" valign="center" bgcolor="#FFFFFF">
               <input name="print" type="button" id="print" style="border: 1px solid #001E6A" value="Print" onClick="PrintDiv();" />
            </td>
            </tr>
          </tbody>
        </table>
   	</td>
</tr>
  
<td>
<table width="100%" bgcolor="#FFF" style="border-collapse:collapse" border="1">
  <tr>
    <td colspan="19" width="100%" align="center" bgcolor="#C17172"><strong>Machine Read Employee Profile & salary Sheet</strong></td>
  </tr>
          
  <tr bgcolor="#0099FF">
    <td><strong>SL No.</strong></td>
    <td><strong>ID No.</strong></td>
    <td><strong>Photo</strong></td>
    <td><strong>Name</strong></td>
     
    <td><strong>Monthly Gross Salary</strong></td>
     <td><strong>Edit/Delete</strong></td>
  </tr>
		  <?php
           $i='';
           $totalnetsalary='0.00';
           $totalpayablesalary='0.00';
           $total_salesitem_purchase_rate='';
           $total_salesitem_price = '';
   
   			$sqlsalesitem = "select * from employee order by id asc";
            $salesitemquery = mysqli_query($conn, $sqlsalesitem);
            if($salesitemquery){
                while($srow = mysqli_fetch_array($salesitemquery)){
                    $id = $srow['id'];
                    $name = $srow['name'];
					$e_id = $srow['e_id'];
					$gross = $srow['gross'];
   					
				$action = "<a href=\"index.php?p=employelist&id=$id\">Edit</a> | 
				<a href=\"javascript:void(0)\" onclick=\"removetablerow('employee', $id, 'employelist')\">Remove</a>";
				//$totalgross=$totalgross+$gross;
 			?>
              <tr>
                <td width="15"><?php echo $i=$i+1;?></td>
                <td><?php echo $id;?></td>
              	<td><img src="empphoto_images/<?php //echo $employenameentry_photo; ?>" title="<?php //echo $employenameentry_photo;?>" height="60" width="60"/></td>
         		<td><?php echo $name;?></td>
              	<td><?php echo $gross;?></td>
 				<td><?php echo $action;?></td>
              </tr>
                <?php
                 }
            }
        ?>
        
 </table>
</td>	
   
   
<td align="center" id="divToPrint" style="display:none">
   
</td>     
</table>