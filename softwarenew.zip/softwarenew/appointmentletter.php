<article class="bottomcontent">
    <h3 style="background:#77F7AA; text-align:center">Appointment Letter</h3>
   	<content>
        <?php
        if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
            echo "<p class=\"red12bold\">You have missing Something</p>";
        }
		if(isset($_GET['message']) && $_GET['message']=='update-successfully'){
            echo "<p class=\"red12bold\">updated successfully</p>";
        }
        elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
            echo "<p class=\"red12bold\">Error occured! Could not insert.</p>";   
        }
        elseif(isset($_GET['message']) && $_GET['message']=='save-successfully'){
            echo "<p class=\"red12bold\">Information insert successfully. Click Print Button To Print or View Previous Bill <td align=\"center\" ><a onclick=\"PrintDiv();\"><input type=\"button\" name=\"user\" id=\"user\" required value=\"Print\" class=\"tdclass\"  /></a></td></p>";   
        }
        $appointmentletterid = 0;
        $expense_name = '';
        $expense_mobile = '';
        $expense_particular = '';
        $expense_amount = '';
        $expense_description = '';
        $expense_voucher = '';
        ?>        
 <form action="save_appointmentletter.php" style="background:#FFF; padding:10px" name="frmcontact" onsubmit="return checkcontactform();" method="post" enctype="multipart/form-data">

	<table width="100%" align="center" border="1" style="BORDER-COLLAPSE: collapse;" bgcolor="#D6FEE1" cellpadding="2">
     <input type="hidden" name="section" id="section" required value="Appointment Letter" class="tdclass"  />
  	<input type="hidden" name="user" id="user" required value="<?php echo $_SESSION['fullname'];?>" class="tdclass"  />
  	<tr>
        <td align="right">Month</td>
        <td><input type="text" name="amonth" id="amonth" value="<?php echo date("F Y");?>" size="70" /></td>
    </tr>
    <tr>
        <td align="right">Date</td>
        <td><input type="text" name="adate" id="adate" value="<?php echo date('Y-m-d');?>"size="70" /></td>
    </tr>
    <tr>
    	<td align="right"><strong>Ref:</strong></td>
    	<td><input type="text" name="ref" id="ref" value="FCCSH/HR/ RMO/TC/2018-02"size="70" /></td>
    </tr>
    
    <tr>
        <td align="right">Mailing Address</td>
        <td><textarea name="address" required id="address" style="width:500px; height:100px">15, New Eskaton Road,
Moghbazar, Queen’s Garden Homes
Flat No-E-8, Dhaka-1000, Bangladesh.
Mobile: 01778-622920.
Email: jolchobi2014@gmail.com
</textarea></td>
    </tr>
    <tr>
    	<td align="right">Subject</td>
    	<td><textarea name="subject" required id="subject" style="width:700px; height:30px">Appointment for post of SENIOR RESIDENT MEDICAL OFFICER.</textarea></td>
    </tr>
   
   <tr>
       <td align="right">Letter Body</td>
       <td><textarea name="letterbody" required id="letterbody" style="width:700px; height:120px">Dear DR. TASNEEMA,
With reference to your application and the subsequent interview you had with us. We are pleased to offer you the following position at Feni Cardiac Center and specialized Hospital, 170, S.S.K Road, Feni, Bangladesh, subject to the following terns and conditions.
</textarea></td>
   </tr>
   
   <tr>
    <td align="right">JOB TITLE</td>
    <td><textarea name="jobtittle" required id="jobtittle" style="width:700px; height:170px">JOB TITLE		: SENIOR RESIDENT MEDICAL OFFICER.
REPORT TO		: HRD, Feni Cardiac Center and Specialized Hospital.
REMUNERATION		: Annexure 01
TERMS & CONDITION	: Annexure 02
JOB DESCRIPTION		: Annexure 03
 </textarea></td>
    </tr>
   
    <tr>
     <td align="right">Annexure 01</td>
    <td><textarea name="annexure1" required id="annexure1" style="width:700px; height:100px">
Employee Name	: DR. TASNEEMA CHOWDHURY
Designation		: SENIOR RESIDENT MEDICAL OFFICER
Total Remuneration	: 70,000.00 BDT
 </textarea></td>
    </tr>
   
    <tr>
        <td align="right">Annexure 02</td>
        <td><textarea name="annexure2" required id="annexure2" style="width:700px; height:250px">Terms and Conditions

1. You will be on contract for a period of 03 (three) Calendar years from the date of your joining which may be extended with notice at the discretion of the hospital. You will enjoy a day off in each week during contract period.

2. In the matter of confirmation of your appointment or of termination of your service during the contract period or during the extended contract period. The management has absolute discretion.

3. In the period of contract, your status will be a resident.

4. The Management may change your designation, duties and responsibilities from time to time as it may deem fit and proper.

5. You will perform to the best of your ability all the duties as are inherent in your post and such additional duties as the hospital may call upon you to perform, from time to time.

6. Your application C.V. or declaration given by you is proved to be false, or if it is found that you have willfully suppressed any material information, you will be liable to the removal from service forthwith without any notice or compensation what-so-ever and without assigning of any reason thereof. And to such other action as the hospital may deem necessary.

7. You will be liable to removal from service forthwith if you are found guilty of insubordination, intemperance or other misconduct. If any breach of any rules pertaining to your service of conduct or non performance of your duties.

8. Upon termination of your employment, you will immediately surrender to the hospital all files, books, magazines, reports, documents, manuals audio and video tapes, floppies and discs and any other knowledge data bases entrusted to you in the course of your employment. You will also surrender any physical property that belongs to Feni Cardiac Center and Specialized Hospital and is in your possessions.

9. You will not reproduce store in a retrieval system or transmit in any form or by any means -electronic, mechanical, photocopying, recording, scanning or otherwise-any copy righted material which is the property of the hospital for your own benefit or for the benefit of any third party - either during the course of your employment or on your separation.

10. You will not either directly or indirectly engage yourself with other organizations or works during service period.

11. This offer of appointment is valid for joining on duty till one month from the receipt of appointment letter. Please bring the original certificates of educational qualifications (Mark sheet, Certificates, etc.) and its photocopies/ Nationality certificates. Three (3) copy passport size photographs and experience certificates at the time to joining.

12. Any change of your residential address should be notified in writing forthwith to the hospital.

13. Other aspects and conditions of service will be governed by the existing rules of the hospital and relevant laws.

14. During the period of your contract, your service can be terminated by the hospital at any time without any notice and if terminated by the hospital during the period of your contract, you will be entitled to any notice as mentioned or pay in lieu there of to any compensation.

15. During the period of your contract, your suitability for permanent employment in the post will be assessed. if the letter of confirmation is not issued to you at the end of the said initial 3 (three) years, the period of your contract shall be deemed to have been extended for a further period of 3 (three) calendar years and you will continue as the contract during the said extended period on the same terms and condition's as laid in this letter.

16. You shall faithfully serve the hospital, obey its lawfully commands, deep its secrets diligently and carefully learn and perform such work and business as may be entrusted to you, attend to your work regularly during such hours as may be prescribed and perform such duties as may be assigned.

17. You will not borrow or accept any money, gift, reward or compensation for your personal gains from or otherwise place yourself under pecuniary obligation to any person client with whom you may be having official dealings.

18. The appointment is subject to separation/ termination by giving one months notice period for each completed year of service subject to a maximum of three month notice. If your services are terminated consequent on any disciplinary action or loss of confidence no notice will be required to terminate your service.

19. In case of your any absence without permission for more than (seven) days, you will loss than on your services and the Hospital will be entitled to terminate your appointment.

20. You will be liable for retirement in any time in the grounds of physical or mental disability, which will be determined by the management in the report of the companies authorized medical consultant.

If the above terms and conditions of service are acceptable to you, then please return the duplicate copy of this letter duly signed by you as a token to your acceptance.
</textarea></td>
    </tr>
    
<tr>
        <td align="right">Annexure 03</td>
        <td><textarea name="annexure3" required id="annexure3" style="width:700px; height:250px">GENERAL JOB DESCRIPTION

Principal Duties and Responsibilities: 
Clinical Management of Patients
•	Complete a brief admission examination on each patient when appropriate and document clinical findings.
•	Attend ward rounds with consulting staff, as required, and be available to discuss patient treatment plans.
•	Provide a 24-hour medical service within the Critical care area by rotation basis.
•	Inform admitting consultants of changes in medical condition of patients and of relevant action taken.
•	Follow the instructions of consultants for their specific regime for each individual patient.
•	Perform clinical procedures as requested by consultant medical staff and nursing staff, these may include phlebotomy and monitoring of intravenous drugs given to patients.
•	Initiate and alter in-patient prescriptions at consultant’s request.
•	Write up “to shift out from Critical care area” for patients as required.
•	Visit patients as required at the request of the nursing staff.
•	Visit all Critical care patients daily and document in clinical notes.
•	To be familiar with all relevant procedures/policies.
•	To be familiar with FCCSH clinical policies. To be aware of the FCCSH clinical risk program and report clinical incidents, drug errors and near misses.
•	To participate in clinical audit and implementation of clinical governance.
•	To participate and assist with clinical procedures as required.
•	You should be part of the quality improvement of JCI documentation process of the hospital.

Operational
•	To be completely familiar with emergency equipment.
•	To dispense drugs with senior nurse on duty.
•	To record all treatments performed in patient notes.
•	To provide a full report to Resident Medical Officer commencing the next shift.

Emergency
•	To carry out Cardiac Arrest and other Emergency Procedures as per hospital policy.
•	To initiate emergency treatments for patients, staff and visitors and complete appropriate documentation.

In-Service Education and  Promotion of the Treatment Centre
•	Promote patient care by liaison with all departments.
•	Participate in the in-service education program, inclusive of CPR, Health & Safety Training and Fire and other JCI related.
•	Ensure medical competence by continual professional development and reading of current medical journals.
•	Promote the center by showing empathy and compassion to patients, their families and friends.
•	Promote the center by demonstrating a customer –focused approach at all times to patients, consultants and staff.
•	Dress code as per FCCSH policy.

Relationships
•	Administratively responsible to the Critical care coordinator.
•	Professionally responsible to the Chairman, Managing Director, and Admin.
•	Liaises closely with nursing staff and other relevant clinical or administrative staff.
•	Uses designated mentor in order to discuss clinical (or non-clinical) situations occurring within the hospital.

Decision Making Authority
•	Can initiate emergency medical care as required within the Critical care area for medical and surgical emergencies.
Health and Safety
•	Take reasonable care of the health and safety of themselves and all other persons.
•	Who may be affected by their acts or omissions at work.
•	Co-operate with their employer to ensure compliance with Health and Safety legislation and the Health and Safety policies and procedures of the treatment center, not intentionally or recklessly interfere with, or misuse, anything provided in the interests of health, safety, or welfare, in pursuance of any of the relevant statutory provisions.

Data Protection
The post holder must at all times respect the confidentiality of information in line with the requirements of the Data Protection Act.  This includes, if required to do so, obtain, process and/or use information held on a computer in a fair and lawful way, to hold data only for the specified registered purposes and to use or disclose data only to authorized persons or organizations as Instructed.
This list of duties and responsibilities is not exhaustive and the post holder may be required to undertake other relevant and appropriate duties as reasonably required.
This job description is subject to regular review and appropriate modification.
Personal Qualities
•	Plan when necessary and to take appropriate initiatives in and urological emergencies when required.
•	Preparation of discharge summaries well in time previous day and briefing the patient about the medications on discharge.
•	Follow hospital practices and demonstrate initiative aligned to ensuring the safest possible environment for patients and staff.
•	To attend all clinical meetings and workshops and actively participate in paper presentations.
•	To be part of training programs conducted in the hospital and to take continuous initiatives for knowledge and skill up gradation.
•	To be involved in teaching programs that is held by the department
•	To be an active member for the quality initiatives of the hospital.
•	Any other responsibility assigned by the Authority.

</textarea></td>
    </tr>
    
    
    <tr>
        <td align="right">conclution</td>
        <td><textarea type="text" name="conclution" id="conclution" style="width:700px; height:150px"/>
        
I have carefully read the above letter and the terms & conditions set out therein, which I have fully understood and I have accepted the same.

    

   Signature	: ...................................

   Date         : ...................................

</textarea></td>
	</tr>
    <tr>
    	<td align="right"></td>
        <td>
        <input type="hidden" name="appointmentletterid" id="appointmentletterid" value="<?php //echo $appointmentid;?>">
        <input type="submit" value=" Save " name="submit_invoice" id="submit_invoice" class="tdclass" />
        </td>
    </tr>
</table>
</form>         

</content>
</article>


<div id="divToPrint" style="display:none;">
<article class="bottomcontent" style="margin:0 auto">
   	  <?php
		  if(isset($_GET['appointmentletterid'])){
          	$appointmentletterid = $_GET['appointmentletterid'];
            $stsql = "select * from appointmentletter where appointmentletterid = $appointmentletterid";
            $stquery = mysqli_query($conn, $stsql);
            if($stquery && mysqli_num_rows($stquery)>0){
               $i=0;
			    while($page_inforow = mysqli_fetch_array($stquery)){
                   $i++;
				    $appointmentletterid = $page_inforow['appointmentletterid'];
                    $address = $page_inforow['address'];
                    $subject = $page_inforow['subject'];
					$user = $page_inforow['user'];
                    $ref = $page_inforow['ref'];
 					$letterbody = $page_inforow['letterbody'];
 					$jobtittle = $page_inforow['jobtittle'];
 					$annexure1 = $page_inforow['annexure1'];
 					$annexure2 = $page_inforow['annexure2'];
 					$annexure3 = $page_inforow['annexure3'];
 					
					$conclution = $page_inforow['conclution'];
 					
					
					
						}
					}
			   }
			?>
             
            <table width="100%" align="center" style="font-size:20px;" bgcolor="#FFF" cellpadding="0">
                <tr>
                    <td align="center">
                        Appointment Letter
                    </td>
                 </tr>
            </table>
                     
         	<table width="100%" align="center" bgcolor="#FFF" style=" padding:0 0 40px;font-size:15px; border-top:none;">
             
                 <tr align="left" height="20">
                    <td style=" padding-top:20px">Ref: <?php echo $ref;?></td>
                   </tr>
                   <tr>
                    <td style=" padding-top:20px">Mailing Address: <?php echo $address;?></td>
                    </tr>
                <tr>
                    <td style=" padding-top:20px"><strong>Subject <?php echo $subject;?></strong></td>
                </tr>
                
                <tr>
                    <td style=" padding-top:20px"><?php echo $letterbody;?></td>
                </tr>
                
                <tr>
                    <td style=" padding-top:20px"><?php echo $jobtittle;?></td>
                </tr>
                <tr>
                    <td style=" padding-top:20px"><?php echo $annexure1;?></td>
                </tr>
                <tr>
                    <td style=" padding-top:20px"><?php echo $annexure2;?></td>
                </tr>
                
                <tr>
                    <td style=" padding-top:20px"><?php echo $annexure3;?></td>
                </tr>
                
                <tr>
                    <td style=" padding-top:20px"><?php echo $conclution;?></td>
                </tr>
                  
        </table>
                   
         
       <table width="100%" align="center" style="font-size:14px; padding:50px 1px" bgcolor="#FFF" cellpadding="0">
            <tr align="center">
               <td>
                <div style="padding-bottom:20px" align="left"></div>
                <div align="right">HRD</div>
               </td>
               
               <td>
                <div style="padding-bottom:20px" align="center"></div>
                <div align="center">MD</div>
               </td>
               <td>
                <div style="padding-bottom:20px" align="left"></div>
                <div align="left"><b>Chairman</b></div>
               </td>
             </tr>
        </table>

             
</article>
</div>