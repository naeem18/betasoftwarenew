<?php
require('labdd.php');
date_default_timezone_set("Asia/Dhaka");

$from = $_POST['ADate1'] ;
$to = $_POST['ADate2'] ;

$labinvoice_id = $_POST['labinvoice_id'];
$labinvoice_patientid = $_POST['labinvoice_patientid'];
$labinvoice_pc = $_POST['labinvoice_pc'];
$labinvoice_mpo = $_POST['labinvoice_mpo'];

$searchstr = " AND dstatus != 'Deleted' AND txstatus != 'Deleted' AND DATE(labinvoice_date) BETWEEN '$from' AND '$to' ";
if (!empty($labinvoice_id)) {
    $searchstr .= " AND labinvoice_id = '" . mysqli_real_escape_string($conn, $labinvoice_id) . "'";
}

if (!empty($labinvoice_patientid)) {
    $searchstr .= " AND labinvoice_patientid = '" . mysqli_real_escape_string($conn, $labinvoice_patientid) . "'";
}
 
if (!empty($labinvoice_pc)) {
    $searchstr .= " AND labinvoice_pc LIKE '%" . mysqli_real_escape_string($conn, $labinvoice_pc) . "%'";
}

if (!empty($labinvoice_mpo)) {
    $searchstr .= " AND labinvoice_mpo LIKE '%" . mysqli_real_escape_string($conn, $labinvoice_mpo) . "%'";
}


$showOutdoor = true;
$showIndoor  = true;

if ($labinvoice_patientid !== '' && $labinvoice_patientid !== null) {
    if (intval($labinvoice_patientid) > 0) {
        // Indoor Patient
        $showOutdoor = false;
        $showIndoor  = true;
    } else {
        // Outdoor Patient (Patient ID = 0)
        $showOutdoor = true;
        $showIndoor  = false;
    }
}


if($showOutdoor){

$sql = "SELECT *
FROM labinvoice
WHERE labinvoice_totalpccomission>0
AND labinvoice_due=0
AND labinvoice_pc!=''
AND labinvoice_patientid=0
$searchstr
ORDER BY labinvoice_id ASC";

$res = mysqli_query($conn,$sql);

if($res && mysqli_num_rows($res)>0){

 echo "<table><tr><td colspan='100%' class='titlebar'>
<strong>Out Door PC Comission</strong>
</td></tr>";
  
echo "<table>
<thead>
<tr>
	<th>SL</th>
	<th>Date</th>
 	<th>Inv No.</th>
	<th>Patient</th>
	<th>PID</th>
	<th>Mobile</th>
	<th>Gross</th>
	<th>InvDisC</th>
	<th>Net</th>
 	<th>F.Disc</th>
  	<th>MPO</th>
	<th>P.C Name</th>
 	<th>P.C Comission</th>
 	<th>Pay</th>
</tr>
</thead>
<tbody>";

$sl = 1;
$gross = $disc = $net =$fdisc =$collection = $cash = $due=$pccom = 0;
			
while ($row = mysqli_fetch_assoc($res)) {
	$action = "<a href=\"index.php?p=labpcpaid&labinvoice_id={$row['labinvoice_id']}\" target=\"_blank\">Pay</a>";

  echo "<tr bgcolor=\"#fff\">
    <td>{$sl}</td>
    <td>{$row['labinvoice_date']}</td>
    <td>{$row['labinvoice_id']}</td>
    <td>" . htmlspecialchars($row['labinvoice_patient']) . "</td>
    <td>{$row['labinvoice_patientid']}</td>
    <td>{$row['labinvoice_mobile']}</td>
    <td>{$row['labinvoice_subtotal']}</td>
    <td>{$row['labinvoice_totaldisc']}</td>
    <td>{$row['labinvoice_subtotalafterdisc']}</td>
    <td>{$row['labinvoice_finaldisc']}</td>
 	
 	<td>{$row['labinvoice_mpo']}</td>
	<td>{$row['labinvoice_pc']}</td>
	<td>{$row['labinvoice_totalpccomission']}</td>
 	<td>{$action}</td>
  </tr>";
  $sl++;
  $gross += $row['labinvoice_subtotal'];
  $disc += $row['labinvoice_totaldisc'];
  $fdisc += $row['labinvoice_finaldisc'];
  $collection += $row['collection_amount'];
  //$cash += $row['labinvoice_receiveamount'];
  $net += $row['labinvoice_subtotalafterdisc'];
  $cash += $row['labinvoice_receiveamount'];
  $due += $row['labinvoice_due'];
  $pccom += $row['labinvoice_totalpccomission'];
}

echo "<tr style='font-weight:bold; background:#f9f9f9'>
  <td colspan='12' align='right'>Total</td>
  <td>{$pccom}</td>
  <td></td>
</tr>";
echo "</tbody></table>";


}

}


if($showIndoor){

$sqlin = "SELECT *
FROM labinvoice
WHERE labinvoice_totalpccomission>0
 
AND labinvoice_pc!=''
AND labinvoice_patientid!=0
$searchstr
ORDER BY labinvoice_id ASC";

$resin = mysqli_query($conn,$sqlin);

if($resin && mysqli_num_rows($resin)>0){

   
echo "<table><tr><td colspan='100%' class='titlebar'>
<strong>Indoor PC Comission</strong>
</td></tr>";

echo "<table>
<thead>
<tr>
	<th>SL</th>
	<th>Date</th>
 	<th>Inv No.</th>
	<th>Patient</th>
	<th>PID</th>
	<th>Mobile</th>
	<th>Gross</th>
	<th>InvDisC</th>
	<th>Net</th>
 	<th>F.Disc</th>
  	<th>MPO</th>
	<th>P.C Name</th>
 	<th>P.C Comission</th>
 	<th>Pay</th>
</tr>
</thead>
<tbody>";

$sl = 1;
$gross = $disc = $net =$fdisc =$collection = $cash = $due=$pccom = 0;
			
while ($row = mysqli_fetch_assoc($resin)) {
	//$action = "<a href=\"index.php?p=indoorlabpcpaid&opregistration_id={$row['labinvoice_patientid']}\" target=\"_blank\">Indoor PC Pay</a>";
	$action = "<a href=\"index.php?p=labpcpaid&labinvoice_id={$row['labinvoice_id']}\" target=\"_blank\">Pay</a>";

  echo "<tr bgcolor=\"#fff\">
    <td>{$sl}</td>
    <td>{$row['labinvoice_date']}</td>
    <td>{$row['labinvoice_id']}</td>
    <td>" . htmlspecialchars($row['labinvoice_patient']) . "</td>
    <td>{$row['labinvoice_patientid']}</td>
    <td>{$row['labinvoice_mobile']}</td>
    <td>{$row['labinvoice_subtotal']}</td>
    <td>{$row['labinvoice_totaldisc']}</td>
    <td>{$row['labinvoice_subtotalafterdisc']}</td>
     <td>{$row['labinvoice_finaldisc']}</td>
 	
 	<td>{$row['labinvoice_mpo']}</td>
	<td>{$row['labinvoice_pc']}</td>
	<td>{$row['labinvoice_totalpccomission']}</td>
 	<td></td>
    
	
  </tr>";
  $sl++;
  $gross += $row['labinvoice_subtotal'];
  $disc += $row['labinvoice_totaldisc'];
  $fdisc += $row['labinvoice_finaldisc'];
  $collection += $row['collection_amount'];
  //$cash += $row['labinvoice_receiveamount'];
  $net += $row['labinvoice_subtotalafterdisc'];
  $cash += $row['labinvoice_receiveamount'];
  $due += $row['labinvoice_due'];
  $pccom += $row['labinvoice_totalpccomission'];
}

echo "<tr style='font-weight:bold; background:#f9f9f9'>
  <td colspan='12' align='right'>Total</td>
   
  <td>{$pccom}</td>
  <td></td>
</tr>";
echo "</tbody></table>";

}

}