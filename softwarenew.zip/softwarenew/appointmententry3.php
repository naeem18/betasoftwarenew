<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Appointment System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        
        .header {
            background: #4a6fc0;
            color: white;
            padding: 25px 30px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 28px;
            margin-bottom: 5px;
        }
        
        .header p {
            opacity: 0.9;
        }
        
        .content {
            display: flex;
            flex-wrap: wrap;
        }
        
        .form-container {
            flex: 1;
            min-width: 300px;
            padding: 30px;
            background: #f9fafc;
        }
        
        .info-container {
            flex: 1;
            min-width: 300px;
            padding: 30px;
            background: #4a6fc0;
            color: white;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #2c3e50;
        }
        
        input, select {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #ddd;
            border-radius: 6px;
            font-size: 16px;
            transition: border 0.3s;
        }
        
        input:focus, select:focus {
            border-color: #4a6fc0;
            outline: none;
        }
        
        button {
            background: #4a6fc0;
            color: white;
            border: none;
            padding: 14px 20px;
            width: 100%;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        button:hover {
            background: #3b5aa6;
        }
        
        .serial-display {
            text-align: center;
            margin-top: 25px;
            padding: 20px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
        }
        
        .serial-number {
            font-size: 32px;
            font-weight: 700;
            letter-spacing: 2px;
            margin: 15px 0;
            color: #ffdd59;
        }
        
        .info-list {
            list-style: none;
            margin-top: 25px;
        }
        
        .info-list li {
            margin-bottom: 15px;
            display: flex;
            align-items: flex-start;
        }
        
        .info-list i {
            margin-right: 12px;
            margin-top: 4px;
            font-size: 18px;
        }
        
        h3 {
            margin-bottom: 20px;
            font-size: 22px;
            position: relative;
            padding-bottom: 10px;
        }
        
        h3:after {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 50px;
            height: 3px;
            background: #ffdd59;
        }
        
        .info-container h3:after {
            left: 50%;
            transform: translateX(-50%);
        }
        
        .period-info {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
            flex-wrap: wrap;
        }
        
        .period-card {
            background: rgba(255, 255, 255, 0.1);
            padding: 15px;
            border-radius: 8px;
            width: calc(50% - 10px);
            margin-bottom: 15px;
            text-align: center;
        }
        
        .period-card h4 {
            margin-bottom: 8px;
            font-size: 16px;
        }
        
        @media (max-width: 768px) {
            .content {
                flex-direction: column;
            }
            
            .period-card {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-stethoscope"></i> Doctor Appointment System</h1>
            <p>Manage appointment serial numbers based on different time periods</p>
        </div>
        
        <div class="content">
            <div class="form-container">
                <h3>Appointment Details</h3>
                
                <div class="form-group">
                    <label for="doctor">Doctor</label>
                    <select id="doctor">
                        <option value="">Select a doctor</option>
                        <option value="dr_john">Dr. John Smith (Cardiologist)</option>
                        <option value="dr_emma">Dr. Emma Wilson (Neurologist)</option>
                        <option value="dr_michael">Dr. Michael Brown (Orthopedist)</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="patient">Patient Name</label>
                    <input type="text" id="patient" placeholder="Enter patient name">
                </div>
                
                <div class="form-group">
                    <label for="date">Appointment Date</label>
                    <input type="date" id="date">
                </div>
                
                <div class="form-group">
                    <label for="period">Serial Period</label>
                    <select id="period">
                        <option value="daily">Daily Serial</option>
                        <option value="weekly">Weekly Serial</option>
                        <option value="biweekly">15-Day Serial</option>
                        <option value="monthly">Monthly Serial</option>
                    </select>
                </div>
                
                <button onclick="generateSerial()">Generate Serial Number</button>
                
                <div class="serial-display">
                    <p>Your serial number will appear here</p>
                    <div class="serial-number" id="serialResult">#00000</div>
                    <p id="serialInfo">Select a doctor and date to generate serial</p>
                </div>
            </div>
            
            <div class="info-container">
                <h3>How Serial Numbers Work</h3>
                
                <div class="period-info">
                    <div class="period-card">
                        <h4><i class="fas fa-calendar-day"></i> Daily</h4>
                        <p>Starts from 1 each day</p>
                    </div>
                    
                    <div class="period-card">
                        <h4><i class="fas fa-calendar-week"></i> Weekly</h4>
                        <p>Resets every Monday</p>
                    </div>
                    
                    <div class="period-card">
                        <h4><i class="fas fa-calendar-alt"></i> 15-Day</h4>
                        <p>Resets on 1st and 16th of each month</p>
                    </div>
                    
                    <div class="period-card">
                        <h4><i class="fas fa-calendar"></i> Monthly</h4>
                        <p>Resets on 1st of each month</p>
                    </div>
                </div>
                
                <ul class="info-list">
                    <li>
                        <i class="fas fa-info-circle"></i>
                        <div>Serial numbers are generated based on the selected time period and doctor's appointment count.</div>
                    </li>
                    <li>
                        <i class="fas fa-user-md"></i>
                        <div>Each doctor has their own independent serial number sequence.</div>
                    </li>
                    <li>
                        <i class="fas fa-database"></i>
                        <div>The system automatically tracks the last serial number for each period.</div>
                    </li>
                    <li>
                        <i class="fas fa-code"></i>
                        <div>Serial numbers are formatted as # followed by 5 digits (e.g., #00042).</div>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <script>
        // Mock database of existing appointments for demonstration
        const existingAppointments = [
            { doctor: 'dr_john', date: '2023-06-15', period: 'daily', serial: 5 },
            { doctor: 'dr_john', date: '2023-06-14', period: 'daily', serial: 8 },
            { doctor: 'dr_emma', date: '2023-06-15', period: 'weekly', serial: 12 },
            { doctor: 'dr_michael', date: '2023-06-10', period: 'monthly', serial: 21 },
        ];
        
        function generateSerial() {
            const doctor = document.getElementById('doctor').value;
            const dateString = document.getElementById('date').value;
            const period = document.getElementById('period').value;
            
            if (!doctor || !dateString) {
                alert('Please select a doctor and date');
                return;
            }
            
            const date = new Date(dateString);
            let maxSerial = 0;
            
            // In a real application, this would be a database query
            // For demo, we're filtering our mock data
            for (const app of existingAppointments) {
                if (app.doctor !== doctor) continue;
                
                const appDate = new Date(app.date);
                let isSamePeriod = false;
                
                switch (period) {
                    case 'daily':
                        isSamePeriod = isSameDay(date, appDate);
                        break;
                    case 'weekly':
                        isSamePeriod = isSameWeek(date, appDate);
                        break;
                    case 'biweekly':
                        isSamePeriod = isSameBiweekly(date, appDate);
                        break;
                    case 'monthly':
                        isSamePeriod = isSameMonth(date, appDate);
                        break;
                }
                
                if (isSamePeriod && app.serial > maxSerial) {
                    maxSerial = app.serial;
                }
            }
            
            const newSerial = maxSerial + 1;
            const formattedSerial = '#' + newSerial.toString().padStart(5, '0');
            
            document.getElementById('serialResult').textContent = formattedSerial;
            
            // Update information text based on period
            let infoText = '';
            switch (period) {
                case 'daily':
                    infoText = `Daily serial for ${formatDate(date)}`;
                    break;
                case 'weekly':
                    infoText = `Weekly serial (week starting ${getMonday(date)})`;
                    break;
                case 'biweekly':
                    infoText = `15-day serial (${getBiweeklyPeriod(date)})`;
                    break;
                case 'monthly':
                    infoText = `Monthly serial for ${date.toLocaleString('default', { month: 'long', year: 'numeric' })}`;
                    break;
            }
            
            document.getElementById('serialInfo').textContent = infoText;
        }
        
        // Date helper functions
        function isSameDay(d1, d2) {
            return d1.toDateString() === d2.toDateString();
        }
        
        function isSameWeek(d1, d2) {
            const monday1 = getMonday(d1);
            const monday2 = getMonday(d2);
            return monday1.toDateString() === monday2.toDateString();
        }
        
        function isSameBiweekly(d1, d2) {
            const period1 = getBiweeklyPeriod(d1);
            const period2 = getBiweeklyPeriod(d2);
            return period1 === period2;
        }
        
        function isSameMonth(d1, d2) {
            return d1.getFullYear() === d2.getFullYear() && d1.getMonth() === d2.getMonth();
        }
        
        function getMonday(date) {
            const d = new Date(date);
            const day = d.getDay();
            const diff = d.getDate() - day + (day === 0 ? -6 : 1);
            return new Date(d.setDate(diff));
        }
        
        function getBiweeklyPeriod(date) {
            const day = date.getDate();
            return day <= 15 ? '1-15' : '16-' + new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
        }
        
        function formatDate(date) {
            return date.toLocaleDateString('en-US', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
            });
        }
        
        // Set default date to today
        document.getElementById('date').valueAsDate = new Date();
    </script>
</body>
</html>