<script language="JavaScript" type="text/javascript">
	
	var empdata = <?php echo $empdata;?>;
	$(document).ready(function($) {
		
 		$( "#salaryentry_name" ).autocomplete({
			
			minLength: 1,
			source: empdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('employenameentry_id').value = ui.item.labelval;
				 document.getElementById('salaryentry_salary').value = ui.item.monthlysalary;
				 document.getElementById('salaryentry_payablesalary').value = ui.item.payablesalary;
				 document.getElementById('pdue').value = ui.item.pdue;
				 document.getElementById('ldue').value = ui.item.ldue;
				 document.getElementById('salaryentry_perday').value = ui.item.perdaysalary;
				 document.getElementById('salaryentry_day').value = 0;
				calculate_total()
				return false;
			}
		});
		
 		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
		
	});
	
		
	function calculate_total(){
		
		var salaryentry_payablesalary = parseFloat(document.getElementById("salaryentry_payablesalary").value);
		if(salaryentry_payablesalary=='' || isNaN(salaryentry_payablesalary)){salaryentry_payablesalary = 0;}
		
		var salaryentry_advpay = parseFloat(document.getElementById("salaryentry_advpay").value);
		if(salaryentry_advpay=='' || isNaN(salaryentry_advpay)){salaryentry_advpay = 0;}
		
		var salaryentry_bonus = parseFloat(document.getElementById("salaryentry_bonus").value);
		if(salaryentry_bonus=='' || isNaN(salaryentry_bonus)){salaryentry_bonus = 0;}
		
		var salaryentry_abs = parseFloat(document.getElementById("salaryentry_abs").value);
		if(salaryentry_abs=='' || isNaN(salaryentry_abs)){salaryentry_abs = 0;}
			
		var salaryentry_perday = parseFloat(document.getElementById("salaryentry_perday").value);
		if(salaryentry_perday=='' || isNaN(salaryentry_perday)){salaryentry_perday = 0;}
		
		var salaryentry_day = parseFloat(document.getElementById("salaryentry_day").value);
		if(salaryentry_day=='' || isNaN(salaryentry_day)){salaryentry_day = 0;}
		
		var salaryentry_overtime = parseFloat(document.getElementById("salaryentry_overtime").value);
		if(salaryentry_overtime=='' || isNaN(salaryentry_overtime)){salaryentry_overtime = 0;}
		
		var pdue = parseFloat(document.getElementById("pdue").value);
		if(pdue=='' || isNaN(pdue)){pdue = 0;}
		
		var ldue = parseFloat(document.getElementById("ldue").value);
		if(ldue=='' || isNaN(ldue)){ldue = 0;}
		
		//absence
		//var salaryentry_abstotal = parseFloat(salaryentry_abs*salaryentry_perday);
		//document.getElementById('salaryentry_abstotal').value=	salaryentry_abstotal.toFixed(2);
		
 		var salaryentry_paid = parseFloat((salaryentry_perday*(salaryentry_day))+salaryentry_advpay+salaryentry_bonus+(salaryentry_perday*salaryentry_overtime))-(pdue+ldue);
		document.getElementById('salaryentry_paid').value=	salaryentry_paid.toFixed(2);
		
		var salaryentry_balance = parseFloat(salaryentry_payablesalary -( salaryentry_paid+(salaryentry_perday*salaryentry_abs))+salaryentry_bonus+(salaryentry_perday*salaryentry_overtime))-(pdue+ldue);
		document.getElementById('salaryentry_balance').value=	salaryentry_balance.toFixed(2);
		
		}
		
		function funcSaveBill1()
			{
				
				var varUserChoice;
				varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
				//alert(fRet); 
				if (varUserChoice == false)
				{
					alert ("Entry Not Saved.");
					return false;
				}
				else
				{
					alert ("Entry Saved.");
					document.frmsales.submit();
					//return true;
				}
			}		
	
</script>