<script language="JavaScript" type="text/javascript">
var itemdata = <?php echo $itemdata;?>;
	$(document).ready(function($) {
		
		$( ".itemname" ).autocomplete({
			
			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				var salesinvoice_ratearray = document.getElementsByName("salesinvoice_rate[]");
				salesinvoice_ratearray[indexpos].value = ui.item.salesitem_price;
				
				var salesinvoice_qtyarray = document.getElementsByName("salesinvoice_qty[]");
				salesinvoice_qtyarray[indexpos].value = 1;
				
				var salesinvoice_pccomissionarray = document.getElementsByName("salesinvoice_pccomission[]");
				salesinvoice_pccomissionarray[indexpos].value = ui.item.salesitem_pccommission;
				
				var salesinvoice_categoryarray = document.getElementsByName("salesinvoice_category[]");
				salesinvoice_categoryarray[indexpos].value = ui.item.salesitem_category;
				
				calculaterowtotal(indexpos);
				calculate_pctotal();
				
				return false;
			}
		});
		
		
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
	});
	
	function calculate_discountp(){
		
		var salesinvoice_discountparray = document.getElementsByName("salesinvoice_discountp[]");
		var salesinvoice_discarray = document.getElementsByName("salesinvoice_disc[]");
		var salesinvoice_ratearray = document.getElementsByName("salesinvoice_rate[]");
		var salesinvoice_qtyarray = document.getElementsByName("salesinvoice_qty[]");
		
		if(salesinvoice_discountparray.length>0){
			for(var p=0; p<salesinvoice_discountparray.length; p++){
				var salesinvoice_discountp = parseFloat(salesinvoice_discountparray[p].value);
				if(salesinvoice_discountp=='' || isNaN(salesinvoice_discountp)){salesinvoice_discountp = 0;}
				
				var salesinvoice_disc = parseFloat(salesinvoice_discarray[p].value);
				if(salesinvoice_disc=='' || isNaN(salesinvoice_disc)){salesinvoice_disc = 0;}
				if(salesinvoice_discountp>0){
					var salesinvoice_rate = parseFloat(salesinvoice_ratearray[p].value);
					if(salesinvoice_rate=='' || isNaN(salesinvoice_rate)){salesinvoice_rate = 0;}
					
					var salesinvoice_qty = salesinvoice_qtyarray[p].value;
					if(salesinvoice_qty=='' || isNaN(salesinvoice_qty)){salesinvoice_qty = 0;}
					
					var total = parseFloat(salesinvoice_rate*salesinvoice_qty);			
					var salesinvoice_disc = parseFloat(total*salesinvoice_discountp*0.01);
					
					salesinvoice_discarray[p].value = salesinvoice_disc.toFixed(2);
				}
				
				calculaterowtotal(p);
			}
		}
	}
	
	function calculaterowtotal(indexpos){
		if(indexpos=='all'){
			var salesinvoice_ratearray = document.getElementsByName("salesinvoice_rate[]");
			var salesinvoice_qtyarray = document.getElementsByName("salesinvoice_qty[]");
			var salesinvoice_discarray = document.getElementsByName("salesinvoice_disc[]");
			var salesinvoice_totalarray = document.getElementsByName("salesinvoice_total[]");
			
			if(salesinvoice_ratearray.length>0){
				for(var p=0; p<salesinvoice_ratearray.length; p++){
					var salesinvoice_rate = parseFloat(salesinvoice_ratearray[p].value);
					if(salesinvoice_rate=='' || isNaN(salesinvoice_rate)){salesinvoice_rate = 0;}
					
					var salesinvoice_qty = parseFloat(salesinvoice_qtyarray[p].value);
					if(salesinvoice_qty=='' || isNaN(salesinvoice_qty)){salesinvoice_qty = 0;}
					
					var total = parseFloat(salesinvoice_rate*salesinvoice_qty);
					
					var salesinvoice_disc = parseFloat(salesinvoice_discarray[p].value);
					if(salesinvoice_disc=='' || isNaN(salesinvoice_disc)){salesinvoice_disc = 0;}
					
					var total = parseFloat(total-salesinvoice_disc);
					
					salesinvoice_totalarray[p].value = total.toFixed(2);
				}
			}
			
		}
		else{
			var salesinvoice_ratearray = document.getElementsByName("salesinvoice_rate[]");
			var salesinvoice_rate = parseFloat(salesinvoice_ratearray[indexpos].value);
			if(salesinvoice_rate=='' || isNaN(salesinvoice_rate)){salesinvoice_rate = 0;}
			
			var salesinvoice_qtyarray = document.getElementsByName("salesinvoice_qty[]");
			var salesinvoice_qty = parseFloat(salesinvoice_qtyarray[indexpos].value);
			if(salesinvoice_qty=='' || isNaN(salesinvoice_qty)){salesinvoice_qty = 0;}
			
			var total = parseFloat(salesinvoice_rate*salesinvoice_qty);
			
			var salesinvoice_discarray = document.getElementsByName("salesinvoice_disc[]");
			var salesinvoice_disc = parseFloat(salesinvoice_discarray[indexpos].value);
			if(salesinvoice_disc=='' || isNaN(salesinvoice_disc)){salesinvoice_disc = 0;}
			
			var total = parseFloat(total-salesinvoice_disc);
			
			var salesinvoice_totalarray = document.getElementsByName("salesinvoice_total[]");
			salesinvoice_totalarray[indexpos].value = total.toFixed(2);
		}
		
		calculate_total();
	}
	
	function calculate_total(){
		
		//subtotal calculation
		var salesinvoice_subtotal = document.getElementById("salesinvoice_subtotal").value;
		if(salesinvoice_subtotal=='' || isNaN(salesinvoice_subtotal)){salesinvoice_subtotal = 0;}
		
		var salesinvoice_totaldisc = parseFloat(document.getElementById("salesinvoice_totaldisc").value);
		if(salesinvoice_totaldisc=='' || isNaN(salesinvoice_totaldisc)){salesinvoice_totaldisc = 0;}
		
		var salesinvoice_finaldisc = parseFloat(document.getElementById("salesinvoice_finaldisc").value);
		if(salesinvoice_finaldisc=='' || isNaN(salesinvoice_finaldisc)){salesinvoice_finaldisc = 0;}
		
		var salesinvoice_subtotalafterdisc = parseFloat(salesinvoice_subtotal-salesinvoice_totaldisc-salesinvoice_finaldisc);
		document.getElementById('salesinvoice_subtotalafterdisc').value= salesinvoice_subtotalafterdisc.toFixed(2);
		
		var salesinvoice_receiveamount = parseFloat(document.getElementById("salesinvoice_receiveamount").value);
		if(salesinvoice_receiveamount=='' || isNaN(salesinvoice_receiveamount)){salesinvoice_receiveamount = 0;}		
		
		var salesinvoicecollection_amount = parseFloat(document.getElementById("salesinvoicecollection_amount").value);
		if(salesinvoicecollection_amount=='' || isNaN(salesinvoicecollection_amount)){salesinvoicecollection_amount = 0;}
		
		var salesinvoice_due = parseFloat(document.getElementById("salesinvoice_due").value);
		if(salesinvoice_due=='' || isNaN(salesinvoice_due)){salesinvoice_due = 0;}
		
		//var salesinvoice_due = parseFloat(salesinvoice_subtotalafterdisc - salesinvoice_receiveamount-salesinvoicecollection_amount);
		//document.getElementById('salesinvoice_due').value=salesinvoice_due.toFixed(2);			
	
	var salesinvoice_currentdue = parseFloat(salesinvoice_due - salesinvoicecollection_amount  - salesinvoice_finaldisc);
		document.getElementById('salesinvoice_currentdue').value=salesinvoice_currentdue.toFixed(2);
		
	}
	
	function calculate_pctotal(){
		var salesinvoice_totalpccomission = 0;
		var salesinvoice_pccomissionarray = document.getElementsByName("salesinvoice_pccomission[]");
		if(salesinvoice_pccomissionarray.length>0){
			for(var p=0; p<salesinvoice_pccomissionarray.length; p++){
				var salesinvoice_pccomission = parseFloat(salesinvoice_pccomissionarray[p].value);
				if(salesinvoice_pccomission=='' || isNaN(salesinvoice_pccomission)){salesinvoice_pccomission = 0;}
				salesinvoice_totalpccomission = parseFloat(salesinvoice_totalpccomission+salesinvoice_pccomission);
			}
		}
		
		document.getElementById("salesinvoice_totalpccomission").value = salesinvoice_totalpccomission;
		
	}
	
	function check_particular(){
		/*var particular_idlistarray = new Array();
		var particular_id = document.getElementsByName('particular_id[]');
		var particular_count = particular_id.length;
		var particular_priceid = document.getElementsByName('particular_price[]');
		var particular_qtyid = document.getElementsByName('particular_qty[]');
			
		var error_messageid = document.getElementById('errmsg_particular_id');
		error_messageid.innerHTML = '';
		
		for(i = 0; i < particular_count; i++) {
												
			if(particular_id[i].value=='' || particular_id[i].value==0){
				error_messageid.innerHTML = 'Missing Particular Name '+parseInt(i+1);
				particular_id[i].focus();
				returnvalue = false;
			}
			
			if(particular_idlistarray.length>0 && particular_idlistarray.indexOf(particular_id[i].value) != -1){
				error_messageid.innerHTML = 'Dupplicate Particular Name '+i;
				particular_id[i].focus();
				return false;
			}
			else{
				particular_idlistarray[i] = particular_id[i].value;
			}
			
			var particular_priceval = parseInt(particular_priceid[i].value);
			if(isNaN(particular_priceval) || particular_priceval==''){particular_priceval = 0;}
			if(particular_priceval==0){
				error_messageid.innerHTML = 'Missing Price '+Math.floor(i+1);
				particular_priceid[i].focus();
				return false;
			}
										
			var particular_qtyval = parseInt(particular_qtyid[i].value);
			if(isNaN(particular_qtyval) || particular_qtyval==''){particular_qtyval = 0;}							
			if(particular_qtyval==0){
				error_messageid.innerHTML = 'Missing QTY '+Math.floor(i+1);
				particular_qtyid.focus();
				return false;
			}
		}*/
		return true;
	}
	function addnew_particularrow(animate) {
		if(check_particular()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" align=\"left\" width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"4\">"+
							'<tr>'+
								'<td align="right">Item Name</td>'+
								'<td> <input type="text" name="salesinvoice_item[]" value="" class="tdclass itemname"/></td>'+
								'<input type="hidden" name="salesinvoice_category[]" value="" class="tdclass"  />'+
								'<td align="right">Rate</td>'+
								"<td> <input type=\"text\" name=\"salesinvoice_rate[]\"  id=\"salesinvoice_rate\" value=\"\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/></td>"+											 
								'<td align="right">Qty</td>'+
								"<td> <input type=\"text\" name=\"salesinvoice_qty[]\"   id=\"salesinvoice_qty\" value=\"\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/></td>"+
								'<td align="right">Disc%</td>'+
								'<td> <input type="text" name="salesinvoice_discountp[]" value="" class="tdclasssale" onKeyUp="calculate_discountp();"/></td>'+
								'<td align="right">Disc</td>'+
								"<td> <input type=\"text\" name=\"salesinvoice_disc[]\" value=\"\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\" /></td>"+
								'<td align="right">P.C</td>'+
								'<td> <input type="text" name="salesinvoice_pccomission[]" value="" class="tdclasssale" onKeyUp="calculate_pctotal();"  /></td>'+
								'<td align="right">Total</td>'+
								'<td> <input type="text" readonly name="salesinvoice_total[]"  id="salesinvoice_total" value="" class="tdclasssale"  /></td>'+												
								'<td>'+
								 "<input type=\"button\" value=\"Cancel\" onClick=\"deletethislistrow('particularlistrowno"+particular_rowcount+"');\" class=\"tdclasssale\"  />"+
								'</td>'+
							  '</tr>'+
						"</table>";
						
			var $newparticularlist = $("<li></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(200); 
			else 
			   $newparticularlist.show();   
			
			$( ".itemname" ).autocomplete({			
				minLength: 1,
				source: itemdata,
				focus: function( event, ui ) {
					//$( "#search_item_number" ).val( ui.item.labelval );
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					
					var salesinvoice_ratearray = document.getElementsByName("salesinvoice_rate[]");
					salesinvoice_ratearray[indexpos].value = ui.item.salesitem_price;
					
					var salesinvoice_qtyarray = document.getElementsByName("salesinvoice_qty[]");
					salesinvoice_qtyarray[indexpos].value = 1;
					
					var salesinvoice_pccomissionarray = document.getElementsByName("salesinvoice_pccomission[]");
					salesinvoice_pccomissionarray[indexpos].value = ui.item.salesitem_pccommission;
					
					var salesinvoice_categoryarray = document.getElementsByName("salesinvoice_category[]");
					salesinvoice_categoryarray[indexpos].value = ui.item.salesitem_category;
	
					calculaterowtotal(indexpos);
					calculate_pctotal();
					
					return false;
				}
			});						
		}
	}
	
	function deletethislistrow(tableidname){
		$("#"+tableidname).parent("li").slideUp(200, function() {
			$(this).remove();
			calculaterowtotal('all');
		});
	}
</script>