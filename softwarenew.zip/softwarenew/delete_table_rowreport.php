<?php
session_start();
if(isset($_GET['idvalue'])){	
 	
	$idvalue = $_GET['idvalue'];
	if($idvalue>0){
		require('labdd.php');
		
		$str2 = "DELETE from labreport where labreport_id = '$idvalue'";
		$userquery = mysqli_query($conn, $str2);
		
		$str = "DELETE from labreport_details where labreport_id = '$idvalue'";
		$userquery = mysqli_query($conn, $str);
 		
		if($userquery){			
			header("location:index.php?p=zz_statementbyreport&message=remove-successfully");			
		}
		else{
			header("location:index.php?p=$returnpage&message=couldnotremove");
		}
	}
	else{
		header("location:index.php?p=zz_statementbyreport&message=incorrect_id");
	}
}
?>
