<script language="JavaScript" type="text/javascript">
	
	var itemdata = <?php echo $itemdata;?>;
	var patientdata = <?php echo $patientdata;?>;
	var drdata = <?php echo $drdata;?>;
	//var testdata = <?php //echo $testdata;?>;
	$(document).ready(function($) {
		//document.getElementsByName("labreport_item[]")[0].focus();

		$( ".itemname" ).autocomplete({
			
			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				var labitem_idarray = document.getElementsByName("labitem_id[]");
				labitem_idarray[indexpos].value = ui.item.labitem_id;
				
				var labreport_categoryarray = document.getElementsByName("labreport_category[]");
				labreport_categoryarray[indexpos].value = ui.item.labitem_category;
				
				var labreport_unitarray = document.getElementsByName("labreport_unit[]");
				labreport_unitarray[indexpos].value = ui.item.labitem_unit;
				
				var labreport_refvaluearray = document.getElementsByName("labreport_refvalue[]");
				labreport_refvaluearray[indexpos].value = ui.item.labitem_refvalue;
				
				return false;
			}
		});
		
		
		$( "#labreport_labinvoiceid" ).autocomplete({
			
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('labreport_patient').value = ui.item.labelval;
				 document.getElementById('labreport_age').value = ui.item.labinvoice_age;
				 document.getElementById('labreport_patientid').value = ui.item.labinvoice_patientid;
				 document.getElementById('labreport_gender').value = ui.item.labinvoice_gender;
				 document.getElementById('labreport_mobile').value = ui.item.labinvoice_mobile;
				 document.getElementById('labreport_address').value = ui.item.labinvoice_address;
				 document.getElementById('labreport_doctor').value = ui.item.labinvoice_doctor;
				
				return false;
			}
		});
		
		$( "#labreport_doctor" ).autocomplete({
			
			minLength: 1,
			source: drdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('labreport_doctor').value = ui.item.labelval;
				 document.getElementById('labreport_doctor').value = ui.item.doctor_name;
				return false;
			}
		});
		
		
		
		
		/*$( "#reportname" ).autocomplete({
			
			minLength: 1,
			source: testdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('reportname').value = ui.item.labelval;
				 document.getElementById('reportname').value = ui.item.category;
				 document.getElementById('sample').value = ui.item.sample;
				 document.getElementById('method').value = ui.item.method;
				return false;
			}
		});*/
		
		
	});
	
	function check_particular(){}
	function addnew_particularrow(animate) {
		if(check_particular()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" style=\"BORDER-COLLAPSE: collapse; border:2px solid #FFF\" bgcolor=\"#c0d2ff\" class=\"tableclass\" cellpadding=\"1\">"+
							'<tr align=\"center\">'+
								'<td><input type="text" name="labreport_item[]" class="tdclass itemname labreport_item"/>'+
								'<input type="hidden" name="labitem_id[]" id="labitem_id" class="tdclass itemname" />'+
								'<input type="hidden" name="labreport_category[]" class="tdclass" /></td>'+
								"<td><input type=\"text\" size=\"12\" name=\"labreport_result[]\" id=\"labreport_result\"/></td>"+											 								"<td> <input type=\"text\" size=\"12\" name=\"labreport_unit[]\"  id=\"labreport_unit\"/></td>"+
								"<td><textarea name=\"labreport_refvalue[]\" id=\"labreport_refvalue\"></textarea></td>"+											 								
								'<td>'+
								 "<input type=\"button\" value=\"Cancel\" onClick=\"deletethislistrow('particularlistrowno"+particular_rowcount+"');\" class=\"tdclasssale\"  />"+
								'</td>'+
							  '</tr>'+
						"</table>";
						
			var $newparticularlist = $("<li></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(200); 
			else 
			   $newparticularlist.show();   
			
			document.getElementsByName("labreport_item[]")[parseInt(particular_rowcount-1)].focus();
			
			$( ".itemname" ).autocomplete({			
				minLength: 1,
				source: itemdata,
				focus: function( event, ui ) {
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					
					var labitem_idarray = document.getElementsByName("labitem_id[]");
					labitem_idarray[indexpos].value = ui.item.labitem_id;
			
					var labreport_categoryarray = document.getElementsByName("labreport_category[]");
					labreport_categoryarray[indexpos].value = ui.item.labitem_category;
					
					var labreport_unitarray = document.getElementsByName("labreport_unit[]");
					labreport_unitarray[indexpos].value = ui.item.labitem_unit;
					
					var labreport_refvaluearray = document.getElementsByName("labreport_refvalue[]");
					labreport_refvaluearray[indexpos].value = ui.item.labitem_refvalue;
					
					return false;
				}
			});						
		}
	}
	
	function deletethislistrow(tableidname){
		$("#"+tableidname).parent("li").slideUp(200, function() {
			$(this).remove();
			
		});
	}
</script>