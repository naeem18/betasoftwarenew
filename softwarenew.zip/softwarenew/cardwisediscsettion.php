<style>
.discount-card{
    width:95%;
    margin:auto;
    background:#fff;
    border-radius:10px;
    box-shadow:0 2px 10px rgba(0,0,0,.15);
    padding:15px;
}

.discount-title{
    text-align:center;
    font-size:22px;
    font-weight:bold;
    color:#0d6efd;
    margin-bottom:15px;
}

.discount-table{
    width:100%;
    border-collapse:collapse;
}

.discount-table th{
    background:#0d6efd;
    color:#fff;
    padding:10px;
    text-align:center;
}

.discount-table td{
    padding:8px;
    border:1px solid #ddd;
}

.discount-table tr:nth-child(even){
    background:#f8f9fa;
}

.discount-table tr:hover{
    background:#eef6ff;
}

.inputbox{
    width:98%;
    padding:6px;
    border:1px solid #ccc;
    border-radius:4px;
}

.discountbox{
    width:80px;
    padding:6px;
    text-align:center;
    border:1px solid #ccc;
    border-radius:4px;
}

.savebtn{
    background:#198754;
    color:#fff;
    border:none;
    padding:10px 25px;
    border-radius:5px;
    cursor:pointer;
    font-weight:bold;
}

.savebtn:hover{
    background:#157347;
}
</style>

<article>

<div class="discount-card">

<h3 class="discount-title">🪪 ID Card Wise Discount Setting</h3>

<content>

<?php
if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
    echo "<h3 style='color:red;text-align:center'>You have missing something</h3>";
}
elseif(isset($_GET['message']) && $_GET['message']=='duplicatename'){
    echo "<h3 style='color:red;text-align:center'>This Item already exists.</h3>";
}
elseif(isset($_GET['message']) && $_GET['message']=='insert-successfully'){
    echo "<h3 style='color:green;text-align:center'>
    Information inserted successfully.
    <br><br>
    <input type='button' value='Print' onclick='PrintDiv();'>
    </h3>";
}
?>

<form action="save_idinfoentry.php" method="post" enctype="multipart/form-data">

<table border="0" width="100%" style="margin-bottom:15px;">
<tr>
    <td width="120"><b>Card Type</b></td>
    <td>
        <select style="width:200px;padding:6px;" id="type" name="type">
            <option value="">Select Type</option>
            <?php
            $doyouknowarray = array('VIP','VVIP','Director');
            foreach($doyouknowarray as $singleoption){
                $selected='';
                if($opregistration_gender=="$singleoption"){
                    $selected=' selected="selected"';
                }
                echo "<option value=\"$singleoption\"$selected>$singleoption</option>";
            }
            ?>
        </select>
    </td>
</tr>
</table>

<table class="discount-table">

<tr>
    <th width="70%">🧪 Test Group</th>
    <th width="30%">💰 Discount (%)</th>
</tr>

<?php
$sqlcategory = "select * from category
                where section='Lab Item Section'
                order by auto_number asc";

$categoryquery = mysqli_query($conn,$sqlcategory);

if($categoryquery && mysqli_num_rows($categoryquery)>0){

while($categoryrow=mysqli_fetch_array($categoryquery))
{
    $category=$categoryrow['category'];
?>

<tr>
    <td>
        <input type="text"
               readonly
               name="category[]"
               value="<?php echo $category;?>"
               class="inputbox">
    </td>

    <td align="center">
        <input type="number"
               name="discp[]"
               value=""
               class="discountbox"> %
    </td>
</tr>

<?php
}
}
?>

</table>

<div style="text-align:center;margin-top:15px;">
    <input type="submit" value="💾 Save Discount" class="savebtn">
</div>

</form>

</content>


<hr style="margin:20px 0;">

<h3 style="
    background:#0d6efd;
    color:#fff;
    padding:10px;
    text-align:center;
    border-radius:5px;
">
📋 Existing CRM Test Discount List
</h3>

<table class="discount-table">
    <tr>
        <th width="5%">SL</th>
        <th width="20%">Card Type</th>
        <th width="45%">Test Group</th>
        <th width="15%">Discount %</th>
        <th width="15%">Action</th>
    </tr>

<?php

$sl = 0;

$sql = "SELECT labtestcrmdiscid,
               cardtype,
               labitem_group,
               discount
        FROM crmtestdisc
        ORDER BY cardtype, labitem_group";

$query = mysqli_query($conn,$sql);

if($query && mysqli_num_rows($query)>0){

    while($row = mysqli_fetch_assoc($query)){

        $sl++;

        $labtestcrmdiscid = $row['labtestcrmdiscid'];
?>

<?php

$cardtype = $row['cardtype'];

if($cardtype=='VIP'){
    $rowcolor = '#FFF3CD';      // Light Yellow
}
elseif($cardtype=='VVIP'){
    $rowcolor = '#F8D7DA';      // Light Red/Pink
}
elseif($cardtype=='General'){
    $rowcolor = '#D1E7DD';      // Light Green
}
else{
    $rowcolor = '#FFFFFF';
}

?>

<tr style="background:<?php echo $rowcolor;?>;">
    <td align="center"><?php echo $sl;?></td>

    <td>
        <b><?php echo $row['cardtype'];?></b>
    </td>

    <td>
        <?php echo $row['labitem_group'];?>
    </td>

    <td align="center">
        <?php echo $row['discount'];?>%
    </td>

    <td align="center">
        <a href="index.php?p=crmtestdisc_edit&labtestcrmdiscid=<?php echo $labtestcrmdiscid;?>">
            ✏️ Edit
        </a>
    </td>
</tr>

<?php
    }
}
else{
?>
<tr>
    <td colspan="5" align="center">
        No Discount Setup Found
    </td>
</tr>
<?php
}
?>

</table>
</div>

</article>