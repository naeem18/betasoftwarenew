<?php
session_start();
if(isset($_GET['table_name'])){

	$table_name = $_GET['table_name'];
	
	if($table_name=='expense'){
		$table_idname = 'auto_number';
	}
	elseif($table_name=='doctorentry'){
		$table_idname = 'doctor_id';
	}
	elseif($table_name=='callentry'){
		$table_idname = 'auto_number';
	}
	elseif($table_name=='category'){
		$table_idname = 'auto_number';
	}
	elseif($table_name=='labinvoicedetails'){
		$table_idname = 'auto_number';
	}
	elseif($table_name=='labinvoicecollection'){
		$table_idname = 'auto_number';
	}
	elseif($table_name=='hospitalinvoicecollection'){
		$table_idname = 'auto_number';
	}
	
	elseif($table_name=='master_menumain'){
		$table_idname = 'auto_number';
	}
	
	elseif($table_name=='master_menusub'){
		$table_idname = 'auto_number';
	}
	else{
	$table_idname = $table_name.'_id';
	}
	
	
	$idvalue = $_GET['idvalue'];
	$returnpage = $_GET['return_page'];
	
	if($table_name !='' && $idvalue>0){
		require('labdd.php');
		
		$str = "DELETE from `$table_name` where `$table_idname` = '$idvalue'";
		//echo $str;
		$userquery = mysqli_query($conn, $str);
		if($userquery){			
			header("location:index.php?p=$returnpage&message=remove-successfully");			
		}
		else{
			header("location:index.php?p=$returnpage&message=couldnotremove");
		}
	}
	else{
		header("location:index.php?p=$returnpage&message=incorrect_id");
	}
}
?>