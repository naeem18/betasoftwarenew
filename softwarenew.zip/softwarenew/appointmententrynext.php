<article class="bottomcontent">
     <content>
        <?php
        if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
            echo "<p class=\"red12bold\">You have missing Something</p>";
        }
		 if(isset($_GET['message']) && $_GET['message']=='update-successfully'){
            echo "<p class=\"red12bold\">updated successfully</p>";
        }
       
         
           		
 		 $appointmententry_id = 0;
		 $note = '';
		 if(isset($_GET['appointmententry_id'])){
          	$appointmententry_id = $_GET['appointmententry_id'];
            $appointmententry_sql = "select appointmententry_id, note from appointmententry where appointmententry_id = $appointmententry_id";
            $appointmententryquery = mysqli_query($conn, $appointmententry_sql);
            if($appointmententryquery && mysqli_num_rows($appointmententryquery)>0){
                while($page_inforow = mysqli_fetch_array($appointmententryquery)){
                   $appointmententry_id = $page_inforow['appointmententry_id'];
                    $note = $page_inforow['note'];
					
                 }
            }
        }
        ?>        
<style>
.form-box {
    width: 420px;
    margin: 40px auto;
    background: #ffffff;
    padding: 25px 30px;
    border-radius: 12px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.08);
    font-family: Arial;
}

.form-box h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #333;
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    font-size: 14px;
    color: #555;
}

.form-group input,
.form-group textarea {
    width: 100%;
    padding: 8px 10px;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 14px;
}

.form-group textarea {
    height: 90px;
    resize: none;
}

.form-actions {
    display: flex;
    justify-content: space-between;
    margin-top: 20px;
}

.btn {
    padding: 8px 16px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
}

.btn-save {
    background: #28a745;
    color: #fff;
}

.btn-cancel {
    background: #dc3545;
    color: #fff;
}

.btn:hover {
    opacity: 0.9;
}
</style>


<form action="save_appointmententryapp.php" 
      name="frmcontact" 
      onsubmit="return checkcontactform();" 
      method="post" 
      enctype="multipart/form-data">

<div class="form-box">

    <h2>Next Appointment</h2>

    <input type="hidden" name="user" value="<?php echo $_SESSION['fullname'];?>" />
    <input type="hidden" name="appointmententry_id" value="<?php echo $appointmententry_id;?>" />

    <!-- Date -->
    <div class="form-group">
        <label>Next Appointment Date</label>
        <div style="display:flex; gap:5px;">
            <input type="text" name="NADate" id="NADate" value="<?php echo date('Y-m-d');?>" />
            <img src="images/cal.gif" onclick="NewCssCal('NADate')" style="cursor:pointer; height:32px;">
        </div>
    </div>

    <!-- Note -->
    <div class="form-group">
        <label>Note</label>
        <textarea name="note" id="note"></textarea>
    </div>

    <!-- Buttons -->
    <div class="form-actions">
        <button type="submit" name="submit" class="btn btn-save">Save</button>
        <a href="index.php?p=statementbyappointmententry">
            <button type="button" class="btn btn-cancel">Cancel</button>
        </a>
    </div>

</div>

</form>         

</content>
</article>