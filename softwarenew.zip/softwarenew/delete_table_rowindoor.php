<?php
session_start();
if(isset($_GET['idvalue'])){	
	
$idvalue = $_GET['idvalue'];
if($idvalue>0){
	require('labdd.php');
	
	$str = "UPDATE hospitalinvoice SET status = 'Deleted'
				  where hospitalinvoice_id = '$idvalue'";
	$userquery = mysqli_query($conn, $str);
	
	$str1 = "UPDATE hospitalinvoicedetails SET  status = 'Deleted'
							where hospitalinvoice_id = '$idvalue'";
	$userquery = mysqli_query($conn, $str1);
	
	$str2 = "UPDATE dailytransection_lab SET  status = 'Deleted'
		 where section='H Cash' AND labinvoice_id = '$idvalue'";
	$userquery = mysqli_query($conn, $str2);

	if($userquery){			
		header("location:index.php?p=statementbyhospitalinvoice&message=remove-successfully");			
		}
	else{
		header("location:index.php?p=$returnpage&message=couldnotremove");
		}
	 }
	else{
		header("location:index.php?p=statementbyhospitalinvoice&message=incorrect_id");
		}
	}
?>