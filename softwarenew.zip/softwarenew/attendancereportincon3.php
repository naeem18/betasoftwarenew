<?php
// Database connection (update with your credentials)
$host = 'localhost';
$user = 'root';
$pass = 'nazirnipaarny';
$db = 'aluminium';
$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Initialize search string
$searchstr = '';
$transactiondatefrom = date('Y-m-d', strtotime('-1 month'));
$transactiondateto = date('Y-m-d');

// Process form input
if (isset($_REQUEST['ADate1']) && $_REQUEST['ADate1'] != '' && isset($_REQUEST['ADate2']) && $_REQUEST['ADate2'] != '') {
    $transactiondatefrom = $_REQUEST['ADate1'];
    $transactiondateto = $_REQUEST['ADate2'];

    $e_id = isset($_REQUEST['e_id']) ? $_REQUEST['e_id'] : '';
    $name = isset($_REQUEST['name']) ? $_REQUEST['name'] : '';

    if ($name != '') {
        $searchstr .= " AND name LIKE '%" . mysqli_real_escape_string($conn, $name) . "%'";
    } elseif ($e_id != '') {
        $searchstr .= " AND e_id LIKE '%" . mysqli_real_escape_string($conn, $e_id) . "%'";
    }
}

// Calculate date range
$datetime1 = new DateTime($transactiondatefrom);
$datetime2 = new DateTime($transactiondateto);
$interval = $datetime1->diff($datetime2);
$totaldays = $interval->format('%a');

if ($datetime1 > $datetime2) {
    // Swap dates if they're in wrong order
    $temp = $transactiondatefrom;
    $transactiondatefrom = $transactiondateto;
    $transactiondateto = $temp;
}

// Get all employees with their salary information
$employees = array();
$sql = "SELECT e_id, name, salary FROM employee ORDER BY name ASC";
$result = mysqli_query($conn, $sql);

while ($row = mysqli_fetch_assoc($result)) {
    $employees[$row['e_id']] = array(
        'name' => $row['name'],
        'salary' => $row['salary'],
        'days_present' => 0,
        'total_deduction' => 0,
        'total_receivable' => 0,
        'total_overtime_hours' => 0,
        'overtime_payment' => 0,
		'entry_times' => array(),  // To store entry times for each day
        'exit_times' => array()   
    );
}

// Process attendance for each day for all employees
for ($i = 0; $i <= $totaldays; $i++) {
    $currentDate = date('Y-m-d', strtotime($transactiondatefrom . " + $i days"));
    $newfromdate = $currentDate . ' 00:00:00';
    $newtodate = $currentDate . ' 23:59:59';

    // Get earliest entry and latest exit
    $sql = "SELECT e_id, name, 
                   MIN(entry_time) AS entry_time, 
                   MAX(CASE WHEN in_out = 2 THEN entry_time END) AS exit_time 
            FROM machine_data 
            WHERE entry_date BETWEEN '$newfromdate' AND '$newtodate' 
            $searchstr
            GROUP BY e_id, name";
			
    		$attendanceResult = mysqli_query($conn, $sql);

    while ($attendance = mysqli_fetch_assoc($attendanceResult)) {
        $e_id = $attendance['e_id'];
        if (!isset($employees[$e_id])) {
            continue;
        }

        $employee = &$employees[$e_id];
        $employee['days_present']++;
		
		// Store entry and exit times
		$employee['entry_times'][$currentDate] = date('H:i:s', strtotime($attendance['entry_time']));
		if (!empty($attendance['exit_time'])) {
			$employee['exit_times'][$currentDate] = date('H:i:s', strtotime($attendance['exit_time']));
		} else {
			$employee['exit_times'][$currentDate] = 'N/A';
		}
		
        // Calculate daily salary
        $daily_salary = $employee['salary'] / 26;

        // Calculate late minutes (assuming 9 AM start + 15 min grace)
        $entry_time = strtotime($attendance['entry_time']);
        $start_time = strtotime('09:00:00');
        $late_minutes = max(0, (($entry_time - $start_time) / 60) - 15);

        if ($late_minutes > 0) {
            // Calculate deduction (11 working hours = 660 minutes)
            $minute_rate = $daily_salary / 660;
            $deduction = $late_minutes * $minute_rate;

            $employee['total_deduction'] += $deduction;
            $employee['total_receivable'] += ($daily_salary - $deduction);
        } else {
            $employee['total_receivable'] += $daily_salary;
        }

        // Calculate overtime (assuming normal end time 18:00)
        if (!empty($attendance['exit_time'])) {
            $exit_time = strtotime($attendance['exit_time']);
            $end_time = strtotime('20:15:00');

            $overtime_minutes = max(0, ($exit_time - $end_time) / 60);
            if ($overtime_minutes > 0) {
                $overtime_hours = $overtime_minutes / 60;
                $employee['total_overtime_hours'] += $overtime_hours;

                // Overtime pay rate: 1.5 times hourly rate
                $hourly_rate = $daily_salary / 11; // 11 working hours/day
                $overtime_rate = $hourly_rate * 1.5;
                $overtime_payment = $overtime_hours * $overtime_rate;

                $employee['overtime_payment'] += $overtime_payment;
            }
        }
    }
}
?>

<!-- Search Form -->
<table width="100%" border="0" cellspacing="0" cellpadding="2">
<tr>
<td valign="top" align="center">
<form name="cbform1" method="post" action="">
<table width="100%" border="1" align="center" cellpadding="2" cellspacing="0" bordercolor="#666666" style="border-collapse: collapse">
<tbody>
<tr bgcolor="#011E6A">
<td colspan="10" bgcolor="#CCCCCC" align="center"><strong>Search Date Wise</strong></td>
</tr>           
<tr>
<td>Date From:</td>
<td>
<input name="ADate1" id="ADate1" style="border: 1px solid #001E6A" value="<?php echo htmlspecialchars($transactiondatefrom); ?>" size="10" readonly />
<img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
</td>
<td>Date To:</td>
<td>
<input name="ADate2" id="ADate2" style="border: 1px solid #001E6A" value="<?php echo htmlspecialchars($transactiondateto); ?>" size="10" readonly />
<img src="images/cal.gif" onClick="javascript:NewCssCal('ADate2')" style="cursor:pointer"/>
</td>
<td>By ID No.</td>
<td><input size="9" type="text" name="e_id" id="e_id"></td>
<td>By Name</td>
<td><input size="9" type="text" name="name" id="name"></td>
<td><input type="submit" value="Search"></td>
</tr>
</tbody>
</table>
</form>

<!-- Report Table -->
<table width="100%" border="1" cellpadding="2" cellspacing="0" bordercolor="#666666" style="border-collapse: collapse">
<tr bgcolor="#CCCCCC">
<th>Emp ID</th>
<th>Name</th>
<th>Entry Time</th>
<th>Exit Time (20:16:00 to 21:30:00)</th>
<th>Salary</th>
<th>Days Present</th>
<th>Deduction</th>
<th>Receivable Salary</th>
<th>Overtime Hours</th>
<th>Overtime Payment</th>
<th>Total Payable</th>


</tr>

<?php
foreach ($employees as $e_id => $emp) {
    $total_payable = $emp['total_receivable'] + $emp['overtime_payment'];
	// Format entry and exit times for display
     
	// Get first entry time and last exit time
   	$first_entry = !empty($emp['entry_times']) ? reset($emp['entry_times']) : 'N/A';
    $last_exit = !empty($emp['exit_times']) ? end($emp['exit_times']) : 'N/A';
	
    echo "<tr>
        <td>{$e_id}</td>
        <td>{$emp['name']}</td>
		
		<td>{$first_entry}</td>
        <td>{$last_exit}</td>
         
		
        <td>" . number_format($emp['salary'], 2) . "</td>
        <td>{$emp['days_present']}</td>
        <td>" . number_format($emp['total_deduction'], 2) . "</td>
        <td>" . number_format($emp['total_receivable'], 2) . "</td>
        <td>" . number_format($emp['total_overtime_hours'], 2) . "</td>
        <td>" . number_format($emp['overtime_payment'], 2) . "</td>
        <td>" . number_format($total_payable, 2) . "</td>
    </tr>";
}
?>
</table>
</td></tr></table>
