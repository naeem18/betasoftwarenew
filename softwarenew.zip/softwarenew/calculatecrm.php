<script language="JavaScript" type="text/javascript">
	var itemdataarray = <?php echo $itemdataarray;?>;
	var itemdata = <?php echo $itemdata;?>;
	var apdata = <?php echo $apdata;?>;
	var iddata = <?php echo $iddata;?>;
	var empdata = <?php echo $empdata;?>;
	var patientdata = <?php echo $patientdata;?>;
	var patientdatainvoice = <?php echo $patientdatainvoice;?>;
	var pcdata = <?php echo $pcdata;?>;
	var drdata = <?php echo $drdata;?>;
	
	var itemarraydata = itemdataarray;
	$(document).ready(function($){
		document.getElementsByName("labinvoice_mobile")[0].focus();

		$( ".itemname" ).autocomplete({
			
			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
 				return false;
			},
			select: function( event, ui ) {
				
 				//Start Duplicate Item Entry Check//
				var itemIdArray = document.getElementsByName("labitem_id[]");
				var itemQtyArray = document.getElementsByName("labinvoice_qty[]");
					//==============================Check Duplicate Id=============================//
					if(itemIdArray.length>0){
						for(var l=0; l<itemIdArray.length; l++){
							var olditem_id = itemIdArray[l].value;
							if(olditem_id !=''){
								if( ui.item.labitem_id == olditem_id){
									/*var qtyVal = parseInt(itemQtyArray[l].value);
									if(qtyVal=='' || isNaN(qtyVal)){qtyVal = 0;}
									qtyVal++;
									itemQtyArray[l].value = qtyVal;
									calculateCurrentRowTotal(l);*/
									$(this).val('');
									$(this).focus();
									alert("Duplicate item found.");
									return false;
								}
							}
						}
					}
					
				//End Duplicate Item Entry Check//
  				
 				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				var labitem_idarray = document.getElementsByName("labitem_id[]");
				labitem_idarray[indexpos].value = ui.item.labitem_id;
				
				var labinvoice_itemarray = document.getElementsByName("labinvoice_item[]");
				labinvoice_itemarray[indexpos].value = ui.item.labitem_name;

				var labinvoice_ratearray = document.getElementsByName("labinvoice_rate[]");
				labinvoice_ratearray[indexpos].value = ui.item.labitem_price;

				var labinvoice_qtyarray = document.getElementsByName("labinvoice_qty[]");
				labinvoice_qtyarray[indexpos].value = 1;
				
				var labinvoice_gpccomissionarray = document.getElementsByName("labinvoice_gpccomission[]");
				labinvoice_gpccomissionarray[indexpos].value = ui.item.labitem_pccommission;
 
				var labinvoice_drcomissionarray = document.getElementsByName("labinvoice_drcomission[]");
				labinvoice_drcomissionarray[indexpos].value = ui.item.labitem_drcommission;

				var labinvoice_grouparray = document.getElementsByName("labinvoice_group[]");
				labinvoice_grouparray[indexpos].value = ui.item.labitem_group;
				
						// VIP Card Discount Auto Apply
						var allowedCards = ['VIP', 'VVIP', 'DIRECTOR'];
 						if (allowedCards.includes(currentCardType)) {
 							var itemGroup = ui.item.labitem_group;
 							if (
								crmtestdisc[currentCardType] &&
								crmtestdisc[currentCardType][itemGroup]
							) {
						
								document.getElementsByName("labinvoice_discountp[]")[indexpos].value =
									crmtestdisc[currentCardType][itemGroup];
						
								calculate_discountp();
							}
						}
				
				var labinvoice_categoryarray = document.getElementsByName("labinvoice_category[]");
				labinvoice_categoryarray[indexpos].value = ui.item.labitem_category;
				
				var reportnamearray = document.getElementsByName("reportname[]");
				reportnamearray[indexpos].value = ui.item.reportname;
				
			 

				/*var labitem_reagentarray = document.getElementsByName("labitem_reagent[]");
				labitem_reagentarray[indexpos].value = ui.item.labitem_reagent;
				
				var labitem_reagentidarray = document.getElementsByName("labitem_reagentid[]");
				labitem_reagentidarray[indexpos].value = ui.item.labitem_reagentid;
				
 				var reagentqtyarray = document.getElementsByName("reagentqty[]");
				reagentqtyarray[indexpos].value = ui.item.reagentqty;*/

 
				calculaterowtotal(indexpos);
				//calculate_pctotal();
				//calculate_drtotal();
				addnew_particularrow(true);
				return false;
			}
		});

		$( "#searchpatientid" ).autocomplete({
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
 				 document.getElementById('labinvoice_patient').value = ui.item.labelval;
				 document.getElementById('searchpatientid').value = 'Success';
				 document.getElementById('labinvoice_patientid').value = ui.item.opregistration_id;
				 document.getElementById('labinvoice_patientcode').value = ui.item.opregistration_code;
				 document.getElementById('labinvoice_age').value = ui.item.opregistration_age;
				 document.getElementById('age').value = ui.item.age;
				 document.getElementById('labinvoice_gender').value = ui.item.opregistration_gender;
				 document.getElementById('labinvoice_mobile').value = ui.item.opregistration_mobile;
				 document.getElementById('labinvoice_address').value = ui.item.opregistration_address;
				 document.getElementById('labinvoice_pc').value = ui.item.pcname;
				 document.getElementById('labinvoice_mpo').value = ui.item.mpo;
				 document.getElementById('bar').value = ui.item.bar;
				 document.getElementById('labinvoice_description').value = ui.item.remark;
				 document.getElementById('labinvoice_ward').value = ui.item.ward;
				 document.getElementById('labinvoice_previousdue').value = ui.item.lab_due;
				 document.getElementById('previous_labinvoice_totalpccomission').value = ui.item.labinvoice_totalpccomission;
 				return false;
			}
		});

		//From ID Holder
		$( "#labinvoice_address" ).autocomplete({
 			minLength: 1,
			source: iddata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				 document.getElementById('labinvoice_patient').value = ui.item.labelval;
				 document.getElementById('labinvoice_age').value = ui.item.opregistration_age;
				 document.getElementById('bar').value = ui.item.bar;
				 document.getElementById('uhid').value = ui.item.uhidcode;
				 document.getElementById('labinvoice_gender').value = ui.item.opregistration_gender;
				 document.getElementById('labinvoice_mobile').value = ui.item.opregistration_mobile;
				 document.getElementById('labinvoice_totaldiscp').value = ui.item.discp;
				 document.getElementById('labinvoice_address').value = ui.item.opregistration_address;
				 //document.getElementById('labinvoice_totaldiscp').value = ui.item.discp;

				currentCardType = ui.item.cardtype; // VIP / GOLD / NORMAL etc

 				return false;
			}
		});

		//From Appointment// scanner user korle ei part off/ disable rakhte hobe
		$( "#labinvoice_patient" ).autocomplete({
 			minLength: 1,
			source: apdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				 document.getElementById('labinvoice_patient').value = ui.item.labelval;
				 document.getElementById('labinvoice_age').value = ui.item.appointmententry_age;
				 document.getElementById('age').value = ui.item.age;
				 document.getElementById('bar').value = ui.item.bar;
				 document.getElementById('labinvoice_gender').value = ui.item.appointmententry_gender;
				 document.getElementById('labinvoice_mobile').value = ui.item.appointmententry_mobile;
				 document.getElementById('labinvoice_address').value = ui.item.appointmententry_address;
				 document.getElementById('labinvoice_doctor').value = ui.item.appointmententry_doctor;
				 document.getElementById('labinvoice_pc').value = ui.item.appointmententry_pc;
				 document.getElementById('labinvoice_mpo').value = ui.item.appointmententry_mpo;
				return false;
			}
		});
		
		//invoice patient data
		$( "#labinvoice_mobile" ).autocomplete({
			minLength: 1,
			source: patientdatainvoice,
			focus: function( event, ui ) {
			  return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );

				 document.getElementById('labinvoice_patient').value = ui.item.labelval;
 				 document.getElementById('labinvoice_age').value = ui.item.labinvoice_age;
				 document.getElementById('age').value = ui.item.age;
				 document.getElementById('labinvoice_gender').value = ui.item.labinvoice_gender;
				 document.getElementById('labinvoice_mobile').value = ui.item.labinvoice_mobile;
				 document.getElementById('labinvoice_address').value = ui.item.labinvoice_address;
 				return false;
			}
		});

		// pc search
		$( "#labinvoice_pc" ).autocomplete({
			
			minLength: 1,
			source: pcdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
 				 document.getElementById('labinvoice_pc').value = ui.item.labelval;
				 document.getElementById('labinvoice_mpo').value = ui.item.mpo;
				 document.getElementById('doctor_id').value = ui.item.doctor_id;
				 document.getElementById('previous_pc_comission').value = ui.item.pc_comission;
				 document.getElementById('doctor_mobile').value = ui.item.doctor_mobile;
 				return false;
			}
		});
		
		// dr search
		$( "#labinvoice_doctor" ).autocomplete({
			
			minLength: 1,
			source: drdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
 				 document.getElementById('labinvoice_doctor').value = ui.item.labelval;
				 document.getElementById('labinvoice_doctor').value = ui.item.doctor_name;
 				 return false;
			}
		});
		
		//dues holder
		$( "#labinvoice_duesholder" ).autocomplete({
 			minLength: 1,
			source: empdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
 				 document.getElementById('labinvoice_duesholder').value = ui.item.labelval;
 				 document.getElementById('employenameentry_id').value = ui.item.employenameentry_id;
 				return false;
			}
		});
		 
 		
		/*$( ".labinvoice_item" ).keypress(function(keyname) {
			if(keyname.which==13){
				var imei = $(this).val();
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				$.each(itemarraydata, function(key, value){
					var valuearray = value.split('||');
					if(key==imei){
						document.getElementsByName("labitem_id[]")[indexpos].value = valuearray[0];
						//document.getElementsByName("salesinvoice_item[]")[indexpos].value = valuearray[1];
						//document.getElementsByName("labinvoice_category[]")[indexpos].value = valuearray[1];
						//document.getElementsByName("labinvoice_unit[]")[indexpos].value = valuearray[2];
						//document.getElementsByName("labinvoice_refvalue[]")[indexpos].value = valuearray[3];
						document.getElementsByName("labinvoice_rate[]")[indexpos].value = valuearray[4];
						//document.getElementsByName("labinvoice_reagent[]")[indexpos].value = valuearray[5];
						document.getElementsByName("labinvoice_pccomission[]")[indexpos].value = valuearray[6];
						document.getElementsByName("labinvoice_drcomission[]")[indexpos].value = valuearray[7];
						document.getElementsByName("labinvoice_qty[]")[indexpos].value = 1;
						calculaterowtotal(indexpos);
						addnew_particularrow(true);
					}
				});
				return false;
			}
		});*/
		
	});
	
	function calculate_discountp(){
		
		var labinvoice_discountparray = document.getElementsByName("labinvoice_discountp[]");
		var labinvoice_discarray = document.getElementsByName("labinvoice_disc[]");
		var labinvoice_ratearray = document.getElementsByName("labinvoice_rate[]");
		var labinvoice_qtyarray = document.getElementsByName("labinvoice_qty[]");
		var labinvoice_gpccomissionarray = document.getElementsByName("labinvoice_gpccomission[]");
			
		if(labinvoice_discountparray.length>0){
			for(var p=0; p<labinvoice_discountparray.length; p++){
				var labinvoice_discountp = parseFloat(labinvoice_discountparray[p].value);
				if(labinvoice_discountp=='' || isNaN(labinvoice_discountp)){labinvoice_discountp = 0;}
				
				var labinvoice_disc = parseFloat(labinvoice_discarray[p].value);
				if(labinvoice_disc=='' || isNaN(labinvoice_disc)){labinvoice_disc = 0;}
				if(labinvoice_discountp>0){
					var labinvoice_rate = parseFloat(labinvoice_ratearray[p].value);
					if(labinvoice_rate=='' || isNaN(labinvoice_rate)){labinvoice_rate = 0;}
					
					var labinvoice_gpccomission = parseFloat(labinvoice_gpccomissionarray[p].value);
					if(labinvoice_gpccomission=='' || isNaN(labinvoice_gpccomission)){labinvoice_gpccomission = 0;}
					
					
					var labinvoice_qty = labinvoice_qtyarray[p].value;
					if(labinvoice_qty=='' || isNaN(labinvoice_qty)){labinvoice_qty = 0;}
					
					var pctotal = parseFloat(labinvoice_gpccomission*labinvoice_qty);			
 					var total = parseFloat(labinvoice_rate*labinvoice_qty);
								
					//var labinvoice_pccomission = parseFloat(pctotal*total*labinvoice_discountp*0.01);
					var labinvoice_disc = parseFloat(total*labinvoice_discountp*0.01);
					
					labinvoice_discarray[p].value = labinvoice_disc.toFixed(2);
				}
				
				calculaterowtotal(p);
			}
		}
	}
	
	function calculaterowtotal(indexpos){
		if(indexpos=='all'){
			var labinvoice_ratearray = document.getElementsByName("labinvoice_rate[]");
			var labinvoice_qtyarray = document.getElementsByName("labinvoice_qty[]");
			var labinvoice_discarray = document.getElementsByName("labinvoice_disc[]");
			var labinvoice_totalarray = document.getElementsByName("labinvoice_total[]");
			
			var labinvoice_gpccomissionarray = document.getElementsByName("labinvoice_gpccomission[]");
			var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
			
			if(labinvoice_ratearray.length>0){
				for(var p=0; p<labinvoice_ratearray.length; p++){
					var labinvoice_rate = parseFloat(labinvoice_ratearray[p].value);
					if(labinvoice_rate=='' || isNaN(labinvoice_rate)){labinvoice_rate = 0;}
					
					var labinvoice_gpccomission = parseFloat(labinvoice_gpccomissionarray[p].value);
					if(labinvoice_gpccomission=='' || isNaN(labinvoice_gpccomission)){labinvoice_gpccomission = 0;}
					
					var labinvoice_qty = parseFloat(labinvoice_qtyarray[p].value);
					if(labinvoice_qty=='' || isNaN(labinvoice_qty)){labinvoice_qty = 0;}
										
					var pctotal = parseFloat(labinvoice_gpccomission*labinvoice_qty);
 					var total = parseFloat(labinvoice_rate*labinvoice_qty);
					
					var labinvoice_disc = parseFloat(labinvoice_discarray[p].value);
					if(labinvoice_disc=='' || isNaN(labinvoice_disc)){labinvoice_disc = 0;}
					
					var pctotal = parseFloat(pctotal-labinvoice_disc/2);
					var total = parseFloat(total-labinvoice_disc);
					
					labinvoice_pccomissionarray[p].value = pctotal.toFixed(2);
 					labinvoice_totalarray[p].value = total.toFixed(2);
					
					
					//var labinvoice_pccomission = parseFloat(labinvoice_pccomission-labinvoice_gpccomission);
					//labinvoice_gpccomissionarray[p].value = labinvoice_pccomission.toFixed(2);

					}
				//calculate_discountp(p);
			}
		}
		else{
			var labinvoice_ratearray = document.getElementsByName("labinvoice_rate[]");
			var labinvoice_rate = parseFloat(labinvoice_ratearray[indexpos].value);
			if(labinvoice_rate=='' || isNaN(labinvoice_rate)){labinvoice_rate = 0;}
			
			var labinvoice_gpccomissionarray = document.getElementsByName("labinvoice_gpccomission[]");
			var labinvoice_gpccomission = parseFloat(labinvoice_gpccomissionarray[indexpos].value);
			if(labinvoice_gpccomission=='' || isNaN(labinvoice_gpccomission)){labinvoice_gpccomission = 0;}
			
			var labinvoice_qtyarray = document.getElementsByName("labinvoice_qty[]");
			var labinvoice_qty = parseFloat(labinvoice_qtyarray[indexpos].value);
			if(labinvoice_qty=='' || isNaN(labinvoice_qty)){labinvoice_qty = 0;}
			
			var pctotal = parseFloat(labinvoice_gpccomission*labinvoice_qty);
			var total = parseFloat(labinvoice_rate*labinvoice_qty);
			
			var labinvoice_discarray = document.getElementsByName("labinvoice_disc[]");
			var labinvoice_disc = parseFloat(labinvoice_discarray[indexpos].value);
			if(labinvoice_disc=='' || isNaN(labinvoice_disc)){labinvoice_disc = 0;}
			
			var pctotal = parseFloat(pctotal-labinvoice_disc/2);
			var total = parseFloat(total-labinvoice_disc);
			
			var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
			labinvoice_pccomissionarray[indexpos].value = pctotal.toFixed(2);
			
			var labinvoice_totalarray = document.getElementsByName("labinvoice_total[]");
			labinvoice_totalarray[indexpos].value = total.toFixed(2);
			
		}
		
		calculate_total();
	}
	
	function calculate_total(){
		var labinvoice_subtotal = 0;
		var labinvoice_totalarray = document.getElementsByName("labinvoice_total[]");
		if(labinvoice_totalarray.length>0){
			for(var p=0; p<labinvoice_totalarray.length; p++){
				var labinvoice_total = parseFloat(labinvoice_totalarray[p].value);
				if(labinvoice_total=='' || isNaN(labinvoice_total)){labinvoice_total = 0;}
				labinvoice_subtotal = parseFloat(labinvoice_subtotal+labinvoice_total);
			}
		}
		//subtotal calculation
		document.getElementById("labinvoice_subtotal").value = labinvoice_subtotal.toFixed(2);
		
		
		// emergency added
		var emergencyp = parseFloat(document.getElementById("emergencyp").value);
		if(emergencyp=='' || isNaN(emergencyp)){emergencyp = 0;}
		
		var emergency = parseFloat(document.getElementById("emergency").value);
		if(emergency=='' || isNaN(emergency)){emergency = 0;}
		
		if(emergencyp>0){
			var emergency = parseFloat(labinvoice_subtotal*emergencyp*0.01);
			document.getElementById('emergency').value= emergency;
		}
		//emergency end
		
 		/*var labinvoice_totaldiscp = parseFloat(document.getElementById("labinvoice_totaldiscp").value);
		if(labinvoice_totaldiscp=='' || isNaN(labinvoice_totaldiscp)){labinvoice_totaldiscp = 0;}
		
		var labinvoice_totaldisc = parseFloat(document.getElementById("labinvoice_totaldisc").value);
		if(labinvoice_totaldisc=='' || isNaN(labinvoice_totaldisc)){labinvoice_totaldisc = 0;}
		
		if(labinvoice_totaldiscp>0){
			var labinvoice_totaldisc = parseFloat(labinvoice_subtotal*labinvoice_totaldiscp*0.01);
			document.getElementById('labinvoice_totaldisc').value= labinvoice_totaldisc;
		}*/
		
		
	 //OPAI//
	 	var labinvoice_totaldiscp = parseFloat(document.getElementById("labinvoice_totaldiscp").value);
		if (labinvoice_totaldiscp == '' || isNaN(labinvoice_totaldiscp)) { labinvoice_totaldiscp = 0; }
		
		var labinvoice_totaldisc = parseFloat(document.getElementById("labinvoice_totaldisc").value);
		if (labinvoice_totaldisc == '' || isNaN(labinvoice_totaldisc)) { labinvoice_totaldisc = 0; }
		
		var labinvoice_subtotal = parseFloat(document.getElementById("labinvoice_subtotal").value);
		if (labinvoice_subtotal == '' || isNaN(labinvoice_subtotal)) { labinvoice_subtotal = 0; }
		
		// --- যদি % দেওয়া থাকে তাহলে amount হিসাব করবে ---
		if (document.activeElement.id === "labinvoice_totaldiscp" && labinvoice_totaldiscp > 0 && labinvoice_subtotal > 0) {
			labinvoice_totaldisc = parseFloat(labinvoice_subtotal * labinvoice_totaldiscp * 0.01);
			document.getElementById('labinvoice_totaldisc').value = labinvoice_totaldisc.toFixed(2);
		}
		
		// --- যদি amount দেওয়া থাকে তাহলে % হিসাব করবে ---
		else if (document.activeElement.id === "labinvoice_totaldisc" && labinvoice_totaldisc > 0 && labinvoice_subtotal > 0) {
			labinvoice_totaldiscp = (labinvoice_totaldisc / labinvoice_subtotal) * 100;
			document.getElementById('labinvoice_totaldiscp').value = labinvoice_totaldiscp.toFixed(2);
		}
	//OPAI//
	 
	 
		
		var labinvoice_subtotalafterdisc = parseFloat(labinvoice_subtotal-labinvoice_totaldisc+emergency);
		document.getElementById('labinvoice_subtotalafterdisc').value=	labinvoice_subtotalafterdisc.toFixed(2);
			
		var labinvoice_receiveamount = parseFloat(document.getElementById("labinvoice_receiveamount").value);
		if(labinvoice_receiveamount=='' || isNaN(labinvoice_receiveamount)){labinvoice_receiveamount = 0;}
		
		var labinvoice_due = parseFloat(labinvoice_subtotalafterdisc-labinvoice_receiveamount);
		document.getElementById('labinvoice_due').value=labinvoice_due.toFixed(2);		
		
		
		
		var varTDShowTotalAmount1 = document.getElementById("labinvoice_subtotalafterdisc").value;
		document.getElementById("tdShowTotalAmount1").innerHTML = varTDShowTotalAmount1;

		
		//pc comission  percentage...
		
		var labinvoice_totalpccomission = document.getElementById("labinvoice_totalpccomission").value;
		if(labinvoice_totalpccomission=='' || isNaN(labinvoice_totalpccomission)){labinvoice_totalpccomission = 0;}
		
		labinvoice_totalpccomission_percent = ((labinvoice_totalpccomission*100)/labinvoice_subtotal);
		document.getElementById('labinvoice_totalpccomission_percent').value=labinvoice_totalpccomission_percent;
		//pc comission percentage...
 		var labinvoice_totalpccomission = 0;
		var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
		if(labinvoice_pccomissionarray.length>0){
			for(var p=0; p<labinvoice_pccomissionarray.length; p++){
				var labinvoice_pccomission = parseFloat(labinvoice_pccomissionarray[p].value);
				if(labinvoice_pccomission=='' || isNaN(labinvoice_pccomission)){labinvoice_pccomission = 0;}
				labinvoice_totalpccomission = parseFloat((labinvoice_totalpccomission+labinvoice_pccomission));
 			}
		}
		
		//none
		//document.getElementById("labinvoice_totalpccomission").value = labinvoice_totalpccomission;
		
 		document.getElementById("labinvoice_totalpccomission").value = labinvoice_totalpccomission-labinvoice_totaldisc/2;
 		
		 
		// Discount (dr, pc: 100%)
		var labinvoice_totalpccomission = 0;
		var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
		if(labinvoice_pccomissionarray.length>0){
			for(var p=0; p<labinvoice_pccomissionarray.length; p++){
				var labinvoice_pccomission = parseFloat(labinvoice_pccomissionarray[p].value);
				if(labinvoice_pccomission=='' || isNaN(labinvoice_pccomission)){labinvoice_pccomission = 0;}
				labinvoice_totalpccomission = parseFloat((labinvoice_totalpccomission+labinvoice_pccomission));
			if(labinvoice_totaldiscp>0){
			document.getElementById("labinvoice_totalpccomission").value = labinvoice_totalpccomission-labinvoice_totaldisc/2;
				}
			}
		}
		// end 21-08-16
		
		// dr comission
		// new 21-08-16
		var labinvoice_totaldrcomission = 0;
		var labinvoice_drcomissionarray = document.getElementsByName("labinvoice_drcomission[]");
		if(labinvoice_drcomissionarray.length>0){
			for(var m=0; m<labinvoice_drcomissionarray.length; m++){
				var labinvoice_drcomission = parseFloat(labinvoice_drcomissionarray[m].value);
				if(labinvoice_drcomission=='' || isNaN(labinvoice_drcomission)){labinvoice_drcomission = 0;}
				
			labinvoice_totaldrcomission = parseFloat((labinvoice_totaldrcomission+labinvoice_drcomission));
			//labinvoice_totalpccomission = parseFloat(labinvoice_totalpccomission);
			if(labinvoice_totaldiscp>0){
			var labinvoice_totaldisc = parseFloat(labinvoice_totaldrcomission*labinvoice_totaldiscp*0.01);
			//document.getElementById('labinvoice_totaldisc').value= labinvoice_totaldisc;
				}
			}
		}
		document.getElementById("labinvoice_totaldrcomission").value = labinvoice_totaldrcomission;
		// end 21-08-16
		
 	}
	

	function calculate_pctotal(){
		var labinvoice_totalpccomission = 0;
		var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
		if(labinvoice_pccomissionarray.length>0){
			for(var p=0; p<labinvoice_pccomissionarray.length; p++){
				var labinvoice_pccomission = parseFloat(labinvoice_pccomissionarray[p].value);
				if(labinvoice_pccomission=='' || isNaN(labinvoice_pccomission)){labinvoice_pccomission = 0;}
				labinvoice_totalpccomission = parseFloat(labinvoice_totalpccomission+labinvoice_pccomission);
				}
			}
		document.getElementById("labinvoice_totalpccomission").value = labinvoice_totalpccomission;
		calculate_total();
						
		}
	
	function calculate_drtotal(){
		var labinvoice_totaldrcomission = 0;
		var labinvoice_drcomissionarray = document.getElementsByName("labinvoice_drcomission[]");
		if(labinvoice_drcomissionarray.length>0){
			for(var m=0; m<labinvoice_drcomissionarray.length; m++){
				var labinvoice_drcomission = parseFloat(labinvoice_drcomissionarray[m].value);
				if(labinvoice_drcomission=='' || isNaN(labinvoice_drcomission)){labinvoice_drcomission = 0;}
				labinvoice_totaldrcomission = parseFloat(labinvoice_totaldrcomission+labinvoice_drcomission);
			}
		}
 		document.getElementById("labinvoice_totaldrcomission").value = labinvoice_totaldrcomission;
		
	}
	
	
	
	function check_particular(){
 		return true;
	}
	
	function addnew_particularrow(animate) {
		if(check_particular()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" style=\"width: 1220px;margin: 2px auto; border-radius: 8px;overflow: hidden; border:2px solid #FFF\" bgcolor=\"#c0d2ff\"  border=\"0\" cellspacing=\"1\" cellpadding=\"4\">"+
							'<tr>'+
								'<td align="right">Test Name</td>'+
								'<td><input type="text" name="labinvoice_itemT[]" class="tdclasss itemname labinvoice_item" autocomplete="off" /></td>'+
								'<input type="hidden" readonly name="labinvoice_item[]" class="tdclasss"/>'+
								'<input type="hidden" name="labitem_id[]" id="labitem_id" class="tdclass itemname" />'+
								'<input type="hidden" name="labinvoice_group[]" class="tdclass" />'+
								'<input type="hidden" name="labinvoice_category[]" class="tdclass" />'+
								'<input type="hidden" name="reportname[]" class="tdclass" />'+
								
 								'<td align="right">Rate</td>'+
								"<td><textarea type=\"text\" readonly style=\"height:16px; width:60px;\" name=\"labinvoice_rate[]\" id=\"labinvoice_rate\" step=\"0.01\" min=\"0\" oninput=\"preventNegative(this)\" class=\"tdclasssale numeric\" onKeyUp=\"calculaterowtotal('all');\"/></textarea></td>"+											 
								'<!--<td align="right">Qty</td>-->'+
								"<input type=\"hidden\" name=\"labinvoice_qty[]\" id=\"labinvoice_qty\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/>"+
								
								'<td align="right">RfCG</td>'+
								'<td><textarea type="text" readonly style="height:16px; width:60px;" name="labinvoice_gpccomission[]" step=\"0.01\" min=\"0\" oninput=\"preventNegative(this)\" class="tdclasssale" onKeyUp="calculate_pctotal();" /></textarea></td>'+
								
								'<td align="right">Disc%</td>'+
								'<td><textarea type="text" style="height:16px; width:60px;" name="labinvoice_discountp[]" class="tdclasssale" onKeyUp="calculate_discountp();"/></textarea></td>'+
								'<td align="right">Disc</td>'+
								"<td><textarea type=\"text\" style=\"height:16px; width:60px;\" name=\"labinvoice_disc[]\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\" /></textarea></td>"+
								'<td align="right">RfC</td>'+
								'<td><textarea readonly type="text" style="height:16px; width:60px;" name="labinvoice_pccomission[]" class="tdclasssale" onKeyUp="calculate_pctotal();" /></textarea></td>'+
								'<!--<td align="right">Dr.</td>-->'+
								'<td><input type="hidden" name="labinvoice_drcomission[]" class="tdclasssale" onKeyUp="calculate_pctotal();" /></td>'+
								'<td align="right">Total</td>'+
								'<td><input type="text" readonly name="labinvoice_total[]" id="labinvoice_total" class="tdclasssale" /></td>'+												
								"<td align=\"right\">R.Date<input type=\"text\" size=\"6\" name=\"labinvoice_reportdate[]\" id=\"labinvoice_reportdate2\" value=\"<?php echo date('Y-m-d');?>\" /></td>"+	
																		
								'<td><input type="text" size="5" name="labinvoice_reporttime[]" id="labinvoice_reporttime" value="<?php echo date('h:i:s', $endTime);?>" /></td>'+												
								'<td>'+
								 "<input type=\"button\" value=\"Del\" onClick=\"deletethislistrow('particularlistrowno"+particular_rowcount+"');\" class=\"tdclasssale\" />"+
								'</td>'+
							  '</tr>'+
						"</table>";
						
			var $newparticularlist = $("<li></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(200); 
			else 
			   $newparticularlist.show();   
			 document.getElementsByName("labinvoice_itemT[]")[parseInt(particular_rowcount-1)].focus();
			
			$( ".itemname" ).autocomplete({
				minLength: 1,
				source: itemdata,
				focus: function( event, ui ) {
 					return false;
				},
				select: function( event, ui ) {
				
				//Start duplicate Item Entry Check//	
			    var itemIdArray = document.getElementsByName("labitem_id[]");
				var itemQtyArray = document.getElementsByName("labinvoice_qty[]");
					//==============================Check Duplicate Id=============================//
					if(itemIdArray.length>0){
						for(var l=0; l<itemIdArray.length; l++){
							var olditem_id = itemIdArray[l].value;
							if(olditem_id !=''){
								if( ui.item.labitem_id == olditem_id){
									/*var qtyVal = parseInt(itemQtyArray[l].value);
									if(qtyVal=='' || isNaN(qtyVal)){qtyVal = 0;}
									qtyVal++;
									itemQtyArray[l].value = qtyVal;
									calculateCurrentRowTotal(l);*/
									$(this).val('');
									$(this).focus();
									alert("Duplicate item found.");
									return false;
								}
							}
						}
					}
					
					//End duplicate Item Entry Check//
					
 					
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				var labitem_idarray = document.getElementsByName("labitem_id[]");
				labitem_idarray[indexpos].value = ui.item.labitem_id;
				
				var labinvoice_itemarray = document.getElementsByName("labinvoice_item[]");
				labinvoice_itemarray[indexpos].value = ui.item.labitem_name;
					
				var labinvoice_ratearray = document.getElementsByName("labinvoice_rate[]");
				labinvoice_ratearray[indexpos].value = ui.item.labitem_price;

				var labinvoice_qtyarray = document.getElementsByName("labinvoice_qty[]");
				labinvoice_qtyarray[indexpos].value = 1;

				var labinvoice_gpccomissionarray = document.getElementsByName("labinvoice_gpccomission[]");
				labinvoice_gpccomissionarray[indexpos].value = ui.item.labitem_pccommission;

				var labinvoice_drcomissionarray = document.getElementsByName("labinvoice_drcomission[]");
				labinvoice_drcomissionarray[indexpos].value = ui.item.labitem_drcommission;

				var labinvoice_grouparray = document.getElementsByName("labinvoice_group[]");
				labinvoice_grouparray[indexpos].value = ui.item.labitem_group;
						// VIP Card Discount Auto Apply
						var allowedCards = ['VIP', 'VVIP', 'DIRECTOR'];
 						if (allowedCards.includes(currentCardType)) {
 							var itemGroup = ui.item.labitem_group;
 							if (
								crmtestdisc[currentCardType] &&
								crmtestdisc[currentCardType][itemGroup]
							) {
						
								document.getElementsByName("labinvoice_discountp[]")[indexpos].value =
									crmtestdisc[currentCardType][itemGroup];
						
								calculate_discountp();
							}
						}
				
				var labinvoice_categoryarray = document.getElementsByName("labinvoice_category[]");
				labinvoice_categoryarray[indexpos].value = ui.item.labitem_category;
				
				var reportnamearray = document.getElementsByName("reportname[]");
				reportnamearray[indexpos].value = ui.item.reportname;
				/* 
				var labitem_reagentarray = document.getElementsByName("labitem_reagent[]");
				labitem_reagentarray[indexpos].value = ui.item.labitem_reagent;
				
				var labitem_reagentidarray = document.getElementsByName("labitem_reagentid[]");
				labitem_reagentidarray[indexpos].value = ui.item.labitem_reagentid;
				
 				var reagentqtyarray = document.getElementsByName("reagentqty[]");
				reagentqtyarray[indexpos].value = ui.item.reagentqty;*/
	
					calculaterowtotal(indexpos);
					calculate_pctotal();
					calculate_drtotal();
					addnew_particularrow(true);   //automatic add next row
					return false;
				}
			});	

			/*$( ".labinvoice_item" ).keypress(function(keyname) {
			if(keyname.which==13){
				var imei = $(this).val();
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();

				$.each(itemarraydata, function(key, value){
					var valuearray = value.split('||');
					if(key==imei){
						document.getElementsByName("labitem_id[]")[indexpos].value = valuearray[0];
						//document.getElementsByName("salesinvoice_item[]")[indexpos].value = valuearray[1];
						document.getElementsByName("labinvoice_category[]")[indexpos].value = valuearray[1];
						//document.getElementsByName("labinvoice_unit[]")[indexpos].value = valuearray[2];
						//document.getElementsByName("labinvoice_refvalue[]")[indexpos].value = valuearray[3];
						document.getElementsByName("labinvoice_rate[]")[indexpos].value = valuearray[4];
						//document.getElementsByName("labinvoice_reagent[]")[indexpos].value = valuearray[5];
						document.getElementsByName("labinvoice_pccomission[]")[indexpos].value = valuearray[6];
						document.getElementsByName("labinvoice_drcomission[]")[indexpos].value = valuearray[7];
						document.getElementsByName("labinvoice_qty[]")[indexpos].value = 1;

						calculaterowtotal(indexpos);
						addnew_particularrow(true);
					}
				});
				return false;
			}
		});	*/			
		}
	}

	function deletethislistrow(tableidname){
		$("#"+tableidname).parent("li").slideUp(200, function() {
			$(this).remove();
			calculaterowtotal('all');
		});
	}
	
// prevent multi times save


function checkcontactform() {
    //OPAI
    // ======= MOBILE NUMBER CHECK =======
    var labinvoice_mobile = document.getElementById("labinvoice_mobile");
    var error_labinvoice_mobile = document.getElementById("error_labinvoice_mobile");
    error_labinvoice_mobile.innerHTML = '';
    if (labinvoice_mobile.value.trim() == '') {
        error_labinvoice_mobile.innerHTML = "Number is missing.";
        labinvoice_mobile.focus();
        return false;
    } 
    //else if (labinvoice_mobile.value.length != 11) {
	else if (labinvoice_mobile.value.length < 10) {
        error_labinvoice_mobile.innerHTML = "Number should be 11 digits.";
        labinvoice_mobile.focus();
        return false;
    }
		
		
    // ======= DISCOUNT PERCENTAGE CHECK =======
    var labinvoice_totaldiscp = document.getElementById("labinvoice_totaldiscp");
    var error_labinvoice_totaldiscp = document.getElementById("error_labinvoice_totaldiscp");
    error_labinvoice_totaldiscp.innerHTML = '';

    if (labinvoice_totaldiscp.value.trim() == '') {
        error_labinvoice_totaldiscp.innerHTML = "Disc % is missing.";
        labinvoice_totaldiscp.focus();
        return false;
    }
    else if (parseFloat(labinvoice_totaldiscp.value) > 30) {
        error_labinvoice_totaldiscp.innerHTML = "Discount % should not exceed 30%.";
        labinvoice_totaldiscp.focus();
        return false;
    }

    // ======= DISCOUNT AMOUNT CHECK =======
    var labinvoice_totaldisc = document.getElementById("labinvoice_totaldisc");
    var labinvoice_subtotal = document.getElementById("labinvoice_subtotal");
    var error_labinvoice_totaldisc = document.getElementById("error_labinvoice_totaldisc");
    error_labinvoice_totaldisc.innerHTML = '';

    if (labinvoice_totaldisc.value.trim() == '') {
        error_labinvoice_totaldisc.innerHTML = "Discount amount is missing.";
        labinvoice_totaldisc.focus();
        return false;
    } 
    else {
        var subtotal = parseFloat(labinvoice_subtotal.value) || 0;
        var totaldisc = parseFloat(labinvoice_totaldisc.value) || 0;
        var maxAllowedDisc = subtotal * .30; // 30% of subtotal

        if (totaldisc > maxAllowedDisc) {
            error_labinvoice_totaldisc.innerHTML = "Discount cannot exceed 30% of subtotal.";
            labinvoice_totaldisc.focus();
            return false;
        }
    }

    // ======= PC COMMISSION CHECK =======
    /*var labinvoice_totalpccomission = document.getElementById("labinvoice_totalpccomission");
    var error_labinvoice_totalpccomission = document.getElementById("error_labinvoice_totalpccomission");
    error_labinvoice_totalpccomission.innerHTML = '';

    if (labinvoice_totalpccomission.value.trim() == '') {
        error_labinvoice_totalpccomission.innerHTML = "PC commission is missing.";
        labinvoice_totalpccomission.focus();
        return false;
    } 
    else if (parseFloat(labinvoice_totalpccomission.value) < 0) {
        error_labinvoice_totalpccomission.innerHTML = "PC commission cannot be negative.";
        labinvoice_totalpccomission.focus();
        return false;
    }*/
	
		// pc comission Negative value hote parbe na
			/*var field = document.getElementById("labinvoice_totalpccomission");
			field.style.border = '';
			// Allow empty (null) value, but not negative
			if (field.value.trim() !== '') {
				var value = parseFloat(field.value);
				if (isNaN(value)) {
					alert("Please enter a valid number for PC commission.");
					field.focus();
					return false;
				}
				else if (value < 0) {
					alert("PC commission cannot be negative.");
					field.style.border = '2px solid red';
					field.focus();
					return false;
				}
			}
		*/	  
// pc comission Negative value hote parbe na//
	
	// ======= DUE AMOUNT CHECK =======
	var labinvoice_due = document.getElementById("labinvoice_due");
	var error_labinvoice_due = document.getElementById("error_labinvoice_due");
	
	if (labinvoice_due && error_labinvoice_due) {
		error_labinvoice_due.innerHTML = '';
		var dueValue = parseFloat(labinvoice_due.value) || 0;
	
		if (dueValue < 0) {
			error_labinvoice_due.innerHTML = "Due amount cannot be negative.";
			labinvoice_due.focus();
			return false;
		}
	}


    // ======= ALL OK =======
    return true;
}

//negative value save hobe na.
function preventNegative(el) {
    if (el.value < 0) el.value = 0; // Negative দিলে 0 করে দেবে
}
		
/*function funcSaveBill1()
	{
	
	var varUserChoice; 
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet); 
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		//document.frmcontact1.submit();
		//return true;
	}
}*/
</script>