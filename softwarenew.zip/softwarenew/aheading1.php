<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="<?php echo $sec;?>" URL="<?php echo $page;?>">
    <title>Beta Software Solutions</title>
    
    <!-- SEO Meta Tags -->
    <meta name="keywords" content="beta solutions, best hospital management software, hospital management, hospital software, 
    healthcare ERP,  school management software, shop management, dairy farm software, business management software, pharmacy software, 
    best software company in dhaka, best software company in bangladesh, software company in dhaka, pos software, school software, 
    Bangladesh software company">
    <meta name="description" content="Beta Healthcare ERP 2.5+ - Comprehensive hospital management system">
    <meta name="robots" content="index, follow">
    
    <!-- Favicon -->
    <link rel="stylesheet" href="style.css" content="width-device-width initial scal=1.0" />
    <link rel="icon" href="images/ico.png">
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script src="js/datetimepicker_css.js"></script>
    
	<script>
    history.replaceState(null, "", "/softwarenew/");
    </script>
    
  
    <!-- Security and UI Restrictions -->
    <!--<style>
        body {
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }
    </style>-->
    
    <script>
	/*// Security measures
    document.addEventListener('DOMContentLoaded', function() {
        // Disable right-click and developer tools
        document.addEventListener('contextmenu', function(e) { e.preventDefault(); });
        
        // Disable keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            // Disable Ctrl+U, Ctrl+S, F12, Ctrl+Shift+I
            if ((e.ctrlKey && (e.key === 'u' || e.key === 'U' || e.key === 's' || e.key === 'S')) || 
                e.key === 'F12' || (e.ctrlKey && e.shiftKey && e.key === 'I')) {
                e.preventDefault();
            }
            
            // Disable Ctrl+C with warning
            if (e.ctrlKey && e.key === 'c') {
                e.preventDefault();
                alert("Copying is disabled on this page!");
            }
        });
        
        // Disable text selection
        document.addEventListener('selectstart', function(e) { e.preventDefault(); });
    });
    
	*/
    // Utility functions
    function removetablerow(table_name, idvalue, return_page) {
        if (confirm("Do you sure want to delete this ID="+idvalue+" from this Table="+table_name)) {
            window.location='delete_table_row.php?table_name='+encodeURIComponent(table_name)+
                           '&idvalue='+encodeURIComponent(idvalue)+
                           '&return_page='+encodeURIComponent(return_page);
        }
    }
     
   </script>
    
 </head>