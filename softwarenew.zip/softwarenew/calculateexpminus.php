<script language="JavaScript" type="text/javascript">
	
	var itemdataarray = '<?php echo $itemdataarray;?>';
	var itemdata = <?php echo $itemdata;?>;
	var patientdata = <?php echo $patientdata;?>;
	var itemarraydata = jQuery.parseJSON(itemdataarray);
	
	$(document).ready(function($) {
		document.getElementsByName("expiryminus_item[]")[0].focus();

		$( ".itemname" ).autocomplete({
			
			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.saleselval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				  
				document.getElementsByName("salesitem_id[]")[indexpos].value = ui.item.salesitem_id;
				document.getElementsByName("expiryminus_purchase_rate[]")[indexpos].value = ui.item.salesitem_purchase_rate;
				document.getElementsByName("expiryminus_rate[]")[indexpos].value = ui.item.salesitem_price;				
				document.getElementsByName("salesitem_pack[]")[indexpos].value =ui.item.salesitem_pack;
				document.getElementsByName("expiryminus_qty[]")[indexpos].value = 1;					
				document.getElementsByName("expiryminus_category[]")[indexpos].value = ui.item.salesitem_category;
				document.getElementsByName("expiryminus_stock[]")[indexpos].value = ui.item.salesitem_stock;
				document.getElementsByName("expire[]")[indexpos].value = ui.item.expire;
				
				calculateCurrentRowTotal(indexpos);
				
				return false;
			}
		});
		
		
		$( "#expiryminus_patient" ).autocomplete({
			
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.saleselval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 	document.getElementById('expiryminus_patientid').value = ui.item.labelval;
				 	document.getElementById('expiryminus_patientcode').value = ui.item.company_code;
					//document.getElementById('expiryminus_previousdue').value = ui.item.company_due;
					document.getElementById('expiryminus_mobile').value = ui.item.company_mobile;
				 	document.getElementById('expiryminus_address').value = ui.item.company_address;
				
				return false;
			}
		});
		
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
		$( ".expiryminus_item" ).keypress(function(keyname) {
			if(keyname.which==13){
				var imei = $(this).val();
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				$.each(itemarraydata, function(key, value){
					var valuearray = value.split('||');
					if(key==imei){
						document.getElementsByName("salesitem_id[]")[indexpos].value = valuearray[0];
						//document.getElementsByName("expiryminus_item[]")[indexpos].value = valuearray[1];
						document.getElementsByName("expiryminus_category[]")[indexpos].value = valuearray[1];
						document.getElementsByName("expiryminus_stock[]")[indexpos].value = valuearray[2];
						document.getElementsByName("expiryminus_purchase_rate[]")[indexpos].value = valuearray[3];
						document.getElementsByName("expiryminus_rate[]")[indexpos].value = valuearray[4];
						document.getElementsByName("expiryminus_qty[]")[indexpos].value = 1;
						calculateCurrentRowTotal(indexpos);
						
						addnew_particularrow(true);
					}
				});
				return false;
			}
		});
		
		
		$( ".sirow input.ccrt" ).keyup(function() {
			var index = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
			calculateCurrentRowTotal(index);
		});
		
		
	});
	
	function calculateCurrentRowTotal(indexpos){
		//purchase 
		
		var expiryminus_purchase_rate = parseFloat(document.getElementsByName("expiryminus_purchase_rate[]")[indexpos].value);
		if(expiryminus_purchase_rate=='' || isNaN(expiryminus_purchase_rate)){expiryminus_purchase_rate = 0.00;}
		
		var expiryminus_rate = parseFloat(document.getElementsByName("expiryminus_rate[]")[indexpos].value);
		if(expiryminus_rate=='' || isNaN(expiryminus_rate)){expiryminus_rate = 0.00;}
		
		var salesitem_pack = parseFloat(document.getElementsByName("salesitem_pack[]")[indexpos].value);
		if(salesitem_pack=='' || isNaN(salesitem_pack)){salesitem_pack = 0.00;}
		
		var expiryminus_pqty = parseFloat(document.getElementsByName("expiryminus_pqty[]")[indexpos].value);
		if(expiryminus_pqty=='' || isNaN(expiryminus_pqty)){expiryminus_pqty = 0.00;}
		
		if(salesitem_pack==0 || expiryminus_pqty==0){
			var expiryminus_qty = parseFloat(document.getElementsByName("expiryminus_qty[]")[indexpos].value);
			if(expiryminus_qty=='' || isNaN(expiryminus_qty)){expiryminus_qty = 0.00;}
		}
		else{
			var expiryminus_qty = parseFloat(salesitem_pack*expiryminus_pqty);
			if(expiryminus_qty=='' || isNaN(expiryminus_qty)){expiryminus_qty = 0.00;}
			document.getElementsByName("expiryminus_qty[]")[indexpos].value = expiryminus_qty.toFixed(2);
		}
		
		var qtyPrice = parseFloat(expiryminus_rate*expiryminus_qty);
		// purchase calculate
		var qtypurchasePrice = parseFloat(expiryminus_purchase_rate*expiryminus_qty);
		
		var expiryminus_discountp = parseFloat(document.getElementsByName("expiryminus_discountp[]")[indexpos].value);
		if(expiryminus_discountp=='' || isNaN(expiryminus_discountp)){expiryminus_discountp = 0.00;}
		if(expiryminus_discountp==0){
			var expiryminus_disc = parseFloat(document.getElementsByName("expiryminus_disc[]")[indexpos].value);
			if(expiryminus_disc=='' || isNaN(expiryminus_disc)){expiryminus_disc = 0.00;}
		}
		else{
			var expiryminus_disc = parseFloat(qtyPrice*expiryminus_discountp*0.01);	
			document.getElementsByName("expiryminus_disc[]")[indexpos].value = expiryminus_disc.toFixed(2);
		}
		
		document.getElementsByName("expiryminus_total[]")[indexpos].value = parseFloat(qtyPrice-expiryminus_disc).toFixed(2);
		//purchase
		document.getElementsByName("purchaseinvoice_total[]")[indexpos].value = parseFloat(qtypurchasePrice).toFixed(2);
		
		
		calculateGrandTotal();
	}
	
	function calculateGrandTotal(){
		var expiryminus_totalarray = document.getElementsByName("expiryminus_total[]");
		var expiryminus_subtotal = 0.00;
		for(var r=0; r<expiryminus_totalarray.length; r++){
			var expiryminus_total = parseFloat(expiryminus_totalarray[r].value);
			if(expiryminus_total=='' || isNaN(expiryminus_total)){expiryminus_total = 0.00;}
			expiryminus_subtotal = parseFloat(expiryminus_subtotal+expiryminus_total);
		}
		document.getElementById("expiryminus_subtotal").value = expiryminus_subtotal.toFixed(2);
		
		
		var purchaseinvoice_totalarray = document.getElementsByName("purchaseinvoice_total[]");
		var expiryminus_purchasesubtotal = 0.00;
		for(var m=0; m<purchaseinvoice_totalarray.length; m++){
			var purchaseinvoice_total = parseFloat(purchaseinvoice_totalarray[m].value);
			if(purchaseinvoice_total=='' || isNaN(purchaseinvoice_total)){purchaseinvoice_total = 0.00;}
			expiryminus_purchasesubtotal = parseFloat(expiryminus_purchasesubtotal+purchaseinvoice_total);
		}
		document.getElementById("expiryminus_purchasesubtotal").value = expiryminus_purchasesubtotal.toFixed(2);
		
		
		// when sale price above 100 tk  then less 5% ....for general it should be off.
			var expiryminus_totaldisc = parseFloat(expiryminus_totaldisc);
			if(expiryminus_totaldisc=='' || isNaN(expiryminus_totaldisc)){expiryminus_totaldisc = 0;}
			
			if(expiryminus_subtotal>=100){
				var expiryminus_totaldisc = parseFloat(expiryminus_subtotal*5*0.01);
				//document.getElementById('expiryminus_totaldisc').value= expiryminus_totaldisc.toFixed(2);
			}
			document.getElementById('expiryminus_totaldisc').value= expiryminus_totaldisc.toFixed(2);
		// when sale price above 100 tk  then less 5%
		
		
		// prevoius due
		var expiryminus_previousdue = parseFloat(document.getElementById("expiryminus_previousdue").value);
		if(expiryminus_previousdue=='' || isNaN(expiryminus_previousdue)){expiryminus_previousdue = 0;}
		
		
		var expiryminus_subtotalafterdisc = parseFloat(expiryminus_subtotal-expiryminus_totaldisc);
		document.getElementById('expiryminus_subtotalafterdisc').value= expiryminus_subtotalafterdisc.toFixed(2);
			
		
			// for all 
		//var expiryminus_receiveamount = parseFloat(document.getElementById("expiryminus_receiveamount").value);
		//if(expiryminus_receiveamount=='' || isNaN(expiryminus_receiveamount)){expiryminus_receiveamount = 0;}
		
		// for Feni Diabetes temprary 
		var expiryminus_receiveamount = parseFloat( expiryminus_subtotalafterdisc);
		document.getElementById('expiryminus_receiveamount').value=expiryminus_receiveamount.toFixed(2);		
		
		
		var expiryminus_due = parseFloat( expiryminus_subtotalafterdisc-expiryminus_receiveamount);
		document.getElementById('expiryminus_due').value=expiryminus_due.toFixed(2);		
		
		
		var cashreceive = parseFloat(document.getElementById("cashreceive").value);
		if(cashreceive=='' || isNaN(cashreceive)){cashreceive = 0;}
		var cashreturn = parseFloat(cashreceive-expiryminus_receiveamount);
		document.getElementById('cashreturn').value=cashreturn.toFixed(2);		
			
	}
	
	function check_blankrow(){
		return true;
	}

	function addnew_particularrow(animate) {
		if(check_blankrow()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" align=\"center\" bgcolor=\"#ccc\" width=\"800\" cellpadding=\"1\">"+
							'<tbody><tr></tr><tr>'+
								'<td align="center" width=\"130\"> <input type="text" required name="expiryminus_item[]" class="tdclass itemname expiryminus_item"/>'+
								'<input type="hidden" name="salesitem_id[]" id="salesitem_id" class="tdclass itemname"/>'+
								'<input type="hidden" name="expiryminus_category[]"  class="tdclass"  /></td>'+
								"<td align=\"center\" width=\"70\"><input type=\"text\" value=\"1\" name=\"expiryminus_qty[]\" class=\"tdclasssale numeric ccrt\"/></td>"+
								'<td align="center" width=\"70\"> <input type="text" name="expiryminus_stock[]" value=\"\" class="tdclasssale itemname"/></td>'+
								"<td align=\"center\" width=\"70\"><input type=\"text\" readonly name=\"expiryminus_purchase_rate[]\" class=\"tdclasssale\"/></td>"+											 
								"<td align=\"center\" width=\"70\"><input type=\"text\" required name=\"expiryminus_rate[]\" value=\"\" class=\"tdclasssale numeric ccrt\"/></td>"+											 
								"<td align=\"center\" width=\"70\"><input type=\"text\" title=\"class\" name=\"salesitem_pack[]\" class=\"tdclasssale numeric ccrt\" ></td>"+
								"<td align=\"center\" width=\"70\"><input type=\"text\" name=\"expiryminus_pqty[]\" value=\"\" class=\"tdclasssale numeric ccrt\" /></td>"+
								
								'<input type="hidden" name="expiryminus_discountp[]" class="tdclasssale numeric ccrt"/>'+
								"<input type=\"hidden\" name=\"expiryminus_disc[]\"  class=\"tdclasssale numeric  ccrt\" />"+
								'<td align="center" width=\"70\"><input type="text" readonly name="expiryminus_total[]" class="tdclasssale numeric ccrt"  /></td>'+	
								'<td align="center" width=\"90\"><input type="text" readonly name="expire[]" size="8" class="ccrt"  /></td>'+												
								'<input type="hidden" required readonly name="purchaseinvoice_total[]" class="tdclasssale numeric ccrt"  />'+												
								'<td>'+
								 "<input type=\"button\" value=\"Del\" class=\"tdclasssales deletethislistrow\"  />"+
								'</td>'+
							  '</tr></tbody>'+
						"</table>";
						
			var $newparticularlist = $("<li class=\"sirow\"></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(300); 
			else 
			   $newparticularlist.show();   
			document.getElementsByName("expiryminus_item[]")[parseInt(particular_rowcount-1)].focus();
			
			$( ".itemname" ).autocomplete({			
				minLength: 1,
				source: itemdata,
				focus: function( event, ui ) {
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					document.getElementsByName("salesitem_id[]")[indexpos].value = ui.item.salesitem_id;
					document.getElementsByName("expiryminus_purchase_rate[]")[indexpos].value = ui.item.salesitem_purchase_rate;
					document.getElementsByName("expiryminus_rate[]")[indexpos].value = ui.item.salesitem_price;				
					document.getElementsByName("salesitem_pack[]")[indexpos].value =ui.item.salesitem_pack;
					document.getElementsByName("expiryminus_qty[]")[indexpos].value = 1;					
					document.getElementsByName("expiryminus_category[]")[indexpos].value = ui.item.salesitem_category;
					document.getElementsByName("expiryminus_stock[]")[indexpos].value = ui.item.salesitem_stock;
					
					calculateCurrentRowTotal(indexpos);
					
					return false;
				}
			});						
		
			$( ".sirow input.ccrt" ).keyup(function() {
				var index = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				calculateCurrentRowTotal(index);
			});
			
			$( ".sirow input.deletethislistrow" ).click(function() {
				$(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').slideUp(200, function() {
					$(this).remove();
					calculateGrandTotal();
				});
			});
			
			$( ".numeric" ).keyup(function() {
				var price = $(this).val();
				var ValidChars = "-.0123456789";
				var IsNumber=true;
				var Char;
				var validint = '';
				for (var i = 0; i < price.length && IsNumber == true; i++){ 
					Char = price.charAt(i);
					if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
					else{
						validint = validint+Char;
					}
				}
				$(this).val(validint);
			});
			
			$( ".expiryminus_item" ).keypress(function(keyname) {
				if(keyname.which==13){
					var imei = $(this).val();
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					
					$.each(itemarraydata, function(key, value){
						var valuearray = value.split('||');
						if(key==imei){
							document.getElementsByName("salesitem_id[]")[indexpos].value = valuearray[0];
							//document.getElementsByName("expiryminus_item[]")[indexpos].value = valuearray[1];
							document.getElementsByName("expiryminus_category[]")[indexpos].value = valuearray[1];
							document.getElementsByName("expiryminus_stock[]")[indexpos].value = valuearray[2];
							document.getElementsByName("expiryminus_purchase_rate[]")[indexpos].value = valuearray[3];
							document.getElementsByName("expiryminus_rate[]")[indexpos].value = valuearray[4];
							document.getElementsByName("expiryminus_qty[]")[indexpos].value = 1;
							
							calculateCurrentRowTotal(indexpos);
							addnew_particularrow(true);
						}
					});
					return false;
				}
			});
			
		}
	}
	
	/*function deletethislistrow(tableidname){
		$("#"+tableidname).parent("li").slideUp(200, function() {
			$(this).remove();
			calculateCurrentRowTotal('all');
		});
	}*/
</script>