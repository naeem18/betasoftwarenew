<?php session_start();?>
<?php
include('bootstrap5.3.8/css/bootstrap-reboot.big.php');

if(isset($_SESSION['username']) && isset($_GET['p']))
{
    // Permission check skip pages
    $skip_pages = array(
        'zz_patientinvestigationlist',
		
        'zz_report_biochemical_single',
        'zz_group_biochemical',
        'zz_report_clinicalpathology_single',
        'zz_report_fullgroup_serology',
        'zz_report_haematology_single',
        'zz_report_hematology',
        'zz_report_histopathology_single',
        'zz_report_hormone_single',
 		'zz_report_immunology_single',
        'zz_report_microbiology_single',
        'zz_report_mycology_single',
        'zz_report_serology_single',
		
        'zz_group_biochemical',
        'zz_group_all',
        'zz_group_clinicalpathology',
        'zz_group_haematology',
        'zz_group_histopathology',
 		'zz_group_hormone',
        'zz_group_microbiology',
        'zz_group_serology',
        'zz_labreportentryurine',
        'zz_multi_group',
        'zz_patientinvestigationlistusg',
		
		 'zz_cbc',
		 'zz_cbcreport',
		 'zz_stoolrereport',
		 'zz_usg',
		
		'z_semenanalysis',
		'zz_echo',
		'samplepage',
		'samplepage',
		'samplepage',
		'samplepage',
		
        'zz_patientlist'
    );

    if(!in_array($_GET['p'], $skip_pages))
    {
        $username = mysqli_real_escape_string($conn, $_SESSION['username']);
        $pageurl  = "index.php?p=" . mysqli_real_escape_string($conn, $_GET['p']);

        $sql = "
            SELECT ms.submenuid
            FROM master_menusub ms
            INNER JOIN master_employeerights mer
                ON ms.submenuid = mer.submenuid
            WHERE mer.username = '$username'
            AND ms.submenulink = '$pageurl'
            LIMIT 1
        ";

        $result = mysqli_query($conn, $sql);

        if(mysqli_num_rows($result) == 0)
        {
            header("Location: logout.php");
            exit();
        }
    }
}
?>
<?php
date_default_timezone_set("Asia/Dhaka");
$pagename = 'homepageac'; //Default page
if(isset($_GET['p']) && is_string($_GET['p'])) {
    $pagename = preg_replace('/[^a-zA-Z0-9_-]/', '', $_GET['p']);
}

// Page title generation
$title = str_replace(['-', '_'], ' ', $pagename);
$title = ($title === 'homepageac') ? 'Beta Hospital Management System' : ucwords($title);
$pagename = $pagename.'.php';

// Check if requested page exists
if (!file_exists($pagename)) {
    $pagename = 'homepageac.php';
    $title = 'BETA HEALTHCARE ERP 2.6+';
}
//include __DIR__ . '/ajax/name.php';
?>