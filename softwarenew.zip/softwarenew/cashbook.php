<?php
$searchstr='';
if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
{
	$transactiondatefrom = $_REQUEST['ADate1'];
	$transactiondateto = $_REQUEST['ADate2'];
	
	$section = $_REQUEST['section'];
 	if($section !=''){
		$searchstr .= " and section like '%$section%'";
		}
	}
else
{
	$transactiondatefrom = date('Y-m-d', strtotime('-0 day'));
	$transactiondateto = date('Y-m-d');
}
?>
<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td valign="top" align="center">
    	<form name="cbform1" method="post" action="index.php?p=cashbook">
            <table width="100%" border="1" align="center" cellpadding="4" cellspacing="0" bordercolor="#666666" style="border-collapse: collapse">
              <tbody>
                <tr bgcolor="#011E6A">
                  <td colspan="10" bgcolor="#CCCCCC"><strong>Search Date wise</strong></td>
                </tr>           
                <tr>
                    <td width="12%" valign="center" align="right" bgcolor="#FFFFFF"> Date From:</td>
                    <td width="16%" bgcolor="#FFFFFF">
                        <input name="ADate1" id="ADate1" style="border: 1px solid #001E6A" value="<?php echo $transactiondatefrom; ?>" size="10" readonly onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
                    </td>
                    <td width="12%" align="right" valign="center" bgcolor="#FFFFFF">Date To:</td>
                    <td width="16%" bgcolor="#FFFFFF">
                    <input name="ADate2" id="ADate2" style="border: 1px solid #001E6A" value="<?php echo $transactiondateto; ?>"  size="10" readonly onKeyDown="return disableEnterKey()" />
                    <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate2')" style="cursor:pointer"/>
                    </td>
                    <td width="10%" align="right" valign="center" bgcolor="#FFFFFF">By Section</td>
            	    <td bgcolor="#FFFFFF"><input type="text" name="section" id="section"/></td>
        
                    <td width="16%" align="left" valign="center" bgcolor="#FFFFFF">
                        <input style="border: 1px solid #001E6A" type="submit" value="Search" name="Submit" />
                        <input name="resetbutton" type="reset" id="resetbutton" style="border: 1px solid #001E6A" value="Reset" />
                    </td>
                    <td width="6%" align="right" valign="center" bgcolor="#FFFFFF">
                       <input name="print" type="button" id="print" style="border: 1px solid #001E6A" value="Print" onClick="PrintDiv();" />
                    </td>
                </tr>
              </tbody>
            </table>
		</form>

   	</td>
</tr>

<tr>
    <td align="center">
		<?php
			$datetime1 = new DateTime($transactiondatefrom);
			$datetime2 = new DateTime($transactiondateto);
			$interval = $datetime1->diff($datetime2);
			$totaldays = $interval->format('%a');
			if($datetime1<$datetime2){
				$fromdate = $transactiondatefrom;
				$todate = $transactiondateto;
			}
			else{
				$fromdate = $transactiondateto;
				$todate = $transactiondatefrom;
			}
		?>
         <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1">
          <tr>
            <td colspan="19" bgcolor="#f2f2f2" align="center" style="color:#03F; border:1px solid #03F; padding-left:15px;">
            	<strong><?php echo $hospitaldata_name; ?></strong><br>
                <strong>Cash Book :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></strong>
            </td>
          </tr>
          </table>
          
         <table align="left" style="BORDER-COLLAPSE: collapse" width="50%" border="1">
          <tr bgcolor="#fff"><td align="center" colspan="3">Income</td></tr>
            
            <tr bgcolor="#ccc">
                <td  align="center">Section</td>
              	<td  align="center">Inv Cash</td> 
                <td  align="center">Due Collection</td>              
             </tr>
              
		<?php
		//$hospitalinvoice_id='';
		
		$totalsumlabinvoice_receiveamount='0.00';
		$totalsumlabinvoice_receiveamount='0.00';
		$totalsumcollection_amount='0.00';
		$totalsumdiscount_amount='0.00';
		//$totalsumexpense_amount='0.00';
		$totalsumlabinvoice_subtotal  ='';
		$totalsumlabinvoice_subtotalafterdisc  ='';
		$totalsumlabinvoice_due  ='';
			// $totalsumlabpcpaid_amount='0.00';
			// $totalsumsalaryentry_paid='0.00';
		$s='';
		for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
			$sqllabinvoice = "select * from dailytransection_lab where expense_amount='' and salaryentry_paid='' and labpcpaid_amount='' and labinvoice_receiveamount!=0 and status !='Deleted' And dailytransection_lab_date between '$newfromdate' and '$newtodate' $searchstr order by section asc";
	  		$labinvoicequery = mysqli_query($conn, $sqllabinvoice);
			if($labinvoicequery &&  mysqli_num_rows($labinvoicequery)>0){
			while ($labinvoicerow = mysqli_fetch_array($labinvoicequery)) {
					$dailytransection_lab_id = $labinvoicerow['dailytransection_lab_id'];
                    $labinvoice_patientid = $labinvoicerow['labinvoice_patientid'];
                    $labinvoice_id = $labinvoicerow['labinvoice_id'];
                    $labinvoice_patient = $labinvoicerow['labinvoice_patient'];
                    $labinvoice_address = $labinvoicerow['labinvoice_address'];
                    $user = $labinvoicerow['user'];
					$update_user = $labinvoicerow['update_user'];
					$section = $labinvoicerow['section'];
					$labinvoice_receiveamount = $labinvoicerow['labinvoice_receiveamount'];
                    $discount_amount = $labinvoicerow['discount_amount'];
					$expense_amount = $labinvoicerow['expense_amount'];
					$salaryentry_paid = $labinvoicerow['salaryentry_paid'];
					$labpcpaid_amount = $labinvoicerow['labpcpaid_amount'];
					$collection_amount = $labinvoicerow['collection_amount'];
					$labinvoice_subtotal = $labinvoicerow['labinvoice_subtotal'];
					$labinvoice_subtotalafterdisc = $labinvoicerow['labinvoice_subtotalafterdisc'];
					$labinvoice_due = $labinvoicerow['labinvoice_due'];
					$dailytransection_lab_date = $labinvoicerow['dailytransection_lab_date'];
					$dailytransection_lab_update = $labinvoicerow['dailytransection_lab_update'];
					  
					$totalsumlabinvoice_receiveamount  = $totalsumlabinvoice_receiveamount + $labinvoice_receiveamount;
					$totalsumcollection_amount  = $totalsumcollection_amount + $collection_amount;
					
					$totalsumdiscount_amount  = $totalsumdiscount_amount + $discount_amount;
					$totalsumlabinvoice_subtotal  = $totalsumlabinvoice_subtotal + $labinvoice_subtotal;
					$totalsumlabinvoice_subtotalafterdisc  = $totalsumlabinvoice_subtotalafterdisc + $labinvoice_subtotalafterdisc;
					$totalsumlabinvoice_due  = $totalsumlabinvoice_due + $labinvoice_due;
					//$totalsumexpense_amount  = $totalsumexpense_amount + $expense_amount;
					//$totalsumsalaryentry_paid  = $totalsumsalaryentry_paid + $salaryentry_paid;
					//$totalsumlabpcpaid_amount  = $totalsumlabpcpaid_amount + $labpcpaid_amount;
			 		?>
                <tr>
                   <td align="center"><?php echo $section; ?></td>
                   <td  align="center"><strong><?php echo $labinvoice_receiveamount; ?></strong> </td>
                   <td  align="center"><strong><?php echo $collection_amount; ?></strong></td>
              	</tr>
                <?php
                }
			}
		}
		?>
        
        <tr bgcolor="#ccc">
           <td align="center"></td>
           <td align="center"><strong>Cash: <?php echo $totalsumlabinvoice_receiveamount; ?></strong></td>
           <td align="center"><strong>Collection: <?php echo $totalsumcollection_amount; ?> </strong><br>
           Gross Cash: <?php echo $totalsumlabinvoice_receiveamount+$totalsumcollection_amount; ?></td>
          </tr>
         </table>
        
        <table align="center" style="BORDER-COLLAPSE: collapse" width="50%" border="1">
          <tr bgcolor="#fff"><td align="center" colspan="4">Expenses</td></tr>
             <tr bgcolor="#f3f3f3">
                <td align="center">Section</td>
              	<td align="center">General Expense</td>
              	<td align="center">Salary Paid</td>
              	<td align="center">PC Paid</td>
            </tr>
 		<?php
 		//$totalsumlabinvoice_receiveamount='0.00';
		//$totalsumcollection_amount='0.00';
		//$totalsumdiscount_amount='0.00';
		$totalsumexpense_amount='0.00';
		$totalsumlabinvoice_subtotal  ='';
		$totalsumlabinvoice_subtotalafterdisc  ='';
		$totalsumlabinvoice_due  ='';
			 $totalsumlabpcpaid_amount='0.00';
			 $totalsumsalaryentry_paid='0.00';
		$s='';
		for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
			$sqllabinvoice = "select * from dailytransection_lab where labinvoice_receiveamount=0 and discount_amount=0 and 
			collection_amount=0 and status !='Deleted' And dailytransection_lab_date between '$newfromdate' and '$newtodate' 
			$searchstr order by section asc";
	  		$labinvoicequery = mysqli_query($conn, $sqllabinvoice);
			if($labinvoicequery &&  mysqli_num_rows($labinvoicequery)>0){
			while ($labinvoicerow = mysqli_fetch_array($labinvoicequery)) {
					$dailytransection_lab_id = $labinvoicerow['dailytransection_lab_id'];
                    $labinvoice_patientid = $labinvoicerow['labinvoice_patientid'];
                    $labinvoice_id = $labinvoicerow['labinvoice_id'];
                    $labinvoice_patient = $labinvoicerow['labinvoice_patient'];
                    $labinvoice_address = $labinvoicerow['labinvoice_address'];
                    $user = $labinvoicerow['user'];
					$update_user = $labinvoicerow['update_user'];
					$section = $labinvoicerow['section'];
					$labinvoice_receiveamount = $labinvoicerow['labinvoice_receiveamount'];
                    $collection_amount = $labinvoicerow['collection_amount'];
					$discount_amount = $labinvoicerow['discount_amount'];
					$expense_amount = $labinvoicerow['expense_amount'];
					$salaryentry_paid = $labinvoicerow['salaryentry_paid'];
					$labpcpaid_amount = $labinvoicerow['labpcpaid_amount'];
					$labinvoice_subtotal = $labinvoicerow['labinvoice_subtotal'];
					$labinvoice_subtotalafterdisc = $labinvoicerow['labinvoice_subtotalafterdisc'];
					$labinvoice_due = $labinvoicerow['labinvoice_due'];
					$dailytransection_lab_date = $labinvoicerow['dailytransection_lab_date'];
					$dailytransection_lab_update = $labinvoicerow['dailytransection_lab_update'];
					 
					//$totalsumlabinvoice_receiveamount  = $totalsumlabinvoice_receiveamount + $labinvoice_receiveamount;
					//$totalsumcollection_amount  = $totalsumcollection_amount + $collection_amount;
					//$totalsumdiscount_amount  = $totalsumdiscount_amount + $discount_amount;
					$totalsumlabinvoice_subtotal  = $totalsumlabinvoice_subtotal + $labinvoice_subtotal;
					$totalsumlabinvoice_subtotalafterdisc  = $totalsumlabinvoice_subtotalafterdisc + $labinvoice_subtotalafterdisc;
					$totalsumlabinvoice_due  = $totalsumlabinvoice_due + $labinvoice_due;
					
					$totalsumexpense_amount  = $totalsumexpense_amount + $expense_amount;
					$totalsumsalaryentry_paid  = $totalsumsalaryentry_paid + $salaryentry_paid;
					$totalsumlabpcpaid_amount  = $totalsumlabpcpaid_amount + $labpcpaid_amount;
							
			 ?>
               
                <tr>
                   <td align="center"><?php echo $section; ?></td>
                   <td align="center"><strong><?php echo $expense_amount; ?></strong></td>
                   <td align="center"><strong><?php echo $salaryentry_paid; ?></strong></td>
                   <td align="center"><strong><?php echo $labpcpaid_amount; ?></strong> </td>
              	</tr>
                <?php
                }
			}
		}
		?>
        
        <tr bgcolor="#f3f3f3">
            <td align="center"></td>
           
            <td align="center"><strong style="color: #1515CF">General Expense:<?php echo $totalsumexpense_amount;?></strong><br>
            Net Exp:<?php echo $totalsumexpense_amount + $totalsumsalaryentry_paid + $totalsumlabpcpaid_amount; ?></td>
            <td align="center"><strong style="color: #1515CF">Salary: <?php echo $totalsumsalaryentry_paid; ?></strong></td>
            <td align="center"><strong style="color: #1515CF">PC: <?php echo $totalsumlabpcpaid_amount; ?></strong></td>
          </tr>
          
          
        </table>
        
        <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1">
 
         <?php /*?><?php
		$totalsumlabinvoice_receiveamount='0.00';
		$totalsumlabinvoice_receiveamount='0.00';
		$totalsumcollection_amount='0.00';
		$totalsumdiscount_amount='0.00';
		$totalsumexpense_amount='0.00';
		$totalsumlabinvoice_subtotal  ='';
		$totalsumlabinvoice_subtotalafterdisc  ='';
		$totalsumlabinvoice_due  ='';
		$totalsumlabpcpaid_amount='0.00';
		$totalsumsalaryentry_paid='0.00';
		$s='';
		for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
			$sqllabinvoice = "select * from dailytransection_lab where status !='Deleted' And dailytransection_lab_date between 
			'$newfromdate' and '$newtodate' $searchstr order by section asc";
	  		$labinvoicequery = mysqli_query($conn, $sqllabinvoice);
			if($labinvoicequery &&  mysqli_num_rows($labinvoicequery)>0){
			while ($labinvoicerow = mysqli_fetch_array($labinvoicequery)) {
					$dailytransection_lab_id = $labinvoicerow['dailytransection_lab_id'];
                    $labinvoice_patientid = $labinvoicerow['labinvoice_patientid'];
                    $labinvoice_id = $labinvoicerow['labinvoice_id'];
                    $labinvoice_patient = $labinvoicerow['labinvoice_patient'];
                    $labinvoice_address = $labinvoicerow['labinvoice_address'];
                    $user = $labinvoicerow['user'];
					$update_user = $labinvoicerow['update_user'];
					$section = $labinvoicerow['section'];
					$labinvoice_receiveamount = $labinvoicerow['labinvoice_receiveamount'];
                    $collection_amount = $labinvoicerow['collection_amount'];
					$discount_amount = $labinvoicerow['discount_amount'];
					$expense_amount = $labinvoicerow['expense_amount'];
					$salaryentry_paid = $labinvoicerow['salaryentry_paid'];
					$labpcpaid_amount = $labinvoicerow['labpcpaid_amount'];
					$labinvoice_subtotal = $labinvoicerow['labinvoice_subtotal'];
					$labinvoice_subtotalafterdisc = $labinvoicerow['labinvoice_subtotalafterdisc'];
					$labinvoice_due = $labinvoicerow['labinvoice_due'];
					$dailytransection_lab_date = $labinvoicerow['dailytransection_lab_date'];
					$dailytransection_lab_update = $labinvoicerow['dailytransection_lab_update'];
					 
					$totalsumlabinvoice_receiveamount  = $totalsumlabinvoice_receiveamount + $labinvoice_receiveamount;
					$totalsumcollection_amount  = $totalsumcollection_amount + $collection_amount;
					$totalsumdiscount_amount  = $totalsumdiscount_amount + $discount_amount;
					$totalsumlabinvoice_subtotal  = $totalsumlabinvoice_subtotal + $labinvoice_subtotal;
					$totalsumlabinvoice_subtotalafterdisc  = $totalsumlabinvoice_subtotalafterdisc + $labinvoice_subtotalafterdisc;
					$totalsumlabinvoice_due  = $totalsumlabinvoice_due + $labinvoice_due;
					$totalsumexpense_amount  = $totalsumexpense_amount + $expense_amount;
					$totalsumsalaryentry_paid  = $totalsumsalaryentry_paid + $salaryentry_paid;
					$totalsumlabpcpaid_amount  = $totalsumlabpcpaid_amount + $labpcpaid_amount;
                 }
			}
		}
		?><?php */?>
         <tr> 
         	<td colspan="7" align="left"><strong style="color: #DC1E03">Balance: 
            <?php echo $totalsumlabinvoice_receiveamount+$totalsumcollection_amount -$totalsumexpense_amount-
			$totalsumsalaryentry_paid-$totalsumlabpcpaid_amount; ?> </strong>
            </td>
          </tr>
             
        </table>
        
        
        
        <?php /*?>Total Cash Till Date: 
        <table align="center" style="BORDER-COLLAPSE: collapse; margin-top:20px;" width="100%" border="1">
 		<?php
 		$totalsumlabinvoice_receiveamount='0.00';
		$totalsumlabinvoice_receiveamount='0.00';
		$totalsumcollection_amount='0.00';
		$totalsumdiscount_amount='0.00';
		$totalsumexpense_amount='0.00';
		$totalsumlabinvoice_subtotal  ='';
		$totalsumlabinvoice_subtotalafterdisc  ='';
		$totalsumlabinvoice_due  ='';
		$totalsumlabpcpaid_amount='0.00';
		$totalsumsalaryentry_paid='0.00';
		$s='';
			
			$sqllabinvoice = "select * from dailytransection_lab order by section asc";
	  		$labinvoicequery = mysqli_query($conn, $sqllabinvoice);
			if($labinvoicequery &&  mysqli_num_rows($labinvoicequery)>0){
			while ($labinvoicerow = mysqli_fetch_array($labinvoicequery)) {
					$dailytransection_lab_id = $labinvoicerow['dailytransection_lab_id'];
                    $labinvoice_patientid = $labinvoicerow['labinvoice_patientid'];
                    $labinvoice_id = $labinvoicerow['labinvoice_id'];
                    $labinvoice_patient = $labinvoicerow['labinvoice_patient'];
                    $labinvoice_receiveamount = $labinvoicerow['labinvoice_receiveamount'];
                    $discount_amount = $labinvoicerow['discount_amount'];
					$expense_amount = $labinvoicerow['expense_amount'];
					$salaryentry_paid = $labinvoicerow['salaryentry_paid'];
					$labpcpaid_amount = $labinvoicerow['labpcpaid_amount'];
					$labinvoice_address = $labinvoicerow['labinvoice_address'];
                    $user = $labinvoicerow['user'];
					$update_user = $labinvoicerow['update_user'];
					 $section = $labinvoicerow['section'];
					$collection_amount = $labinvoicerow['collection_amount'];
					$labinvoice_subtotal = $labinvoicerow['labinvoice_subtotal'];
					$labinvoice_subtotalafterdisc = $labinvoicerow['labinvoice_subtotalafterdisc'];
					$labinvoice_due = $labinvoicerow['labinvoice_due'];
					$dailytransection_lab_date = $labinvoicerow['dailytransection_lab_date'];
					$dailytransection_lab_update = $labinvoicerow['dailytransection_lab_update'];
					?>
                <?php  
					$totalsumlabinvoice_receiveamount  = $totalsumlabinvoice_receiveamount + $labinvoice_receiveamount;
					$totalsumcollection_amount  = $totalsumcollection_amount + $collection_amount;
					$totalsumdiscount_amount  = $totalsumdiscount_amount + $discount_amount;
					$totalsumlabinvoice_subtotal  = $totalsumlabinvoice_subtotal + $labinvoice_subtotal;
					$totalsumlabinvoice_subtotalafterdisc  = $totalsumlabinvoice_subtotalafterdisc + $labinvoice_subtotalafterdisc;
					$totalsumlabinvoice_due  = $totalsumlabinvoice_due + $labinvoice_due;
					$totalsumexpense_amount  = $totalsumexpense_amount + $expense_amount;
					$totalsumsalaryentry_paid  = $totalsumsalaryentry_paid + $salaryentry_paid;
					$totalsumlabpcpaid_amount  = $totalsumlabpcpaid_amount + $labpcpaid_amount;
			
                }
			}
		
		?>
        
        <tr bgcolor="#BEC2EC">
            <td align="left"><strong>Total: </strong></td>
           
           <td align="left"><strong>Cash: <?php echo $totalsumlabinvoice_receiveamount; ?></strong></td>
            <td align="left"><strong>Collection: <?php echo $totalsumcollection_amount; ?> </strong><br>Gross Cash: <?php echo $totalsumlabinvoice_receiveamount+$totalsumcollection_amount; ?></td>
            <td align="left"><strong style="color: #1515CF">General Expense:<?php echo $totalsumexpense_amount;?></strong><br>Net Exp:<?php echo $totalsumexpense_amount + $totalsumsalaryentry_paid + $totalsumlabpcpaid_amount; ?></td>
            <td align="left"><strong style="color: #1515CF">Salary: <?php echo $totalsumsalaryentry_paid; ?></strong></td>
            <td align="left"><strong style="color: #1515CF">PC: <?php echo $totalsumlabpcpaid_amount; ?></strong></td>
            <td colspan="2" align="left"><strong style="color: #DC1E03; background:">Total Cash In Hand: 
            <?php echo $totalsumlabinvoice_receiveamount+$totalsumcollection_amount -$totalsumexpense_amount-$totalsumsalaryentry_paid-$totalsumlabpcpaid_amount; ?> </strong></td>
          </tr>
        </table><?php */?>
    </td>
</tr>

 <td align="center" id="divToPrint" style="display:none">
 		<?php
			$datetime1 = new DateTime($transactiondatefrom);
			$datetime2 = new DateTime($transactiondateto);
			$interval = $datetime1->diff($datetime2);
			$totaldays = $interval->format('%a');
			if($datetime1<$datetime2){
				$fromdate = $transactiondatefrom;
				$todate = $transactiondateto;
			}
			else{
				$fromdate = $transactiondateto;
				$todate = $transactiondatefrom;
			}
		?>
         <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1">
          <tr>
            <td colspan="19" bgcolor="#f2f2f2" align="center" style="color:#03F; border:1px solid #03F; padding-left:15px;">
            	<strong><?php echo $hospitaldata_name; ?></strong><br>
                <strong>Cash Book :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></strong>
            </td>
          </tr>
          </table>
          
         <table align="left" style="BORDER-COLLAPSE: collapse" width="50%" border="1">
          <tr bgcolor="#fff"><td align="center" colspan="3">Income</td></tr>
            
            <tr bgcolor="#ccc">
                <td  align="center">Section</td>
              	<td  align="center">Inv Cash</td> 
                <td  align="center">Due Collection</td>              
             </tr>
              
		<?php
		//$hospitalinvoice_id='';
		
		$totalsumlabinvoice_receiveamount='0.00';
		$totalsumlabinvoice_receiveamount='0.00';
		$totalsumcollection_amount='0.00';
		$totalsumdiscount_amount='0.00';
		//$totalsumexpense_amount='0.00';
		$totalsumlabinvoice_subtotal  ='';
		$totalsumlabinvoice_subtotalafterdisc  ='';
		$totalsumlabinvoice_due  ='';
			// $totalsumlabpcpaid_amount='0.00';
			// $totalsumsalaryentry_paid='0.00';
		$s='';
		for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
			$sqllabinvoice = "select * from dailytransection_lab where expense_amount='' and salaryentry_paid='' and labpcpaid_amount='' and labinvoice_receiveamount!=0 and status !='Deleted' And dailytransection_lab_date between '$newfromdate' and '$newtodate' $searchstr order by section asc";
	  		$labinvoicequery = mysqli_query($conn, $sqllabinvoice);
			if($labinvoicequery &&  mysqli_num_rows($labinvoicequery)>0){
			while ($labinvoicerow = mysqli_fetch_array($labinvoicequery)) {
					$dailytransection_lab_id = $labinvoicerow['dailytransection_lab_id'];
                    $labinvoice_patientid = $labinvoicerow['labinvoice_patientid'];
                    $labinvoice_id = $labinvoicerow['labinvoice_id'];
                    $labinvoice_patient = $labinvoicerow['labinvoice_patient'];
                    $labinvoice_address = $labinvoicerow['labinvoice_address'];
                    $user = $labinvoicerow['user'];
					$update_user = $labinvoicerow['update_user'];
					$section = $labinvoicerow['section'];
					$labinvoice_receiveamount = $labinvoicerow['labinvoice_receiveamount'];
                    $discount_amount = $labinvoicerow['discount_amount'];
					$expense_amount = $labinvoicerow['expense_amount'];
					$salaryentry_paid = $labinvoicerow['salaryentry_paid'];
					$labpcpaid_amount = $labinvoicerow['labpcpaid_amount'];
					$collection_amount = $labinvoicerow['collection_amount'];
					$labinvoice_subtotal = $labinvoicerow['labinvoice_subtotal'];
					$labinvoice_subtotalafterdisc = $labinvoicerow['labinvoice_subtotalafterdisc'];
					$labinvoice_due = $labinvoicerow['labinvoice_due'];
					$dailytransection_lab_date = $labinvoicerow['dailytransection_lab_date'];
					$dailytransection_lab_update = $labinvoicerow['dailytransection_lab_update'];
					  
					$totalsumlabinvoice_receiveamount  = $totalsumlabinvoice_receiveamount + $labinvoice_receiveamount;
					$totalsumcollection_amount  = $totalsumcollection_amount + $collection_amount;
					
					$totalsumdiscount_amount  = $totalsumdiscount_amount + $discount_amount;
					$totalsumlabinvoice_subtotal  = $totalsumlabinvoice_subtotal + $labinvoice_subtotal;
					$totalsumlabinvoice_subtotalafterdisc  = $totalsumlabinvoice_subtotalafterdisc + $labinvoice_subtotalafterdisc;
					$totalsumlabinvoice_due  = $totalsumlabinvoice_due + $labinvoice_due;
					//$totalsumexpense_amount  = $totalsumexpense_amount + $expense_amount;
					//$totalsumsalaryentry_paid  = $totalsumsalaryentry_paid + $salaryentry_paid;
					//$totalsumlabpcpaid_amount  = $totalsumlabpcpaid_amount + $labpcpaid_amount;
			 		?>
                <tr>
                   <td align="center"><?php echo $section; ?></td>
                   <td  align="center"><strong><?php echo $labinvoice_receiveamount; ?></strong> </td>
                   <td  align="center"><strong><?php echo $collection_amount; ?></strong></td>
              	</tr>
                <?php
                }
			}
		}
		?>
        
        <tr bgcolor="#ccc">
           <td align="center"></td>
           <td align="center"><strong>Cash: <?php echo $totalsumlabinvoice_receiveamount; ?></strong></td>
           <td align="center"><strong>Collection: <?php echo $totalsumcollection_amount; ?> </strong><br>
           Gross Cash: <?php echo $totalsumlabinvoice_receiveamount+$totalsumcollection_amount; ?></td>
          </tr>
         </table>
        
        <table align="center" style="BORDER-COLLAPSE: collapse" width="50%" border="1">
          <tr bgcolor="#fff"><td align="center" colspan="4">Expenses</td></tr>
             <tr bgcolor="#f3f3f3">
                <td align="center">Section</td>
              	<td align="center">General Expense</td>
              	<td align="center">Salary Paid</td>
              	<td align="center">PC Paid</td>
            </tr>
 		<?php
 		//$totalsumlabinvoice_receiveamount='0.00';
		//$totalsumcollection_amount='0.00';
		//$totalsumdiscount_amount='0.00';
		$totalsumexpense_amount='0.00';
		$totalsumlabinvoice_subtotal  ='';
		$totalsumlabinvoice_subtotalafterdisc  ='';
		$totalsumlabinvoice_due  ='';
			 $totalsumlabpcpaid_amount='0.00';
			 $totalsumsalaryentry_paid='0.00';
		$s='';
		for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
			$sqllabinvoice = "select * from dailytransection_lab where labinvoice_receiveamount=0 and discount_amount=0 and 
			collection_amount=0 and status !='Deleted' And dailytransection_lab_date between '$newfromdate' and '$newtodate' 
			$searchstr order by section asc";
	  		$labinvoicequery = mysqli_query($conn, $sqllabinvoice);
			if($labinvoicequery &&  mysqli_num_rows($labinvoicequery)>0){
			while ($labinvoicerow = mysqli_fetch_array($labinvoicequery)) {
					$dailytransection_lab_id = $labinvoicerow['dailytransection_lab_id'];
                    $labinvoice_patientid = $labinvoicerow['labinvoice_patientid'];
                    $labinvoice_id = $labinvoicerow['labinvoice_id'];
                    $labinvoice_patient = $labinvoicerow['labinvoice_patient'];
                    $labinvoice_address = $labinvoicerow['labinvoice_address'];
                    $user = $labinvoicerow['user'];
					$update_user = $labinvoicerow['update_user'];
					$section = $labinvoicerow['section'];
					$labinvoice_receiveamount = $labinvoicerow['labinvoice_receiveamount'];
                    $collection_amount = $labinvoicerow['collection_amount'];
					$discount_amount = $labinvoicerow['discount_amount'];
					$expense_amount = $labinvoicerow['expense_amount'];
					$salaryentry_paid = $labinvoicerow['salaryentry_paid'];
					$labpcpaid_amount = $labinvoicerow['labpcpaid_amount'];
					$labinvoice_subtotal = $labinvoicerow['labinvoice_subtotal'];
					$labinvoice_subtotalafterdisc = $labinvoicerow['labinvoice_subtotalafterdisc'];
					$labinvoice_due = $labinvoicerow['labinvoice_due'];
					$dailytransection_lab_date = $labinvoicerow['dailytransection_lab_date'];
					$dailytransection_lab_update = $labinvoicerow['dailytransection_lab_update'];
					 
					//$totalsumlabinvoice_receiveamount  = $totalsumlabinvoice_receiveamount + $labinvoice_receiveamount;
					//$totalsumcollection_amount  = $totalsumcollection_amount + $collection_amount;
					//$totalsumdiscount_amount  = $totalsumdiscount_amount + $discount_amount;
					$totalsumlabinvoice_subtotal  = $totalsumlabinvoice_subtotal + $labinvoice_subtotal;
					$totalsumlabinvoice_subtotalafterdisc  = $totalsumlabinvoice_subtotalafterdisc + $labinvoice_subtotalafterdisc;
					$totalsumlabinvoice_due  = $totalsumlabinvoice_due + $labinvoice_due;
					
					$totalsumexpense_amount  = $totalsumexpense_amount + $expense_amount;
					$totalsumsalaryentry_paid  = $totalsumsalaryentry_paid + $salaryentry_paid;
					$totalsumlabpcpaid_amount  = $totalsumlabpcpaid_amount + $labpcpaid_amount;
							
			 ?>
               
                <tr>
                   <td align="center"><?php echo $section; ?></td>
                   <td align="center"><strong><?php echo $expense_amount; ?></strong></td>
                   <td align="center"><strong><?php echo $salaryentry_paid; ?></strong></td>
                   <td align="center"><strong><?php echo $labpcpaid_amount; ?></strong> </td>
              	</tr>
                <?php
                }
			}
		}
		?>
        
        <tr bgcolor="#f3f3f3">
            <td align="center"></td>
           
            <td align="center"><strong style="color: #1515CF">General Expense:<?php echo $totalsumexpense_amount;?></strong><br>
            Net Exp:<?php echo $totalsumexpense_amount + $totalsumsalaryentry_paid + $totalsumlabpcpaid_amount; ?></td>
            <td align="center"><strong style="color: #1515CF">Salary: <?php echo $totalsumsalaryentry_paid; ?></strong></td>
            <td align="center"><strong style="color: #1515CF">PC: <?php echo $totalsumlabpcpaid_amount; ?></strong></td>
          </tr>
          
          
        </table>
        
        <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1">
 
         <?php /*?><?php
		$totalsumlabinvoice_receiveamount='0.00';
		$totalsumlabinvoice_receiveamount='0.00';
		$totalsumcollection_amount='0.00';
		$totalsumdiscount_amount='0.00';
		$totalsumexpense_amount='0.00';
		$totalsumlabinvoice_subtotal  ='';
		$totalsumlabinvoice_subtotalafterdisc  ='';
		$totalsumlabinvoice_due  ='';
		$totalsumlabpcpaid_amount='0.00';
		$totalsumsalaryentry_paid='0.00';
		$s='';
		for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
			$sqllabinvoice = "select * from dailytransection_lab where status !='Deleted' And dailytransection_lab_date between 
			'$newfromdate' and '$newtodate' $searchstr order by section asc";
	  		$labinvoicequery = mysqli_query($conn, $sqllabinvoice);
			if($labinvoicequery &&  mysqli_num_rows($labinvoicequery)>0){
			while ($labinvoicerow = mysqli_fetch_array($labinvoicequery)) {
					$dailytransection_lab_id = $labinvoicerow['dailytransection_lab_id'];
                    $labinvoice_patientid = $labinvoicerow['labinvoice_patientid'];
                    $labinvoice_id = $labinvoicerow['labinvoice_id'];
                    $labinvoice_patient = $labinvoicerow['labinvoice_patient'];
                    $labinvoice_address = $labinvoicerow['labinvoice_address'];
                    $user = $labinvoicerow['user'];
					$update_user = $labinvoicerow['update_user'];
					$section = $labinvoicerow['section'];
					$labinvoice_receiveamount = $labinvoicerow['labinvoice_receiveamount'];
                    $collection_amount = $labinvoicerow['collection_amount'];
					$discount_amount = $labinvoicerow['discount_amount'];
					$expense_amount = $labinvoicerow['expense_amount'];
					$salaryentry_paid = $labinvoicerow['salaryentry_paid'];
					$labpcpaid_amount = $labinvoicerow['labpcpaid_amount'];
					$labinvoice_subtotal = $labinvoicerow['labinvoice_subtotal'];
					$labinvoice_subtotalafterdisc = $labinvoicerow['labinvoice_subtotalafterdisc'];
					$labinvoice_due = $labinvoicerow['labinvoice_due'];
					$dailytransection_lab_date = $labinvoicerow['dailytransection_lab_date'];
					$dailytransection_lab_update = $labinvoicerow['dailytransection_lab_update'];
					 
					$totalsumlabinvoice_receiveamount  = $totalsumlabinvoice_receiveamount + $labinvoice_receiveamount;
					$totalsumcollection_amount  = $totalsumcollection_amount + $collection_amount;
					$totalsumdiscount_amount  = $totalsumdiscount_amount + $discount_amount;
					$totalsumlabinvoice_subtotal  = $totalsumlabinvoice_subtotal + $labinvoice_subtotal;
					$totalsumlabinvoice_subtotalafterdisc  = $totalsumlabinvoice_subtotalafterdisc + $labinvoice_subtotalafterdisc;
					$totalsumlabinvoice_due  = $totalsumlabinvoice_due + $labinvoice_due;
					$totalsumexpense_amount  = $totalsumexpense_amount + $expense_amount;
					$totalsumsalaryentry_paid  = $totalsumsalaryentry_paid + $salaryentry_paid;
					$totalsumlabpcpaid_amount  = $totalsumlabpcpaid_amount + $labpcpaid_amount;
                 }
			}
		}
		?><?php */?>
         <tr> 
         	<td colspan="7" align="left"><strong style="color: #DC1E03">Balance: 
            <?php echo $totalsumlabinvoice_receiveamount+$totalsumcollection_amount -$totalsumexpense_amount-
			$totalsumsalaryentry_paid-$totalsumlabpcpaid_amount; ?> </strong>
            </td>
          </tr>
             
        </table>
        
        
        
        <?php /*?>Total Cash Till Date: 
        <table align="center" style="BORDER-COLLAPSE: collapse; margin-top:20px;" width="100%" border="1">
 		<?php
 		$totalsumlabinvoice_receiveamount='0.00';
		$totalsumlabinvoice_receiveamount='0.00';
		$totalsumcollection_amount='0.00';
		$totalsumdiscount_amount='0.00';
		$totalsumexpense_amount='0.00';
		$totalsumlabinvoice_subtotal  ='';
		$totalsumlabinvoice_subtotalafterdisc  ='';
		$totalsumlabinvoice_due  ='';
		$totalsumlabpcpaid_amount='0.00';
		$totalsumsalaryentry_paid='0.00';
		$s='';
			
			$sqllabinvoice = "select * from dailytransection_lab order by section asc";
	  		$labinvoicequery = mysqli_query($conn, $sqllabinvoice);
			if($labinvoicequery &&  mysqli_num_rows($labinvoicequery)>0){
			while ($labinvoicerow = mysqli_fetch_array($labinvoicequery)) {
					$dailytransection_lab_id = $labinvoicerow['dailytransection_lab_id'];
                    $labinvoice_patientid = $labinvoicerow['labinvoice_patientid'];
                    $labinvoice_id = $labinvoicerow['labinvoice_id'];
                    $labinvoice_patient = $labinvoicerow['labinvoice_patient'];
                    $labinvoice_receiveamount = $labinvoicerow['labinvoice_receiveamount'];
                    $discount_amount = $labinvoicerow['discount_amount'];
					$expense_amount = $labinvoicerow['expense_amount'];
					$salaryentry_paid = $labinvoicerow['salaryentry_paid'];
					$labpcpaid_amount = $labinvoicerow['labpcpaid_amount'];
					$labinvoice_address = $labinvoicerow['labinvoice_address'];
                    $user = $labinvoicerow['user'];
					$update_user = $labinvoicerow['update_user'];
					 $section = $labinvoicerow['section'];
					$collection_amount = $labinvoicerow['collection_amount'];
					$labinvoice_subtotal = $labinvoicerow['labinvoice_subtotal'];
					$labinvoice_subtotalafterdisc = $labinvoicerow['labinvoice_subtotalafterdisc'];
					$labinvoice_due = $labinvoicerow['labinvoice_due'];
					$dailytransection_lab_date = $labinvoicerow['dailytransection_lab_date'];
					$dailytransection_lab_update = $labinvoicerow['dailytransection_lab_update'];
					?>
                <?php  
					$totalsumlabinvoice_receiveamount  = $totalsumlabinvoice_receiveamount + $labinvoice_receiveamount;
					$totalsumcollection_amount  = $totalsumcollection_amount + $collection_amount;
					$totalsumdiscount_amount  = $totalsumdiscount_amount + $discount_amount;
					$totalsumlabinvoice_subtotal  = $totalsumlabinvoice_subtotal + $labinvoice_subtotal;
					$totalsumlabinvoice_subtotalafterdisc  = $totalsumlabinvoice_subtotalafterdisc + $labinvoice_subtotalafterdisc;
					$totalsumlabinvoice_due  = $totalsumlabinvoice_due + $labinvoice_due;
					$totalsumexpense_amount  = $totalsumexpense_amount + $expense_amount;
					$totalsumsalaryentry_paid  = $totalsumsalaryentry_paid + $salaryentry_paid;
					$totalsumlabpcpaid_amount  = $totalsumlabpcpaid_amount + $labpcpaid_amount;
			
                }
			}
		
		?>
        
        <tr bgcolor="#BEC2EC">
            <td align="left"><strong>Total: </strong></td>
           
           <td align="left"><strong>Cash: <?php echo $totalsumlabinvoice_receiveamount; ?></strong></td>
            <td align="left"><strong>Collection: <?php echo $totalsumcollection_amount; ?> </strong><br>Gross Cash: <?php echo $totalsumlabinvoice_receiveamount+$totalsumcollection_amount; ?></td>
            <td align="left"><strong style="color: #1515CF">General Expense:<?php echo $totalsumexpense_amount;?></strong><br>Net Exp:<?php echo $totalsumexpense_amount + $totalsumsalaryentry_paid + $totalsumlabpcpaid_amount; ?></td>
            <td align="left"><strong style="color: #1515CF">Salary: <?php echo $totalsumsalaryentry_paid; ?></strong></td>
            <td align="left"><strong style="color: #1515CF">PC: <?php echo $totalsumlabpcpaid_amount; ?></strong></td>
            <td colspan="2" align="left"><strong style="color: #DC1E03; background:">Total Cash In Hand: 
            <?php echo $totalsumlabinvoice_receiveamount+$totalsumcollection_amount -$totalsumexpense_amount-$totalsumsalaryentry_paid-$totalsumlabpcpaid_amount; ?> </strong></td>
          </tr>
        </table><?php */?>
    </td>   
</table>