<script language="JavaScript" type="text/javascript">
	
	var itemdata = <?php echo $itemdata;?>;
	var patientdata = <?php echo $patientdata;?>;
	$(document).ready(function($) {
		//document.getElementsByName("bar[]")[0].focus();
		$( ".itemname" ).autocomplete({			
			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.saleselval );
				return false;
			}, 
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				document.getElementsByName("purchaseitem_id[]")[indexpos].value = ui.item.salesitem_id;
				document.getElementsByName("purchaseinvoice_item[]")[indexpos].value =ui.item.salesitem_name;
				document.getElementsByName("purchaseinvoice_category[]")[indexpos].value = ui.item.salesitem_category;
				document.getElementsByName("hscode[]")[indexpos].value = ui.item.salesitem_hscode;
				document.getElementsByName("color[]")[indexpos].value = ui.item.salesitem_color;
				document.getElementsByName("pack[]")[indexpos].value = ui.item.salesitem_pack;
				document.getElementsByName("pcs[]")[indexpos].value ='';
				document.getElementsByName("purchase_price[]")[indexpos].value = ui.item.salesitem_purchase_price;				
				document.getElementsByName("cartoon_no[]")[indexpos].value =ui.item.salesitem_cartoon_no;
				document.getElementsByName("cartoon_size[]")[indexpos].value = ui.item.salesitem_cartoon_size;
				//document.getElementsByName("gross_weight[]")[indexpos].value = ui.item.salesitem_sales_rate;
				
				//calculateCurrentRowTotal(indexpos);
				addnew_particularrow(true);
				
				return false;
			}
		});
		
		
		$( "#purchaseinvoice_patient" ).autocomplete({
			
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.saleselval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('purchaseinvoice_patientid').value = ui.item.labelval;
				 document.getElementById('purchaseinvoice_previousdue').value = ui.item.company_due;
				 document.getElementById('purchaseinvoice_mobile').value = ui.item.company_mobile;
				 document.getElementById('purchaseinvoice_address').value = ui.item.company_address;
				
				return false;
			}
		});
		
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
		$( ".sirow input.ccrt" ).keyup(function() {
			var index = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
			calculateCurrentRowTotal(index);
		});
	});
	
	function calculateCurrentRowTotal(index){
		
		var inventorysalesinvoice_rate = parseFloat(document.getElementsByName("inventorysalesinvoice_rate[]")[index].value);
		if(inventorysalesinvoice_rate=='' || isNaN(inventorysalesinvoice_rate)){inventorysalesinvoice_rate = 0.00;}
		
s		
		var inventorysalesinvoice_qty = parseFloat(document.getElementsByName("inventorysalesinvoice_qty[]")[index].value);
		if(inventorysalesinvoice_qty=='' || isNaN(inventorysalesinvoice_qty)){inventorysalesinvoice_qty = 0.00;}
		
		
		var inventorysalesinvoice_total = parseFloat(inventorysalesinvoice_rate*inventorysalesinvoice_qty);
		document.getElementsByName("inventorysalesinvoice_total[]")[index].value = parseFloat(inventorysalesinvoice_total ).toFixed(2);
	
	
		calculateGrandTotal();
	}
	
	function calculateGrandTotal(){
		var inventorysalesinvoice_totalarray = document.getElementsByName("inventorysalesinvoice_total[]");
		var inventorysalesinvoice_subtotal = 0.00;
		for(var r=0; r<inventorysalesinvoice_totalarray.length; r++){
			var inventorysalesinvoice_total = parseFloat(inventorysalesinvoice_totalarray[r].value);
			if(inventorysalesinvoice_total=='' || isNaN(inventorysalesinvoice_total)){inventorysalesinvoice_total = 0.00;}
			inventorysalesinvoice_subtotal = parseFloat(inventorysalesinvoice_subtotal+inventorysalesinvoice_total);
		}
		
		document.getElementById("inventorysalesinvoice_subtotal").value = inventorysalesinvoice_subtotal.toFixed(2);
		
		
	
		
		
		}
	
	function check_blankrow(){/*
		var purchaseinvoice_itemArray = document.getElementsByName('purchaseinvoice_item[]');
		var total_purchase_priceArray = document.getElementsByName('total_purchase_price[]');
			
		var error_messageid = document.getElementById('errmsg_particular_id');
		error_messageid.innerHTML = '';
		
		for(r = 0; r < purchaseinvoice_itemArray.length; r++) {
												
			if(purchaseinvoice_itemArray[r].value==''){
				error_messageid.innerHTML = 'Missing item name '+parseInt(r+1);
				purchaseinvoice_itemArray[r].focus();
				return false;
			}
			
			if(total_purchase_priceArray[r].value=='' || total_purchase_priceArray[r].value==0){
				error_messageid.innerHTML = 'Missing item total '+parseInt(r+1);
				total_purchase_priceArray[r].focus();
				return false;
			}
		}
		
		return true;
	*/}

	function addnew_particularrow(animate) {
		if(check_blankrow()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" align=\"left\" style=\" border:2px solid #FFF;\" border=\"1\" width=\"1284\" cellpadding=\"1\">"+
					'<tbody><tr></tr><tr>'+
						'<td align="center" width=\"130\"> <input type="text" name="bar[]" class="tdclass itemname"/>'+
						'<td align="center" width=\"170\"> <input type="text" name="purchaseinvoice_item[]"  size="25"/>'+
						'<input type="hidden" name="purchaseitem_id[]" class="tdclass itemname"/>'+
						'<input type="hidden" name="purchaseinvoice_category[]" class="tdclass"  /></td>'+
						 
						'<td align=\"center\" width=\"95\"> <input type="text" name="hscode[]" class="tdclasssale itemname"/></td>'+
						"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"color[]\" class=\"tdclasssale\"/></td>"+											 
											
						"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"pack[]\" class=\"tdclasssale numeric ccrt\" ></td>"+
						"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"pcs[]\" class=\"tdclasssale numeric ccrt\" /></td>"+
						
						"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"total_pcs[]\" class=\"tdclasssale numeric ccrt\"/></td>"+
						'<td align="center" width="95"><input type="text" name="purchase_price[]" class="tdclasssale numeric ccrt"/>'+
						"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"total_purchase_price[]\" class=\"tdclasssale numeric ccrt\"/>"+
						'<td align="center" width="95"><input type="text" name="cartoon_no[]" class="tdclasssale numeric ccrt" /></td>'+												
						'<td align="center" width=\"95\"><input type="text" name="cartoon_size[]" class="tdclasssale numeric ccrt" /></td>'+												
						
						'<td align="center" width=\"95\"><input type="text" name="gross_weight[]" class="tdclasssale numeric ccrt" /></td>'+												
						'<td align="center" width=\"95\"><input type="text" name="net_weight[]" class="tdclasssale numeric ccrt" /></td>'+												
						'<td align="center" width=\"95\"><textarea type="text" name="remark[]" class="tdclass" /></textarea></td>'+												
						
						'<td>'+
						 "<input type=\"button\" value=\"X\" class=\"tdclasssales deletethislistrow\"  />"+
						'</td>'+
					  '</tr></tbody>'+
				"</table>";
						
			var $newparticularlist = $("<li class=\"sirow\"></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(300); 
			else 
			   $newparticularlist.show();
			   document.getElementsByName("bar[]")[parseInt(particular_rowcount-1)].focus();  
			
			$( ".itemname" ).autocomplete({			
				minLength: 1,
				source: itemdata,
				focus: function( event, ui ) {
					//$( "#search_item_number" ).val( ui.item.saleselval );
					return false;
				},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				document.getElementsByName("purchaseitem_id[]")[indexpos].value = ui.item.salesitem_id;
				document.getElementsByName("purchaseinvoice_item[]")[indexpos].value =ui.item.salesitem_name;
				document.getElementsByName("purchaseinvoice_category[]")[indexpos].value = ui.item.salesitem_category;
				document.getElementsByName("hscode[]")[indexpos].value = ui.item.salesitem_hscode;
				document.getElementsByName("color[]")[indexpos].value = ui.item.salesitem_color;
				document.getElementsByName("pack[]")[indexpos].value = ui.item.salesitem_pack;
				document.getElementsByName("pcs[]")[indexpos].value ='';
				document.getElementsByName("purchase_price[]")[indexpos].value = ui.item.salesitem_purchase_price;				
				document.getElementsByName("cartoon_no[]")[indexpos].value =ui.item.salesitem_cartoon_no;
				document.getElementsByName("cartoon_size[]")[indexpos].value = ui.item.salesitem_cartoon_size;
				
				//calculateCurrentRowTotal(indexpos);
				addnew_particularrow(true);
				
				return false;
			}
			});						
		
			$( ".sirow input.ccrt" ).keyup(function() {
				var index = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				calculateCurrentRowTotal(index);
			});
			
			$( ".sirow input.deletethislistrow" ).click(function() {
				$(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').slideUp(500, function() {
					$(this).remove();
					calculateGrandTotal();
				});
			});
			
			$( ".numeric" ).keyup(function() {
				var price = $(this).val();
				var ValidChars = "-.0123456789";
				var IsNumber=true;
				var Char;
				var validint = '';
				for (var i = 0; i < price.length && IsNumber == true; i++){ 
					Char = price.charAt(i);
					if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
					else{
						validint = validint+Char;
					}
				}
				$(this).val(validint);
			});
		}
	}
	
function funcSaveBill1()
{
	
	var varUserChoice;
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet); 
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		document.frmsales.submit();
		//return true;
	}
}	
</script>