<?php
echo "<h2 style='color:red; text-align:center;'>Access Denied</h2>";
echo "<p style='text-align:center;'>You do not have permission to access this page.</p>";
echo "<p style='text-align:center;'><a href='login_form.php'>Go to Home Page</a></p>";
?>