<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
<?php
if(isset($_GET['barCode'])){$barcode_gen_code = trim($_GET['barCode']);}
elseif(isset($barCode)){$barcode_gen_code = $barCode;}
else{$barcode_gen_code = '';}

if(isset($_GET['company_name'])){$company_name = trim($_GET['company_name']);}
elseif(isset($company_name)){$company_name = $company_name;}
else{$company_name = '';}

if(isset($_GET['product_name'])){$product_name = trim($_GET['product_name']);}
elseif(isset($product_name)){$product_name = $product_name;}
else{$product_name = '';}

if(isset($_GET['pricestr'])){$pricestr = trim($_GET['pricestr']);}
elseif(isset($pricestr)){$pricestr = $pricestr;}
else{$pricestr = '';}

$font_sizeOptions = array('Small'=>'11', 'Regular'=>'12', 'Large'=>'13');
$fontsize = $font_sizeOptions['Regular'];
$lineheight = $fontsize;
$labelwidth = 57*3.7795275591;
$labelheight = 31*3.7795275591;
if($company_name ==''){
	$labelheight -= 23;
}
if($product_name ==''){
	$labelheight -= 23;
}
if($pricestr ==''){
	$labelheight -= 23;
}
$str = '<div style="width:'.$labelwidth.'px; height:'.'40'.'px;">
		<div style="text-align:justify;width:'.$labelwidth.'px; height:'.$labelheight.'px;overflow:hidden; position:relative;font-size:'.$fontsize.'px;color:#000;line-height:'.$lineheight.'px;">        
			<div style="margin:0 auto;text-align:center;margin:1px 0; overflow:hidden;">';
				if($company_name !=''){
					$str .= '<div style="width:100%; height:'.$lineheight.'px;overflow:hidden;">'.$company_name.'</div>';
				}
				if($product_name !=''){
					$str .= $product_name;
				}
				if($pricestr !=''){
					if($labelheight <=94){$str .= ', ';}
					else{$str .= '<br />';}
					$str .= $pricestr;
				}
			
if($barcode_gen_code !=''){
	$rbarcode_gen_code = str_replace('&', '_and_', $barcode_gen_code);
	$rbarcode_gen_code = str_replace('+', '_plus_', $rbarcode_gen_code);
	$rbarcode_gen_code = str_replace('/', '_bksls_', $rbarcode_gen_code);
	$height = 25;
	$bottomHight = $height+$fontsize+10;
	$str .= '</div>
			<div style="width:98%;text-align:center; height:'.$bottomHight.'px; overflow:hidden; position:absolute; bottom:0px; left:1%; z-index:10;">
				<img style=" max-width:80%;" src="barcode.php?code='.$rbarcode_gen_code.'&height='.$height.'" alt="'.$barcode_gen_code.'"></img>
				<div style="clear:both;width:100%; height:0px;"></div>
				'.$barcode_gen_code;
}
				
$str .= '</div>
		</div>
	</div>';
echo $str; 
?>
</body>
</html>