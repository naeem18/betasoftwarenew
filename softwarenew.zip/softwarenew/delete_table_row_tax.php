<?php
session_start();
if(isset($_GET['idvalue'])){	
	$idvalue = $_GET['idvalue'];
	if($idvalue>0){
		require('labdd.php');
		
		 $str2 = "update labinvoice set dstatus = 'Deleted',
		 								tstatus = '1'
							 where labinvoice_id = '$idvalue'";
		$userquery = mysqli_query($conn, $str2);
		
		 $str = "update labinvoicedetails set dstatus = 'Deleted',
		 									  tstatus = '1'
									 where labinvoice_id = '$idvalue'";
		$userquery = mysqli_query($conn, $str);
		
		 $str3 = "update dailytransection_lab set dstatus = 'Deleted',
		 										  tstatus = '1'
			where section='Lab Cash' AND labinvoice_id = '$idvalue'";
		$userquery = mysqli_query($conn, $str3);
 		
		if($userquery){			
			header("location:index.php?p=statementbyinvoice&message=remove-successfully");			
		}
		else{
			header("location:index.php?p=$returnpage&message=couldnotremove");
		}
	}
	else{
		header("location:index.php?p=statementbyinvoice&message=incorrect_id");
	}
}
?>

<?php /*?><?php
session_start();
if(isset($_GET['idvalue'])){	
	
	
	$idvalue = $_GET['idvalue'];
	if($idvalue>0){
		require('labdd.php');
		
		$str2 = "DELETE from labinvoice where labinvoice_id = '$idvalue'";
		$userquery = mysqli_query($conn, $str2);
		
		 $str = "DELETE from labinvoicedetails where labinvoice_id = '$idvalue'";
		$userquery = mysqli_query($conn, $str);
		
		 $str3 = "DELETE from dailytransection_lab where section='Lab Cash' AND labinvoice_id = '$idvalue'";
		$userquery = mysqli_query($conn, $str3);
		
		
		if($userquery){			
			header("location:index.php?p=statementbyinvoice&message=remove-successfully");			
		}
		else{
			header("location:index.php?p=$returnpage&message=couldnotremove");
		}
	}
	else{
		header("location:index.php?p=statementbyinvoice&message=incorrect_id");
	}
}
?><?php */?>

