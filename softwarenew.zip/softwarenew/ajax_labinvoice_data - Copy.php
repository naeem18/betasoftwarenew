<?php
//OAI
require('labdd.php');
date_default_timezone_set("Asia/Dhaka");

$from = $_POST['ADate1'] ;
$to = $_POST['ADate2'] ;

$labinvoice_id = $_POST['labinvoice_id'];
$labinvoice_patient = $_POST['labinvoice_patient'];
$labinvoice_patientid = $_POST['labinvoice_patientid'];
$labinvoice_doctor = $_POST['labinvoice_doctor'];
$labinvoice_pc = $_POST['labinvoice_pc'];
$labinvoice_mpo = $_POST['labinvoice_mpo'];
$bar = $_POST['bar'];
$user = $_POST['user'];


$searchstr = " AND dstatus != 'Deleted' AND txstatus != 'Deleted' ";

//............. From to To
$labinvoice_id_from = isset($_POST['labinvoice_id_from']) ? (int)$_POST['labinvoice_id_from'] : 0;
$labinvoice_id_to   = isset($_POST['labinvoice_id_to']) ? (int)$_POST['labinvoice_id_to'] : 0;

if ($labinvoice_id_from > 0 && $labinvoice_id_to > 0) {
    $searchstr .= " AND labinvoice_id BETWEEN $labinvoice_id_from AND $labinvoice_id_to ";
} elseif ($labinvoice_id_from > 0) {
    $searchstr .= " AND labinvoice_id >= $labinvoice_id_from ";
} elseif ($labinvoice_id_to > 0) {
    $searchstr .= " AND labinvoice_id <= $labinvoice_id_to ";
} elseif (!empty($_POST['labinvoice_id'])) {
    // single invoice id
    $labinvoice_id = intval($_POST['labinvoice_id']); 
    $searchstr .= " AND labinvoice_id = '$labinvoice_id' ";
} else {
    // তারিখ দিয়ে ফিল্টার শুধু তখন হবে যখন কোন labinvoice_id দেওয়া হয়নি
    $searchstr .= " AND DATE(labinvoice_date) BETWEEN '$from' AND '$to' ";
}

//..............From to To END
 
if (!empty($labinvoice_id)) {
    $searchstr .= " AND labinvoice_id = '" . mysqli_real_escape_string($conn, $labinvoice_id) . "'";
}
if (!empty($labinvoice_patient)) {
    $searchstr .= " AND labinvoice_patient LIKE '%" . mysqli_real_escape_string($conn, $labinvoice_patient) . "%'";
}
if (!empty($labinvoice_patientid)) {
    $searchstr .= " AND labinvoice_patientid LIKE '%" . mysqli_real_escape_string($conn, $labinvoice_patientid) . "%'";
}

if (!empty($labinvoice_doctor)) {
    $searchstr .= " AND labinvoice_doctor LIKE '%" . mysqli_real_escape_string($conn, $labinvoice_doctor) . "%'";
}
if (!empty($labinvoice_pc)) {
    $searchstr .= " AND labinvoice_pc LIKE '%" . mysqli_real_escape_string($conn, $labinvoice_pc) . "%'";
}
if (!empty($labinvoice_mpo)) {
    $searchstr .= " AND labinvoice_mpo LIKE '%" . mysqli_real_escape_string($conn, $labinvoice_mpo) . "%'";
}

if (!empty($bar)) {
    $searchstr .= " AND bar LIKE '%" . mysqli_real_escape_string($conn, $bar) . "%'";
}

if (!empty($user)) {
    $searchstr .= " AND user LIKE '%" . mysqli_real_escape_string($conn, $user) . "%'";
}


$sql = "SELECT * FROM labinvoice WHERE 1=1 $searchstr ORDER BY labinvoice_id ASC";
$res = mysqli_query($conn, $sql);

if (!$res || mysqli_num_rows($res) == 0) {
  echo "<p style='color:red'>❗ No records found for the selected filters.</p>";
  exit;
}

echo "<table>
<thead>
<tr>
	<th>SL</th>
	<th>Date</th>
	<th>Print Memo</th>
	<th>Bill No.</th>
	<th>Patient</th>
	<th>BarCode</th>
	<th>Mobile</th>
	<th>Gross</th>
	<th>Disc.</th>
	<th>Net</th>
	<th>Cash</th>
	<th>F.Disc.</th>
	<th>Collection</th>
	<th>Due</th>
	<th>Ref. Dr.</th>
	<th>MPO</th>
	<th>P.C Name</th>
	<th>P.C Com Due</th>
	<th>Note</th>
	<th>User</th>
	<th>Updated User</th>
	<th>Info. Update</th>
 </tr>
</thead>
<tbody>";

$sl = 1;
$gross = $disc = $net =$fdisc =$collection = $cash = $due = 0;
			
while ($row = mysqli_fetch_assoc($res)) {
	$action = "<a href=\"printlabinvoiceduplicate.php?&labinvoice_id={$row['labinvoice_id']}\" target=\"_blank\">Print</a>";
	$actioninfo = "<a href=\"index.php?p=labinvoiceinfoupdate&labinvoice_id={$row['labinvoice_id']}\" target=\"_blank\">Info.Update</a>";

  echo "<tr bgcolor=\"#fff\">
    <td>{$sl}</td>
    <td>{$row['labinvoice_date']}</td>
    <td>{$action} <br>({$row['uniqid']})</td>
    <td>{$row['labinvoice_id']}</td>
     
	 <td>" . 
        (!empty($row['labinvoice_patientid']) 
            ? "<b>" . htmlspecialchars($row['labinvoice_patient']) . " (" . htmlspecialchars($row['labinvoice_patientid']) . ")</b>" 
            : htmlspecialchars($row['labinvoice_patient'])
        ) 
    . "</td>
	 
    <td>{$row['bar']}</td>
    <td>{$row['labinvoice_mobile']}</td>
    <td>{$row['labinvoice_subtotal']}</td>
    <td>{$row['labinvoice_totaldisc']}</td>
    <td>{$row['labinvoice_subtotalafterdisc']}</td>
    <td><b>{$row['labinvoice_receiveamount']}</b></td>
    <td>{$row['labinvoice_finaldisc']}</td>
    <td>{$row['collection_amount']}</td>
    <td><strong>{$row['labinvoice_due']}</strong></td>
	
	<td>{$row['labinvoice_doctor']}</td>
	<td>{$row['labinvoice_mpo']}</td>
	<td>{$row['labinvoice_pc']}</td>
	<td>{$row['labinvoice_totalpccomission']}</td>
	<td>{$row['labinvoice_description']}</td>
	<td>{$row['user']}</td>
	<td>{$row['update_user']}</td>
	<td>{$actioninfo}</td>
 	
  </tr>";
  $sl++;
  $gross += $row['labinvoice_subtotal'];
  $disc += $row['labinvoice_totaldisc'];
  $fdisc += $row['labinvoice_finaldisc'];
  $collection += $row['collection_amount'];
  //$cash += $row['labinvoice_receiveamount'];
  $net += $row['labinvoice_subtotalafterdisc'];
  $cash += $row['labinvoice_receiveamount'];
  $due += $row['labinvoice_due'];
}

echo "<tr style='font-weight:bold; background:#f9f9f9'>
  <td colspan='7' align='right'>Total</td>
  <td>{$gross}</td>
  <td>{$disc}</td>
  <td>{$net}</td>
  <td>{$cash}</td>
  <td>{$fdisc}</td>
  <td>{$collection}</td>
  <td>{$due}</td>
  <td colspan=\"8\"></td>
</tr>";
echo "</tbody></table>";