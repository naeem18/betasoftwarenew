 
    <h3 style="background:#ccc; color:#000; text-align:center">Submit OTP</h3>
		<content>
		  <?php
			if(isset($_GET['message']) && $_GET['message']=='errorinsert'){
			echo "<h2 class=\"red12bold\">OTP Did Not Match</h2>";   
			}
			elseif(isset($_GET['message']) && $_GET['message']=='insert-successfully'){
			echo "<h2 class=\"red12bold\">OTP Submited successfully</h2>";   
			}
			$doctor_id = 0;
 			$doctor_name = '';
			 
			$code = '';
			 
			
			if(isset($_GET['doctor_id'])){
				$doctor_id = $_GET['doctor_id'];
				$sqldoctor = "select doctor_name,doctor_id,code from doctorentry where doctor_id = $doctor_id";
				$doctorquery = mysqli_query($conn, $sqldoctor);
				if($doctorquery){
					while($doctorrow = mysqli_fetch_array($doctorquery)){
						$doctor_id = $doctorrow['doctor_id'];
 						$doctor_name = $doctorrow['doctor_name'];
   					}
				}
			}
         ?>        
		<form action="save_doctorcode.php" name="frmcontact" onsubmit="return checkcontactform();" method="post" enctype="multipart/form-data">
            <table width="600" align="center" border="1" style="BORDER-COLLAPSE: collapse; color:#fff" bgcolor="#096B7F" cellpadding="2">
                   
                <tr>
                    <td>Name</td>
                    <td><input size="28" type="text" required name="" id="" value="<?php echo $doctor_name;?>" /></td>
                </tr>

                 <tr>
                    <td>Code/OTP</td>
                    <td><input size="28" name="code" id="code" /></td>
                 </tr>

     
                <tr>
                    <td>&nbsp;</td>
                    <td>
                        <input type="hidden" name="doctor_id" id="doctor_id" value="<?php echo $doctor_id;?>">
                        <input type="submit" value=" Submit " name="submit_doctor" id="submit_doctor" class="submitbuttoncss" />
                    </td>
                </tr>
          </table>
      </form>
 </content>
</article>