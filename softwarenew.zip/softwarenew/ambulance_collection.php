<article class="bottomcontent">
   <h3 style="background: #6F7BFB; color:#fff; text-align:center">Ambulance Due Collection</h3>
   <content>
<?php
$patientdata = '';
$sqlopregistration = "select * from opregistration order by opregistration_id asc";
$opregistrationquery = mysqli_query($conn, $sqlopregistration);
if($opregistrationquery && mysqli_num_rows($opregistrationquery)>0){

	while ($opregistrationrow = mysqli_fetch_array($opregistrationquery))
	{
		$opregistration_id = $opregistrationrow['opregistration_id'];
		$opregistration_code = $opregistrationrow['opregistration_code'];
		$opregistration_name = $opregistrationrow['opregistration_name'];
		$ward = $opregistrationrow['ward'];
		$advanced = $opregistrationrow['advanced'];
		$opregistration_mobile = $opregistrationrow['opregistration_mobile'];
		$opregistration_address = $opregistrationrow['opregistration_address'];
		$patientdata[] =array( 'labelval' => $opregistration_name,
							'label' => $opregistration_id,
							'opregistration_id'=>$opregistration_id,
							'opregistration_code'=>$opregistration_code,
							'advanced'=>$advanced,
							'ward'=>$ward,
							'opregistration_mobile'=>$opregistration_mobile,
							'opregistration_address'=>$opregistration_address
							);
		}
	}
$patientdata = json_encode($patientdata);
?>
<link rel="stylesheet" href="autocomplete/jquery-ui.css">
<script src="autocomplete/jquery-ui.min.js"></script>
  <script language="JavaScript" type="text/javascript">
   var patientdata = <?php echo $patientdata;?>;
	$(document).ready(function($) {
	
   	$( "#opregistration_id" ).autocomplete({
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				document.getElementById('name').value = ui.item.labelval;
				document.getElementById('mobile').value = ui.item.opregistration_mobile;
				document.getElementById('opregistration_id').value = ui.item.opregistration_id;
				document.getElementById('opregistration_code').value = ui.item.opregistration_code;
				document.getElementById('address').value = ui.item.opregistration_address;
				//document.getElementById('received').value = ui.item.advanced;
				//document.getElementById('labcollection_address').value = ui.item.opregistration_address;
				
				return false;
			}
		});
	});
		
     function calculate_total(){
		var charge = parseFloat(document.getElementById("charge").value);
		if(charge=='' || isNaN(charge)){charge = 0;}
		
		var less = parseFloat(document.getElementById("less").value);
		if(less=='' || isNaN(less)){less = '';}
		
		var received = parseFloat(document.getElementById("received").value);
		if(received=='' || isNaN(received)){received = '';}
		
		var due = parseFloat(charge -(less+received));
		document.getElementById('due').value= due.toFixed(2);
		}
		</script>
        <?php
        if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
            echo "<p class=\"red12bold\">You have missing Something</p>";
        }
		 if(isset($_GET['message']) && $_GET['message']=='update-successfully'){
            echo "<p class=\"red12bold\">updated successfully</p>";
        }
        elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
            echo "<p class=\"red12bold\">Error occured! Could not insert.</p>";   
        }
        elseif(isset($_GET['message']) && $_GET['message']=='save-successfully'){
            echo "<p class=\"red12bold\">Information insert successfully. Click Print Button To Print or View Previous Bill <td align=\"center\" ><a onclick=\"PrintDiv();\"><input type=\"button\" name=\"user\" id=\"user\" required value=\"Print\" class=\"tdclass\"  /></a></td></p>";   
        }
        $ambulance_id = 0;
        $name = '';
        $mobile = '';
        $destination = '';
        $opregistration_id = '';
        $charge = '';
        $month = '';
        $description = '';
		if(isset($_GET['ambulance_id'])){
        $ambulance_id = $_GET['ambulance_id'];
		$sqlst = "select * from ambulance where ambulance_id=$ambulance_id";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery &&  mysqli_num_rows($stquery)>0){
			 while ($strow = mysqli_fetch_array($stquery)) {
					$ambulance_id = $strow['ambulance_id'];
                    $name = $strow['name'];
					$user = $strow['user'];
                    $update_user = $strow['update_user'];
                    $mobile = $strow['mobile'];
					$referer = $strow['referer'];
					$starting_location = $strow['starting_location'];
                    $destination = $strow['destination'];
                    $charge = $strow['charge'];
                    $received = $strow['received'];
                    $due = $strow['due'];
                    $month = $strow['month'];
                    $description = $strow['description'];
                    $opregistration_id = $strow['opregistration_id'];
                    $dueholder = $strow['dueholder'];
                    $created_date = $strow['created_date'];
					}
				}
		 	}
         ?>        
<form action="save_ambulance_collection.php" style="background:#FFF; padding:10px" name="frmcontact" onsubmit="return checkcontactform();" method="post" enctype="multipart/form-data">
   <table width="55%" align="center" border="1" style="BORDER-COLLAPSE: collapse;" bgcolor="#ccc" cellpadding="2">
         <input type="hidden" name="user" id="user" required value="<?php echo $_SESSION['fullname'];?>" class="tdclass" />
         <input type="hidden" name="type" id="type" required value="Ambulance Collection" class="tdclass" />
    <tr>
        <td align="right">Date/Month</td>
        <td><input type="text" name="month" id="month" value="<?php echo date("F Y");?>" class="tdclass3" /></td>
    </tr>
    
    <tr>
        <td align="right">Date</td>
        <td><input type="text" name="created_date" id="created_date" value="<?php echo date('Y-m-d');?>" class="tdclass3" /></td>
    </tr>
    
    <tr>
        <td align="right"><strong>Patient Code</strong></td>
        <td>
        	<input type="hidden" name="opregistration_code" id="opregistration_code" class="tdclass3" />
            <input type="text" name="opregistration_id" id="opregistration_id" value="<?php echo $opregistration_id ;?>" class="tdclass3" />
        </td>
    </tr>
   
    <tr>
    	<td align="right"><strong>Name</strong>*</td>
    	<td><input type="text" required name="name" id="name" value="<?php echo $name ;?>" class="tdclass3" /></td>
    </tr>
    
    <tr>
        <td align="right">Address</td>
        <td><textarea type="text" name="address" id="address" class="textareadetailsr" /><?php echo $address ;?></textarea></td>
    </tr>
    
    <tr>
        <td align="right">Mobile Number</td>
        <td><input type="text" name="mobile" id="mobile" value="<?php echo $mobile ;?>" class="tdclass3" /></td>
    </tr>
    
    <tr>
        <td align="right">Referrer</td>
        <td><input type="text" name="referer" id="referer" value="<?php echo $referer ;?>" class="tdclass3" /></td>
    </tr>
    
    <tr>
        <td align="right">From Location*</td>
        <td><textarea type="text" required name="starting_location" id="starting_location" class="textareadetailsr" /><?php echo $starting_location ;?></textarea></td>
    </tr>
    
    <tr>
        <td align="right">Destination*</td>
        <td><textarea name="destination" required id="destination" class="textareadetailsr"><?php echo $destination ;?></textarea></td>
    </tr>
    
    <tr>
        <td align="right"><strong>Previous Due*</strong></td>
        <td><input name="charge" id="charge" required value="<?php echo $due ;?>" onKeyUp="calculate_total();" class="tdclass3" /></td>
    </tr>
    
    <tr>
        <td align="right"><strong>Less</strong></td>
        <td><input name="less" id="less" onKeyUp="calculate_total();" class="tdclass3" /></td>
    </tr>
    
    <input type="hidden" name="Lless" id="Lless" onKeyUp="calculate_total();" value="<?php echo $less ;?>" class="tdclass3" />
    <input type="hidden" name="Rreceived" id="Rreceived" value="<?php echo $received ;?>" onKeyUp="calculate_total();" class="tdclass3" />
   
    <tr>
        <td align="right"><strong>Collection*</strong></td>
        <td><input name="received" id="received" required onKeyUp="calculate_total();" class="tdclass3" /></td>
    </tr>
    
    <tr>
        <td align="right"><strong>Current Due</strong></td>
        <td><input name="due" id="due" readonly onKeyUp="calculate_total();" class="tdclass3" /></td>
    </tr>
     
    <tr>
        <td align="right">Due Holder</td>
        <td><textarea type="text" name="dueholder" id="dueholder" class="textareadetailsr" /><?php echo $dueholder ;?></textarea></td>
    </tr>
    
    <tr>
        <td align="right">Note</td>
        <td><textarea type="text" name="description" id="description" class="textareadetailsr" /><?php echo $description ;?></textarea></td>
    </tr>
    
    <tr>
        <td align="right"></td>
        <td>
            <input type="hidden" name="ambulance_id" id="ambulance_id" value="<?php echo $ambulance_id;?>">
            <input type="submit" value=" Save " name="submit_invoice" id="submit_invoice" class="tdclass" />
            <input type="reset" name="expense" id="expense" value="Cancel" class="tdclass"/>
        </td>
    </tr>
</table>
</form>
</content>
</article>