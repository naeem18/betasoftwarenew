<?php
// ১. এরর মেসেজ দেখানোর জন্য সেটিংস (ডিবাগিংয়ের জন্য অত্যন্ত জরুরি)
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// ২. সেশন এবং টাইমজোন শুরু
session_start();
date_default_timezone_set('Asia/Dhaka');

// ৩. ডিফল্ট পেইজ সেট করা
$pagename = "dashboardhomepage2.php";

// ৪. URL থেকে পেইজের নাম নেওয়া এবং নিরাপত্তার জন্য স্যানিটাইজ করা
if (isset($_GET["p"]) && is_string($_GET["p"])) {
    // শুধুমাত্র অক্ষর, সংখ্যা এবং আন্ডারস্কোর অনুমোদিত (LFI প্রতিরোধ)
    $pagename = preg_replace('/[^a-zA-Z0-9_-]/', '', $_GET["p"]);
}

// ৫. পেইজের টাইটেল তৈরি করা
$title = str_replace(array("-", "_"), " ", $pagename);
$title = ($title === "homepageac") ? "Beta Hospital Management System" : ucwords($title);

// ৬. .php এক্সটেনশন যোগ করা
$pagename = $pagename . ".php";

// ৭. যদি ফাইলটি ফোল্ডারে না পাওয়া যায়, তবে ডিফল্ট হোমপেইজে নিয়ে যাবে
if (!file_exists($pagename)) {
    $pagename = "homepageac.php";
    $title = "BETA HEALTHCARE ERP 2.6+";
}

// ৮. সেশন টোকেন ভ্যালিডেশন (সিকিউরিটি চেক)
if (isset($_SESSION["auto_number"]) && isset($conn)) {
    $safe_auto_number = mysqli_real_escape_string($conn, $_SESSION["auto_number"]);
    $sql = mysqli_query($conn, "SELECT login_token FROM master_employee WHERE auto_number='$safe_auto_number'");
    
    if ($sql && mysqli_num_rows($sql) > 0) {
        $row = mysqli_fetch_assoc($sql);
        if (isset($_SESSION["login_token"]) && $row["login_token"] != $_SESSION["login_token"]) {
            session_destroy();
            header("Location: index.php?msg=session_expired");
            exit;
        }
    }
}

// ৯. ক্ষতিকর require_once লাইনটি এখান থেকে সম্পূর্ণ মুছে ফেলা হয়েছে।
?>