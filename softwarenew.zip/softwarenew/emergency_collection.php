<link rel="stylesheet" href="autocomplete/jquery-ui.css">
<script src="autocomplete/jquery-ui.min.js"></script>
<script language="JavaScript" type="text/javascript">
function disableEnterKey(e)
	{
	var evt = e || window.event; 
		var key = evt.keyCode;
		//alert (key);
		if(key == 13) // if enter key press
		{
			//alert ("Enter Key Press");
			return false;
		}
	}
</script>	

<script language="JavaScript" type="text/javascript">
	
	
	function calculate_total(){
		
		var emergencyinvoice_due = parseFloat(document.getElementById("emergencyinvoice_due").value);
		if(emergencyinvoice_due=='' || isNaN(emergencyinvoice_due)){emergencyinvoice_due = 0;}
		
		var discountp_amount = parseFloat(document.getElementById("discountp_amount").value);
		if(discountp_amount=='' || isNaN(discountp_amount)){discountp_amount = 0;}
		
		var discount_amount = parseFloat(document.getElementById("discount_amount").value);
		if(discount_amount=='' || isNaN(discount_amount)){discount_amount = 0;}
		


		var Tcollection_amount = parseFloat(document.getElementById("Tcollection_amount").value);
		if(Tcollection_amount=='' || isNaN(Tcollection_amount)){Tcollection_amount = '';}
		
		//var emergencyinvoice_totalpccomission_update = parseFloat(emergencyinvoice_totalpccomission - discount_amount/2);
		//document.getElementById('emergencyinvoice_totalpccomission_update').value=emergencyinvoice_totalpccomission_update.toFixed(2);
		
			
		var total_balance = parseFloat(emergencyinvoice_due - discount_amount - Tcollection_amount);
		document.getElementById('total_balance').value=	total_balance.toFixed(2);
		
		}
		
function percentToAmount() {
     var emergencyinvoice_due = parseFloat(document.getElementById("emergencyinvoice_due").value) || 0;
     var percent = parseFloat(document.getElementById("discountp_amount").value) || 0;
     var amount = (emergencyinvoice_due * percent) / 100;
     document.getElementById("discount_amount").value = amount.toFixed(2);
     calculate_total();
}

function amountToPercent() {
     var emergencyinvoice_due = parseFloat(document.getElementById("emergencyinvoice_due").value) || 0;
     var amount = parseFloat(document.getElementById("discount_amount").value) || 0;
     var percent = 0;
     if (emergencyinvoice_due > 0) {
        percent = (amount * 100) / emergencyinvoice_due;
    }
     document.getElementById("discountp_amount").value = percent.toFixed(2);
     calculate_total();
}


	function funcSaveBill1()
{
	
	var varUserChoice; 
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet); 
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		document.frmsales.submit();
		//return true;
	}
}				

</script>
	<?php //include("calculate_collection_emergency.php");?>

	<article class="bottomcontent">
    	<h3 align="center">Emergency Due Receive Invoice</h3>
   		<content>
         <?php
			if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
				echo "<p class=\"red12bold\">You have missing Something</p>";
			}
			elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
				echo "<p class=\"red12bold\">Error occured! Could not insert.</p>";   
			}
			elseif(isset($_GET['message']) && $_GET['message']=='save-successfully'){
				echo "<p class=\"red12bold\">Information insert successfully. Click Print Button To Print or View Previous Bill <td width=\"30\" align=\"center\" >
				<a onclick=\"PrintDiv();\"><input type=\"button\" required value=\"Print\" class=\"tdclass\"  /></a></td></p>";   
			}
			$emergencyinvoice_patient ='';
			$emergencyinvoice_patientid ='';
			$emergencyinvoice_gender = '';
			$emergencyinvoice_mobile ='';
			$emergencyinvoice_address = '';
			$emergencyinvoice_doctor = '';
			$emergencyinvoice_pc ='';
			$emergencyinvoice_totalpccomission ='';
			$emergencyinvoice_due=''; 
			$emergencyinvoice_subtotalafterdisc ='';
 			  
		 if(isset($_GET['emergencyinvoice_id'])){
            require('labdd.php');
            $emergencyinvoice_id = $_GET['emergencyinvoice_id'];
            $sqlst = "select * from emergencyinvoice where emergencyinvoice_id = $emergencyinvoice_id";
            $stquery = mysqli_query($conn, $sqlst);
            if($stquery){
                while($strow = mysqli_fetch_array($stquery)){
                  $emergencyinvoice_id = $strow['emergencyinvoice_id'];
                    $emergencyinvoice_patientid = $strow['emergencyinvoice_patientid'];
                    $emergencyinvoice_patient = $strow['emergencyinvoice_patient'];
					$user = $strow['user'];
					$update_user = $strow['update_user'];
                    $emergencyinvoice_age = $strow['emergencyinvoice_age'];
                    $emergencyinvoice_gender = $strow['emergencyinvoice_gender'];
                    $emergencyinvoice_address = $strow['emergencyinvoice_address'];
                    $emergencyinvoice_doctor = $strow['emergencyinvoice_doctor'];
                 	$emergencyinvoice_subtotal = $strow['emergencyinvoice_subtotal'];
					$emergencyinvoice_totaldiscp = $strow['emergencyinvoice_totaldiscp'];
					$emergencyinvoice_totaldisc = $strow['emergencyinvoice_totaldisc'];
					$emergencyinvoice_subtotalafterdisc = $strow['emergencyinvoice_subtotalafterdisc'];
					$emergencyinvoice_receiveamount = $strow['emergencyinvoice_receiveamount'];
					$emergencyinvoice_due = $strow['emergencyinvoice_due'];
					$emergencyinvoice_date=	$strow['emergencyinvoice_date'];
                }
            }
        }
      ?>
<form action="save_emergencycollection.php" name="frmcontact" onsubmit="return checkcontactform();" onKeyDown="return disableEnterKey(event)" method="post" enctype="multipart/form-data">
                          
	<table width="550" align="center" border="0" bgcolor="#89C5C5" cellpadding="2">
      <input type="hidden" name="user" id="user" required value="<?php echo $_SESSION['fullname'];?>" class="tdclass"/>
      <input type="hidden" name="emergencyinvoice_id" id="emergencyinvoice_id" value="<?php echo $emergencyinvoice_id;?>" class="tdclass"/>
    
  <tr>
    <td align="right">Patient</td>
    <td><input type="text" readonly name="emergencyinvoice_name" id="emergencyinvoice_name" value="<?php echo $emergencyinvoice_patient;?>" class="tdclass"  /></td>
   
     <td align="right">Patient ID </td>
     <td width="30"> <input type="text" readonly name="opregistration_id" id="opregistration_id" value="<?php echo $emergencyinvoice_patientid;?>" class="tdclass2"  /></td>
  </tr>
   
   <tr>
    <td align="right">Mobile</td>
    <td> <input type="text" name="emergencyinvoice_number" id="emergencyinvoice_number" value="<?php echo $emergencyinvoice_mobile;?>" class="tdclass"  /></td>
    
    <td align="right">Address</td>
	<td> <textarea type="text" name="emergencyinvoice_address" id="emergencyinvoice_address" class="tdclass"  /><?php echo $emergencyinvoice_address;?></textarea></td>
  </tr>
   
   <tr>
     <td align="right">Date </td>
     <td><input type="text" name="emergencyinvoice_date" readonly id="emergencyinvoice_date" value="<?php echo date('Y-m-d H:i:s');?>" class="tdclass2"  /></td>
      
    <!--<td align="right">PC </td>
    <td width="30"> <input type="text" readonly name="emergencyinvoice_pc" id="emergencyinvoice_pc" value="<?php echo $emergencyinvoice_pc;?>" class="tdclass2"  /></td>
  </tr>
   
  <tr>
    <td align="right">PC Comission</td>
    <td width="30"> <input type="text" readonly name="emergencyinvoice_totalpccomission" id="emergencyinvoice_totalpccomission" value="<?php echo $emergencyinvoice_totalpccomission;?>"  class="tdclass numeric" onKeyUp="calculate_total();"/></td>
  
    <td align="right">Current PC Comission</td>
    <td width="30"> <input type="text" readonly name="emergencyinvoice_totalpccomission_update" id="emergencyinvoice_totalpccomission_update"  class="tdclass numeric" onKeyUp="calculate_total();"/></td>
  --></tr>
</table>
 
 <table  border="0" width="550" align="center" cellpadding="2"  bgcolor="#F3F3F3">
  <tr>
    <td align="right">Note </td>
    <td><textarea type="text" name="note" id="note"/></textarea></td>
  </tr>
 </table>	
 
	<table width="550" align="center" border="0" bgcolor="#FFFFFF" cellpadding="2">
  	<tr>
       <td align="right" style="border-top:1px solid #999;">Invoice Amounts:</td>
    	<td width="50" style="border-top:1px solid #999;"> 
    	<input type="text" readonly name="emergencyinvoice_subtotalafterdisc" id="emergencyinvoice_subtotalafterdisc" value="<?php echo $emergencyinvoice_subtotalafterdisc;?>" class="tdclass"  /></td>
  	</tr>
    
    <tr>
     	<td align="right">Total Dues:</td>
    	<td><input type="text" readonly name="emergencyinvoice_due" id="emergencyinvoice_due" value="<?php echo $emergencyinvoice_due;?>" onKeyUp="calculate_total();" class="tdclass"  /></td>
  	</tr>
    
     <tr>
     	<td align="right">Discount %:</td>
    	<td> <input type="text" name="discountp_amount" id="discountp_amount" class="tdclass numeric" onKeyUp="percentToAmount();" /></td>
  	</tr>
    
     <tr>
     	<td align="right">Discount Amount:</td>
    	<td> <input type="text" name="discount_amount" id="discount_amount" class="tdclass numeric" onKeyUp="amountToPercent();" /></td>
  	</tr>
    
     <tr>
     	<td align="right"><strong>Receive Amount</strong>:</td>
    	<td> <input type="text"  required name="Tcollection_amount" id="Tcollection_amount" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
  	</tr>

    <tr>
         <td align="right">Current Dues Amount:</td>
         <td> <input type="text" readonly name="total_balance" id="total_balance" class="tdclass numeric" onKeyUp="calculate_total();" /></td>
  	</tr>
    
	<tr>
     <td align="right"></td>
	 <td>
         <input type="hidden" name="emergencycollection_id" id="emergencycollection_id" value="<?php echo $emergencycollection_id;?>">
         <input type="submit"  value=" save " name="submit_invoice" id="submit_invoice" onClick="return funcSaveBill1()" class="tdclass1" />
       </td>
  	</tr>
   
    </table>
  </form>         

</content>
</article>

<div id="divToPrint" style="display:none;">
<article class="bottomcontent" style="margin:0 auto; margin-left:<?php echo $printdata_name; ?>">
  	<?php
		$emergencyinvoice_id = $_GET['emergencyinvoice_id'];
        $emergencyinvoice_sql = "select * from emergencyinvoice where emergencyinvoice_id = $emergencyinvoice_id ";
        $emergencyinvoicequery = mysqli_query($conn, $emergencyinvoice_sql);
        if($emergencyinvoicequery && mysqli_num_rows($emergencyinvoicequery)>0 && ($emergencyinvoice_id<40000)){
            while ($onerow = mysqli_fetch_array($emergencyinvoicequery)){
					$emergencyinvoice_id = $onerow['emergencyinvoice_id'];
					$emergencyinvoice_id = $onerow['emergencyinvoice_id'];
					$emergencyinvoice_date = $onerow['emergencyinvoice_date'];
					$total_balance = $onerow['total_balance'];
					$opregistration_id = $onerow['opregistration_id'];
					$emergencyinvoice_name = $onerow['emergencyinvoice_name'];
					$emergencyinvoice_address = $onerow['emergencyinvoice_address'];
					$emergencyinvoice_number = $onerow['emergencyinvoice_number'];
					$emergencyinvoice_date = $onerow['emergencyinvoice_date'];
					$emergencyinvoice_date = $onerow['emergencyinvoice_date'];
					
					$collection_amount = $onerow['collection_amount'];
					$emergencyinvoice_subtotalafterdisc = $onerow['emergencyinvoice_subtotalafterdisc'];
					$discount_amount = $onerow['discount_amount'];
					$note = $onerow['note'];
					$user = $onerow['user'];		
					$due = $onerow['due'];		
              ?>
                
               <?php if($heading=='Yes'){ ?>
                <table align="center" width="<?php echo $printdata_mobile; ?>"  style="border:1px solid #999; padding:0 5px; font-size:12px; "  bgcolor="#FFF" cellpadding="0">
                <tr>
                <?php
                if($hospitaldata_logo!=''){
					?>
                    <td width="65">
                    <div align="left" style="font-size:15px;">
                    <img alt="barcode" width="60" height="60" src="logo_images/<?php echo $hospitaldata_logo; ?>"  /></div>
                   </td>
               <?php }?>
                <td width="320" style="border-right:1px solid #666">
                    <div align="left" style="font-size:16px;"><strong><?php echo $hospitaldata_name;?></strong></div>
                    <div align="left"> <?php echo $hospitaldata_address1;?></div>
                    <?php /*?><div align="left"> <?php echo $hospitaldata_mobile;?></div><?php */?>
                </td>
                 <td width="90">
                    <div align="right" style="font-size:13px;"><strong><?php echo 'Contact';?></strong></div>
                    <div align="right"> <?php echo $hospitaldata_mobile;?></div>
                </td>
                 </tr>
            </table>
           <?php }?>      
                  
            <table align="center" width="<?php echo $printdata_mobile; ?>" style="border:1px solid #999;font-size:13px; border-bottom:none; padding:2px 8px 0 8px; 
			<?php if($heading=='Yes'){ ?> margin-top:12px;<?php }?> <?php if($heading=='No'){ ?> margin-top:65px;<?php }?>" bgcolor="#FFF" cellpadding="0">
            <tr>
                <td width="250">
                    <!--<div  align="left"><strong>Patient ID : <?php //echo $opregistration_id;?></strong> </div>-->
                    <div  align="left"><strong>Patient : <?php echo $emergencyinvoice_name;?> </strong> </div>
                    <div  align="left">Mobile : <?php echo $emergencyinvoice_number;?></div>
                   <!-- <div  align="left">Address : <?php //echo $emergencyinvoice_address;?></div>-->
               <div  align="left">Lab Invoice No : <?php echo $emergencyinvoice_id;?></div>
               <div  align="left">Lab Inv Date : <?php  echo $emergencyinvoice_date;?></div></td>
                <td width="200">
                    <div  align="right" style="font-size:14px"><strong>Due Collection Invoice</strong></div>
                    <div  align="right">Collection No : <?php echo $emergencyinvoice_id;?></div>
                     <div  align="right">C.Date: <?php  echo $emergencyinvoice_date;?></div>
                     
                    
                    
               </td>
             </tr>
             </table>
                         
            
             <table align="center" width="<?php echo $printdata_mobile; ?>" bgcolor="#FFF" style="padding:0 0 40px;font-size:13px; border:1px #999 solid; border-top:none; "cellspacing="0" cellpadding="0">
                
              <tr height="20">
                <td style="border:1px solid #999;text-align:center;"><strong>Particular</strong></td>
                <td style="border:1px solid #999; text-align:center;">Invoice Amount</td>
                <td style="border:1px solid #999; text-align:center;">Previous Dues</td>
                <td style="border:1px solid #999; text-align:center;">Discount</td>
               <td style="border:1px solid #999; text-align:center;">Received</td>
                <td style="border:1px solid #999; text-align:center;">Current Dues</td>
             </tr>
             
                <tr>
                <td style=" text-align:center;"><?php echo 'Due Collection'?></td>
                <td style=" text-align:center;"><?php echo $emergencyinvoice_subtotalafterdisc;?></td>
                <td style=" text-align:center;"><strong><?php echo $total_balance+$collection_amount;?></strong></td>
                <td style=" text-align:center;"><?php echo $discount_amount;?></td>
                <td style=" text-align:center;"><strong><?php echo $collection_amount;?></strong></td>
                 <td style=" text-align:center;"><?php echo $due;?></td>
               </tr>
               
            </table>
                    
                <?php
				}
			}
        ?>
         <table align="center" width="<?php echo $printdata_mobile; ?>" style="font-size:12px; font-style:italic">
        <tr> <td><?php include ("convert_currency_to_words.php");

		echo 'InWord:';	echo covert_currency_to_words($collection_amount); ?></td></tr>
        </table>

 <table align="center" width="<?php echo $printdata_mobile; ?>" border="0">
    <tr>
        <td width="400" style=" font-size:12px"><?php echo $note; ?></td>
 </tr>
 </table>
      
        <table align="center" width="<?php echo $printdata_mobile; ?>" style=" font-size:12px; padding:5px 2px" bgcolor="#FFF" cellpadding="0">
                          
        <tr>
            <td width="350">
                <div  align="left">Prepared By:<?php echo $user; ?>  
                  </div>
            </td>
            <td width="200">
                <div  style="padding-bottom:10px" align="right"></div>
                <div  align="right">Received By</div>
            </td>
         </tr>
             
        </table>

    <table align="center" width="<?php echo $printdata_mobile; ?>" border="0">
    <tr>
        <td width="400" style=" font-size:10px">Software by: Betasofts.com (1795909185)</td>
      </tr></table>
   
</article>
</div>