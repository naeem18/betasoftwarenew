<?php
header('Content-Type: application/json');

// Get and validate input data
$input = json_decode(file_get_contents('php://input'), true);

if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON data']);
    exit;
}

// Authentication check
if (!isset($input['username']) || !isset($input['password'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Username and password required']);
    exit;
}

if ($input['username'] !== 'rubel' || $input['password'] !== 'rubel') {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Validate required field
if (!isset($input['InvNo'])) {
    http_response_code(400);
    echo json_encode(['error' => 'InvNo is required']);
    exit;
}
include('labdd.php');


if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed: ' . $conn->connect_error]);
    exit;
}

// Extract data with null checks
$InvNo = $input['InvNo'];
$patientName = isset($input['patientName']) ? $input['patientName'] : null;
$Age = isset($input['Age']) ? $input['Age'] : null;
$Parameter = isset($input['Parameter']) ? $input['Parameter'] : null;
$Result = isset($input['Result']) ? $input['Result'] : null;
$Unit = isset($input['Unit']) ? $input['Unit'] : null;
$NormalValue = isset($input['NormalValue']) ? $input['NormalValue'] : null;
$ReportingGroup = isset($input['ReportingGroup']) ? $input['ReportingGroup'] : null;
$AliasName = isset($input['AliasName']) ? $input['AliasName'] : null;

try {
    // Prepare SQL statement with proper parameter binding
    $stmt = $conn->prepare("INSERT INTO labdata 
                          (InvNo, patientName, Age, Parameter, Result, Unit, NormalValue, ReportingGroup, AliasName) 
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }

    // Bind parameters
    $stmt->bind_param("sssssssss", 
        $InvNo,
        $patientName,
        $Age,
        $Parameter,
        $Result,
        $Unit,
        $NormalValue,
        $ReportingGroup,
        $AliasName
    );

    // Execute and check result
    if ($stmt->execute()) {
        $insertId = $stmt->insert_id;
        echo json_encode([
            'status' => 'success',
            'message' => 'Data inserted successfully',
            'inserted_id' => $insertId,
            'received' => $input
        ]);
    } else {
        throw new Exception("Database insert failed: " . $stmt->error);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Insert failed',
        'message' => $e->getMessage()
    ]);
}

$conn->close();
?>