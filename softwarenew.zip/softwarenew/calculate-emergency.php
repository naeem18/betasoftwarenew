<script language="JavaScript" type="text/javascript">
	
	var itemdataarray = <?php echo $itemdataarray;?>;
	var itemdata = <?php echo $itemdata;?>;
	var patientdata = <?php echo $patientdata;?>;
	var pcdata = <?php echo $pcdata;?>;
	var drdata = <?php echo $drdata;?>;
	var itemarraydata = itemdataarray;
		//var itemarraydata = jQuery.parseJSON(itemdataarray);
	$(document).ready(function($) {
		//document.getElementsByName("emergencyinvoice_item[]")[0].focus();

		$( ".itemname" ).autocomplete({
			
			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				var labitem_idarray = document.getElementsByName("labitem_id[]");
				labitem_idarray[indexpos].value = ui.item.labitem_id;
			
				var emergencyinvoice_ratearray = document.getElementsByName("emergencyinvoice_rate[]");
				emergencyinvoice_ratearray[indexpos].value = ui.item.labitem_price;
				
				var emergencyinvoice_qtyarray = document.getElementsByName("emergencyinvoice_qty[]");
				emergencyinvoice_qtyarray[indexpos].value = 1;
				
				var emergencyinvoice_pccomissionarray = document.getElementsByName("emergencyinvoice_pccomission[]");
				emergencyinvoice_pccomissionarray[indexpos].value = ui.item.labitem_pccommission;
				
				var emergencyinvoice_drcomissionarray = document.getElementsByName("emergencyinvoice_drcomission[]");
				emergencyinvoice_drcomissionarray[indexpos].value = ui.item.labitem_drcommission;
				
				var emergencyinvoice_categoryarray = document.getElementsByName("emergencyinvoice_category[]");
				emergencyinvoice_categoryarray[indexpos].value = ui.item.labitem_group;
				
				var emergencyinvoice_unitarray = document.getElementsByName("emergencyinvoice_unit[]");
				emergencyinvoice_unitarray[indexpos].value = ui.item.labitem_unit;
				
				var emergencyinvoice_refvaluearray = document.getElementsByName("emergencyinvoice_refvalue[]");
				emergencyinvoice_refvaluearray[indexpos].value = ui.item.labitem_refvalue;
				
				var emergencyinvoice_reagentarray = document.getElementsByName("emergencyinvoice_reagent[]");
				emergencyinvoice_reagentarray[indexpos].value = ui.item.labitem_reagent;
			
				calculaterowtotal(indexpos);
				//calculate_pctotal();
				//calculate_drtotal();
				//addnew_particularrow(true);   //automatic add next row
				return false;
			}
		});
		
		
		$( "#emergencyinvoice_patientid" ).autocomplete({
 			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('emergencyinvoice_patient').value = ui.item.labelval;
				 document.getElementById('emergencyinvoice_patientid').value = ui.item.opregistration_id;
				 document.getElementById('emergencyinvoice_patientcode').value = ui.item.opregistration_code;
				 document.getElementById('bar').value = ui.item.bar;
				 document.getElementById('emergencyinvoice_age').value = ui.item.opregistration_age;
				 document.getElementById('emergencyinvoice_gender').value = ui.item.opregistration_gender;
				 document.getElementById('emergencyinvoice_mobile').value = ui.item.opregistration_mobile;
				 document.getElementById('emergencyinvoice_address').value = ui.item.opregistration_address;
				 document.getElementById('emergencyinvoice_previousdue').value = ui.item.emergency_due;
				
				return false;
			}
		});
		
		// pc search
		$( "#emergencyinvoice_pc" ).autocomplete({
			
			minLength: 1,
			source: pcdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('emergencyinvoice_pc').value = ui.item.labelval;
				 document.getElementById('emergencyinvoice_mpo').value = ui.item.mpo;
				
				return false;
			}
		});
		
		// dr search
		$( "#emergencyinvoice_doctor" ).autocomplete({
			
			minLength: 1,
			source: drdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('emergencyinvoice_doctor').value = ui.item.labelval;
				 document.getElementById('emergencyinvoice_doctor').value = ui.item.doctor_name;
				return false;
			}
		});
		
		  
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
		$( ".emergencyinvoice_item" ).keypress(function(keyname) {
			if(keyname.which==13){
				var imei = $(this).val();
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				$.each(itemarraydata, function(key, value){
					var valuearray = value.split('||');
					if(key==imei){
						document.getElementsByName("labitem_id[]")[indexpos].value = valuearray[0];
						//document.getElementsByName("salesinvoice_item[]")[indexpos].value = valuearray[1];
						document.getElementsByName("emergencyinvoice_category[]")[indexpos].value = valuearray[1];
						document.getElementsByName("emergencyinvoice_unit[]")[indexpos].value = valuearray[2];
						document.getElementsByName("emergencyinvoice_refvalue[]")[indexpos].value = valuearray[3];
						document.getElementsByName("emergencyinvoice_rate[]")[indexpos].value = valuearray[4];
						document.getElementsByName("emergencyinvoice_reagent[]")[indexpos].value = valuearray[5];
						document.getElementsByName("emergencyinvoice_pccomission[]")[indexpos].value = valuearray[6];
						document.getElementsByName("emergencyinvoice_drcomission[]")[indexpos].value = valuearray[7];
						document.getElementsByName("emergencyinvoice_qty[]")[indexpos].value = 1;
						
						calculaterowtotal(indexpos);
						addnew_particularrow(true);
					}
				});
				return false;
			}
		});
	});
	
	function calculate_discountp(){
		
		var emergencyinvoice_discountparray = document.getElementsByName("emergencyinvoice_discountp[]");
		var emergencyinvoice_discarray = document.getElementsByName("emergencyinvoice_disc[]");
		var emergencyinvoice_ratearray = document.getElementsByName("emergencyinvoice_rate[]");
		var emergencyinvoice_qtyarray = document.getElementsByName("emergencyinvoice_qty[]");
		//var emergencyinvoice_pccomissionarray = document.getElementsByName("emergencyinvoice_pccomission[]");
			
		if(emergencyinvoice_discountparray.length>0){
			for(var p=0; p<emergencyinvoice_discountparray.length; p++){
				var emergencyinvoice_discountp = parseFloat(emergencyinvoice_discountparray[p].value);
				if(emergencyinvoice_discountp=='' || isNaN(emergencyinvoice_discountp)){emergencyinvoice_discountp = 0;}
				
				var emergencyinvoice_disc = parseFloat(emergencyinvoice_discarray[p].value);
				if(emergencyinvoice_disc=='' || isNaN(emergencyinvoice_disc)){emergencyinvoice_disc = 0;}
				if(emergencyinvoice_discountp>0){
					var emergencyinvoice_rate = parseFloat(emergencyinvoice_ratearray[p].value);
					if(emergencyinvoice_rate=='' || isNaN(emergencyinvoice_rate)){emergencyinvoice_rate = 0;}
					
					var emergencyinvoice_qty = emergencyinvoice_qtyarray[p].value;
					if(emergencyinvoice_qty=='' || isNaN(emergencyinvoice_qty)){emergencyinvoice_qty = 0;}
					
					var total = parseFloat(emergencyinvoice_rate*emergencyinvoice_qty);			
					var emergencyinvoice_disc = parseFloat(total*emergencyinvoice_discountp*0.01);
					
					emergencyinvoice_discarray[p].value = emergencyinvoice_disc.toFixed(2);
				}
				
				calculaterowtotal(p);
			}
		}
	}
	
	function calculaterowtotal(indexpos){
		if(indexpos=='all'){
			var emergencyinvoice_ratearray = document.getElementsByName("emergencyinvoice_rate[]");
			var emergencyinvoice_qtyarray = document.getElementsByName("emergencyinvoice_qty[]");
			var emergencyinvoice_discarray = document.getElementsByName("emergencyinvoice_disc[]");
			var emergencyinvoice_totalarray = document.getElementsByName("emergencyinvoice_total[]");
				var emergencyinvoice_pccomissionarray = document.getElementsByName("emergencyinvoice_pccomission[]");
			
			if(emergencyinvoice_ratearray.length>0){
				for(var p=0; p<emergencyinvoice_ratearray.length; p++){
					var emergencyinvoice_rate = parseFloat(emergencyinvoice_ratearray[p].value);
					if(emergencyinvoice_rate=='' || isNaN(emergencyinvoice_rate)){emergencyinvoice_rate = 0;}
					
					
					var emergencyinvoice_qty = parseFloat(emergencyinvoice_qtyarray[p].value);
					if(emergencyinvoice_qty=='' || isNaN(emergencyinvoice_qty)){emergencyinvoice_qty = 0;}
					
					var total = parseFloat(emergencyinvoice_rate*emergencyinvoice_qty);
					
					var emergencyinvoice_disc = parseFloat(emergencyinvoice_discarray[p].value);
					if(emergencyinvoice_disc=='' || isNaN(emergencyinvoice_disc)){emergencyinvoice_disc = 0;}
					
					var total = parseFloat(total-emergencyinvoice_disc);
					emergencyinvoice_totalarray[p].value = total.toFixed(2);
					
					
					
				}
			}
		}
		else{
			var emergencyinvoice_ratearray = document.getElementsByName("emergencyinvoice_rate[]");
			var emergencyinvoice_rate = parseFloat(emergencyinvoice_ratearray[indexpos].value);
			if(emergencyinvoice_rate=='' || isNaN(emergencyinvoice_rate)){emergencyinvoice_rate = 0;}
			
				
			var emergencyinvoice_qtyarray = document.getElementsByName("emergencyinvoice_qty[]");
			var emergencyinvoice_qty = parseFloat(emergencyinvoice_qtyarray[indexpos].value);
			if(emergencyinvoice_qty=='' || isNaN(emergencyinvoice_qty)){emergencyinvoice_qty = 0;}
			
			var total = parseFloat(emergencyinvoice_rate*emergencyinvoice_qty);
			
			var emergencyinvoice_discarray = document.getElementsByName("emergencyinvoice_disc[]");
			var emergencyinvoice_disc = parseFloat(emergencyinvoice_discarray[indexpos].value);
			if(emergencyinvoice_disc=='' || isNaN(emergencyinvoice_disc)){emergencyinvoice_disc = 0;}
			
			var total = parseFloat(total-emergencyinvoice_disc);
			
			var emergencyinvoice_totalarray = document.getElementsByName("emergencyinvoice_total[]");
			emergencyinvoice_totalarray[indexpos].value = total.toFixed(2);
			
			
			//pc comission 31-01-17
				//var emergencyinvoice_discountparray = document.getElementsByName("emergencyinvoice_discountp[]");
//				var emergencyinvoice_discountp = parseFloat(emergencyinvoice_discountparray[indexpos].value);
//				if(emergencyinvoice_discountp=='' || isNaN(emergencyinvoice_discountp)){emergencyinvoice_discountp = 0;}
//				
//				var emergencyinvoice_pccomissionarray = document.getElementsByName("emergencyinvoice_pccomission[]");
//				var emergencyinvoice_pccomission = parseFloat(emergencyinvoice_pccomissionarray[indexpos].value);
//				if(emergencyinvoice_pccomission=='' || isNaN(emergencyinvoice_pccomission)){emergencyinvoice_pccomission = 0;}
//				
//				var totalpc = parseFloat(emergencyinvoice_pccomission);
//				
//				var totalpc = parseFloat(totalpc-emergencyinvoice_pccomission*emergencyinvoice_discountp*0.01);
//				var emergencyinvoice_pccomissionarray = document.getElementsByName("emergencyinvoice_pccomission[]");
//				
//				emergencyinvoice_pccomissionarray[indexpos].value = totalpc.toFixed(2);
			//pc comission 31-01-17
		}
		
		
		calculate_total();
	}
	
	function calculate_total(){
		var emergencyinvoice_subtotal = 0;
		var emergencyinvoice_totalarray = document.getElementsByName("emergencyinvoice_total[]");
		if(emergencyinvoice_totalarray.length>0){
			for(var p=0; p<emergencyinvoice_totalarray.length; p++){
				var emergencyinvoice_total = parseFloat(emergencyinvoice_totalarray[p].value);
				if(emergencyinvoice_total=='' || isNaN(emergencyinvoice_total)){emergencyinvoice_total = 0;}
				emergencyinvoice_subtotal = parseFloat(emergencyinvoice_subtotal+emergencyinvoice_total);
			}
		}
		//subtotal calculation
		document.getElementById("emergencyinvoice_subtotal").value = emergencyinvoice_subtotal.toFixed(2);
		
		var emergencyinvoice_totaldiscp = parseFloat(document.getElementById("emergencyinvoice_totaldiscp").value);
		if(emergencyinvoice_totaldiscp=='' || isNaN(emergencyinvoice_totaldiscp)){emergencyinvoice_totaldiscp = 0;}
		
		var emergencyinvoice_totaldisc = parseFloat(document.getElementById("emergencyinvoice_totaldisc").value);
		if(emergencyinvoice_totaldisc=='' || isNaN(emergencyinvoice_totaldisc)){emergencyinvoice_totaldisc = 0;}
		
		if(emergencyinvoice_totaldiscp>0){
			var emergencyinvoice_totaldisc = parseFloat(emergencyinvoice_subtotal*emergencyinvoice_totaldiscp*0.01);
			document.getElementById('emergencyinvoice_totaldisc').value= emergencyinvoice_totaldisc;
		}
		var emergencyinvoice_subtotalafterdisc = parseFloat(emergencyinvoice_subtotal-emergencyinvoice_totaldisc);
		document.getElementById('emergencyinvoice_subtotalafterdisc').value=	emergencyinvoice_subtotalafterdisc.toFixed(2);
			
		var emergencyinvoice_receiveamount = parseFloat(document.getElementById("emergencyinvoice_receiveamount").value);
		if(emergencyinvoice_receiveamount=='' || isNaN(emergencyinvoice_receiveamount)){emergencyinvoice_receiveamount = 0;}
		
		var emergencyinvoice_due = parseFloat(emergencyinvoice_subtotalafterdisc-emergencyinvoice_receiveamount);
		document.getElementById('emergencyinvoice_due').value=emergencyinvoice_due.toFixed(2);		
		
		//pc comission  percentage...
		
		var emergencyinvoice_totalpccomission = document.getElementById("emergencyinvoice_totalpccomission").value;
		if(emergencyinvoice_totalpccomission=='' || isNaN(emergencyinvoice_totalpccomission)){emergencyinvoice_totalpccomission = 0;}
		
		 emergencyinvoice_totalpccomission_percent = ((emergencyinvoice_totalpccomission*100)/emergencyinvoice_subtotal);
		document.getElementById('emergencyinvoice_totalpccomission_percent').value=emergencyinvoice_totalpccomission_percent;
		//pc comission  percentage...
		
		// new 21-08-16
		// discount 50/50
		var emergencyinvoice_totalpccomission = 0;
		var emergencyinvoice_pccomissionarray = document.getElementsByName("emergencyinvoice_pccomission[]");
		if(emergencyinvoice_pccomissionarray.length>0){
			for(var p=0; p<emergencyinvoice_pccomissionarray.length; p++){
				var emergencyinvoice_pccomission = parseFloat(emergencyinvoice_pccomissionarray[p].value);
				if(emergencyinvoice_pccomission=='' || isNaN(emergencyinvoice_pccomission)){emergencyinvoice_pccomission = 0;}
				emergencyinvoice_totalpccomission = parseFloat((emergencyinvoice_totalpccomission+emergencyinvoice_pccomission));
			//if(emergencyinvoice_totaldiscp>0){
			//var emergencyinvoice_totalpccomission = parseFloat(emergencyinvoice_totalpccomission*emergencyinvoice_totaldiscp*0.01);
			//}
			}
		}
		document.getElementById("emergencyinvoice_totalpccomission").value = emergencyinvoice_totalpccomission-emergencyinvoice_totaldisc/2;
		// end 21-08-16
		
		// Discount (dr, pc: 100%)
		var emergencyinvoice_totalpccomission = 0;
		var emergencyinvoice_pccomissionarray = document.getElementsByName("emergencyinvoice_pccomission[]");
		if(emergencyinvoice_pccomissionarray.length>0){
			for(var p=0; p<emergencyinvoice_pccomissionarray.length; p++){
				var emergencyinvoice_pccomission = parseFloat(emergencyinvoice_pccomissionarray[p].value);
				if(emergencyinvoice_pccomission=='' || isNaN(emergencyinvoice_pccomission)){emergencyinvoice_pccomission = 0;}
				emergencyinvoice_totalpccomission = parseFloat((emergencyinvoice_totalpccomission+emergencyinvoice_pccomission));
			if(emergencyinvoice_totaldiscp>0){
			document.getElementById("emergencyinvoice_totalpccomission").value = emergencyinvoice_totalpccomission-emergencyinvoice_totaldisc;
				}
			}
		}
		// end 21-08-16
		
		// dr comission
		
		// new 21-08-16
		var emergencyinvoice_totaldrcomission = 0;
		var emergencyinvoice_drcomissionarray = document.getElementsByName("emergencyinvoice_drcomission[]");
		if(emergencyinvoice_drcomissionarray.length>0){
			for(var m=0; m<emergencyinvoice_drcomissionarray.length; m++){
				var emergencyinvoice_drcomission = parseFloat(emergencyinvoice_drcomissionarray[m].value);
				if(emergencyinvoice_drcomission=='' || isNaN(emergencyinvoice_drcomission)){emergencyinvoice_drcomission = 0;}
				
		emergencyinvoice_totaldrcomission = parseFloat((emergencyinvoice_totaldrcomission+emergencyinvoice_drcomission));
			//emergencyinvoice_totalpccomission = parseFloat(emergencyinvoice_totalpccomission);
			if(emergencyinvoice_totaldiscp>0){
			var emergencyinvoice_totaldisc = parseFloat(emergencyinvoice_totaldrcomission*emergencyinvoice_totaldiscp*0.01);
			//document.getElementById('emergencyinvoice_totaldisc').value= emergencyinvoice_totaldisc;
		}}
		}
		document.getElementById("emergencyinvoice_totaldrcomission").value = emergencyinvoice_totaldrcomission;
		// end 21-08-16
		
	
	//pc % count
		//var emergencyinvoice_totalpccomission_percent = parseFloat(document.getElementById("emergencyinvoice_totalpccomission_percent").value);
		//if(emergencyinvoice_totalpccomission_percent=='' || isNaN(emergencyinvoice_totalpccomission_percent)){emergencyinvoice_totalpccomission_percent = 0;}
		
		//var emergencyinvoice_subtotal = parseFloat(document.getElementById("emergencyinvoice_subtotal").value);
		//if(emergencyinvoice_subtotal=='' || isNaN(emergencyinvoice_subtotal)){emergencyinvoice_subtotal = 0;}
		
		
		
		
		
	}
	

	function calculate_pctotal(){
		var emergencyinvoice_totalpccomission = 0;
		var emergencyinvoice_pccomissionarray = document.getElementsByName("emergencyinvoice_pccomission[]");
		if(emergencyinvoice_pccomissionarray.length>0){
			for(var p=0; p<emergencyinvoice_pccomissionarray.length; p++){
				var emergencyinvoice_pccomission = parseFloat(emergencyinvoice_pccomissionarray[p].value);
				if(emergencyinvoice_pccomission=='' || isNaN(emergencyinvoice_pccomission)){emergencyinvoice_pccomission = 0;}
				emergencyinvoice_totalpccomission = parseFloat(emergencyinvoice_totalpccomission+emergencyinvoice_pccomission);
				}
			}
		document.getElementById("emergencyinvoice_totalpccomission").value = emergencyinvoice_totalpccomission;
		}
	
	function calculate_drtotal(){
		var emergencyinvoice_totaldrcomission = 0;
		var emergencyinvoice_drcomissionarray = document.getElementsByName("emergencyinvoice_drcomission[]");
		if(emergencyinvoice_drcomissionarray.length>0){
			for(var m=0; m<emergencyinvoice_drcomissionarray.length; m++){
				var emergencyinvoice_drcomission = parseFloat(emergencyinvoice_drcomissionarray[m].value);
				if(emergencyinvoice_drcomission=='' || isNaN(emergencyinvoice_drcomission)){emergencyinvoice_drcomission = 0;}
				emergencyinvoice_totaldrcomission = parseFloat(emergencyinvoice_totaldrcomission+emergencyinvoice_drcomission);
			}
		}
		
		document.getElementById("emergencyinvoice_totaldrcomission").value = emergencyinvoice_totaldrcomission;
		
	}
	
	function check_particular(){
		
		return true;
	}
	function addnew_particularrow(animate) {
		if(check_particular()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" style=\"BORDER-COLLAPSE: collapse; border:2px solid #FFF\" bgcolor=\"#c0d2ff\" align=\"left\" width=\"<?php echo $printdata_address3;?>\" border=\"0\" cellspacing=\"1\" cellpadding=\"4\">"+
							'<tr>'+
								'<td align="right">Test Name</td>'+
								'<td><input type="text" name="emergencyinvoice_item[]" class="tdclass itemname emergencyinvoice_item"/></td>'+
								'<input type="hidden" name="labitem_id[]"  id="labitem_id" class="tdclass itemname" />'+
								'<input type="hidden" name="emergencyinvoice_category[]" value="" class="tdclass"  />'+
								'<input type="hidden" name="emergencyinvoice_unit[]" value="" class="tdclass"  />'+
								'<input type="hidden" name="emergencyinvoice_refvalue[]" value="" class="tdclass"  />'+
								'<!--<td align="right">Stock</td>-->'+
								"<input type=\"hidden\" name=\"emergencyinvoice_reagent[]\"  id=\"emergencyinvoice_reagent\" value=\"\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/>"+											 
								'<td align="right">Rate</td>'+
								"<td> <input type=\"text\" name=\"emergencyinvoice_rate[]\"  id=\"emergencyinvoice_rate\" value=\"\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/></td>"+											 
								'<!--<td align="right">Qty</td>-->'+
								"<input type=\"hidden\" name=\"emergencyinvoice_qty[]\"   id=\"emergencyinvoice_qty\" value=\"\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/>"+
								'<td align="right">Disc%</td>'+
								'<td> <input type="text" name="emergencyinvoice_discountp[]" value="" class="tdclasssale" onKeyUp="calculate_discountp();"/></td>'+
								'<td align="right">Disc</td>'+
								"<td> <input type=\"text\" name=\"emergencyinvoice_disc[]\" value=\"\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\" /></td>"+
								'<td align="right">P.C</td>'+
								'<td> <input type="text" name="emergencyinvoice_pccomission[]" value="" class="tdclasssale" onKeyUp="calculate_pctotal();"  /></td>'+
								'<td align="right">Dr.</td>'+
								'<td> <input type="text" name="emergencyinvoice_drcomission[]" value="" class="tdclasssale" onKeyUp="calculate_pctotal();"  /></td>'+
								'<td align="right">Total</td>'+
								'<td> <input type="text" readonly name="emergencyinvoice_total[]"  id="emergencyinvoice_total" value="" class="tdclasssale"  /></td>'+												
								'<td>'+
								 "<input type=\"button\" value=\"Cancel\" onClick=\"deletethislistrow('particularlistrowno"+particular_rowcount+"');\" class=\"tdclasssale\"  />"+
								'</td>'+
							  '</tr>'+
						"</table>";
						
			var $newparticularlist = $("<li></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(200); 
			else 
			   $newparticularlist.show();   
			document.getElementsByName("emergencyinvoice_item[]")[parseInt(particular_rowcount-1)].focus();
			
			$( ".itemname" ).autocomplete({			
				minLength: 1,
				source: itemdata,
				focus: function( event, ui ) {
					//$( "#search_item_number" ).val( ui.item.labelval );
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					
					var labitem_idarray = document.getElementsByName("labitem_id[]");
					labitem_idarray[indexpos].value = ui.item.labitem_id;
			
					var emergencyinvoice_ratearray = document.getElementsByName("emergencyinvoice_rate[]");
					emergencyinvoice_ratearray[indexpos].value = ui.item.labitem_price;
					
					var emergencyinvoice_qtyarray = document.getElementsByName("emergencyinvoice_qty[]");
					emergencyinvoice_qtyarray[indexpos].value = 1;
					
					var emergencyinvoice_pccomissionarray = document.getElementsByName("emergencyinvoice_pccomission[]");
					emergencyinvoice_pccomissionarray[indexpos].value = ui.item.labitem_pccommission;
					
					var emergencyinvoice_drcomissionarray = document.getElementsByName("emergencyinvoice_drcomission[]");
					emergencyinvoice_drcomissionarray[indexpos].value = ui.item.labitem_drcommission;
					
					var emergencyinvoice_categoryarray = document.getElementsByName("emergencyinvoice_category[]");
					emergencyinvoice_categoryarray[indexpos].value = ui.item.labitem_group;
					
					var emergencyinvoice_unitarray = document.getElementsByName("emergencyinvoice_unit[]");
					emergencyinvoice_unitarray[indexpos].value = ui.item.labitem_unit;
					
					var emergencyinvoice_refvaluearray = document.getElementsByName("emergencyinvoice_refvalue[]");
					emergencyinvoice_refvaluearray[indexpos].value = ui.item.labitem_refvalue;
					
					var emergencyinvoice_reagentarray = document.getElementsByName("emergencyinvoice_reagent[]");
					emergencyinvoice_reagentarray[indexpos].value = ui.item.labitem_reagent;
	
					calculaterowtotal(indexpos);
					calculate_pctotal();
					calculate_drtotal();
					//addnew_particularrow(true);   //automatic add next row
					return false;
				}
			});	

			$( ".emergencyinvoice_item" ).keypress(function(keyname) {
			if(keyname.which==13){
				var imei = $(this).val();
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				$.each(itemarraydata, function(key, value){
					var valuearray = value.split('||');
					if(key==imei){
						document.getElementsByName("labitem_id[]")[indexpos].value = valuearray[0];
						//document.getElementsByName("salesinvoice_item[]")[indexpos].value = valuearray[1];
						document.getElementsByName("emergencyinvoice_category[]")[indexpos].value = valuearray[1];
						document.getElementsByName("emergencyinvoice_unit[]")[indexpos].value = valuearray[2];
						document.getElementsByName("emergencyinvoice_refvalue[]")[indexpos].value = valuearray[3];
						document.getElementsByName("emergencyinvoice_rate[]")[indexpos].value = valuearray[4];
						document.getElementsByName("emergencyinvoice_reagent[]")[indexpos].value = valuearray[5];
						document.getElementsByName("emergencyinvoice_pccomission[]")[indexpos].value = valuearray[6];
						document.getElementsByName("emergencyinvoice_drcomission[]")[indexpos].value = valuearray[7];
						document.getElementsByName("emergencyinvoice_qty[]")[indexpos].value = 1;
						
						calculaterowtotal(indexpos);
						addnew_particularrow(true);
					}
				});
				return false;
			}
		});				
		}
	}
	
	function deletethislistrow(tableidname){
		$("#"+tableidname).parent("li").slideUp(200, function() {
			$(this).remove();
			calculaterowtotal('all');
		});
	}
	
	function checkcontactform(){
	var error_emergencyinvoice_due = document.getElementById("error_emergencyinvoice_due");
 	error_emergencyinvoice_due.innerHTML = '';
		if(emergencyinvoice_due.value==''){
			error_emergencyinvoice_due.innerHTML = "0";
			emergencyinvoice_due.focus();
			return false;
		}
			
	else if (emergencyinvoice_due.value< "0")
		{
		error_emergencyinvoice_due.innerHTML = "Receive Amount Should not be bigger than Receivable Amount"
		emergencyinvoice_due.focus();
		return false;
		}
	
 	  
   		return true;
 	}
	
	function preventNegative(el) {
			if (el.value < 0) el.value = 0; // Negative দিলে 0 করে দেবে
		}
</script>