<script language="JavaScript" type="text/javascript">
	
	var patientdata = <?php echo $patientdata;?>;
	$(document).ready(function($) {
		
		
		$( "#bankinvoice_name" ).autocomplete({
			
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('bankinvoice_name').value = ui.item.labelval;
				 document.getElementById('bankaccounts_id').value = ui.item.bankaccounts_id;
				 document.getElementById('bankinvoice_number').value = ui.item.bankaccounts_number;
				 document.getElementById('current_balance').value = ui.item.current_balance;
				 document.getElementById('bankinvoice_address').value = ui.item.bankaccounts_address;
				 document.getElementById('section').value = ui.item.section;
				
				return false;
			}
		});
		
			
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
	});
	
		
	function calculate_total(){
		
		var current_balance = parseFloat(document.getElementById("current_balance").value);
		if(current_balance=='' || isNaN(current_balance)){current_balance = 0;}
			
		var deposite_amount = parseFloat(document.getElementById("deposite_amount").value);
		if(deposite_amount=='' || isNaN(deposite_amount)){deposite_amount = 0;}
		
		var total_balance = parseFloat(current_balance + deposite_amount);
		document.getElementById('total_balance').value=	total_balance.toFixed(2);
		
		}
	
function funcSaveBill1()
		{
			
			var varUserChoice; 
			varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
			//alert(fRet); 
			if (varUserChoice == false)
			{
				alert ("Entry Not Saved.");
				return false;
			}
			else
			{
				alert ("Entry Saved.");
				document.frmsales.submit();
				//return true;
			}
		}		
</script>