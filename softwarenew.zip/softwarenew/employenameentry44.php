 <table align="left" width="50%" border="1" style="BORDER-COLLAPSE: collapse;" cellspacing="1" cellpadding="3">
      <tr>
        <td colspan="10" bgcolor="#0033FF" align="left" style="color:#fff; border:1px solid #03F;">
            <strong><?php //echo $hospitaldata_name; ?></strong><br>
            <strong>In Time Information </strong>
        </td>
      </tr>
      <tr bgcolor="#ccc" align="center">
        <td>ID</td>
        <td>Name</td>
        <td>In Time</td>
      </tr>

	  <?php
     	$sqlsalesitem = "select * from machine_data where in_out=1 order by id asc";
	  	$salesitemquery = mysqli_query($conn, $sqlsalesitem);
			while ($salesitemrow = mysqli_fetch_array($salesitemquery))
				{
				$e_id = $salesitemrow['e_id'];
				$entry_time = $salesitemrow['entry_time'];
				$entry_date = $salesitemrow['entry_date'];
				//$in_out = $salesitemrow[2];
				if($in_out=1){
							$inTime = "$entry_date $entry_time";
						}
			 
						
			$sqlst = "select * from employee where e_id='$e_id'";
			$exec3 = mysqli_query($conn, $sqlst) or die ("Error in Query3".mysql_error());
			$onerow = mysqli_fetch_array($exec3);
 				$name = $onerow['name'];	
 					
				?>
				<tr bgcolor="#fff" align="center">
					<td align="left"><?php echo $e_id; ?></td>
					<td align="left"><?php echo $name; ?></td>
					<td><?php echo $inTime; ?></td>
 				</tr>
			<?Php	
			}			
		?>
 </table>
 
 <?php /*?><table align="left" width="50%" border="1" style="BORDER-COLLAPSE: collapse;" cellspacing="1" cellpadding="3">
      <tr>
        <td colspan="10" bgcolor="#0033FF" align="left" style="color:#fff; border:1px solid #03F;">
            <strong><?php //echo $hospitaldata_name; ?></strong><br>
            <strong>Out Time Information </strong>
        </td>
      </tr>
      <tr bgcolor="#ccc" align="center">
       <td>ID</td><td>Name</td>
       <td>Out Time</td>
      </tr>

	  <?php
     	$sqlsalesitem = "select * from machine_data where in_out=2 order by id asc";
	  	$salesitemquery = mysqli_query($conn, $sqlsalesitem);
			while ($salesitemrow = mysqli_fetch_array($salesitemquery))
				{
				$e_id = $salesitemrow['e_id'];
				$entry_time = $salesitemrow['entry_time'];
				$entry_date = $salesitemrow['entry_date'];
				//$in_out = $salesitemrow[2];
				if($in_out=2){
							$inTime = "$entry_date $entry_time";
						}
					
					$sqlst = "select * from employee where e_id='$e_id'";
			$exec3 = mysqli_query($conn, $sqlst) or die ("Error in Query3".mysql_error());
			$onerow = mysqli_fetch_array($exec3);
		
				$name = $onerow['name'];	
				?>
				<tr bgcolor="#fff" align="center">
                <td><?php echo $e_id; ?></td> <td><?php echo $name; ?></td>
					<td><?php echo $inTime; ?></td>
				</tr>
			<?Php	
			}			
		?>
 </table><?php */?>