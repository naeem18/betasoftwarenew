<?php
// ajax_patient_list.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
require_once 'labdd.php';

// Initialize variables
$searchstr = '';
$transactiondatefrom = date('Y-m-d');
$transactiondateto = date('Y-m-d');
$search_params = [];
$types = 'ss';

// Process search parameters
if (!empty($_REQUEST['ADate1']) && !empty($_REQUEST['ADate2'])) {
    $transactiondatefrom = $_REQUEST['ADate1'];
    $transactiondateto = $_REQUEST['ADate2'];
    
    // Process each search filter independently
    if (!empty($_REQUEST['labinvoice_id'])) {
        $searchstr .= " AND labinvoice_id LIKE ?";
        $search_params[] = "%".$_REQUEST['labinvoice_id']."%";
        $types .= 's';
    }
    if (!empty($_REQUEST['bar'])) {
        $searchstr .= " AND bar LIKE ?";
        $search_params[] = "%".$_REQUEST['bar']."%";
        $types .= 's';
    }
    if (!empty($_REQUEST['labinvoice_mobile'])) {
        $searchstr .= " AND labinvoice_mobile LIKE ?";
        $search_params[] = "%".$_REQUEST['labinvoice_mobile']."%";
        $types .= 's';
    }
    if (!empty($_REQUEST['labinvoice_patientid'])) {
        $searchstr .= " AND labinvoice_patientid LIKE ?";
        $search_params[] = "%".$_REQUEST['labinvoice_patientid']."%";
        $types .= 's';
    }
}

// Calculate date range
$datetime1 = new DateTime($transactiondatefrom);
$datetime2 = new DateTime($transactiondateto);

// Ensure proper date ordering
if ($datetime1 > $datetime2) {
    $temp = $datetime1;
    $datetime1 = $datetime2;
    $datetime2 = $temp;
}

// Main data query
$s = 0;
$output = '';

$sql = "SELECT bar, labinvoice_patientid, labinvoice_id,labinvoice_patient,labinvoice_age,labinvoice_mobile,
labinvoice_ward,labinvoice_date FROM labinvoice 
        WHERE labinvoice_date BETWEEN ? AND ? 
        $searchstr 
        ORDER BY labinvoice_id DESC";

$stmt = $conn->prepare($sql);
if ($stmt) {
    $start_date = $datetime1->format('Y-m-d 00:00:00');
    $end_date = $datetime2->format('Y-m-d 23:59:59');
    
    // Bind parameters dynamically
    $bind_params = [$types, &$start_date, &$end_date];
    foreach ($search_params as &$param) {
        $bind_params[] = &$param;
    }
    
    call_user_func_array([$stmt, 'bind_param'], $bind_params);
    
    if ($stmt->execute()) {
        $result = $stmt->get_result();
        
        // Pre-fetch all test names in one query
        $test_names = [];
        if ($result->num_rows > 0) {
            $invoice_ids = [];
            while ($row = $result->fetch_assoc()) {
                $invoice_ids[] = $row['labinvoice_id'];
            }
            
            // Reset result pointer
            $result->data_seek(0);
            
            // Get all test names in one query
            if (!empty($invoice_ids)) {
                $placeholders = implode(',', array_fill(0, count($invoice_ids), '?'));
					$excluded_categories = array('USG', 'X-RAY', 'Tube', 'ECG', 'ECHO', 'CT-SCAN', 'Physiotherapy', 'TUBE');
					$placeholders_cat = "'" . implode("','", $excluded_categories) . "'";
                $test_query = "SELECT labinvoice_id, labinvoicedetails_item, labinvoicedetails_category, rstatus 
                             FROM labinvoicedetails 
                             WHERE labinvoice_id IN ($placeholders)
							 AND labinvoicedetails_category NOT IN ($placeholders_cat)
                             AND treturn != 'Y' 
                             AND dstatus != 'Deleted' 
                             AND status != 'Deleted'";
                
                $stmt_test = $conn->prepare($test_query);
                if ($stmt_test) {
                    $types_test = str_repeat('i', count($invoice_ids));
                    $params = array_merge([$types_test], $invoice_ids);
                    $refs = [];
                    foreach($params as $key => $value) {
                        $refs[$key] = &$params[$key]; 
                    }
                    
                    call_user_func_array([$stmt_test, 'bind_param'], $refs);
                    
                    if ($stmt_test->execute()) {
                        $test_result = $stmt_test->get_result();
                        while ($test = $test_result->fetch_assoc()) {
                            if (!isset($test_names[$test['labinvoice_id']])) {
                                $test_names[$test['labinvoice_id']] = [];
                            }
                            $test_names[$test['labinvoice_id']][] = [
                                'item' => $test['labinvoicedetails_item'],
                                'status' => $test['rstatus']
                            ];
                        }
                    }
                    $stmt_test->close();
                }
            }
        }
        
        // Generate HTML output
        $output .= '<table width="100%" style="border-collapse: collapse;" border="1" cellspacing="1" cellpadding="3">';
        $output .= '<tr><td colspan="12" bgcolor="#f2f2f2" align="center" style="color:#03F; border:1px solid #03F;">';
        $output .= '<strong>Patient With Investigation List:: Date: ' . date('d.m.y', strtotime($datetime1->format('Y-m-d'))) . ' to ' . date('d.m.y', strtotime($datetime2->format('Y-m-d'))) . '</strong>';
        $output .= '</td></tr>';
        $output .= '<tr bgcolor="#ccc">';
        $output .= '<td>SL</td><td>Barcode</td><td>ID</td><td>Inv No.</td><td>Inv Date</td>';
        $output .= '<td>Patient Name</td><td>Age</td><td>Mobile</td><td>Cabin</td>';
        $output .= '<td>Test Name</td><td>Action</td></tr>';
        
        while ($row = $result->fetch_assoc()) {
            $s++;
            $output .= '<tr bgcolor="#fff">';
            $output .= '<td>' . $s . '</td>';
            $output .= '<td>' . htmlspecialchars($row['bar']) . '</td>';
            $output .= '<td>' . htmlspecialchars($row['labinvoice_patientid']) . '</td>';
            $output .= '<td>' . htmlspecialchars($row['labinvoice_id']) . '</td>';
            $output .= '<td>' . htmlspecialchars($row['labinvoice_date']) . '</td>';
            $output .= '<td>' . htmlspecialchars($row['labinvoice_patient']) . '</td>';
            $output .= '<td>' . htmlspecialchars($row['labinvoice_age']) . '</td>';
            $output .= '<td>' . htmlspecialchars($row['labinvoice_mobile']) . '</td>';
            $output .= '<td>' . htmlspecialchars($row['labinvoice_ward']) . '</td>';
            //$output .= '<td>' . htmlspecialchars($row['labinvoice_doctor']) . '</td>';
            $output .= '<td style="font-size: 11px;">';
            
            // Display test names
            if (isset($test_names[$row['labinvoice_id']]) && !empty($test_names[$row['labinvoice_id']])) {
                foreach ($test_names[$row['labinvoice_id']] as $test) {
                    $color = $test['status'] != 0 ? 'red' : '';
                    $output .= '<div style="margin: 2px 0;"><span class="'.$color.'">'.
                             htmlspecialchars($test['item']).'</span></div>';
                }
            } else {
                $output .= '<div style="color: #999;">No tests found</div>';
            }
            
            $output .= '</td>';
            $output .= '<td><a href="index.php?p=zz_patientinvestigationlist&labinvoice_id=' . $row['labinvoice_id'] . '" target="_blank">Report Entry</a></td>';
            $output .= '</tr>';
        }
        
        $output .= '</table>';
        
    }
    $stmt->close();
} else {
    $output = '<tr><td colspan="12">Error preparing query: ' . htmlspecialchars($conn->error) . '</td></tr>';
}

echo $output;
$conn->close();
?>