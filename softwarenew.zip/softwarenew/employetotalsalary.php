<?php
date_default_timezone_set('Asia/Dhaka');
$searchstr = '';
if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '') {
    $transactiondatefrom = $_REQUEST['ADate1'];
    $transactiondateto = $_REQUEST['ADate2'];    
} else {
    $transactiondatefrom = date('Y-m-d', strtotime('-0 day'));
    $transactiondateto = date('Y-m-d');
}

$datetime1 = new DateTime($transactiondatefrom);
$datetime2 = new DateTime($transactiondateto);
$interval = $datetime1->diff($datetime2);
$totaldays = $interval->format('%a');
if($datetime1 < $datetime2) {
    $fromdate = $transactiondatefrom;
    $todate = $transactiondateto;
} else {
    $fromdate = $transactiondateto;
    $todate = $transactiondatefrom;
}
?>

<table width="90%" border="0" cellspacing="0" cellpadding="2">
    <tr>
        <td valign="top" align="center">
            <form name="cbform1" method="post" action="index.php?p=employetotalsalary">
                <table width="100%" border="1" align="center" cellpadding="2" cellspacing="0" bordercolor="#666666" style="border-collapse: collapse">
                    <tbody>
                        <tr bgcolor="#011E6A">
                            <td colspan="10" bgcolor="#CCCCCC" align="center"><strong>Search Date wise</strong></td>
                        </tr>           
                        <tr>
                            <td>Date From:</td>
                            <td><input name="ADate1" id="ADate1" style="border: 1px solid #001E6A" value="<?php echo $transactiondatefrom; ?>" size="10" readonly onKeyDown="return disableEnterKey()" />
                                <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
                            </td>
                            <td>Date To:</td>
                            <td><input name="ADate2" id="ADate2" style="border: 1px solid #001E6A" value="<?php echo $transactiondateto; ?>" size="10" readonly onKeyDown="return disableEnterKey()" />
                                <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate2')" style="cursor:pointer"/>
                            </td>
                            <td><input style="border: 1px solid #001E6A" type="submit" value="Search" name="Submit" />
                                <input name="resetbutton" type="reset" id="resetbutton" style="border: 1px solid #001E6A" value="Reset" />
                            </td>
                            <td><input name="print" type="button" id="print" style="border: 1px solid #001E6A" value="Print" onClick="PrintDiv();" /></td>
                        </tr>
                    </tbody>
                </table>
            </form>
        </td>
    </tr>

    <tr>
        <td align="center">
            <table align="center" width="100%" border="1" style="BORDER-COLLAPSE: collapse;" cellspacing="1" cellpadding="3">
                <tr>
                    <td colspan="100%" bgcolor="#0033FF" align="center" style="color:#fff; border:1px solid #03F;">
                        <strong>Total Salary Sheet</strong><br>
                        <strong>Date Range: <?php echo $fromdate; ?> to <?php echo $todate; ?></strong>
                    </td>
                </tr>
                <tr bgcolor="#ccc" align="center">
                    <td>SL</td>
                    <td>Employee ID</td>
                    <td>Name</td>
                    <td>Total Check-ins</td>
                    <td>Salary Per Day</td>
                    <td>Total Salary (Days × Daily)</td>
                    <td>Deductions</td>
                    <td>Net Salary</td>
                </tr>
                <?php
                $grossT = 0;
                $in_outTT = 0;
                $totalSalary = 0;
                $totalDeductions = 0;
                $totalNetSalary = 0;
                $s = 0;
                
                $newfromdate = date('Y-m-d 08:00:00', strtotime($fromdate));
                $newtodate = date('Y-m-d 08:59:59', strtotime($todate));
                
                /*$sqlst = "SELECT e_id, COUNT(*) as total_checkins 
                          FROM machine_data 
                          WHERE in_out=1 AND (entry_date BETWEEN '$newfromdate' AND '$newtodate') 
                          $searchstr 
                          GROUP BY e_id 
                          ORDER BY e_id ASC";*/
						  
						   $sqlst = "SELECT e_id, COUNT(*) as total_checkins 
                          FROM machine_data 
                          WHERE in_out=1
                          GROUP BY e_id 
                          ORDER BY e_id ASC";
                
                $stquery = mysqli_query($conn, $sqlst);
                
                if($stquery && mysqli_num_rows($stquery) > 0) {
                    while ($strow = mysqli_fetch_array($stquery)) {
                        $s++;
                        $e_id = $strow['e_id'];
                        $total_checkins = $strow['total_checkins'];
                        
                        // Get employee details
                        $empQuery = "SELECT name, gross FROM employee WHERE e_id='$e_id'";
                        $empResult = mysqli_query($conn, $empQuery);
                        
                        if($empResult && mysqli_num_rows($empResult) > 0) {
                            $empData = mysqli_fetch_array($empResult);
                            $name = $empData['name'];
                            $gross = $empData['gross'];
                            
                            // Calculate salaries
                            $dailySalary = $gross / 30;
                            $totalEarned = $dailySalary * $total_checkins;
                            $deductions = 0; // You can add your deduction logic here
                            $netSalary = $totalEarned - $deductions;
                            
                            // Add to totals
                            $in_outTT += $total_checkins;
                            $totalSalary += $totalEarned;
                            $totalDeductions += $deductions;
                            $totalNetSalary += $netSalary;
                ?>
                <tr bgcolor="#fff" align="center">
                    <td><?php echo $s; ?></td>
                    <td><?php echo $e_id; ?></td>
                    <td><?php echo $name; ?></td>
                    <td><?php echo $total_checkins; ?></td>
                    <td><?php echo number_format($dailySalary, 2); ?></td>
                    <td><?php echo number_format($totalEarned, 2); ?></td>
                    <td><?php echo number_format($deductions, 2); ?></td>
                    <td><?php echo number_format($netSalary, 2); ?></td>
                </tr>
                <?php
                        }
                    }
                } else {
                    echo '<tr><td colspan="8" align="center">No records found</td></tr>';
                }
                ?>
                <!-- Summary Row -->
                <tr bgcolor="#ffcc99" align="center" style="font-weight:bold;">
                    <td colspan="3">TOTALS</td>
                    <td><?php echo $in_outTT; ?></td>
                    <td>-</td>
                    <td><?php echo number_format($totalSalary, 2); ?></td>
                    <td><?php echo number_format($totalDeductions, 2); ?></td>
                    <td><?php echo number_format($totalNetSalary, 2); ?></td>
                </tr>
            </table>
        </td>
    </tr>
</table>