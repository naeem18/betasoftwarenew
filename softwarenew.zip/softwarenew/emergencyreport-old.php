<?php
$searchstr='';
if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
{
	$transactiondatefrom = $_REQUEST['ADate1'];
	$transactiondateto = $_REQUEST['ADate2'];
	
	$emergency_head = $_REQUEST['emergency_head'];
	$emergency_particular = $_REQUEST['emergency_particular'];
	
	if($emergency_head !=''){
		$searchstr .= " and emergency_head like '%$emergency_head%'";
	}
	elseif($emergency_particular !=''){
		$searchstr .= " and emergency_particular like '%$emergency_particular%'";
		}
}
else
{
	$transactiondatefrom = date('Y-m-d', strtotime('-0 day'));
	$transactiondateto = date('Y-m-d');
}
?>

<script language="javascript">
function cbcustomername1()
{
	document.cbform1.submit();
}
</script>

<script type="text/javascript">
window.onload = function ()
{
	var oTextbox = new AutoSuggestControl(document.getElementById("searchcustomername"), new StateSuggestions());        
}
</script>


<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td valign="top" align="center">
    	<form name="cbform1" method="post" action="index.php?p=emergencyreport">
            <table width="100%" border="0" align="center" cellpadding="4" cellspacing="0" bordercolor="#666666" id="AutoNumber3" style="border-collapse: collapse">
              <tbody>
                <tr bgcolor="#011E6A">
                  <td colspan="10" bgcolor="#CCCCCC" class="bodytext3"><strong>Search Date / Doctor wise</strong></td>
                </tr>           
                <tr>
                    <td class="bodytext31" width="10%" valign="center"  align="right" bgcolor="#FFFFFF"> Date From&nbsp;:&nbsp;</td>
                    <td width="12%" align="left" valign="center"  bgcolor="#FFFFFF" class="bodytext30">
                        <input name="ADate1" id="ADate1" style="border: 1px solid #001E6A" value="<?php echo $transactiondatefrom; ?>"  size="10"  readonly="readonly" onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
                    </td>
                    <td width="8%" align="right" valign="center"  bgcolor="#FFFFFF" class="bodytext30"> Date To&nbsp;:&nbsp;</td>
                    <td width="12%" align="left" valign="center"  bgcolor="#FFFFFF">
                        <span class="bodytext31">
                            <input name="ADate2" id="ADate2" style="border: 1px solid #001E6A" value="<?php echo $transactiondateto; ?>"  size="10"  readonly="readonly" onKeyDown="return disableEnterKey()" />
                            <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate2')" style="cursor:pointer"/>
                        </span>
                    </td>
                    <td width="8%" align="right" valign="center"  bgcolor="#FFFFFF" class="bodytext30">By Head</td>
            	    <td width="8%" align="left" valign="center"  bgcolor="#FFFFFF"> <input type="text" name="emergency_head" id="emergency_head" value=""   /></td>
                    
                    <td width="8%" align="right" valign="center"  bgcolor="#FFFFFF" class="bodytext30">By Particular</td>
            	    <td width="8%" align="left" valign="center"  bgcolor="#FFFFFF"> <input type="text" name="emergency_particular" id="emergency_particular" value=""   /></td>
                   
                    <td align="left" valign="top"  bgcolor="#FFFFFF">
                        <input type="hidden" name="cbfrmflag1" value="cbfrmflag1">
                        <input  style="border: 1px solid #001E6A" type="submit" value="Search" name="Submit" />
                        </td>
                    <td width="10%" align="right" valign="top"  bgcolor="#FFFFFF">
                       <input name="print" type="button" id="print"  style="border: 1px solid #001E6A" value="Print" onClick="PrintDiv();" />
                    </td>
                </tr>
              </tbody>
            </table>
		</form>
      
   	</td>
</tr>

	<td> 
		<?php 
		
		$datetime1 = new DateTime($transactiondatefrom);
		$datetime2 = new DateTime($transactiondateto);
		$interval = $datetime1->diff($datetime2);
		$totaldays = $interval->format('%a');
		if($datetime1<$datetime2){
			$fromdate = $transactiondatefrom;
			$todate = $transactiondateto;
		}
		else{
			$fromdate = $transactiondateto;
			$todate = $transactiondatefrom;
		}
		?>
        
        <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1" cellspacing="0" cellpadding="2">
        <tbody>
         <tr>
            <td colspan="19" bgcolor="#f2f2f2" align="center" style="color:#03F; border:1px solid #03F; padding-left:15px;">
            	<strong><?php echo $hospitaldata_name; ?></strong><br>
                <samp>Statement By Emergency :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></samp>
            </td>
          </tr>
            <tr>
               	<td width="10%" align="left" valign="center" bgcolor="#77F7AA" >
               		<strong>Print</strong>
           		</td>
                <td width="10%" align="left" valign="center" bgcolor="#77F7AA" >
               		<strong>Date</strong>
           		</td>
                <td width="10%" align="left" valign="center" bgcolor="#77F7AA" >
               		<strong>Bill No.</strong>
           		</td>
              	<td width="10%" align="left" valign="center" bgcolor="#77F7AA" >
                	<strong>Patient Name</strong>
              	</td> 
                <td width="10%" align="left" valign="center" bgcolor="#77F7AA" >
                	<strong>Emergency Head</strong>
              	</td>
                <td width="10%" align="left" valign="center" bgcolor="#77F7AA" >
                	<strong>Particular</strong>
              	</td>             
              	<td width="10%" align="left" valign="center" bgcolor="#77F7AA" >
                	<strong>Received Amount</strong>
              	</td> 
                <td width="10%" align="left" valign="center" bgcolor="#77F7AA" >
                	<strong> User </strong>
              	</td>
                <td width="10%" align="left" valign="center" bgcolor="#77F7AA" >
                	<strong>Edit/ Delete</strong>
              	</td>              
              </tr>
		<?php
		$totalsumemergency_amount='0.00';
			
		for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
		 	$sqlst = "select * from emergency where emergency_amount!= '' and  emergency_date between '$newfromdate' and '$newtodate' $searchstr order by emergency_id asc";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery &&  mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery)) {
					$emergency_id = $strow['emergency_id'];
                    $emergency_name = $strow['emergency_name'];
					$user = $strow['user'];
                    $emergency_mobile = $strow['emergency_mobile'];
					$emergency_head = $strow['emergency_head'];
                    $emergency_particular = $strow['emergency_particular'];
                    $emergency_amount = $strow['emergency_amount'];
                    $emergency_description = $strow['emergency_description'];
                    $emergency_voucher = $strow['emergency_voucher'];
                    $emergency_date = $strow['emergency_date'];
			$action = "<a href=\"index.php?p=emergencyinvoice&emergency_id=$emergency_id\">Edit</a>";
			$action2 = "<a href=\"index.php?p=printemergency&emergency_id=$emergency_id\" target=\"_blank\">print</a>";

					?>
				<?php  
					$totalsumemergency_amount  = $totalsumemergency_amount + $emergency_amount;
					?>
                <tr>
                 <td bgcolor="#FFFFFF" class="bodytext31" valign="center"  align="left">
                       <samp><?php echo $action2;?></samp>
                    </td>
                    <td bgcolor="#FFFFFF" class="bodytext31" valign="center"  align="left">
                        <samp><?php echo $emergency_date; ?></samp>
                    </td>
                    <td bgcolor="#FFFFFF"  class="bodytext31" valign="center"  align="left">
                        <samp><?php echo $emergency_id; ?></samp>
                    </td>
                   
                     <td bgcolor="#FFFFFF"  class="bodytext31" valign="center"  align="left">
                        <samp><?php echo $emergency_name; ?></samp>
                    </td>
                     <td bgcolor="#FFFFFF"  class="bodytext31" valign="center"  align="left">
                        <samp><?php echo $emergency_head; ?></samp>
                    </td>
                    <td bgcolor="#FFFFFF"  class="bodytext31" valign="center"  align="left">
                        <samp><?php echo $emergency_particular; ?></samp>
                    </td>
                    <td bgcolor="#FFFFFF" class="bodytext31" valign="center"  align="left">
                       <samp> <?php echo $emergency_amount; ?></samp>
                    </td>
                     <td bgcolor="#FFFFFF" class="bodytext31" valign="center"  align="left">
                       <samp> <?php echo $user; ?></samp>
                    </td>
                     <td bgcolor="#FFFFFF" class="bodytext31" valign="center"  align="left">
                       <samp> <?php echo $action;?></samp>
                    </td>
                    
              	</tr>
                <?php
                	}
				}
			}
		?>
        	<tr>
              <td class="bodytext31" valign="center"  align="left">&nbsp;</td>
               <td class="bodytext31" valign="center"  align="left">&nbsp;</td>
               <td class="bodytext31" valign="center"  align="left">&nbsp;</td>
              <td class="bodytext31" valign="center"  align="left">&nbsp;</td>
              <td class="bodytext31" valign="center"  align="left">&nbsp;</td>
              <td class="bodytext31" valign="center"  align="left"><div align="right"><strong>Total : </strong></div></td>
              <td class="bodytext31" valign="center"  align="left" >
              <div align="right"><strong><?php echo number_format($totalsumemergency_amount, 2, '.', ''); ?></strong></div></td>
             <td class="bodytext31" valign="center"  align="left">&nbsp;</td>
             <td class="bodytext31" valign="center"  align="left">&nbsp;</td>
            </tr>
           <tbody>
        </table>
        </td>
      
<td align="center" id="divToPrint" style="display:none">
   
		<?php 
		
		$datetime1 = new DateTime($transactiondatefrom);
		$datetime2 = new DateTime($transactiondateto);
		$interval = $datetime1->diff($datetime2);
		$totaldays = $interval->format('%a');
		if($datetime1<$datetime2){
			$fromdate = $transactiondatefrom;
			$todate = $transactiondateto;
		}
		else{
			$fromdate = $transactiondateto;
			$todate = $transactiondatefrom;
		}
		?>
        
        <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1" cellspacing="0" cellpadding="2">
        <tbody>
         <tr>
            <td colspan="19" bgcolor="#f2f2f2" align="center" style="color:#03F; border:1px solid #03F; padding-left:15px;">
            	<strong>Maa-Moni Hospital</strong><br>
                <samp>Statement By Emergency :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></samp>
            </td>
          </tr>
            <tr>
               	<td width="10%" align="left" valign="center" bgcolor="#77F7AA" >
               		<strong>Print</strong>
           		</td>
                <td width="10%" align="left" valign="center" bgcolor="#77F7AA" >
               		<strong>Date</strong>
           		</td>
                <td width="10%" align="left" valign="center" bgcolor="#77F7AA" >
               		<strong>Bill No.</strong>
           		</td>
              	<td width="10%" align="left" valign="center" bgcolor="#77F7AA" >
                	<strong>Patient Name</strong>
              	</td> 
                <td width="10%" align="left" valign="center" bgcolor="#77F7AA" >
                	<strong>Emergency Head</strong>
              	</td>
                <td width="10%" align="left" valign="center" bgcolor="#77F7AA" >
                	<strong>Particular</strong>
              	</td>             
              	<td width="10%" align="left" valign="center" bgcolor="#77F7AA" >
                	<strong>Received Amount</strong>
              	</td> 
                <td width="10%" align="left" valign="center" bgcolor="#77F7AA" >
                	<strong> User </strong>
              	</td>
                <td width="10%" align="left" valign="center" bgcolor="#77F7AA" >
                	<strong>Edit/ Delete</strong>
              	</td>              
              </tr>
		<?php
		$totalsumemergency_amount='0.00';
			
		for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
			$sqlst = "select * from emergency where emergency_amount!= '' and  emergency_date between '$newfromdate' and '$newtodate' $searchstr order by emergency_id desc";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery &&  mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery)) {
					$emergency_id = $strow['emergency_id'];
                    $emergency_name = $strow['emergency_name'];
					$user = $strow['user'];
                    $emergency_mobile = $strow['emergency_mobile'];
					$emergency_head = $strow['emergency_head'];
                    $emergency_particular = $strow['emergency_particular'];
                    $emergency_amount = $strow['emergency_amount'];
                    $emergency_description = $strow['emergency_description'];
                    $emergency_voucher = $strow['emergency_voucher'];
                    $emergency_date = $strow['emergency_date'];
			$action = "<a href=\"emergencyinvoice.php&emergency_id=$emergency_id\">Edit</a>";
			$action2 = "<a href=\"index.php?p=printemergency&emergency_id=$emergency_id\" target=\"_blank\">print</a>";

					?>
				<?php  
					$totalsumemergency_amount  = $totalsumemergency_amount + $emergency_amount;
					?>
                <tr>
                 <td bgcolor="#FFFFFF" class="bodytext31" valign="center"  align="left">
                       <samp><?php //echo $action2;?></samp>
                    </td>
                    <td bgcolor="#FFFFFF" class="bodytext31" valign="center"  align="left">
                        <samp><?php echo $emergency_date; ?></samp>
                    </td>
                    <td bgcolor="#FFFFFF"  class="bodytext31" valign="center"  align="left">
                        <samp><?php echo $emergency_id; ?></samp>
                    </td>
                   
                     <td bgcolor="#FFFFFF"  class="bodytext31" valign="center"  align="left">
                        <samp><?php echo $emergency_name; ?></samp>
                    </td>
                     <td bgcolor="#FFFFFF"  class="bodytext31" valign="center"  align="left">
                        <samp><?php echo $emergency_head; ?></samp>
                    </td>
                    <td bgcolor="#FFFFFF"  class="bodytext31" valign="center"  align="left">
                        <samp><?php echo $emergency_particular; ?></samp>
                    </td>
                    <td bgcolor="#FFFFFF" class="bodytext31" valign="center"  align="left">
                       <samp> <?php echo $emergency_amount; ?></samp>
                    </td>
                     <td bgcolor="#FFFFFF" class="bodytext31" valign="center"  align="left">
                       <samp> <?php echo $user; ?></samp>
                    </td>
                     <td bgcolor="#FFFFFF" class="bodytext31" valign="center"  align="left">
                       <samp> <?php // echo $action;?></samp>
                    </td>
                    
              	</tr>
                <?php
                	}
				}
			}
		?>
        	<tr>
              <td class="bodytext31" valign="center"  align="left">&nbsp;</td>
               <td class="bodytext31" valign="center"  align="left">&nbsp;</td>
               <td class="bodytext31" valign="center"  align="left">&nbsp;</td>
              <td class="bodytext31" valign="center"  align="left">&nbsp;</td>
              <td class="bodytext31" valign="center"  align="left">&nbsp;</td>
              <td class="bodytext31" valign="center"  align="left"><div align="right"><strong>Total : </strong></div></td>
              <td class="bodytext31" valign="center"  align="left" >
              <div align="right"><strong><?php echo number_format($totalsumemergency_amount, 2, '.', ''); ?></strong></div></td>
             <td class="bodytext31" valign="center"  align="left">&nbsp;</td>
             <td class="bodytext31" valign="center"  align="left">&nbsp;</td>
            </tr>
           <tbody>
        </table>
        </td>
</table>