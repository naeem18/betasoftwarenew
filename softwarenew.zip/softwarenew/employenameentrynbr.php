<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$message = '';
if(isset($_POST) && array_key_exists('btnAttUpload', $_POST)){
	$message = '<p>There is an error for submit this file.</p>';
	$entry = $out = $update = $empInsert = 0;
	$created_date = $modified_date  = time();
	require_once 'ExcelLibrary/PHPExcel.php';
	//require_once dirname(__FILE__) . '/ExcelLibrary/Classes/PHPExcel/IOFactory.php';
	
	$uploadfile = basename($_FILES['attendance_file']['name']);
	$upload_filearray = explode('.', $uploadfile);				
	$fileextension = $upload_filearray[floor(count($upload_filearray)-1)];
	$tempFile = $_FILES['attendance_file']['tmp_name'];
	$object = PHPExcel_IOFactory::load($tempFile);
	
	$employeeArray = array();
	$empObj = mysqli_query($conn, "SELECT eTIN FROM employeemi WHERE BINStatus = 'Active'");
	if($empObj){
		while($empOneRow=mysqli_fetch_array($empObj)){
			$employeeArray[] = $empOneRow['eTIN'];
		}
	}

	$eIds = array();
	foreach($object->getWorksheetIterator() as $worksheet){
		$highestRow = $worksheet->getHighestRow();
		$highestColumn = $worksheet->getHighestColumn();
		//var_dump($highestColumn);
		for($row=2; $row<=$highestRow; $row++){
			$eTIN = intval($worksheet->getCellByColumnAndRow(0, $row)->getValue());
			$BINIssueDate = addslashes($worksheet->getCellByColumnAndRow(1, $row)->getValue());
			$Commissionerate = addslashes($worksheet->getCellByColumnAndRow(2, $row)->getValue());
 			$Division = addslashes($worksheet->getCellByColumnAndRow(3, $row)->getValue());
			$Circle = addslashes($worksheet->getCellByColumnAndRow(4, $row)->getValue());
			$BIN = addslashes($worksheet->getCellByColumnAndRow(5, $row)->getValue());
 			$Name = addslashes($worksheet->getCellByColumnAndRow(6, $row)->getValue());
			$ResidencyStatus = addslashes($worksheet->getCellByColumnAndRow(7, $row)->getValue());
			$TradingBrandName = addslashes($worksheet->getCellByColumnAndRow(8, $row)->getValue());
			$FactoryBusinessOperationAddress = addslashes($worksheet->getCellByColumnAndRow(9, $row)->getValue());
			$District = addslashes($worksheet->getCellByColumnAndRow(10, $row)->getValue());
			$PoliceStation = addslashes($worksheet->getCellByColumnAndRow(11, $row)->getValue());
 			$PostalCode = addslashes($worksheet->getCellByColumnAndRow(12, $row)->getValue());
			$LandPhoneNumber = addslashes($worksheet->getCellByColumnAndRow(13, $row)->getValue());
			$MobileNumber = addslashes($worksheet->getCellByColumnAndRow(14, $row)->getValue());
			$Email = addslashes($worksheet->getCellByColumnAndRow(15, $row)->getValue());
			$FaxNumber = addslashes($worksheet->getCellByColumnAndRow(16, $row)->getValue());
			$WebAddress = addslashes($worksheet->getCellByColumnAndRow(17, $row)->getValue());
			$RegisteredHQAddress = addslashes($worksheet->getCellByColumnAndRow(18, $row)->getValue());
			$RegisteredHQAddressOutsideBangladesh = addslashes($worksheet->getCellByColumnAndRow(19, $row)->getValue());
			$EquityInformation = addslashes($worksheet->getCellByColumnAndRow(20, $row)->getValue());
			$Turnoverinpast12MonthsPeriod = addslashes($worksheet->getCellByColumnAndRow(21, $row)->getValue());
			$ProjectedTurnoverinnext12MonthsPeriod = addslashes($worksheet->getCellByColumnAndRow(22, $row)->getValue());
			$WithholdingEntity = addslashes($worksheet->getCellByColumnAndRow(23, $row)->getValue());
			$TypeofOwnership = addslashes($worksheet->getCellByColumnAndRow(24, $row)->getValue());
			$ForcedRegistration = addslashes($worksheet->getCellByColumnAndRow(25, $row)->getValue());
			$EffectiveDateofRegistration = addslashes($worksheet->getCellByColumnAndRow(26, $row)->getValue());
 			$RegistrationCategory = addslashes($worksheet->getCellByColumnAndRow(27, $row)->getValue());
			$Old11_digitBIN = addslashes($worksheet->getCellByColumnAndRow(28, $row)->getValue());
			$MajorAreaofEconomicActivity = addslashes($worksheet->getCellByColumnAndRow(29, $row)->getValue());
			$AreasofManufacturing = addslashes($worksheet->getCellByColumnAndRow(30, $row)->getValue());
			$AreasofService = addslashes($worksheet->getCellByColumnAndRow(31, $row)->getValue());
			$BINStatus = addslashes($worksheet->getCellByColumnAndRow(32, $row)->getValue());
 			$TradeLicense = addslashes($worksheet->getCellByColumnAndRow(33, $row)->getValue());
			$TradeLicenseIssueDate = addslashes($worksheet->getCellByColumnAndRow(34, $row)->getValue());
			$RJSCIncorporationNumber = addslashes($worksheet->getCellByColumnAndRow(35, $row)->getValue());
			$RJSCIncorporationNumberIssueDate = addslashes($worksheet->getCellByColumnAndRow(36, $row)->getValue());
			$BIDARegistrationNumber = addslashes($worksheet->getCellByColumnAndRow(37, $row)->getValue());
			$BIDARegistrationNumberIssueDate = addslashes($worksheet->getCellByColumnAndRow(38, $row)->getValue());
			$IRCNumber = addslashes($worksheet->getCellByColumnAndRow(39, $row)->getValue());
			$IRCNumberIssueDate = addslashes($worksheet->getCellByColumnAndRow(40, $row)->getValue());
			$ERCNumber = addslashes($worksheet->getCellByColumnAndRow(41, $row)->getValue());
			$ERCNumberIssueDate = addslashes($worksheet->getCellByColumnAndRow(42, $row)->getValue());

			//var_dump($DateTime);

			if($eTIN>0){
				if(!in_array($eTIN, $eIds)){
					$eIds[] = $eTIN;
				}
				if(!in_array($eTIN, $employeeArray)){
					$employeeArray[] = $eTIN;
					
					$insertid  = mysqli_query($conn, "INSERT INTO employeemi SET `eTIN`='$eTIN', `BINIssueDate`='$BINIssueDate', `Commissionerate`='$Commissionerate',
					 `Division`='$Division', `Circle`='$Circle', `BIN`='$BIN', `Name`='$Name', `ResidencyStatus`='$ResidencyStatus',
					 `TradingBrandName`='$TradingBrandName', `FactoryBusinessOperationAddress`='$FactoryBusinessOperationAddress', `District`='$District',  
					`PoliceStation`='$PoliceStation', `PostalCode`='$PostalCode', `LandPhoneNumber`='$LandPhoneNumber', 
					`MobileNumber`='$MobileNumber', `Email`='$Email', `FaxNumber`='$FaxNumber', `WebAddress`='$WebAddress', 
					`RegisteredHQAddress`='$RegisteredHQAddress', `RegisteredHQAddressOutsideBangladesh`='$RegisteredHQAddressOutsideBangladesh',
					 `EquityInformation`='$EquityInformation', `Turnoverinpast12MonthsPeriod`='$Turnoverinpast12MonthsPeriod', 
					 `ProjectedTurnoverinnext12MonthsPeriod`='$ProjectedTurnoverinnext12MonthsPeriod', `WithholdingEntity`='$WithholdingEntity', 
					 `TypeofOwnership`='$TypeofOwnership', `ForcedRegistration`='$ForcedRegistration', `EffectiveDateofRegistration`='$EffectiveDateofRegistration',
					  `RegistrationCategory`='$RegistrationCategory', `Old11_digitBIN`='$Old11_digitBIN', `MajorAreaofEconomicActivity`='$MajorAreaofEconomicActivity', 
					  `AreasofManufacturing`='$AreasofManufacturing', `AreasofService`='$AreasofService', `BINStatus`='$BINStatus', 
					  `TradeLicense`='$TradeLicense', `TradeLicenseIssueDate`='$TradeLicenseIssueDate', `RJSCIncorporationNumber`='$RJSCIncorporationNumber', 
					  `RJSCIncorporationNumberIssueDate`='$RJSCIncorporationNumberIssueDate', `BIDARegistrationNumber`='$BIDARegistrationNumber', 
					  `BIDARegistrationNumberIssueDate`='$BIDARegistrationNumberIssueDate', `IRCNumber`='$IRCNumber', `IRCNumberIssueDate`='$IRCNumberIssueDate',
					  `ERCNumber`='$ERCNumber', `ERCNumberIssueDate`='$ERCNumberIssueDate'");
					if($insertid){
						$entry++;
					}
					$empInsert++;
				}
				
				//$date = date('Y-m-d', strtotime($DateTime));
				//$time = date('H:i:s', strtotime($DateTime));
				$xlsData[] = array(
					'eTIN'=>$eTIN,
					'BINIssueDate'=>$BINIssueDate,
					'Commissionerate'=>$Commissionerate,
					'Division'=>$Division,
 					'Circle'=>$Circle,
					'BIN'=>$BIN,
					'Name'=>$Name,
					'ResidencyStatus'=>$ResidencyStatus,
					'TradingBrandName'=>$TradingBrandName,
					'FactoryBusinessOperationAddress'=>$FactoryBusinessOperationAddress,
					'District'=>$District,
					'PoliceStation'=>$PoliceStation,
					'PostalCode'=>$PostalCode,
					'LandPhoneNumber'=>$LandPhoneNumber,
					'MobileNumber'=>$MobileNumber,
					'Email'=>$Email,
					'FaxNumber'=>$FaxNumber,
					'WebAddress'=>$WebAddress,
					'RegisteredHQAddress'=>$RegisteredHQAddress,
					'RegisteredHQAddressOutsideBangladesh'=>$RegisteredHQAddressOutsideBangladesh,
					'EquityInformation'=>$EquityInformation,
					'Turnoverinpast12MonthsPeriod'=>$Turnoverinpast12MonthsPeriod,
					'ProjectedTurnoverinnext12MonthsPeriod'=>$ProjectedTurnoverinnext12MonthsPeriod,
					'WithholdingEntity'=>$WithholdingEntity,

					'TypeofOwnership'=>$TypeofOwnership,
					'ForcedRegistration'=>$ForcedRegistration,
					'EffectiveDateofRegistration'=>$EffectiveDateofRegistration,
					'RegistrationCategory'=>$RegistrationCategory,
					'Old11_digitBIN'=>$Old11_digitBIN,
					'MajorAreaofEconomicActivity'=>$MajorAreaofEconomicActivity,
					'AreasofManufacturing'=>$AreasofManufacturing,
					'AreasofService'=>$AreasofService,
					'BINStatus'=>$BINStatus,
					'TradeLicense'=>$TradeLicense,
					'TradeLicenseIssueDate'=>$TradeLicenseIssueDate,
					'RJSCIncorporationNumber'=>$RJSCIncorporationNumber,
					'RJSCIncorporationNumberIssueDate'=>$RJSCIncorporationNumberIssueDate,
					'BIDARegistrationNumber'=>$BIDARegistrationNumber,
					'BIDARegistrationNumberIssueDate'=>$BIDARegistrationNumberIssueDate,
					'IRCNumber'=>$IRCNumber,
					'IRCNumberIssueDate'=>$IRCNumberIssueDate,
					'ERCNumber'=>$ERCNumber,
					'ERCNumberIssueDate'=>$ERCNumberIssueDate);
			}
		}
	}
	//print_r($xlsData);
	$dptData = 0;
	
	
	$message = "<p>Total $dptData Duplicate found and $entry saved</p>";
	if($empInsert>0){
		//$message .= "<br>Total $empInsert employee added. Please work on employee setting first then update new Employee information.";
	}
}
?>
<header class="header_tittle">
    <h3>IBUS Import Information</h3>
</header>

<form action="index.php?p=employenameentrynbr" enctype="multipart/form-data" onSubmit="return checkFile();" method="post" accept-charset="utf-8">
    <table cellpadding="5" cellspacing="0" width="100%">
    	<?php
        if($message !=''){
			echo $message;
		}
		?>
        <tr>
        	<td width="200">
            	<label>IBUS Import File*:</label>
            </td>
            <td>
            	<input required class="bordernone" type="file" name="attendance_file" id="attendance_file" accept=".xls,.xlsx" />
      			<span class="errormsg" id="errmsg_attendance_file"></span>
            </td>
        </tr>
        <tr>
        	<td width="200">&nbsp;</td>
            <td>
            	<input type="submit" name="btnAttUpload" id="btnAttUpload" class="btn btn-primary backlink" value=" Upload and View " />
		        <input type="button" onClick="resetform();" value="Cancel" class="hidediv btn btn-warning mleft10" />
            </td>
        </tr>
    </table>
</form>

<script type="text/javascript">
    function checkFile(){
        var elementmessage = document.getElementById('errmsg_attendance_file');
        elementmessage.innerHTML = '';
        
        var ext = $('#attendance_file').val().split('.').pop().toLowerCase();
        var allow = new Array('xls','xlsx');
        if(jQuery.inArray(ext, allow) == -1) {
            elementmessage.innerHTML = 'File type is invalid. Only <strong>.xls/.xlsx</strong> file types are allowed.';
            $('#attendance_file').focus();
			
			return false;
        }
        return true;
    }

    function resetform(){
        document.frmImportCustomers.instance_id.value = 0;
        $('#attendance_file').val('');
        $("#formtitle").html('Attendance Import Information');
        $("#btnAttUpload").val(' Upload and View ');                                                
    }
</script>
<table align="left" width="100%" border="1" style="BORDER-COLLAPSE: collapse;" cellspacing="1" cellpadding="3">
  <tr>
    <td colspan="100%" bgcolor="#0033FF" align="center" style="color:#fff; border:1px solid #03F;">
         <strong>In-Out Information </strong>
    </td>
  </tr>
  <tr bgcolor="#ccc" align="center">
    <td>ID</td>
    <td>Name</td>
    <td>In Time</td>
    <td>Out Time</td>
  </tr>
</table>