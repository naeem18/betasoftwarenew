<?php
/*
|--------------------------------------------------------------------------
| HOSPITAL ERP - DEMO DASHBOARD
|--------------------------------------------------------------------------
| Non-functional demo dashboard
| No database connection
| No INSERT / UPDATE / DELETE
| No real calculation
|--------------------------------------------------------------------------
*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Hospital ERP - Dashboard</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

:root{
    --primary:#2563eb;
    --primary-dark:#1d4ed8;
    --sidebar:#0f172a;
    --sidebar2:#111c34;
    --body:#f4f7fb;
    --white:#ffffff;
    --text:#172033;
    --muted:#718096;
    --border:#e7ebf2;
    --green:#10b981;
    --orange:#f59e0b;
    --red:#ef4444;
    --purple:#8b5cf6;
    --cyan:#06b6d4;
    --shadow:0 4px 20px rgba(15,23,42,.06);
}

body{
    font-family:Arial, Helvetica, sans-serif;
    background:var(--body);
    color:var(--text);
}

/* =========================
   LAYOUT
========================= */

.app{
    display:flex;
    min-height:100vh;
}

/* =========================
   SIDEBAR
========================= */

.sidebar{
    width:250px;
    background:linear-gradient(180deg,var(--sidebar),var(--sidebar2));
    color:#fff;
    position:fixed;
    top:0;
    left:0;
    bottom:0;
    z-index:1000;
    overflow-y:auto;
    transition:.3s;
}

.logo{
    height:76px;
    display:flex;
    align-items:center;
    padding:0 20px;
    border-bottom:1px solid rgba(255,255,255,.08);
}

.logo-icon{
    width:42px;
    height:42px;
    background:#2563eb;
    border-radius:12px;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:23px;
    margin-right:11px;
}

.logo-text strong{
    display:block;
    font-size:17px;
}

.logo-text span{
    display:block;
    font-size:10px;
    color:#94a3b8;
    margin-top:2px;
    letter-spacing:1px;
}

.menu-title{
    color:#64748b;
    font-size:10px;
    text-transform:uppercase;
    padding:20px 20px 8px;
    letter-spacing:1.2px;
}

.menu{
    list-style:none;
    padding:0 10px;
}

.menu li{
    margin-bottom:3px;
}

.menu a{
    display:flex;
    align-items:center;
    gap:13px;
    padding:11px 13px;
    border-radius:9px;
    color:#cbd5e1;
    text-decoration:none;
    font-size:13px;
    transition:.2s;
}

.menu a:hover,
.menu a.active{
    background:rgba(37,99,235,.20);
    color:#fff;
}

.menu-icon{
    width:22px;
    text-align:center;
    font-size:16px;
}

.menu-arrow{
    margin-left:auto;
    color:#64748b;
    font-size:11px;
}

.sidebar-bottom{
    position:absolute;
    bottom:20px;
    left:15px;
    right:15px;
}

.user-mini{
    background:rgba(255,255,255,.06);
    padding:10px;
    border-radius:10px;
    display:flex;
    align-items:center;
}

.user-avatar{
    width:36px;
    height:36px;
    border-radius:50%;
    background:#2563eb;
    display:flex;
    align-items:center;
    justify-content:center;
    margin-right:10px;
    font-size:14px;
}

.user-info strong{
    display:block;
    font-size:12px;
}

.user-info span{
    color:#94a3b8;
    font-size:10px;
}

/* =========================
   MAIN
========================= */

.main{
    margin-left:250px;
    width:calc(100% - 250px);
}

/* =========================
   TOPBAR
========================= */

.topbar{
    height:76px;
    background:#fff;
    border-bottom:1px solid var(--border);
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding:0 28px;
    position:sticky;
    top:0;
    z-index:500;
}

.left-top{
    display:flex;
    align-items:center;
}

.mobile-menu{
    display:none;
    font-size:23px;
    margin-right:15px;
    cursor:pointer;
}

.search-box{
    width:300px;
    height:40px;
    background:#f5f7fa;
    border:1px solid #edf0f5;
    border-radius:9px;
    display:flex;
    align-items:center;
    padding:0 13px;
}

.search-box span{
    color:#94a3b8;
    margin-right:8px;
}

.search-box input{
    border:0;
    outline:0;
    background:transparent;
    width:100%;
    font-size:12px;
}

.top-actions{
    display:flex;
    align-items:center;
    gap:12px;
}

.top-btn{
    width:38px;
    height:38px;
    border:1px solid var(--border);
    background:#fff;
    border-radius:9px;
    display:flex;
    align-items:center;
    justify-content:center;
    cursor:pointer;
    position:relative;
    font-size:16px;
}

.notification-dot{
    position:absolute;
    top:7px;
    right:7px;
    width:7px;
    height:7px;
    border-radius:50%;
    background:#ef4444;
    border:1px solid #fff;
}

.date-box{
    background:#f5f7fa;
    padding:9px 13px;
    border-radius:9px;
    font-size:11px;
    color:#64748b;
}

/* =========================
   CONTENT
========================= */

.content{
    padding:25px 28px 35px;
}

.welcome{
    display:flex;
    align-items:center;
    justify-content:space-between;
    margin-bottom:23px;
}

.welcome h1{
    font-size:23px;
    margin-bottom:6px;
}

.welcome p{
    color:var(--muted);
    font-size:12px;
}

.welcome-right{
    display:flex;
    gap:8px;
}

.btn{
    border:0;
    padding:10px 15px;
    border-radius:8px;
    font-size:11px;
    cursor:pointer;
}

.btn-primary{
    background:var(--primary);
    color:#fff;
}

.btn-light{
    background:#fff;
    color:#475569;
    border:1px solid var(--border);
}

/* =========================
   KPI CARDS
========================= */

.kpi-grid{
    display:grid;
    grid-template-columns:repeat(4,1fr);
    gap:16px;
    margin-bottom:20px;
}

.card{
    background:#fff;
    border:1px solid var(--border);
    border-radius:13px;
    box-shadow:var(--shadow);
}

.kpi-card{
    padding:18px;
    position:relative;
    overflow:hidden;
}

.kpi-top{
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.kpi-title{
    color:#64748b;
    font-size:11px;
    font-weight:600;
}

.kpi-icon{
    width:40px;
    height:40px;
    border-radius:10px;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:18px;
}

.icon-blue{
    background:#e8f0ff;
    color:#2563eb;
}

.icon-green{
    background:#e7faf3;
    color:#10b981;
}

.icon-orange{
    background:#fff5df;
    color:#f59e0b;
}

.icon-purple{
    background:#f2eafe;
    color:#8b5cf6;
}

.kpi-number{
    font-size:24px;
    font-weight:700;
    margin-top:12px;
}

.kpi-footer{
    display:flex;
    align-items:center;
    gap:7px;
    margin-top:7px;
    font-size:10px;
}

.up{
    color:#10b981;
    font-weight:bold;
}

.down{
    color:#ef4444;
    font-weight:bold;
}

.kpi-footer span:last-child{
    color:#94a3b8;
}

/* =========================
   GRID
========================= */

.grid-2-1{
    display:grid;
    grid-template-columns:2fr 1fr;
    gap:20px;
    margin-bottom:20px;
}

.grid-equal{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:20px;
    margin-bottom:20px;
}

.card-header{
    padding:17px 18px;
    border-bottom:1px solid var(--border);
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.card-header h3{
    font-size:13px;
}

.card-header span{
    font-size:10px;
    color:#94a3b8;
}

.card-body{
    padding:18px;
}

/* =========================
   CHART
========================= */

.chart-area{
    height:260px;
    position:relative;
    padding-left:30px;
    padding-bottom:25px;
}

.chart-grid{
    position:absolute;
    left:30px;
    right:5px;
    top:10px;
    bottom:30px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
}

.chart-line{
    border-top:1px dashed #e7ebf2;
    width:100%;
}

.chart-values{
    position:absolute;
    left:0;
    top:5px;
    bottom:25px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
    font-size:9px;
    color:#94a3b8;
}

.bars{
    position:absolute;
    left:40px;
    right:10px;
    bottom:30px;
    top:18px;
    display:flex;
    align-items:flex-end;
    justify-content:space-around;
}

.bar-group{
    height:100%;
    display:flex;
    align-items:flex-end;
    gap:3px;
    width:35px;
}

.bar{
    width:8px;
    border-radius:4px 4px 0 0;
}

.bar.one{
    background:#2563eb;
}

.bar.two{
    background:#93c5fd;
}

.months{
    position:absolute;
    left:40px;
    right:10px;
    bottom:3px;
    display:flex;
    justify-content:space-around;
    font-size:9px;
    color:#94a3b8;
}

/* =========================
   BED OCCUPANCY
========================= */

.bed-row{
    margin-bottom:17px;
}

.bed-title{
    display:flex;
    justify-content:space-between;
    margin-bottom:7px;
    font-size:11px;
}

.bed-title span:last-child{
    font-weight:bold;
}

.progress{
    width:100%;
    height:8px;
    background:#eef2f7;
    border-radius:20px;
    overflow:hidden;
}

.progress-bar{
    height:100%;
    border-radius:20px;
}

.blue{
    background:#2563eb;
}

.green{
    background:#10b981;
}

.orange{
    background:#f59e0b;
}

.red{
    background:#ef4444;
}

.purple{
    background:#8b5cf6;
}

.bed-summary{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:8px;
    margin-top:20px;
}

.bed-summary-item{
    background:#f8fafc;
    border-radius:9px;
    padding:11px;
    text-align:center;
}

.bed-summary-item strong{
    display:block;
    font-size:17px;
}

.bed-summary-item span{
    font-size:9px;
    color:#94a3b8;
}

/* =========================
   APPOINTMENTS
========================= */

.appointment{
    display:flex;
    align-items:center;
    padding:11px 0;
    border-bottom:1px solid #f0f2f6;
}

.appointment:last-child{
    border-bottom:0;
}

.time{
    width:60px;
    font-size:10px;
    color:#64748b;
    font-weight:bold;
}

.doctor-avatar{
    width:34px;
    height:34px;
    border-radius:50%;
    background:#e8f0ff;
    color:#2563eb;
    display:flex;
    align-items:center;
    justify-content:center;
    margin-right:10px;
    font-size:11px;
    font-weight:bold;
}

.appointment-info{
    flex:1;
}

.appointment-info strong{
    display:block;
    font-size:11px;
}

.appointment-info span{
    font-size:9px;
    color:#94a3b8;
}

.status{
    padding:5px 8px;
    border-radius:20px;
    font-size:8px;
    font-weight:bold;
}

.status-green{
    background:#e7faf3;
    color:#059669;
}

.status-orange{
    background:#fff5df;
    color:#d97706;
}

.status-blue{
    background:#e8f0ff;
    color:#2563eb;
}

/* =========================
   QUICK ACTION
========================= */

.quick-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:10px;
}

.quick-action{
    border:1px solid var(--border);
    border-radius:10px;
    padding:13px;
    cursor:pointer;
    transition:.2s;
    background:#fff;
}

.quick-action:hover{
    border-color:#bfdbfe;
    transform:translateY(-2px);
}

.quick-icon{
    width:34px;
    height:34px;
    border-radius:9px;
    display:flex;
    align-items:center;
    justify-content:center;
    margin-bottom:8px;
    font-size:15px;
}

.quick-action strong{
    font-size:10px;
    display:block;
}

.quick-action span{
    color:#94a3b8;
    font-size:8px;
}

/* =========================
   TABLE
========================= */

.table-wrap{
    overflow-x:auto;
}

table{
    width:100%;
    border-collapse:collapse;
}

th{
    background:#f8fafc;
    color:#64748b;
    font-size:9px;
    font-weight:600;
    text-align:left;
    padding:11px 12px;
    border-bottom:1px solid var(--border);
}

td{
    padding:12px;
    border-bottom:1px solid #f0f2f6;
    font-size:10px;
}

.patient{
    display:flex;
    align-items:center;
}

.patient-avatar{
    width:30px;
    height:30px;
    border-radius:50%;
    background:#eef2ff;
    color:#4f46e5;
    display:flex;
    align-items:center;
    justify-content:center;
    margin-right:8px;
    font-size:10px;
    font-weight:bold;
}

.patient-name strong{
    display:block;
    font-size:10px;
}

.patient-name span{
    color:#94a3b8;
    font-size:8px;
}

.department{
    color:#64748b;
}

/* =========================
   REVENUE
========================= */

.revenue-box{
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding:12px 0;
    border-bottom:1px solid #f0f2f6;
}

.revenue-box:last-child{
    border-bottom:0;
}

.revenue-left{
    display:flex;
    align-items:center;
}

.revenue-icon{
    width:34px;
    height:34px;
    border-radius:9px;
    display:flex;
    align-items:center;
    justify-content:center;
    margin-right:9px;
}

.revenue-left strong{
    display:block;
    font-size:10px;
}

.revenue-left span{
    color:#94a3b8;
    font-size:8px;
}

.revenue-amount{
    font-size:11px;
    font-weight:bold;
}

/* =========================
   DEPARTMENT
========================= */

.dept{
    display:flex;
    align-items:center;
    padding:10px 0;
    border-bottom:1px solid #f0f2f6;
}

.dept:last-child{
    border-bottom:0;
}

.dept-icon{
    width:35px;
    height:35px;
    border-radius:9px;
    display:flex;
    align-items:center;
    justify-content:center;
    margin-right:10px;
}

.dept-info{
    flex:1;
}

.dept-info strong{
    display:block;
    font-size:10px;
}

.dept-info span{
    color:#94a3b8;
    font-size:8px;
}

.dept-count{
    font-size:11px;
    font-weight:bold;
}

/* =========================
   EMERGENCY
========================= */

.emergency-box{
    background:linear-gradient(135deg,#fff1f2,#fff7f7);
    border:1px solid #fee2e2;
    border-radius:11px;
    padding:15px;
    margin-bottom:13px;
}

.emergency-header{
    display:flex;
    align-items:center;
    justify-content:space-between;
}

.emergency-title{
    display:flex;
    align-items:center;
}

.pulse{
    width:10px;
    height:10px;
    border-radius:50%;
    background:#ef4444;
    margin-right:8px;
    box-shadow:0 0 0 5px rgba(239,68,68,.10);
}

.emergency-title strong{
    font-size:11px;
}

.emergency-number{
    font-size:23px;
    font-weight:bold;
    color:#dc2626;
    margin-top:9px;
}

.emergency-text{
    font-size:9px;
    color:#9f1239;
}

/* =========================
   FOOTER
========================= */

.footer{
    text-align:center;
    color:#94a3b8;
    font-size:9px;
    padding:5px 0 20px;
}

/* =========================
   RESPONSIVE
========================= */

@media(max-width:1100px){

    .kpi-grid{
        grid-template-columns:repeat(2,1fr);
    }

    .grid-2-1,
    .grid-equal{
        grid-template-columns:1fr;
    }
}

@media(max-width:850px){

    .sidebar{
        transform:translateX(-100%);
    }

    .sidebar.show{
        transform:translateX(0);
    }

    .main{
        margin-left:0;
        width:100%;
    }

    .mobile-menu{
        display:block;
    }

    .search-box{
        width:230px;
    }
}

@media(max-width:650px){

    .topbar{
        padding:0 14px;
    }

    .content{
        padding:18px 14px 25px;
    }

    .search-box{
        display:none;
    }

    .date-box{
        display:none;
    }

    .welcome{
        display:block;
    }

    .welcome-right{
        margin-top:12px;
    }

    .kpi-grid{
        grid-template-columns:1fr 1fr;
        gap:10px;
    }

    .kpi-card{
        padding:13px;
    }

    .kpi-number{
        font-size:20px;
    }

    .kpi-icon{
        width:34px;
        height:34px;
        font-size:15px;
    }
}

@media(max-width:450px){

    .kpi-grid{
        grid-template-columns:1fr;
    }

    .quick-grid{
        grid-template-columns:1fr 1fr;
    }

    .welcome h1{
        font-size:20px;
    }
}
</style>
</head>

<body>

<div class="app">

    <!-- ================= SIDEBAR ================= -->

    <aside class="sidebar" id="sidebar">

        <div class="logo">

            <div class="logo-icon">
                🏥
            </div>

            <div class="logo-text">
                <strong><?php echo $hospitaldata_name;?></strong>
                <span>MANAGEMENT SYSTEM</span>
            </div>

        </div>


        <div class="menu-title">Main Menu</div>

        <ul class="menu">

            <li>
                <a href="#" class="active">
                    <span class="menu-icon">▣</span>
                    Dashboard
                </a>
            </li>

            <li>
                <a href="#">
                    <span class="menu-icon">👤</span>
                    Patients
                    <span class="menu-arrow">›</span>
                </a>
            </li>

            <li>
                <a href="#">
                    <span class="menu-icon">👨‍⚕️</span>
                    Doctors
                    <span class="menu-arrow">›</span>
                </a>
            </li>

            <li>
                <a href="#">
                    <span class="menu-icon">📅</span>
                    Appointments
                    <span class="menu-arrow">›</span>
                </a>
            </li>

            <li>
                <a href="#">
                    <span class="menu-icon">🛏</span>
                    IPD / Admission
                    <span class="menu-arrow">›</span>
                </a>
            </li>

            <li>
                <a href="#">
                    <span class="menu-icon">🚑</span>
                    Emergency
                    <span class="menu-arrow">›</span>
                </a>
            </li>

            <div class="menu-title">Clinical</div>

            <li>
                <a href="#">
                    <span class="menu-icon">🧪</span>
                    Laboratory
                    <span class="menu-arrow">›</span>
                </a>
            </li>

            <li>
                <a href="#">
                    <span class="menu-icon">💊</span>
                    Pharmacy
                    <span class="menu-arrow">›</span>
                </a>
            </li>

            <li>
                <a href="#">
                    <span class="menu-icon">🩻</span>
                    Radiology
                    <span class="menu-arrow">›</span>
                </a>
            </li>

            <li>
                <a href="#">
                    <span class="menu-icon">🩺</span>
                    Operation Theatre
                    <span class="menu-arrow">›</span>
                </a>
            </li>

            <div class="menu-title">Management</div>

            <li>
                <a href="#">
                    <span class="menu-icon">💰</span>
                    Accounts
                    <span class="menu-arrow">›</span>
                </a>
            </li>

            <li>
                <a href="#">
                    <span class="menu-icon">📦</span>
                    Inventory
                    <span class="menu-arrow">›</span>
                </a>
            </li>

            <li>
                <a href="#">
                    <span class="menu-icon">👥</span>
                    HR & Payroll
                    <span class="menu-arrow">›</span>
                </a>
            </li>

            <li>
                <a href="#">
                    <span class="menu-icon">📊</span>

                    Reports
                    <span class="menu-arrow">›</span>
                </a>
            </li>

            <li>
                <a href="#">
                    <span class="menu-icon">⚙️</span>
                    Settings
                </a>
            </li>

        </ul>


        <div class="sidebar-bottom">

            <div class="user-mini">

                <div class="user-avatar">
                    AD
                </div>

                <div class="user-info">
                    <strong>Administrator</strong>
                    <span>Super Admin</span>
                </div>

            </div>

        </div>

    </aside>


    <!-- ================= MAIN ================= -->

    <main class="main">

        <!-- TOP BAR -->

        <header class="topbar">

            <div class="left-top">

                <div class="mobile-menu" onclick="toggleSidebar()">
                    ☰
                </div>

                <div class="search-box">

                    <span>⌕</span>

                    <input
                        type="text"
                        placeholder="Search patient, doctor, invoice..."
                    >

                </div>

            </div>


            <div class="top-actions">

                <div class="date-box">
                    📅 Monday, 10 August 2026
                </div>

                <div class="top-btn">
                    🔔
                    <span class="notification-dot"></span>
                </div>

                <div class="top-btn">
                    ⚙
                </div>

            </div>

        </header>


        <!-- CONTENT -->

        <section class="content">

            <!-- WELCOME -->

            <div class="welcome">

                <div>

                    <h1>Good Morning, Administrator 👋</h1>

                    <p>
                        Here's what's happening in your hospital today.
                    </p>

                </div>

                <div class="welcome-right">

                    <button class="btn btn-light">
                        📥 Export
                    </button>

                    <button class="btn btn-primary">
                        + New Patient
                    </button>

                </div>

            </div>


            <!-- KPI CARDS -->

            <div class="kpi-grid">

                <!-- PATIENTS -->

                <div class="card kpi-card">

                    <div class="kpi-top">

                        <div class="kpi-title">
                            TOTAL PATIENTS
                        </div>

                        <div class="kpi-icon icon-blue">
                            👥
                        </div>

                    </div>

                    <div class="kpi-number">
                        12,548
                    </div>

                    <div class="kpi-footer">
                        <span class="up">↑ 12.5%</span>
                        <span>vs last month</span>
                    </div>

                </div>


                <!-- OPD -->

                <div class="card kpi-card">

                    <div class="kpi-top">

                        <div class="kpi-title">
                            OPD TODAY
                        </div>

                        <div class="kpi-icon icon-green">
                            🩺
                        </div>

                    </div>

                    <div class="kpi-number">
                        386
                    </div>

                    <div class="kpi-footer">
                        <span class="up">↑ 8.2%</span>
                        <span>vs yesterday</span>
                    </div>

                </div>


                <!-- ADMISSION -->

                <div class="card kpi-card">

                    <div class="kpi-top">

                        <div class="kpi-title">
                            ADMISSIONS
                        </div>

                        <div class="kpi-icon icon-orange">
                            🛏
                        </div>

                    </div>

                    <div class="kpi-number">
                        42
                    </div>

                    <div class="kpi-footer">
                        <span class="up">↑ 4.1%</span>
                        <span>today</span>
                    </div>

                </div>


                <!-- REVENUE -->

                <div class="card kpi-card">

                    <div class="kpi-top">

                        <div class="kpi-title">
                            TODAY'S REVENUE
                        </div>

                        <div class="kpi-icon icon-purple">
                            ৳
                        </div>

                    </div>

                    <div class="kpi-number">
                        ৳ 8.45 L
                    </div>

                    <div class="kpi-footer">
                        <span class="up">↑ 14.8%</span>
                        <span>vs yesterday</span>
                    </div>

                </div>

            </div>


            <!-- CHART + BED -->

            <div class="grid-2-1">


                <!-- PATIENT CHART -->

                <div class="card">

                    <div class="card-header">

                        <h3>Patient Statistics</h3>

                        <span>Last 6 Months ▾</span>

                    </div>

                    <div class="card-body">

                        <div class="chart-area">

                            <div class="chart-grid">

                                <div class="chart-line"></div>
                                <div class="chart-line"></div>
                                <div class="chart-line"></div>
                                <div class="chart-line"></div>
                                <div class="chart-line"></div>

                            </div>


                            <div class="chart-values">

                                <span>600</span>
                                <span>450</span>
                                <span>300</span>
                                <span>150</span>
                                <span>0</span>

                            </div>


                            <div class="bars">

                                <div class="bar-group">
                                    <div class="bar one" style="height:45%;"></div>
                                    <div class="bar two" style="height:35%;"></div>
                                </div>

                                <div class="bar-group">
                                    <div class="bar one" style="height:55%;"></div>
                                    <div class="bar two" style="height:42%;"></div>
                                </div>

                                <div class="bar-group">
                                    <div class="bar one" style="height:65%;"></div>
                                    <div class="bar two" style="height:50%;"></div>
                                </div>

                                <div class="bar-group">
                                    <div class="bar one" style="height:72%;"></div>
                                    <div class="bar two" style="height:58%;"></div>
                                </div>

                                <div class="bar-group">
                                    <div class="bar one" style="height:82%;"></div>
                                    <div class="bar two" style="height:66%;"></div>
                                </div>

                                <div class="bar-group">
                                    <div class="bar one" style="height:92%;"></div>
                                    <div class="bar two" style="height:75%;"></div>
                                </div>

                            </div>


                            <div class="months">

                                <span>Mar</span>
                                <span>Apr</span>
                                <span>May</span>
                                <span>Jun</span>
                                <span>Jul</span>
                                <span>Aug</span>

                            </div>

                        </div>

                    </div>

                </div>


                <!-- BED OCCUPANCY -->

                <div class="card">

                    <div class="card-header">

                        <h3>Bed Occupancy</h3>

                        <span>Today</span>

                    </div>

                    <div class="card-body">


                        <div class="bed-row">

                            <div class="bed-title">
                                <span>General Ward</span>
                                <span>68%</span>
                            </div>

                            <div class="progress">
                                <div class="progress-bar blue"
                                     style="width:68%;"></div>
                            </div>

                        </div>


                        <div class="bed-row">

                            <div class="bed-title">
                                <span>ICU</span>
                                <span>82%</span>
                            </div>

                            <div class="progress">
                                <div class="progress-bar red"
                                     style="width:82%;"></div>
                            </div>

                        </div>


                        <div class="bed-row">

                            <div class="bed-title">
                                <span>Cabin</span>
                                <span>55%</span>
                            </div>

                            <div class="progress">
                                <div class="progress-bar green"
                                     style="width:55%;"></div>
                            </div>

                        </div>


                        <div class="bed-row">

                            <div class="bed-title">
                                <span>CCU</span>
                                <span>76%</span>
                            </div>

                            <div class="progress">
                                <div class="progress-bar purple"
                                     style="width:76%;"></div>
                            </div>

                        </div>


                        <div class="bed-row">

                            <div class="bed-title">
                                <span>Emergency</span>
                                <span>91%</span>
                            </div>

                            <div class="progress">
                                <div class="progress-bar orange"
                                     style="width:91%;"></div>
                            </div>

                        </div>


                        <div class="bed-summary">

                            <div class="bed-summary-item">
                                <strong>284</strong>
                                <span>Total Beds</span>
                            </div>

                            <div class="bed-summary-item">
                                <strong>218</strong>
                                <span>Occupied</span>
                            </div>

                            <div class="bed-summary-item">
                                <strong>66</strong>
                                <span>Available</span>
                            </div>

                        </div>

                    </div>

                </div>

            </div>


            <!-- APPOINTMENT + QUICK ACTION -->

            <div class="grid-equal">


                <!-- APPOINTMENTS -->

                <div class="card">

                    <div class="card-header">

                        <h3>Today's Appointments</h3>

                        <span>View All →</span>

                    </div>

                    <div class="card-body">

                        <div class="appointment">

                            <div class="time">
                                09:00 AM
                            </div>

                            <div class="doctor-avatar">
                                AR
                            </div>

                            <div class="appointment-info">

                                <strong>
                                    Dr. Ahmed Rahman
                                </strong>

                                <span>
                                    Cardiology • Patient: Rahim
                                </span>

                            </div>

                            <span class="status status-green">
                                Completed
                            </span>

                        </div>


                        <div class="appointment">

                            <div class="time">
                                10:30 AM
                            </div>

                            <div class="doctor-avatar">
                                KA
                            </div>

                            <div class="appointment-info">

                                <strong>
                                    Dr. Karim Ahmed
                                </strong>

                                <span>
                                    Medicine • Patient: Sumaiya
                                </span>

                            </div>

                            <span class="status status-orange">
                                Waiting
                            </span>

                        </div>


                        <div class="appointment">

                            <div class="time">
                                11:15 AM
                            </div>

                            <div class="doctor-avatar">
                                HS
                            </div>

                            <div class="appointment-info">

                                <strong>
                                    Dr. Hasan Shah
                                </strong>

                                <span>
                                    Surgery • Patient: Mamun
                                </span>

                            </div>

                            <span class="status status-blue">
                                Confirmed
                            </span>

                        </div>


                        <div class="appointment">

                            <div class="time">
                                12:30 PM
                            </div>

                            <div class="doctor-avatar">
                                NK
                            </div>

                            <div class="appointment-info">

                                <strong>
                                    Dr. Nazmul Khan
                                </strong>

                                <span>
                                    ENT • Patient: Jannat
                                </span>

                            </div>

                            <span class="status status-blue">
                                Confirmed
                            </span>

                        </div>

                    </div>

                </div>


                <!-- QUICK ACTIONS -->

                <div class="card">

                    <div class="card-header">

                        <h3>Quick Actions</h3>

                        <span>Shortcuts</span>

                    </div>

                    <div class="card-body">

                        <div class="quick-grid">


                            <div class="quick-action">

                                <div class="quick-icon icon-blue">
                                    👤
                                </div>

                                <strong>New Patient</strong>

                                <span>Register patient</span>

                            </div>


                            <div class="quick-action">

                                <div class="quick-icon icon-green">
                                    📅
                                </div>

                                <strong>Appointment</strong>

                                <span>Book appointment</span>

                            </div>


                            <div class="quick-action">

                                <div class="quick-icon icon-orange">
                                    🛏
                                </div>

                                <strong>Admission</strong>

                                <span>Admit patient</span>

                            </div>


                            <div class="quick-action">

                                <div class="quick-icon icon-purple">
                                    🧪
                                </div>

                                <strong>Lab Invoice</strong>

                                <span>Create lab invoice</span>

                            </div>


                            <div class="quick-action">

                                <div class="quick-icon icon-green">
                                    💊
                                </div>

                                <strong>Pharmacy Sale</strong>

                                <span>New medicine sale</span>

                            </div>


                            <div class="quick-action">

                                <div class="quick-icon icon-orange">
                                    💰
                                </div>

                                <strong>Receive Payment</strong>

                                <span>Collect payment</span>

                            </div>


                        </div>

                    </div>

                </div>

            </div>


            <!-- RECENT PATIENTS -->

            <div class="card" style="margin-bottom:20px;">

                <div class="card-header">

                    <h3>Recent Patients</h3>

                    <span>View All →</span>

                </div>

                <div class="table-wrap">

                    <table>

                        <thead>

                            <tr>

                                <th>PATIENT</th>
                                <th>PATIENT ID</th>
                                <th>DOCTOR</th>
                                <th>DEPARTMENT</th>
                                <th>VISIT TYPE</th>
                                <th>STATUS</th>
                                <th>AMOUNT</th>

                            </tr>

                        </thead>

                        <tbody>


                            <tr>

                                <td>

                                    <div class="patient">

                                        <div class="patient-avatar">
                                            RH
                                        </div>

                                        <div class="patient-name">

                                            <strong>
                                                Rahim Uddin
                                            </strong>

                                            <span>
                                                Male • 42 Years
                                            </span>

                                        </div>

                                    </div>

                                </td>

                                <td>
                                    P-10245
                                </td>

                                <td>
                                    Dr. Ahmed
                                </td>

                                <td class="department">
                                    Cardiology
                                </td>

                                <td>
                                    OPD
                                </td>

                                <td>
                                    <span class="status status-green">
                                        Completed
                                    </span>
                                </td>

                                <td>
                                    ৳ 2,500
                                </td>

                            </tr>


                            <tr>

                                <td>

                                    <div class="patient">

                                        <div class="patient-avatar">
                                            KA
                                        </div>

                                        <div class="patient-name">

                                            <strong>
                                                Karim Ahmed
                                            </strong>

                                            <span>
                                                Male • 35 Years
                                            </span>

                                        </div>

                                    </div>

                                </td>

                                <td>
                                    P-10246
                                </td>

                                <td>
                                    Dr. Hasan
                                </td>

                                <td class="department">
                                    Medicine
                                </td>

                                <td>
                                    IPD
                                </td>

                                <td>
                                    <span class="status status-orange">
                                        Admitted
                                    </span>
                                </td>

                                <td>
                                    ৳ 8,750
                                </td>

                            </tr>


                            <tr>

                                <td>

                                    <div class="patient">

                                        <div class="patient-avatar">
                                            SJ
                                        </div>

                                        <div class="patient-name">

                                            <strong>
                                                Sumaiya Jahan
                                            </strong>

                                            <span>
                                                Female • 29 Years
                                            </span>

                                        </div>

                                    </div>

                                </td>

                                <td>
                                    P-10247
                                </td>

                                <td>
                                    Dr. Karim
                                </td>

                                <td class="department">
                                    Surgery
                                </td>

                                <td>
                                    OPD
                                </td>

                                <td>
                                    <span class="status status-blue">
                                        Waiting
                                    </span>
                                </td>

                                <td>
                                    ৳ 1,200
                                </td>

                            </tr>


                            <tr>

                                <td>

                                    <div class="patient">

                                        <div class="patient-avatar">
                                            MA
                                        </div>

                                        <div class="patient-name">

                                            <strong>
                                                Mamun Ali
                                            </strong>

                                            <span>
                                                Male • 51 Years
                                            </span>

                                        </div>

                                    </div>

                                </td>

                                <td>
                                    P-10248
                                </td>

                                <td>
                                    Dr. Nazmul
                                </td>

                                <td class="department">
                                    ENT
                                </td>

                                <td>
                                    Emergency
                                </td>

                                <td>
                                    <span class="status status-orange">
                                        Processing
                                    </span>
                                </td>

                                <td>
                                    ৳ 4,800
                                </td>

                            </tr>


                        </tbody>

                    </table>

                </div>

            </div>


            <!-- REVENUE + DEPARTMENT + EMERGENCY -->

            <div class="grid-2-1">


                <!-- REVENUE -->

                <div class="card">

                    <div class="card-header">

                        <h3>Revenue Summary</h3>

                        <span>Today</span>

                    </div>

                    <div class="card-body">


                        <div class="revenue-box">

                            <div class="revenue-left">

                                <div class="revenue-icon icon-blue">
                                    🩺
                                </div>

                                <div>

                                    <strong>OPD Revenue</strong>

                                    <span>386 patients</span>

                                </div>

                            </div>

                            <div class="revenue-amount">
                                ৳ 2,45,000
                            </div>

                        </div>


                        <div class="revenue-box">

                            <div class="revenue-left">

                                <div class="revenue-icon icon-green">
                                    🧪
                                </div>

                                <div>

                                    <strong>Laboratory</strong>

                                    <span>245 invoices</span>

                                </div>

                            </div>

                            <div class="revenue-amount">
                                ৳ 1,85,500
                            </div>

                        </div>


                        <div class="revenue-box">

                            <div class="revenue-left">

                                <div class="revenue-icon icon-orange">
                                    💊
                                </div>

                                <div>

                                    <strong>Pharmacy</strong>

                                    <span>318 sales</span>

                                </div>

                            </div>

                            <div class="revenue-amount">
                                ৳ 2,75,800
                            </div>

                        </div>


                        <div class="revenue-box">

                            <div class="revenue-left">

                                <div class="revenue-icon icon-purple">
                                    🛏
                                </div>

                                <div>

                                    <strong>IPD / Admission</strong>

                                    <span>42 admissions</span>

                                </div>

                            </div>

                            <div class="revenue-amount">
                                ৳ 1,48,700
                            </div>

                        </div>


                    </div>

                </div>


                <!-- DEPARTMENT -->

                <div class="card">

                    <div class="card-header">

                        <h3>Department Overview</h3>

                        <span>Today</span>

                    </div>

                    <div class="card-body">


                        <div class="dept">

                            <div class="dept-icon icon-blue">
                                ❤️
                            </div>

                            <div class="dept-info">

                                <strong>
                                    Cardiology
                                </strong>

                                <span>
                                    OPD & IPD
                                </span>

                            </div>

                            <div class="dept-count">
                                86
                            </div>

                        </div>


                        <div class="dept">

                            <div class="dept-icon icon-green">
                                🩺
                            </div>

                            <div class="dept-info">

                                <strong>
                                    Medicine
                                </strong>

                                <span>
                                    OPD & IPD
                                </span>

                            </div>

                            <div class="dept-count">
                                124
                            </div>

                        </div>


                        <div class="dept">

                            <div class="dept-icon icon-orange">
                                🧠
                            </div>

                            <div class="dept-info">

                                <strong>
                                    Neurology
                                </strong>

                                <span>
                                    OPD
                                </span>

                            </div>

                            <div class="dept-count">
                                58
                            </div>

                        </div>


                        <div class="dept">

                            <div class="dept-icon icon-purple">
                                🦴
                            </div>

                            <div class="dept-info">

                                <strong>
                                    Orthopedics
                                </strong>

                                <span>
                                    OPD & Surgery
                                </span>

                            </div>

                            <div class="dept-count">
                                67
                            </div>

                        </div>


                        <div class="dept">

                            <div class="dept-icon icon-blue">
                                👂
                            </div>

                            <div class="dept-info">

                                <strong>
                                    ENT
                                </strong>

                                <span>
                                    OPD
                                </span>

                            </div>

                            <div class="dept-count">
                                51
                            </div>

                        </div>


                    </div>

                </div>


                <!-- EMERGENCY -->

                <div class="card">

                    <div class="card-header">

                        <h3>Emergency Status</h3>

                        <span>Live Status</span>

                    </div>

                    <div class="card-body">

                        <div class="emergency-box">

                            <div class="emergency-header">

                                <div class="emergency-title">

                                    <span class="pulse"></span>

                                    <strong>
                                        Emergency Department
                                    </strong>

                                </div>

                                <span class="status status-orange">
                                    HIGH
                                </span>

                            </div>

                            <div class="emergency-number">
                                18
                            </div>

                            <div class="emergency-text">
                                Patients currently waiting
                            </div>

                        </div>


                        <div class="bed-row">

                            <div class="bed-title">
                                <span>Emergency Beds</span>
                                <span>91%</span>
                            </div>

                            <div class="progress">

                                <div
                                    class="progress-bar red"
                                    style="width:91%;"
                                ></div>

                            </div>

                        </div>


                        <div class="bed-row">

                            <div class="bed-title">
                                <span>Available Ambulances</span>
                                <span>4 / 8</span>
                            </div>

                            <div class="progress">

                                <div
                                    class="progress-bar green"
                                    style="width:50%;"
                                ></div>

                            </div>

                        </div>


                        <div class="bed-row">

                            <div class="bed-title">
                                <span>Doctors Available</span>
                                <span>7</span>
                            </div>

                            <div class="progress">

                                <div
                                    class="progress-bar blue"
                                    style="width:70%;"
                                ></div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>


            <!-- FOOTER -->

            <div class="footer">

                Hospital ERP Dashboard • Demo / Non-Functional UI • 2026

            </div>

        </section>

    </main>

</div>


<script>

function toggleSidebar(){

    var sidebar = document.getElementById("sidebar");

    if(sidebar.classList.contains("show")){

        sidebar.classList.remove("show");

    }else{

        sidebar.classList.add("show");

    }

}


/* Demo notification */

document.querySelectorAll(".quick-action").forEach(function(item){

    item.addEventListener("click", function(){

        alert("Demo Only - This feature is currently non-functional.");

    });

});


document.querySelectorAll(".btn").forEach(function(button){

    button.addEventListener("click", function(){

        if(this.innerText.indexOf("New Patient") !== -1){

            alert("Demo Only - New Patient module is not connected.");

        }

        if(this.innerText.indexOf("Export") !== -1){

            alert("Demo Only - Export is not connected.");

        }

    });

});

</script>

</body>
</html>