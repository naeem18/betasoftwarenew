<?php
$searchstr='';
if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
{
	$transactiondatefrom = $_REQUEST['ADate1'];
	$transactiondateto = $_REQUEST['ADate2'];
	
}
else
{
	$transactiondatefrom = date('Y-m-d', strtotime('-2 day'));
	$transactiondateto = date('Y-m-d');
}

$pcdata = array();
$sqlpc = "select doctor_name, mpo from doctorentry where doctor_category='pc' order by doctor_name asc";
$stqry1 = mysqli_query($conn, $sqlpc);
if($stqry1 && mysqli_num_rows($stqry1)>0){

	while ($strow = mysqli_fetch_array($stqry1)){
		//$doctor_id = $strow['doctor_id'];
		$doctor_name = $strow['doctor_name'];
		$mpo = $strow['mpo'];
		$pcdata[] =array( 'labelval' => $doctor_name,
							'label' => $doctor_name,
							'doctor_name'=>$doctor_name,
							'mpo'=>$mpo
							);
		}
	}
$pcdata = json_encode($pcdata);
?>
<link rel="stylesheet" href="autocomplete/jquery-ui.css">
<script src="autocomplete/jquery-ui.min.js"></script>
<script language="JavaScript" type="text/javascript">
	
	var pcdata = <?php echo $pcdata;?>;
   	$(document).ready(function($) {
 	$( "#appointmententry_pc" ).autocomplete({
 			minLength: 1,
			source: pcdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('appointmententry_pc').value = ui.item.labelval;
				 document.getElementById('appointmententry_mpo').value = ui.item.mpo;
				
				return false;
			}
		});
 	});
	
 </script>
<style>
.appointment-wrapper {
    width: 100%;
    max-width: 850px;
    margin: 20px auto;
    font-family: Arial, Helvetica, sans-serif;
}

.appointment-card {
    background: #ffffff;
    border: 1px solid #dfe5ec;
    border-radius: 10px;
    box-shadow: 0 4px 18px rgba(0,0,0,0.08);
    overflow: hidden;
}

.appointment-header {
    background: linear-gradient(135deg, #1769aa, #0d8abc);
    color: #fff;
    padding: 16px 22px;
    font-size: 20px;
    font-weight: bold;
}

.appointment-header small {
    display: block;
    font-size: 12px;
    font-weight: normal;
    opacity: .85;
    margin-top: 4px;
}

.appointment-body {
    padding: 20px 25px;
}

.appointment-table {
    width: 100%;
    border-collapse: collapse;
}

.appointment-table tr {
    border-bottom: 1px solid #f0f2f5;
}

.appointment-table tr:last-child {
    border-bottom: none;
}

.appointment-table td {
    padding: 9px 8px;
    vertical-align: middle;
}

.appointment-label {
    width: 30%;
    text-align: right;
    font-size: 14px;
    font-weight: 600;
    color: #374151;
    padding-right: 18px !important;
}

.appointment-input,
.appointment-table input[type="text"],
.appointment-table textarea,
.appointment-table select {
    box-sizing: border-box;
    width: 100%;
    max-width: 500px;
    min-height: 36px;
    border: 1px solid #cfd7e3;
    border-radius: 5px;
    background: #fff;
    padding: 7px 10px;
    font-size: 14px;
    color: #333;
    outline: none;
    transition: all .2s ease;
}

.appointment-table textarea {
    min-height: 70px;
    resize: vertical;
}

.appointment-table input:focus,
.appointment-table select:focus,
.appointment-table textarea:focus {
    border-color: #168ac5;
    box-shadow: 0 0 0 3px rgba(22,138,197,.12);
}

.appointment-table input[required],
.appointment-table select[required] {
    background-color: #fff;
}

.required-star {
    color: #e53935;
    font-weight: bold;
}

.appointment-age-row {
    display: flex;
    gap: 7px;
    max-width: 500px;
}

.appointment-age-row input {
    width: 55% !important;
}

.appointment-age-row select {
    width: 45% !important;
}

.appointment-actions {
    text-align: center;
    padding-top: 18px !important;
}

.btn-save,
.btn-cancel {
    border: none;
    border-radius: 5px;
    padding: 9px 22px;
    font-size: 14px;
    font-weight: bold;
    cursor: pointer;
    margin: 0 4px;
    transition: .2s;
}


.btn-save {
    background: #168ac5;
    color: #fff;
}

.btn-save:hover {
    background: #0d6f9f;
}

.btn-cancel {
    background: #e9edf2;
    color: #374151;
    text-decoration: none;
}

.btn-cancel:hover {
    background: #d9dee5;
}

.message-success {
    max-width: 850px;
    margin: 15px auto;
    padding: 12px 16px;
    border-radius: 6px;
    background: #e9f8ef;
    border: 1px solid #b7e4c7;
    color: #18723a;
    font-size: 14px;
    font-weight: bold;
}

.message-error {
    max-width: 850px;
    margin: 15px auto;
    padding: 12px 16px;
    border-radius: 6px;
    background: #fff0f0;
    border: 1px solid #f1b8b8;
    color: #c62828;
    font-size: 14px;
    font-weight: bold;
}

/* Mobile */
@media (max-width: 650px) {

    .appointment-wrapper {
        width: 96%;
        margin: 10px auto;
    }

    .appointment-body {
        padding: 15px 10px;
    }

    .appointment-table,
    .appointment-table tbody,
    .appointment-table tr,
    .appointment-table td {
        display: block;
        width: 100%;
        box-sizing: border-box;
    }

    .appointment-table tr {
        padding: 8px 0;
        border-bottom: none;
    }

    .appointment-label {
        width: 100%;
        text-align: left;
        padding: 5px 3px !important;
    }

    .appointment-table input[type="text"],
    .appointment-table textarea,
    .appointment-table select {
        max-width: 100%;
    }

    .appointment-age-row {
        max-width: 100%;
    }

    .appointment-age-row input,
    .appointment-age-row select {
        width: 50% !important;
    }

    .appointment-actions {
        text-align: center !important;
    }
}
</style>
 
        <?php
 			if(isset($_GET['message']) && $_GET['message']=='error-insert'){
				echo '<div class="message-error">
						Error occurred! Could not insert.
					  </div>';
			}
			elseif(isset($_GET['message']) && $_GET['message']=='save-successfully'){
				echo '<div class="message-success">
						Information inserted successfully.
					  </div>';
			}
		
		 $appointmententry_number  =1;
		 $appointmententry_id = 0;
		 $appointmententry_name = '';
		 $appointmententry_mobile = '';
		 $appointmententry_doctor = '';
		 $appointmententry_amount ='';
          if(isset($_GET['appointmententry_id'])){
          	$appointmententry_id = $_GET['appointmententry_id'];
            $appointmententry_sql = "select * from appointmententry where appointmententry_id = $appointmententry_id";
            $appointmententryquery = mysqli_query($conn, $appointmententry_sql);
            if($appointmententryquery && mysqli_num_rows($appointmententryquery)>0){
                while($page_inforow = mysqli_fetch_array($appointmententryquery)){
                   $appointmententry_id = $page_inforow['appointmententry_id'];
                    $appointmententry_name = $page_inforow['appointmententry_name'];
					$user = $page_inforow['user'];
                    $age = $page_inforow['age'];
                    $apccomission = $page_inforow['apccomission'];
                    $appointmententry_mobile = $page_inforow['appointmententry_mobile'];
					$appointmententry_age= $page_inforow['appointmententry_age'];
					$appointmententry_gender= $page_inforow['appointmententry_gender'];
					$appointmententry_doctor = $page_inforow['appointmententry_doctor'];
                    $appointmententry_pc = $page_inforow['appointmententry_pc'];
                    $appointmententry_mpo = $page_inforow['appointmententry_mpo'];
                    $appointmententry_date = $page_inforow['appointmententry_date'];
					$appointmententry_update = $page_inforow['appointmententry_update'];
					$appointmententry_time = $page_inforow['appointmententry_time'];
					$appointmententry_amount = $page_inforow['appointmententry_amount'];
					$appointmententry_address = $page_inforow['appointmententry_address'];
					$appointmententry_pcategory  = $page_inforow['appointmententry_pcategory'];
					$appointmententry_number  = $page_inforow['appointmententry_number'];
                 }
            }
        }
        ?> 
    <div class="appointment-wrapper">

    <div class="appointment-card">

        <div class="appointment-header">
            Appointment Entry
            <small>Patient appointment information</small>
        </div>

        <div class="appointment-body">
               
 <form action="save_appointmententry.php" name="frmcontact" onsubmit="return checkcontactform();" method="post" enctype="multipart/form-data">

<table class="appointment-table">

                <tr>
                    <td class="appointment-label">
                        Appointment Date
                    </td>

                    <td>
                        <input type="text"
                               name="ADate1"
                               id="ADate1"
                               value="<?php echo $appointmententry_date;?>"
                               class="tdclass">

                        <img src="images/cal.gif"
                             onClick="javascript:NewCssCal('ADate1')"
                             style="cursor:pointer; vertical-align:middle;">
                    </td>
                </tr>


                <tr>
                    <td class="appointment-label">
                        Appointment Number
                    </td>

                    <td>
                        <input type="text"
                               name="appointmententry_number"
                               id="appointmententry_number"
                               value="<?php echo $appointmententry_number;?>"
                               class="tdclass">
                    </td>
                </tr>


                <tr>
                    <td class="appointment-label">
                        Appointment Time
                    </td>

                    <td>
                        <input type="text"
                               name="appointmententry_time"
                               id="appointmententry_time"
                               value="<?php echo $appointmententry_time;?>"
                               class="tdclass">
                    </td>
                </tr>


                <tr>
                    <td class="appointment-label">
                        Patient Name <span class="required-star">*</span>
                    </td>

                    <td>
                        <input type="text"
                               required
                               name="appointmententry_name"
                               id="appointmententry_name"
                               value="<?php echo $appointmententry_name;?>"
                               class="tdclass">
                    </td>
                </tr>


                <tr>
                    <td class="appointment-label">
                        Age <span class="required-star">*</span>
                    </td>

                    <td>
                        <div class="appointment-age-row">

                            <input type="text"
                                   required
                                   name="appointmententry_age"
                                   id="appointmententry_age"
                                   value="<?php echo $appointmententry_age;?>"
                                   class="tdclass">

                            <select required
                                    id="age"
                                    name="age"
                                    class="tdclass">

                                <option value="<?php echo $age;?>">
                                    <?php echo $age;?>
                                </option>

                                <option value="Day">Day</option>
                                <option value="Days">Days</option>
                                <option value="Month">Month</option>
                                <option value="Months">Months</option>
                                <option value="Year">Year</option>
                                <option value="Years">Years</option>

                            </select>

                        </div>
                    </td>
                </tr>


                <tr>
                    <td class="appointment-label">
                        Gender <span class="required-star">*</span>
                    </td>

                    <td>
                        <select required
                                id="appointmententry_gender"
                                name="appointmententry_gender"
                                class="tdclass">

                            <option value="<?php echo $appointmententry_gender;?>">
                                <?php echo $appointmententry_gender;?>
                            </option>

                            <option value="Female">Female</option>
                            <option value="Male">Male</option>
                            <option value="Other">Other</option>

                        </select>
                    </td>
                </tr>


                <tr>
                    <td class="appointment-label">
                        Mobile Number <span class="required-star">*</span>
                    </td>

                    <td>
                        <input type="text"
                               required
                               name="appointmententry_mobile"
                               id="appointmententry_mobile"
                               value="<?php echo $appointmententry_mobile;?>"
                               class="tdclass">
                    </td>
                </tr>


                <tr>
                    <td class="appointment-label">
                        Address
                    </td>

                    <td>
                        <textarea
                            name="appointmententry_address"
                            id="appointmententry_address"
                            class="tdclass"><?php echo $appointmententry_address;?></textarea>
                    </td>
                </tr>


                <tr>
                    <td class="appointment-label">
                        Patient Category
                    </td>

                    <td>
                        <select
                            id="appointmententry_pcategory"
                            name="appointmententry_pcategory"
                            class="tdclass">

                            <option value="<?php echo $appointmententry_pcategory;?>">
                                <?php echo $appointmententry_pcategory;?>
                            </option>

                            <option value="New">New</option>
                            <option value="Old">Old</option>
                            <option value="Report">Report</option>

                        </select>
                    </td>
                </tr>


                <tr>
                    <td class="appointment-label">
                        Paid Amount
                    </td>

                    <td>
                        <input type="text"
                               name="appointmententry_amount"
                               id="appointmententry_amount"
                               value="<?php echo $appointmententry_amount;?>"
                               class="tdclass">
                    </td>
                </tr>


                <tr>
                    <td class="appointment-label">
                        Consulting Doctor
                    </td>

                    <td>

                        <select
                            id="appointmententry_doctor"
                            name="appointmententry_doctor"
                            class="tdclass">

                            <option value="<?php echo $appointmententry_doctor;?>">
                                <?php echo $appointmententry_doctor;?>
                            </option>

                            <?php
                            $query5 = "select * from doctorentry
                                       where doctor_category='doctor'
                                       order by doctor_name";

                            $exec5 = mysqli_query($conn, $query5);

                            while($res5 = mysqli_fetch_array($exec5))
                            {
                                $res5doctorname = trim($res5["doctor_name"]);
                                $res5doctorcode = $res5["doctor_id"];

                                if($res5doctorname !='')
                                {
                            ?>

                            <option value="<?php echo $res5doctorname;?>">
                                <?php echo $res5doctorname;?>
                            </option>

                            <?php
                                }
                            }
                            ?>

                        </select>

                    </td>
                </tr>


                <tr>
                    <td class="appointment-label">
                        RF/PC Commission
                    </td>

                    <td>
                        <input type="text"
                               name="apccomission"
                               id="apccomission"
                               value="<?php echo $apccomission;?>"
                               class="tdclass">
                    </td>
                </tr>


                <tr>
                    <td class="appointment-label">
                        PC
                    </td>

                    <td>
                        <input type="text"
                               name="appointmententry_pc"
                               id="appointmententry_pc"
                               value="<?php echo $appointmententry_pc;?>"
                               class="tdclass">
                    </td>
                </tr>


                <tr>
                    <td class="appointment-label">
                        MPO
                    </td>

                    <td>
                        <input type="text"
                               name="appointmententry_mpo"
                               id="appointmententry_mpo"
                               value="<?php echo $appointmententry_mpo;?>"
                               class="tdclass">
                    </td>
                </tr>


                <tr>
                    <td></td>

                    <td class="appointment-actions">

                        <input type="hidden"
                               name="appointmententry_id"
                               id="appointmententry_id"
                               value="<?php echo $appointmententry_id;?>">

                        <input type="submit"
                               value="Save"
                               name="submit_invoice"
                               id="submit_invoice"
                               class="btn-save">

                        <a href="index.php?p=appointmententry"
                           class="btn-cancel">
                           Cancel
                        </a>

                    </td>
                </tr>

            </table>
</form>         
		</div>
    </div>

</div>



<div id="divToPrint" style="display:none;">
 <article class="bottomcontent" style="margin:0 auto;">
    <content>

		  <?php
		   if(isset($_GET['appointmententry_id'])){
          	$appointmententry_id = $_GET['appointmententry_id'];
            $appointmententry_sql = "select * from appointmententry where appointmententry_id = $appointmententry_id";
            $appointmententryquery = mysqli_query($conn, $appointmententry_sql);
            if($appointmententryquery && mysqli_num_rows($appointmententryquery)>0){
                while($page_inforow = mysqli_fetch_array($appointmententryquery)){
                   $appointmententry_id = $page_inforow['appointmententry_id'];
                    $appointmententry_name = $page_inforow['appointmententry_name'];
                    $appointmententry_mobile = $page_inforow['appointmententry_mobile'];
					$user = $page_inforow['user'];
                    $appointmententry_doctor = $page_inforow['appointmententry_doctor'];
                     $appointmententry_time = $page_inforow['appointmententry_time'];
                   $appointmententry_date = $page_inforow['appointmententry_date'];
				
		 	 ?>        
               <table width="240" align="center"  style="border:1px solid #000;padding:0 10px; font-size:12px; "  bgcolor="#FFF" cellpadding="0">
                <tr>
                    <td width="240">
                        <div align="left" style="font-size:14px">[Tocken of  Serial]</div>
                        <div align="left" style="font-size:14px"><strong><?php echo $hospitaldata_name;?></strong></div>
                        <div align="left"> <?php echo $hospitaldata_address1;?></div>
                   		<div align="left">Date:&emsp;<?php  echo $appointmententry_date ;?></div>
                    </td>
                    
                 </tr>
            </table>
            <table width="240" align="center" style="border:1px solid #000;font-size:12px; padding:0 10px; margin-top:2px" bgcolor="#FFF" cellpadding="0">
                <tr>
                    <td width="240">
                        <div align="left"><strong>Serial No.:&emsp;<?php echo $appointmententry_id;?></strong></div>
                        <div align="left">Paitnt Name:&emsp;<?php echo $appointmententry_name;?></div>
                        <div align="left">Mobile:&emsp;<?php echo $appointmententry_mobile;?></div>
                        <div align="left">Consultant.:&emsp;<?php echo $appointmententry_doctor;?></div>
                     </td>
                 </tr>
            </table>
                    
        
        	<table width="240" align="center" style=" font-size:12px; padding:12px 1px" bgcolor="#FFF" cellpadding="0">
                 <tr>
                    <td width="200">
                        <div>Prepared By:&emsp;<?php echo $user; ?></div>
                    </td>
                    
                 </tr>
                 
            </table>
           
             <table align="center" width="240" border="0">
            	<tr>
                <td width="240" style=" font-size:11px">Software by: Betasofts.com (01757 827474)</td>
              </tr>
            </table>
		  <?php
                }
            }
          }
          ?>
                      
    </content>
</article>
</div>