<?php
// Database connection
//$conn = mysqli_connect("localhost", "username", "password", "database");

// Date handling
$fromdate = isset($_REQUEST['ADate1']) ? $_REQUEST['ADate1'] : date('Y-m-d');
$todate = isset($_REQUEST['ADate2']) ? $_REQUEST['ADate2'] : date('Y-m-d');

// Initialize employee shift days count
$employee_shift_days = array();

// Get all dates in range
$dates = array();
$current = strtotime($fromdate);
$end = strtotime($todate);
while($current <= $end) {
    $dates[] = date('Y-m-d', $current);
    $current = strtotime('+1 day', $current);
}

// Process each day
foreach ($dates as $date) {
    // Check 8-4 shift
    $result = mysqli_query($conn, "SELECT e.e_id, e.name FROM machine_data md 
              JOIN employee e ON md.e_id = e.e_id 
              WHERE md.entry_time BETWEEN '$date 08:00:00' AND '$date 08:59:59' 
              AND md.in_out=1");
    while ($row = mysqli_fetch_array($result)) {
        $e_id = $row['e_id'];
        if (!isset($employee_shift_days[$e_id])) {
            $employee_shift_days[$e_id] = ['name' => $row['name'], '8_4' => 0, '9_5' => 0];
        }
        $employee_shift_days[$e_id]['8_4']++;
    }
    
    // Check 9-5 shift
    $result = mysqli_query($conn, "SELECT e.e_id, e.name FROM machine_data md 
              JOIN employee e ON md.e_id = e.e_id 
              WHERE md.entry_time BETWEEN '$date 09:00:00' AND '$date 09:59:59' 
              AND md.in_out=1");
    while ($row = mysqli_fetch_array($result)) {
        $e_id = $row['e_id'];
        if (!isset($employee_shift_days[$e_id])) {
            $employee_shift_days[$e_id] = ['name' => $row['name'], '8_4' => 0, '9_5' => 0];
        }
        $employee_shift_days[$e_id]['9_5']++;
    }
}

// Display results
echo "<h3>Employee Shift Days Count ($fromdate to $todate)</h3>";
echo "<table border='1' cellpadding='5'>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>8-4 Days</th>
            <th>9-5 Days</th>
            <th>Total Days</th>
        </tr>";

$total_8_4 = 0;
$total_9_5 = 0;

foreach ($employee_shift_days as $e_id => $data) {
    $total = $data['8_4'] + $data['9_5'];
    echo "<tr>
            <td>$e_id</td>
            <td>{$data['name']}</td>
            <td>{$data['8_4']}</td>
            <td>{$data['9_5']}</td>
            <td>$total</td>
          </tr>";
    $total_8_4 += $data['8_4'];
    $total_9_5 += $data['9_5'];
}

echo "<tr>
        <td colspan='2'><strong>Total</strong></td>
        <td><strong>$total_8_4</strong></td>
        <td><strong>$total_9_5</strong></td>
        <td><strong>".($total_8_4 + $total_9_5)."</strong></td>
      </tr>";
echo "</table>";
?>