 <?php
   echo "<p class=\"red12bold\">Information insert successfully. Click Print Button To Print or View Previous Bill <td align=\"center\" ><a onclick=\"PrintDiv();\"><input type=\"button\" name=\"user\" id=\"user\" required value=\"Print\" class=\"tdclass\"  /></a></td></p>";   
 ?>
  	  <article>
		  <?php
		   if(isset($_GET['appointmententry_id'])){
          	$appointmententry_id = $_GET['appointmententry_id'];
            $asql = "select * from appointmententry where appointmententry_id = $appointmententry_id";
            $aqry = mysqli_query($conn, $asql);
            if($aqry && mysqli_num_rows($aqry)>0){
                while($prow = mysqli_fetch_array($aqry)){
                   $appointmententry_id = $prow['appointmententry_id'];
                   $appointmententry_code = $prow['appointmententry_code'];
                    $appointmententry_name = $prow['appointmententry_name'];
                    $appointmententry_mobile = $prow['appointmententry_mobile'];
					$bar = $prow['bar'];
                    $uhid = $prow['uhid'];
                    $user = $prow['user'];
                    $day_serial = $prow['day_serial'];
                    $appointmententry_doctor = $prow['appointmententry_doctor'];
                    $appointmententry_time = $prow['appointmententry_time'];
                    $appointmententry_number = $prow['appointmententry_number'];
                    $appointmententry_date = $prow['appointmententry_date'];
				 	$appointmententry_amount = $prow['appointmententry_amount'];
					$appointmententry_pcategory = $prow['appointmententry_pcategory'];
 					$appointmententry_age = $prow['appointmententry_age'];
				 	$appointmententry_gender = $prow['appointmententry_gender'];
					
				/*$sqlst2 = "select * from opregistration where apid='$appointmententry_id'";
				$exec3 = mysqli_query($conn, $sqlst2) or die ("Error in Query3".mysql_error());
				$onerow = mysqli_fetch_array($exec3);
					$opregistration_id = $onerow['opregistration_id'];*/
 		 	 ?>        
              <table align="center" width="100%" style="border:1px solid #999; padding:0 5px; font-size:12px;" bgcolor="#FFF" cellpadding="0">
                <tr>
                <?php
                if($hospitaldata_logo!=''){
					?>
                    <td width="65">
                    <div align="left" style="font-size:15px;">
                    <img alt="barcode" width="60" height="60" src="logo_images/<?php echo $hospitaldata_logo; ?>" /></div>
                   </td>
               <?php }?>
                <td width="320">
                    <div align="left" style="font-size:18px;"><strong><?php echo $hospitaldata_name;?></strong></div>
                    <div align="left"><?php echo $hospitaldata_address1;?></div>
                    <div align="left" style="font-size:14px;">Contact:<?php echo $hospitaldata_mobile;?></div>
                </td>
                </tr>
             </table>
            
            <table align="center" width="100%" style="border:1px solid #999; height:60px;padding:0 5px; font-size:13px;" bgcolor="#FFF" cellpadding="0">
              <tr align="right">
                <td align="left"><strong>Serial Number : <?php  echo $appointmententry_number;?></strong></td>
                <td align="right">
                	<?php 
                	$barCode = $bar;
                	require("barcodePrint.php");
            		?>
                </td>
             </tr>
           </table>
                       
            <table align="center" width="100%" style="border:1px solid #999;font-size:12px; border-bottom:none; padding:2px 8px 0 8px; margin-top:6px" bgcolor="#FFF" cellpadding="0">
                <tr>
                    <td width="300">
                        <div align="left"><strong>Patient: <?php echo $appointmententry_name;?></strong></div>
                        <div align="left">Mobile : <?php echo $appointmententry_mobile;?></div>
                        <div align="left">Gender : <?php echo $appointmententry_gender;?></div>
                        <div align="left">Age : <?php echo $appointmententry_age;?> Years</div>
                        <div align="left"><strong>Category : <?php echo $appointmententry_pcategory;?></strong></div>
                    </td>
                    <td width="150">
                        <div align="right" style="font-size:15px"><strong>Appointment Slip</strong></div>
                        <div align="right">Ref. No.: <?php echo $appointmententry_id;?></div>
                        <div align="right">UHID : <?php  echo $uhid;?></div>
                        <div align="right">A.Date: <?php  echo $appointmententry_date;?></div>
                      	<div align="right">Time: <?php  echo $appointmententry_time;?></div>
                        
                  </td>
                 </tr>
             </table>
                 
            <table align="center" width="100%" style="border:1px solid #999;font-size:12px; padding:0 8px 5px 8px;" bgcolor="#FFF" cellpadding="0">
                <tr><td width="450"><strong>Ref Dr.: <?php echo $appointmententry_doctor;?></strong></td></tr>
                </table>
                 <table align="center" width="100%" bgcolor="#FFF" style=" padding:0 0 40px;font-size:12px; border:1px #999 solid; border-top:none;" cellspacing="0" cellpadding="0">
                    
                <tr height="20">
                    <td style="border:1px solid #999;text-align:center;border-top:none;"><strong>Particular</strong></td>
                    <td style="border:1px solid #999; text-align:center;border-top:none;"><strong>Paid Amount</strong></td>
                </tr>
                
                <tr>
                    <td style=" text-align:center; padding-left:3px" width="250">Consultant Fee</td>
                    <td style="text-align:center;"><?php echo $appointmententry_amount;?></td>
                </tr>
             </table>
                <?php
              		}
			  	}
			 }
              ?>
              
         <table width="100%" align="center" style="font-size:12px;">
        	<tr>
            	<td><?php include ("convert_currency_to_words.php");
 					echo 'InWord:';	echo covert_currency_to_words($appointmententry_amount); ?>
            	</td>
            </tr>
         </table>
        
         <table align="center" width="100%" style=" font-size:12px; padding:5px 2px" bgcolor="#FFF" cellpadding="0">
              <tr>
                <td width="200">
                	<div>Prepared By: <?php echo $user; ?></div>
                </td>
                <td width="200">
                	<div style="padding-bottom:10px" align="right"></div>
                	<div align="right">Authorised Sign</div>
                </td>
             </tr>
         </table>
       
</article>

<div id="divToPrint" style="display:none;">
 <article>
		  <?php
		   if(isset($_GET['appointmententry_id'])){
          	$appointmententry_id = $_GET['appointmententry_id'];
            $asql = "select * from appointmententry where appointmententry_id = $appointmententry_id";
            $aqry = mysqli_query($conn, $asql);
            if($aqry && mysqli_num_rows($aqry)>0){
                while($prow = mysqli_fetch_array($aqry)){
                   $appointmententry_id = $prow['appointmententry_id'];
                   $appointmententry_code = $prow['appointmententry_code'];
                    $appointmententry_name = $prow['appointmententry_name'];
                    $appointmententry_mobile = $prow['appointmententry_mobile'];
					$bar = $prow['bar'];
                    $uhid = $prow['uhid'];
                    $user = $prow['user'];
                    $day_serial = $prow['day_serial'];
                    $appointmententry_doctor = $prow['appointmententry_doctor'];
                    $appointmententry_time = $prow['appointmententry_time'];
                    $appointmententry_number = $prow['appointmententry_number'];
                    $appointmententry_date = $prow['appointmententry_date'];
				 	$appointmententry_amount = $prow['appointmententry_amount'];
					$appointmententry_pcategory = $prow['appointmententry_pcategory'];
 					$appointmententry_age = $prow['appointmententry_age'];
				 	$appointmententry_gender = $prow['appointmententry_gender'];
				 
 		 	 ?>        
              <table align="center" width="100%" style="border:1px solid #999; padding:0 5px; font-size:12px;" bgcolor="#FFF" cellpadding="0">
                <tr>
                <?php
                if($hospitaldata_logo!=''){
					?>
                    <td width="65">
                    <div align="left" style="font-size:15px;">
                    <img alt="barcode" width="60" height="60" src="logo_images/<?php echo $hospitaldata_logo; ?>" /></div>
                   </td>
               <?php }?>
                <td width="320">
                    <div align="left" style="font-size:18px;"><strong><?php echo $hospitaldata_name;?></strong></div>
                    <div align="left"><?php echo $hospitaldata_address1;?></div>
                    <div align="left" style="font-size:14px;">Contact:<?php echo $hospitaldata_mobile;?></div>
                </td>
                </tr>
             </table>
            
            <table align="center" width="100%" style="border:1px solid #999; height:60px;padding:0 5px; font-size:13px;" bgcolor="#FFF" cellpadding="0">
            <tr align="right">
                <td align="left"><strong>Serial Number : <?php  echo $appointmententry_number;?></strong></td>
                <td align="right">
                <?php 
                $barCode = $bar;
                require("barcodePrint.php");
            	?>
                </td>
                
            	</tr>
            </table>
                       
            <table align="center" width="100%" style="border:1px solid #999;font-size:12px; border-bottom:none; padding:2px 8px 0 8px; margin-top:6px" bgcolor="#FFF" cellpadding="0">
                <tr>
                    <td width="300">
                        <div align="left"><strong>Patient: <?php echo $appointmententry_name;?></strong></div>
                        <div align="left">Mobile : <?php echo $appointmententry_mobile;?></div>
                        <div align="left">Gender : <?php echo $appointmententry_gender;?></div>
                        <div align="left">Age : <?php echo $appointmententry_age;?> Years</div>
                        <div align="left"><strong>Category : <?php echo $appointmententry_pcategory;?></strong></div>
                    </td>
                    <td width="150">
                        <div align="right" style="font-size:15px"><strong>Appointment Slip</strong></div>
                        <div align="right">Ref. No.: <?php echo $appointmententry_id;?></div>
                        <div align="right">UHID : <?php  echo $uhid;?></div>
                        <div align="right">A.Date: <?php  echo $appointmententry_date;?></div>
                      	<div align="right">Time: <?php  echo $appointmententry_time;?></div>
                        
                  </td>
                 </tr>
             </table>
                 
            <table align="center" width="100%" style="border:1px solid #999;font-size:12px; padding:0 8px 5px 8px;" bgcolor="#FFF" cellpadding="0">
                <tr><td width="450"><strong>Ref Dr.: <?php echo $appointmententry_doctor;?></strong></td></tr>
                </table>
                 <table align="center" width="100%" bgcolor="#FFF" style=" padding:0 0 40px;font-size:12px; border:1px #999 solid; border-top:none;" cellspacing="0" cellpadding="0">
                    
                <tr height="20">
                    <td style="border:1px solid #999;text-align:center;border-top:none;"><strong>Particular</strong></td>
                    <td style="border:1px solid #999; text-align:center;border-top:none;"><strong>Paid Amount</strong></td>
                </tr>
                
                <tr>
                    <td style=" text-align:center; padding-left:3px" width="250">Consultant Fee</td>
                    <td style="text-align:center;"><?php echo $appointmententry_amount;?></td>
                </tr>
             </table>
                <?php
              		}
			  	}
			 }
              ?>
              
         <table width="100%" align="center" style="font-size:12px;">
        	<tr>
            	<td><?php //include ("convert_currency_to_words.php");
 					echo 'InWord:';	echo covert_currency_to_words($appointmententry_amount); ?>
            	</td>
            </tr>
         </table>
        
         <table align="center" width="100%" style=" font-size:12px; padding:5px 2px" bgcolor="#FFF" cellpadding="0">
              <tr>
                <td width="200">
                	<div>Prepared By: <?php echo $user; ?></div>
                </td>
                <td width="200">
                	<div style="padding-bottom:10px" align="right"></div>
                	<div align="right">Authorised Sign</div>
                </td>
             </tr>
         </table>
       
</article>
</div>