<?php if($_SESSION['employeename']=='ADMINISTRATOR' or $_SESSION['employeename']=='SUPERADMINISTRATOR'){ 
/* Hospital ERP - Modern Dashboard UI Only */
?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Hospital ERP Dashboard</title>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:Arial,Helvetica,sans-serif;
    background:#f5f7fb;
    color:#172033;
}

:root{
    --blue:#2563eb;
    --dark:#0f172a;
    --text:#172033;
    --muted:#7b8798;
    --border:#e8edf3;
    --white:#fff;
    --green:#10b981;
    --orange:#f59e0b;
    --red:#ef4444;
    --purple:#8b5cf6;
}

/* =========================
   MAIN
========================= */

.dashboard{
    min-height:100vh;
}

/* =========================
   TOP HEADER
========================= */

.header{
    height:72px;
    background:#fff;
    border-bottom:1px solid var(--border);

    display:flex;
    align-items:center;
    justify-content:space-between;

    padding:0 28px;
}

.logo{
    display:flex;
    align-items:center;
    gap:10px;
}

.logo-icon{
    width:40px;
    height:40px;

    border-radius:10px;

    background:#2563eb;
    color:#fff;

    display:flex;
    align-items:center;
    justify-content:center;

    font-size:20px;
}

.logo-text h2{
    font-size:16px;
}

.logo-text span{
    display:block;
    color:#8a94a6;
    font-size:9px;
    margin-top:2px;
    letter-spacing:1px;
}

.header-right{
    display:flex;
    align-items:center;
    gap:12px;
}

.search{
    width:250px;
    height:38px;

    background:#f6f8fb;
    border:1px solid var(--border);
    border-radius:8px;

    display:flex;
    align-items:center;

    padding:0 12px;
}

.search span{
    color:#94a3b8;
    margin-right:7px;
}

.search input{
    width:100%;
    border:0;
    outline:none;
    background:none;
    font-size:11px;
}

.header-icon{
    width:38px;
    height:38px;

    border:1px solid var(--border);
    border-radius:8px;

    display:flex;
    align-items:center;
    justify-content:center;

    background:#fff;

    font-size:15px;
}

.admin{
    display:flex;
    align-items:center;
    gap:8px;

    margin-left:5px;
}

.admin-avatar{
    width:34px;
    height:34px;

    border-radius:50%;

    background:#dbeafe;
    color:#2563eb;

    display:flex;
    align-items:center;
    justify-content:center;

    font-size:11px;
    font-weight:bold;
}

.admin-name strong{
    display:block;
    font-size:10px;
}

.admin-name span{
    font-size:8px;
    color:#94a3b8;
}

/* =========================
   CONTENT
========================= */

.container{
    padding:25px 28px;
    max-width:1700px;
    margin:auto;
}

/* =========================
   WELCOME
========================= */

.welcome{
    display:flex;
    justify-content:space-between;
    align-items:center;

    margin-bottom:22px;
}

.welcome h1{
    font-size:22px;
    margin-bottom:5px;
}

.welcome p{
    color:var(--muted);
    font-size:11px;
}

.date{
    background:#fff;
    border:1px solid var(--border);

    padding:10px 14px;

    border-radius:8px;

    font-size:10px;
    color:#64748b;
}

/* =========================
   KPI
========================= */

.kpi{
    display:grid;
    grid-template-columns:
    repeat(5,1fr);

    gap:14px;

    margin-bottom:18px;
}

.kpi-card{
    background:#fff;

    border:1px solid var(--border);

    border-radius:12px;

    padding:16px;

    position:relative;

    box-shadow:0 3px 15px rgba(15,23,42,.03);
}

.kpi-top{
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.kpi-title{
    font-size:9px;
    color:#7b8798;
    font-weight:bold;
    letter-spacing:.3px;
}

.kpi-icon{
    width:35px;
    height:35px;

    border-radius:9px;

    display:flex;
    align-items:center;
    justify-content:center;

    font-size:16px;
}

.blue{
    background:#eaf2ff;
    color:#2563eb;
}

.green{
    background:#e9fbf4;
    color:#10b981;
}

.orange{
    background:#fff5df;
    color:#f59e0b;
}

.red{
    background:#fff0f1;
    color:#ef4444;
}

.purple{
    background:#f2ecff;
    color:#8b5cf6;
}

.kpi-value{
    font-size:23px;
    font-weight:bold;

    margin-top:12px;
}

.kpi-bottom{
    margin-top:7px;

    font-size:9px;

    color:#94a3b8;
}

.up{
    color:#10b981;
    font-weight:bold;
}

/* =========================
   MAIN GRID
========================= */

.main-grid{
    display:grid;

    grid-template-columns:
    1.5fr
    1fr
    1fr;

    gap:16px;

    margin-bottom:16px;
}

/* =========================
   CARD
========================= */

.card{
    background:#fff;

    border:1px solid var(--border);

    border-radius:12px;

    box-shadow:
    0 3px 15px
    rgba(15,23,42,.03);

    overflow:hidden;
}

.card-header{
    height:52px;

    padding:0 17px;

    border-bottom:1px solid var(--border);

    display:flex;
    justify-content:space-between;
    align-items:center;
}

.card-header h3{
    font-size:12px;
}

.card-header span{
    font-size:9px;
    color:#94a3b8;
}

.card-body{
    padding:16px;
}

/* =========================
   TODAY OVERVIEW
========================= */

.overview{
    display:grid;

    grid-template-columns:
    repeat(2,1fr);

    gap:10px;
}

.overview-box{
    border:1px solid var(--border);

    border-radius:9px;

    padding:12px;

    background:#fafbfc;
}

.overview-box span{
    display:block;

    color:#8a94a6;

    font-size:9px;

    margin-bottom:7px;
}

.overview-box strong{
    font-size:19px;
}

.overview-box small{
    display:block;

    margin-top:4px;

    color:#94a3b8;

    font-size:8px;
}

/* =========================
   MINI CHART
========================= */

.chart{
    height:150px;

    display:flex;
    align-items:flex-end;
    justify-content:space-between;

    gap:10px;

    padding-top:15px;
}

.chart-column{
    flex:1;

    height:100%;

    display:flex;
    align-items:flex-end;
    justify-content:center;
}

.chart-bar{
    width:65%;

    min-height:10px;

    border-radius:5px 5px 2px 2px;

    background:#2563eb;
}

.chart-label{
    text-align:center;

    font-size:8px;

    color:#94a3b8;

    margin-top:6px;
}

/* =========================
   BED STATUS
========================= */

.bed{
    margin-bottom:14px;
}

.bed-head{
    display:flex;
    justify-content:space-between;

    margin-bottom:6px;

    font-size:9px;
}

.bed-head span:last-child{
    font-weight:bold;
}

.progress{
    height:7px;

    background:#edf1f5;

    border-radius:20px;

    overflow:hidden;
}

.progress div{
    height:100%;

    border-radius:20px;
}

.bed-total{
    display:grid;

    grid-template-columns:
    repeat(3,1fr);

    gap:7px;

    margin-top:15px;
}

.bed-total div{
    background:#f7f9fb;

    padding:9px;

    text-align:center;

    border-radius:8px;
}

.bed-total strong{
    display:block;

    font-size:15px;
}

.bed-total span{
    color:#94a3b8;

    font-size:8px;
}

/* =========================
   EMERGENCY
========================= */

.emergency{
    background:#fff6f6;

    border:1px solid #fee2e2;

    border-radius:9px;

    padding:13px;

    margin-bottom:12px;
}

.emergency-top{
    display:flex;
    align-items:center;

    justify-content:space-between;
}

.emergency-title{
    display:flex;
    align-items:center;

    font-size:10px;
    font-weight:bold;
}

.live{
    width:8px;
    height:8px;

    background:#ef4444;

    border-radius:50%;

    margin-right:7px;

    box-shadow:
    0 0 0 4px
    rgba(239,68,68,.1);
}

.emergency-number{
    font-size:25px;

    font-weight:bold;

    color:#dc2626;

    margin-top:8px;
}

.emergency-text{
    font-size:8px;

    color:#9f1239;
}

/* =========================
   LOWER GRID
========================= */

.lower-grid{
    display:grid;

    grid-template-columns:
    1.3fr
    1fr
    1fr;

    gap:16px;

    margin-bottom:16px;
}

/* =========================
   APPOINTMENT
========================= */

.appointment{
    display:flex;

    align-items:center;

    padding:10px 0;

    border-bottom:1px solid #f0f2f5;
}

.appointment:last-child{
    border-bottom:0;
}

.app-time{
    width:58px;

    font-size:9px;

    color:#64748b;
}

.doc{
    width:31px;
    height:31px;

    border-radius:50%;

    background:#eaf2ff;

    color:#2563eb;

    display:flex;
    align-items:center;
    justify-content:center;

    font-size:9px;

    font-weight:bold;

    margin-right:8px;
}

.app-info{
    flex:1;
}

.app-info strong{
    display:block;

    font-size:9px;
}

.app-info span{
    font-size:8px;

    color:#94a3b8;
}

.badge{
    padding:4px 7px;

    border-radius:20px;

    font-size:7px;

    font-weight:bold;
}

.badge-green{
    color:#059669;
    background:#e8faf3;
}

.badge-orange{
    color:#d97706;
    background:#fff5df;
}

.badge-blue{
    color:#2563eb;
    background:#eaf2ff;
}

/* =========================
   QUICK ACTION
========================= */

.actions{
    display:grid;

    grid-template-columns:
    repeat(2,1fr);

    gap:9px;
}

.action{
    padding:11px;

    border:1px solid var(--border);

    border-radius:9px;

    transition:.2s;

    cursor:pointer;
}

.action:hover{
    border-color:#bfdbfe;

    background:#f8fbff;

    transform:translateY(-1px);
}

.action-icon{
    width:31px;
    height:31px;

    border-radius:8px;

    display:flex;
    align-items:center;
    justify-content:center;

    margin-bottom:7px;

    font-size:14px;
}

.action strong{
    display:block;

    font-size:9px;
}

.action span{
    display:block;

    font-size:7px;

    color:#94a3b8;

    margin-top:3px;
}

/* =========================
   ALERTS
========================= */

.alert{
    display:flex;

    align-items:center;

    padding:11px 0;

    border-bottom:1px solid #f0f2f5;
}

.alert:last-child{
    border-bottom:0;
}

.alert-icon{
    width:32px;
    height:32px;

    border-radius:8px;

    display:flex;
    align-items:center;
    justify-content:center;

    margin-right:9px;
}

.alert-content{
    flex:1;
}

.alert-content strong{
    display:block;

    font-size:9px;
}

.alert-content span{
    display:block;

    font-size:8px;

    color:#94a3b8;

    margin-top:2px;
}

.alert-arrow{
    color:#94a3b8;

    font-size:12px;
}

/* =========================
   FOOTER
========================= */

.footer{
    text-align:center;

    color:#a0a9b8;

    font-size:8px;

    padding:10px;
}

/* =========================
   RESPONSIVE
========================= */

@media(max-width:1200px){

    .kpi{
        grid-template-columns:
        repeat(3,1fr);
    }

    .main-grid,
    .lower-grid{
        grid-template-columns:1fr 1fr;
    }

}

@media(max-width:850px){

    .header{
        padding:0 15px;
    }

    .container{
        padding:18px 15px;
    }

    .search{
        display:none;
    }

    .main-grid,
    .lower-grid{
        grid-template-columns:1fr;
    }

}

@media(max-width:600px){

    .kpi{
        grid-template-columns:
        repeat(2,1fr);
    }

    .welcome{
        display:block;
    }

    .date{
        display:inline-block;
        margin-top:10px;
    }

    .admin-name{
        display:none;
    }

}

@media(max-width:420px){

    .kpi{
        grid-template-columns:1fr;
    }

    .header{
        height:62px;
    }

    .logo-text h2{
        font-size:14px;
    }

}

</style>

</head>

<body>


<div class="dashboard">


<!-- =====================================================
     HEADER
====================================================== -->

<header class="header">

    <div class="logo">

        <div class="logo-icon">
            ✚
        </div>

        <div class="logo-text">

            <h2><?php echo $hospitaldata_name;?></h2>

            <span>
                HEALTHCARE MANAGEMENT
            </span>

        </div>

    </div>


    <div class="header-right">

        <div class="search">

            <span>⌕</span>

            <input
                type="text"
                placeholder="Search patient, doctor..."
            >

        </div>


        <div class="header-icon">
            🔔
        </div>


        <div class="header-icon">
            ⚙
        </div>


        <div class="admin">

            <div class="admin-avatar">
                AD
            </div>

            <div class="admin-name">

                <strong>
                    Administrator
                </strong>

                <span>
                    Super Admin
                </span>

            </div>

        </div>

    </div>

</header>


<!-- =====================================================
     CONTENT
====================================================== -->

<div class="container">


<!-- WELCOME -->

<div class="welcome">

    <div>

        <h1>
            <?php
$hour = date('H');

if ($hour < 12) {
    $greeting = "Good Morning";
} elseif ($hour < 18) {
    $greeting = "Good Afternoon";
} else {
    $greeting = "Good Evening";
}
?> <?php echo $greeting; ?>, <?php echo $_SESSION['fullname'];?> 👋
        </h1>

        <p>
            Here is today's hospital overview.
        </p>

    </div>


    <div class="date">
        📅 <?php echo date('d F Y'); ?>
    </div>

</div>


<!-- =====================================================
     KPI
====================================================== -->

<div class="kpi">


    <div class="kpi-card">

        <div class="kpi-top">

            <span class="kpi-title">
                TODAY'S PATIENTS
            </span>

            <div class="kpi-icon blue">
                👥
            </div>

        </div>

        <div class="kpi-value">
            386
        </div>

        <div class="kpi-bottom">
            <span class="up">↑ 8.2%</span>
            vs yesterday
        </div>

    </div>


    <div class="kpi-card">

        <div class="kpi-top">

            <span class="kpi-title">
                OPD
            </span>

            <div class="kpi-icon green">
                🩺
            </div>

        </div>

        <div class="kpi-value">
            248
        </div>

        <div class="kpi-bottom">
            <span class="up">↑ 5.4%</span>
            today
        </div>

    </div>


    <div class="kpi-card">

        <div class="kpi-top">

            <span class="kpi-title">
                ADMITTED
            </span>

            <div class="kpi-icon orange">
                🛏
            </div>

        </div>

        <div class="kpi-value">
            74
        </div>

        <div class="kpi-bottom">
            18 new admissions
        </div>

    </div>


    <div class="kpi-card">

        <div class="kpi-top">

            <span class="kpi-title">
                AVAILABLE BED
            </span>

            <div class="kpi-icon purple">
                🛌
            </div>

        </div>

        <div class="kpi-value">
            42
        </div>

        <div class="kpi-bottom">
            Out of 284 beds
        </div>

    </div>


    <div class="kpi-card">

        <div class="kpi-top">

            <span class="kpi-title">
                TODAY'S COLLECTION
            </span>

            <div class="kpi-icon green">
                ৳
            </div>

        </div>

        <div class="kpi-value">
            ৳8.45L
        </div>

        <div class="kpi-bottom">
            <span class="up">↑ 12.8%</span>
            vs yesterday
        </div>

    </div>


</div>


<!-- =====================================================
     MAIN INFORMATION
====================================================== -->

<div class="main-grid">


<!-- TODAY OVERVIEW -->

<div class="card">

    <div class="card-header">

        <h3>
            Today's Overview
        </h3>

        <span>
            Live Overview
        </span>

    </div>


    <div class="card-body">

        <div class="overview">


            <div class="overview-box">

                <span>
                    New Patients
                </span>

                <strong>
                    86
                </strong>

                <small>
                    Registered today
                </small>

            </div>


            <div class="overview-box">

                <span>
                    Appointments
                </span>

                <strong>
                    124
                </strong>

                <small>
                    Scheduled today
                </small>

            </div>


            <div class="overview-box">

                <span>
                    Lab Tests
                </span>

                <strong>
                    216
                </strong>

                <small>
                    Tests received
                </small>

            </div>


            <div class="overview-box">

                <span>
                    Pharmacy Sales
                </span>

                <strong>
                    318
                </strong>

                <small>
                    Transactions today
                </small>

            </div>


        </div>

    </div>

</div>


<!-- PATIENT TREND -->

<div class="card">

    <div class="card-header">

        <h3>
            Patient Trend
        </h3>

        <span>
            Last 7 Days
        </span>

    </div>


    <div class="card-body">

        <div class="chart">


            <div class="chart-column">

                <div
                    class="chart-bar"
                    style="height:45%;"
                ></div>

            </div>


            <div class="chart-column">

                <div
                    class="chart-bar"
                    style="height:60%;"
                ></div>

            </div>


            <div class="chart-column">

                <div
                    class="chart-bar"
                    style="height:52%;"
                ></div>

            </div>


            <div class="chart-column">

                <div
                    class="chart-bar"
                    style="height:70%;"
                ></div>

            </div>


            <div class="chart-column">

                <div
                    class="chart-bar"
                    style="height:63%;"
                ></div>

            </div>


            <div class="chart-column">

                <div
                    class="chart-bar"
                    style="height:82%;"
                ></div>

            </div>


            <div class="chart-column">

                <div
                    class="chart-bar"
                    style="height:92%;"
                ></div>

            </div>

        </div>


        <div style="
            display:flex;
            justify-content:space-between;
            font-size:8px;
            color:#94a3b8;
        ">

            <span>Mon</span>
            <span>Tue</span>
            <span>Wed</span>
            <span>Thu</span>
            <span>Fri</span>
            <span>Sat</span>
            <span>Sun</span>

        </div>

    </div>

</div>


<!-- BED STATUS -->

<div class="card">

    <div class="card-header">

        <h3>
            Bed Status
        </h3>

        <span>
            284 Total
        </span>

    </div>


    <div class="card-body">


        <div class="bed">

            <div class="bed-head">

                <span>
                    General Ward
                </span>

                <span>
                    72%
                </span>

            </div>

            <div class="progress">

                <div
                    style="
                    width:72%;
                    background:#2563eb;
                    "
                ></div>

            </div>

        </div>


        <div class="bed">

            <div class="bed-head">

                <span>
                    ICU
                </span>

                <span>
                    86%
                </span>

            </div>

            <div class="progress">

                <div
                    style="
                    width:86%;
                    background:#ef4444;
                    "
                ></div>

            </div>

        </div>


        <div class="bed">

            <div class="bed-head">

                <span>
                    Cabin
                </span>

                <span>
                    58%
                </span>

            </div>

            <div class="progress">

                <div
                    style="
                    width:58%;
                    background:#10b981;
                    "
                ></div>

            </div>

        </div>


        <div class="bed">

            <div class="bed-head">

                <span>
                    Emergency
                </span>

                <span>
                    91%
                </span>

            </div>

            <div class="progress">

                <div
                    style="
                    width:91%;
                    background:#f59e0b;
                    "
                ></div>

            </div>

        </div>


        <div class="bed-total">

            <div>

                <strong>
                    284
                </strong>

                <span>
                    Total
                </span>

            </div>


            <div>

                <strong>
                    242
                </strong>

                <span>
                    Occupied
                </span>

            </div>


            <div>

                <strong>
                    42
                </strong>

                <span>
                    Available
                </span>

            </div>

        </div>

    </div>

</div>


</div>


<!-- =====================================================
     LOWER SECTION
====================================================== -->

<div class="lower-grid">


<!-- APPOINTMENTS -->

<div class="card">

    <div class="card-header">

        <h3>
            Upcoming Appointments
        </h3>

        <span>
            View All →
        </span>

    </div>


    <div class="card-body">


        <div class="appointment">

            <div class="app-time">
                09:30 AM
            </div>

            <div class="doc">
                AR
            </div>

            <div class="app-info">

                <strong>
                    Dr. Ahmed Rahman
                </strong>

                <span>
                    Cardiology • Rahim Uddin
                </span>

            </div>

            <span class="badge badge-green">
                Confirmed
            </span>

        </div>


        <div class="appointment">

            <div class="app-time">
                10:15 AM
            </div>

            <div class="doc">
                KA
            </div>

            <div class="app-info">

                <strong>
                    Dr. Karim Ahmed
                </strong>

                <span>
                    Medicine • Sumaiya
                </span>

            </div>

            <span class="badge badge-orange">
                Waiting
            </span>

        </div>


        <div class="appointment">

            <div class="app-time">
                11:00 AM
            </div>

            <div class="doc">
                NS
            </div>

            <div class="app-info">

                <strong>
                    Dr. Nazmul Shah
                </strong>

                <span>
                    Surgery • Mamun Ali
                </span>

            </div>

            <span class="badge badge-blue">
                Confirmed
            </span>

        </div>


        <div class="appointment">

            <div class="app-time">
                12:30 PM
            </div>

            <div class="doc">
                HK
            </div>

            <div class="app-info">

                <strong>
                    Dr. Hasan Khan
                </strong>

                <span>
                    ENT • Jannat Akter
                </span>

            </div>

            <span class="badge badge-blue">
                Confirmed
            </span>

        </div>


    </div>

</div>


<!-- QUICK ACTION -->

<div class="card">

    <div class="card-header">

        <h3>
            Quick Actions
        </h3>

        <span>
            Shortcuts
        </span>

    </div>


    <div class="card-body">

        <div class="actions">


            <div class="action">

                <div class="action-icon blue">
                    👤
                </div>

                <strong>
                    New Patient
                </strong>

                <span>
                    Register patient
                </span>

            </div>


            <div class="action">

                <div class="action-icon green">
                    📅
                </div>

                <strong>
                    Appointment
                </strong>

                <span>
                    Book appointment
                </span>

            </div>


            <div class="action">

                <div class="action-icon orange">
                    🛏
                </div>

                <strong>
                    Admission
                </strong>

                <span>
                    Admit patient
                </span>

            </div>


            <div class="action">

                <div class="action-icon purple">
                    🧪
                </div>

                <strong>
                    Lab Invoice
                </strong>

                <span>
                    New lab invoice
                </span>

            </div>


            <div class="action">

                <div class="action-icon green">
                    💊
                </div>

                <strong>
                    Pharmacy Sale
                </strong>

                <span>
                    New sale
                </span>

            </div>


            <div class="action">

                <div class="action-icon orange">
                    💰
                </div>

                <strong>
                    Collection
                </strong>

                <span>
                    Receive payment
                </span>

            </div>


        </div>

    </div>

</div>


<!-- ALERTS -->

<div class="card">

    <div class="card-header">

        <h3>
            Important Alerts
        </h3>

        <span>
            4 Alerts
        </span>

    </div>


    <div class="card-body">


        <div class="alert">

            <div class="alert-icon red">
                🚨
            </div>

            <div class="alert-content">

                <strong>
                    Emergency Capacity High
                </strong>

                <span>
                    91% beds occupied
                </span>

            </div>

            <div class="alert-arrow">
                ›
            </div>

        </div>


        <div class="alert">

            <div class="alert-icon orange">
                💊
            </div>

            <div class="alert-content">

                <strong>
                    Low Pharmacy Stock
                </strong>

                <span>
                    12 items need attention
                </span>

            </div>

            <div class="alert-arrow">
                ›
            </div>

        </div>


        <div class="alert">

            <div class="alert-icon blue">
                🧪
            </div>

            <div class="alert-content">

                <strong>
                    Pending Lab Reports
                </strong>

                <span>
                    18 reports pending
                </span>

            </div>

            <div class="alert-arrow">
                ›
            </div>

        </div>


        <div class="alert">

            <div class="alert-icon purple">
                💳
            </div>

            <div class="alert-content">

                <strong>
                    Outstanding Payments
                </strong>

                <span>
                    24 invoices due
                </span>

            </div>

            <div class="alert-arrow">
                ›
            </div>

        </div>


    </div>

</div>


</div>


<!-- FOOTER -->

<div class="footer">
    <!--Hospital ERP • Dashboard UI • Non Functional Design-->
</div>


</div>

</div>


</body>
</html>
<?php }?>
<?php if($_SESSION['employeename']=='GENERAL'){ ?>
 
 <article class="bottomcontent">
     <div style="background:#F2F2F2; min-height:558px; padding:80px 80px; ">
   
      <h2 style=" width:820px; color:#0cf;box-shadow: 0 0 11px; text-align:center;
      margin: 0px 0 20px 0px; padding:10px; color:#0CF; font-weight:bold; font-size:17px; float:left">Welcome To :  <?php echo $hospitaldata_name; ?></h2>
          
     <p> <img src="images/logo2.jpg" width="840" height="350"\></p>
          			
     <div style=" width:820px; color:#0cf;box-shadow: 0 0 11px; text-align:center;
      margin: 20px 0 0 0px; padding:10px; color:#0CF; font-weight:bold; font-size:16px; float:left">
           :: Powered By Beta Software Solutions ::</div>
    </div>
</article>
<?php }?>
