<?php
//openA
date_default_timezone_set('Asia/Dhaka');
$employee_name = isset($_REQUEST['employee_name']) ? trim($_REQUEST['employee_name']) : '';
$fromdate = !empty($_REQUEST['ADate1']) ? $_REQUEST['ADate1'] : date('Y-m-d');
$todate = !empty($_REQUEST['ADate2']) ? $_REQUEST['ADate2'] : date('Y-m-d');
?>

<form method="post" action="">
    Employee: <input type="text" name="employee_name" value="<?php echo htmlspecialchars($employee_name); ?>">
    From: <input type="date" name="ADate1" value="<?php echo $fromdate; ?>">
    To: <input type="date" name="ADate2" value="<?php echo $todate; ?>">
    <button type="submit">Search</button>
</form>

<table border="1" cellspacing="0" cellpadding="5" width="100%" style="border-collapse: collapse;">
<tr bgcolor="#0033FF" style="color:#fff;">
    <th>SL</th><th>ID</th><th>Name</th><th>Entry Date</th>
    <th>Roster Start</th><th>Roster End</th><th>In Time</th>
    <th>Grace (15m)</th><th>Late (Min)</th><th>Salary/Day</th>
    <th>Deduction</th><th>Net Salary</th><th>Status</th>
</tr>

<?php
$s = 0; $totalLate = 0; $totalDeduction = 0; $totalNet = 0;

$sql = "SELECT md.*, e.name, e.gross FROM machine_data md
        JOIN employee e ON md.e_id = e.e_id
        WHERE md.entry_date BETWEEN '$fromdate' AND '$todate' AND md.in_out=1 ";
if(!empty($employee_name)) {
    $sql .= " AND e.name LIKE '%".mysqli_real_escape_string($conn,$employee_name)."%' ";
}
$sql .= " ORDER BY md.entry_date ASC, md.entry_time ASC";

$result = mysqli_query($conn, $sql) or die("Attendance query failed: ".mysqli_error($conn));

while($row = mysqli_fetch_assoc($result)) {
    $s++;
    $e_id = $row['e_id']; $name = $row['name']; $gross = $row['gross'];
    $entry_date = $row['entry_date'];
    $entry_time = strtotime($entry_date.' '.$row['entry_time']);
    if(!$entry_time) continue;

    // Get all rosters for this employee on this date
    $sqlRoster = "SELECT * FROM rostering WHERE e_id='".mysqli_real_escape_string($conn,$e_id)."' 
                  AND fromdate <= '$entry_date' AND todate >= '$entry_date' ORDER BY fromtime ASC";
    $rosterQ = mysqli_query($conn,$sqlRoster) or die("Roster query failed: ".mysqli_error($conn));

    $lateMinutes = 0; $deduction = 0; $netSalary = round($gross/30,2);
    $status = "❌ No Roster Found"; $rosterStartStr=$rosterEndStr='-';
    $rosterFound = false;

    if(mysqli_num_rows($rosterQ) > 0) {
        $status = "❌ Outside Roster"; // default

        while($roster = mysqli_fetch_assoc($rosterQ)) {
            $rosterStart = strtotime($entry_date.' '.$roster['fromtime']);
            $rosterEnd = strtotime($entry_date.' '.$roster['totime']);
            
            // Handle overnight shifts
            if($rosterEnd <= $rosterStart) {
                $rosterEnd = strtotime('+1 day', $rosterEnd);
            }

            $rosterStartStr = date('h:i:s A', $rosterStart);
            $rosterEndStr = date('h:i:s A', $rosterEnd);
            $rosterFound = true;

            // Entry before roster start - consider on time with no deduction
            if($entry_time < $rosterStart) {
                $lateMinutes = 0;
                $deduction = 0;
                $netSalary = round($gross/30, 2);
                $status = "On Time (Early)";
                break;
            }

            // Grace period (15 minutes after roster start)
            $graceEnd = $rosterStart + (15 * 60);
            if($entry_time <= $graceEnd) {
                $lateMinutes = 0;
                $deduction = 0;
                $netSalary = round($gross/30, 2);
                $status = "On Time (Grace)";
                break;
            }

            // Late but still within roster end time
            if($entry_time > $graceEnd && $entry_time <= $rosterEnd) {
                $lateMinutes = floor(($entry_time - $graceEnd) / 60);
                $dailySalary = $gross / 30;
                $perMinuteRate = $dailySalary / (8 * 60); // 8 hours work day
                $deduction = round($lateMinutes * $perMinuteRate, 2);
                $netSalary = round($dailySalary - $deduction, 2);
                $status = "Late";
                break;
            }
            
            // If we reach here, the entry is after this roster period
            // Continue to check next roster if available
        }
    }

    // If no roster was found that matches the entry time
    if($rosterFound && $status === "❌ Outside Roster") {
        $lateMinutes = 0;
        $deduction = 0;
        $netSalary = 0; // No salary if outside all rosters
        $status = "❌ Outside Roster (No Pay)";
    }

    $totalLate += $lateMinutes; 
    $totalDeduction += $deduction; 
    $totalNet += $netSalary;
?>
<tr>
    <td><?php echo $s;?></td>
    <td><?php echo $e_id;?></td>
    <td><?php echo htmlspecialchars($name);?></td>
    <td><?php echo $entry_date;?></td>
    <td><?php echo $rosterStartStr;?></td>
    <td><?php echo $rosterEndStr;?></td>
    <td><?php echo date('h:i:s A', $entry_time);?></td>
    <td>15 min</td>
    <td><?php echo $lateMinutes;?></td>
    <td><?php echo number_format($gross/30, 2);?></td>
    <td><?php echo number_format($deduction, 2);?></td>
    <td><?php echo number_format($netSalary, 2);?></td>
    <td><?php echo $status;?></td>
</tr>
<?php } ?>

<tr bgcolor="#FFCC99">
    <td colspan="8" align="right"><strong>Totals</strong></td>
    <td><strong><?php echo $totalLate;?> min</strong></td>
    <td>-</td>
    <td><strong><?php echo number_format($totalDeduction, 2);?></strong></td>
    <td><strong><?php echo number_format($totalNet, 2);?></strong></td>
    <td>-</td>
</tr>
</table>