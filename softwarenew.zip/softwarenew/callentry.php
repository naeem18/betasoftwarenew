<article class="bottomcontent">
<header class="header_tittle">
    <h3 style="background:#D6FEE1; text-align:center">Call Entry</h3>
</header>
   <content>
     
        <?php
        if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
            echo "<p class=\"red12bold\">You have missing Something</p>";
        }
		 if(isset($_GET['message']) && $_GET['message']=='update-successfully'){
            echo "<p class=\"red12bold\">updated successfully</p>";
        }
       
        elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
            echo "<p class=\"red12bold\">Error occured! Could not insert.</p>";   
        }
        elseif(isset($_GET['message']) && $_GET['message']=='save-successfully'){
            echo "<p class=\"red12bold\">Information insert successfully. Click Print Button To Print or View Previous Bill <td align=\"center\" ><a onclick=\"PrintDiv();\"><input type=\"button\" name=\"user\" id=\"user\" required value=\"Print\" class=\"tdclass\"  /></a></td></p>";   
        }
           		
       	 			 
					 $auto_number = 0;
                     $callentry_name = '';
                     $callentry_mobile = '';
                     $callentry_description = '';
                    
                    
        
        if(isset($_GET['auto_number'])){
          	$auto_number = $_GET['auto_number'];
            $callentry_sql = "select * from callentry where auto_number = $auto_number";
            $callentryquery = mysqli_query($conn, $callentry_sql);
            if($callentryquery && mysqli_num_rows($callentryquery)>0){
                while($page_inforow = mysqli_fetch_array($callentryquery)){
                   $auto_number = $page_inforow['auto_number'];
                    $callentry_name = $page_inforow['callentry_name'];
                    $callentry_mobile = $page_inforow['callentry_mobile'];
					$user = $page_inforow['user'];
                    $callentry_description = $page_inforow['callentry_description'];
                    $callentry_date = $page_inforow['callentry_date'];
                }
            }
        }
		
		
        ?>        
           
<form action="save_callentry.php" name="frmcontact" onsubmit="return checkcontactform();" method="post" enctype="multipart/form-data">

<table width="600" align="center" border="1" style="BORDER-COLLAPSE: collapse;" bgcolor="#77F7AA" cellpadding="2">
    <input type="hidden" name="user" id="user" value="<?php echo $_SESSION['fullname'];?>" class="tdclass"  />
     <tr>
        <td align="right">Date:&emsp;</td>
        <td><input type="text" name="callentry_date" id="callentry_date" value="<?php echo date('Y-m-d');?>" class="tdclass" /></td>
    </tr>
    <tr>
    	<td align="right"> Calling Person&emsp;</td>
    	<td><input type="text" required name="callentry_name" id="callentry_name" value="<?php echo $callentry_name ;?>" class="tdclass" /></td>
    </tr>
    <tr>
        <td align="right">Mobile Number&emsp;</td>
        <td><input type="text"  name="callentry_mobile" id="callentry_mobile" value="<?php echo $callentry_mobile ;?>" class="tdclass"  /></td>
    </tr>
    
    <tr>
        <td align="right">Call Description&emsp;</td>
        <td><textarea type="text" name="callentry_description"  id="callentry_description" class="textareadetailsr" /><?php echo $callentry_description ;?></textarea></td>
	</tr>
    <tr>
    	<td align="right">&emsp;</td>
        <td>
        <input type="hidden" name="auto_number" id="auto_number" value="<?php echo $auto_number;?>">
        <input type="submit" value=" Save Call" name="submit_invoice" id="submit_invoice" class="tdclass" />
        &emsp;
        <a href="index.php?p=callentry"><input type="button" name="callentry" id="callentry" value="Cancel" class="tdclass"/></a>
        </td>
    </tr>
</table>
</form>         

</content>
</article>