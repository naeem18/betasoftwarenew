<?php
session_start();
if(isset($_GET['idvalue'])){	
	$idvalue = $_GET['idvalue'];
	if($idvalue>0){
		require('labdd.php');
		$ruser=$_SESSION['username'];
		$removeip = $_SERVER["REMOTE_ADDR"];
 		 $str2 = "update labinvoice set ruser = '$ruser',
		 								removeip = '$removeip',
		 								dstatus = 'Deleted'
						 where labinvoice_id = '$idvalue'";
		 $userquery = mysqli_query($conn, $str2);
		
		 $str = "update labinvoicedetails set dstatus = 'Deleted'
							   where labinvoice_id = '$idvalue'";
		 $userquery = mysqli_query($conn, $str);
		
		 $str3 = "update dailytransection_lab set dstatus = 'Deleted'
			where section='Lab Cash' AND labinvoice_id = '$idvalue'";
		 $userquery = mysqli_query($conn, $str3);
 		
		if($userquery){			
			header("location:index.php?p=statementbyinvoiceadminn&message=remove-successfully");			
		}
		else{
			header("location:index.php?p=$returnpage&message=couldnotremove");
		}
	}
	else{
		header("location:index.php?p=statementbyinvoiceadminn&message=incorrect_id");
	}
}
?>