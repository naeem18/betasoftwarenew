 
  <?php
$searchstr='';
if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
{
	$transactiondatefrom = $_REQUEST['ADate1'];
	$transactiondateto = $_REQUEST['ADate2'];	
}
else
{
	$transactiondatefrom = date('Y-m-d', strtotime('-0 day'));
	$transactiondateto = date('Y-m-d');
}
?>

<table width="100%" border="0" cellspacing="0" cellpadding="2">
 <tr>
    <td valign="top" align="center">
    	<form name="cbform1" method="post" action="index.php?p=employenameentry5">
            <table width="100%" border="1" align="center" cellpadding="2" cellspacing="0" bordercolor="#666666" style="border-collapse: collapse">
              <tbody>
                <tr bgcolor="#011E6A">
                  <td colspan="10" bgcolor="#CCCCCC" align="center"><strong>Search Date wise</strong></td>
                </tr>           
                <tr>
                    <td>Date From:</td>
                    <td><input name="ADate1" id="ADate1" style="border: 1px solid #001E6A" value="<?php echo $transactiondatefrom; ?>" size="10" readonly onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
                    </td>
                    <td>Date To:</td>
                    <td><input name="ADate2" id="ADate2" style="border: 1px solid #001E6A" value="<?php echo $transactiondateto; ?>" size="10" readonly onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate2')" style="cursor:pointer"/>
                    </td>
                    
                      <td><input style="border: 1px solid #001E6A" type="submit" value="Search" name="Submit" />
                          <input name="resetbutton" type="reset" id="resetbutton" style="border: 1px solid #001E6A" value="Reset" />
                    </td>
                    <td><input name="print" type="button" id="print"  style="border: 1px solid #001E6A" value="Print" onClick="PrintDiv();" /></td>
                </tr>
              </tbody>
            </table>
		</form>
   	</td>
</tr>
<tr>
   <td align="center">


 <table align="left" width="50%" border="1" style="BORDER-COLLAPSE: collapse;" cellspacing="1" cellpadding="3">
      <tr>
        <td colspan="10" bgcolor="#0033FF" align="center" style="color:#fff; border:1px solid #03F;">
             <strong>In Time Information </strong>
        </td>
      </tr>
      <tr bgcolor="#ccc" align="center">
        <td>SL</td>
         <td>ID</td>
        <td>Name</td>
        <td>In Time</td>
      </tr>

	  <?php
	  $s='';
     	$sqlsalesitem = "select * from machine_data where in_out=1 order by id asc";
	  	$salesitemquery = mysqli_query($conn, $sqlsalesitem);
			while ($salesitemrow = mysqli_fetch_array($salesitemquery))
				{
				$e_id = $salesitemrow['e_id'];
				$entry_time = $salesitemrow['entry_time'];
				$entry_date = $salesitemrow['entry_date'];
				//$in_out = $salesitemrow[2];
				if($in_out=1){
							$inTime = "$entry_date $entry_time";
						}
			$sqlst = "select * from employee where e_id='$e_id'";
			$exec3 = mysqli_query($conn, $sqlst) or die ("Error in Query3".mysql_error());
			$onerow = mysqli_fetch_array($exec3);
		
				$name = $onerow['name'];	
				//$id = $onerow['id'];	
					
				?>
				<tr bgcolor="#fff" align="center">
					<td align="left"><?php echo $s=$s+1; ?></td>
					<td align="left"><?php echo $e_id; ?></td>
                    <td align="left"><?php echo $name; ?></td>
					<td><?php echo $entry_date .'#'. $entry_time; ?></td>
				</tr>
			<?Php	
			}			
		?>
 </table>
 
 <table align="left" width="50%" border="1" style="BORDER-COLLAPSE: collapse;" cellspacing="1" cellpadding="3">
      <tr>
        <td colspan="10" bgcolor="#0033FF" align="center" style="color:#fff; border:1px solid #03F;">
            <strong>Out Time Information </strong>
        </td>
      </tr>
      <tr bgcolor="#ccc" align="center">
       <td>ID</td>
       <td>Name</td>
       <td>Out Time</td>
      </tr>

	  <?php
     	$sqlsalesitem = "select * from machine_data where in_out=2 order by id asc";
	  	$salesitemquery = mysqli_query($conn, $sqlsalesitem);
			while ($salesitemrow = mysqli_fetch_array($salesitemquery))
				{
				$e_id = $salesitemrow['e_id'];
				$entry_time = $salesitemrow['entry_time'];
				$entry_date = $salesitemrow['entry_date'];
				//$in_out = $salesitemrow[2];
				if($in_out=2){
							$inTime = "$entry_date $entry_time";
						}
				$sqlst = "select * from employee where e_id='$e_id'";
			$exec3 = mysqli_query($conn, $sqlst) or die ("Error in Query3".mysql_error());
			$onerow = mysqli_fetch_array($exec3);
		
				$name = $onerow['name'];	
				//$id = $onerow['id'];	
			
				?>
				<tr bgcolor="#fff" align="center">
                <td><?php echo $e_id; ?></td>
                 <td align="left"><?php echo $name; ?></td>
					<td><?php echo $inTime; ?></td>
				</tr>
			<?Php	
			}			
		?>
 </table>
 
 </td></tr>
 
 <tr>
   <td align="center" id="divToPrint" style="display:none">
   
 <table align="left" width="50%" border="1" style="BORDER-COLLAPSE: collapse;" cellspacing="1" cellpadding="3">
      <tr>
        <td colspan="10" bgcolor="#0033FF" align="center" style="color:#fff; border:1px solid #03F;">
            <strong><?php //echo $hospitaldata_name; ?></strong><br>
            <strong>In Time Information </strong>
        </td>
      </tr>
      <tr bgcolor="#ccc" align="center">
        <td>SL</td>
         <td>ID</td>
        <td>Name</td>
        <td>In Time</td>
      </tr>

	  <?php
     	$sqlsalesitem = "select * from machine_data where in_out=1 order by id asc";
	  	$salesitemquery = mysqli_query($conn, $sqlsalesitem);
			while ($salesitemrow = mysqli_fetch_array($salesitemquery))
				{
				$e_id = $salesitemrow['e_id'];
				$entry_time = $salesitemrow['entry_time'];
				$entry_date = $salesitemrow['entry_date'];
				//$in_out = $salesitemrow[2];
				if($in_out=1){
							$inTime = "$entry_date $entry_time";
						}
			$sqlst = "select * from employee where e_id='$e_id'";
			$exec3 = mysqli_query($conn, $sqlst) or die ("Error in Query3".mysql_error());
			$onerow = mysqli_fetch_array($exec3);
		
				$name = $onerow['name'];	
				//$id = $onerow['id'];	
					
				?>
				<tr bgcolor="#fff" align="center">
					<td align="left"><?php echo $s=$s+1; ?></td>
					<td align="left"><?php echo $e_id; ?></td>
                    <td align="left"><?php echo $name; ?></td>
					<td><?php echo $entry_date .'#'. $entry_time; ?></td>
				</tr>
			<?Php	
			}			
		?>
 </table>
 
 <table align="left" width="50%" border="1" style="BORDER-COLLAPSE: collapse;" cellspacing="1" cellpadding="3">
      <tr>
        <td colspan="10" bgcolor="#0033FF" align="center" style="color:#fff; border:1px solid #03F;">
            <strong><?php //echo $hospitaldata_name; ?></strong><br>
            <strong>Out Time Information </strong>
        </td>
      </tr>
      <tr bgcolor="#ccc" align="center">
       <td>ID</td>
       <td>Name</td>
       <td>Out Time</td>
      </tr>

	  <?php
     	$sqlsalesitem = "select * from machine_data where in_out=2 order by id asc";
	  	$salesitemquery = mysqli_query($conn, $sqlsalesitem);
			while ($salesitemrow = mysqli_fetch_array($salesitemquery))
				{
				$e_id = $salesitemrow['e_id'];
				$entry_time = $salesitemrow['entry_time'];
				$entry_date = $salesitemrow['entry_date'];
				//$in_out = $salesitemrow[2];
				if($in_out=2){
							$inTime = "$entry_date $entry_time";
						}
				$sqlst = "select * from employee where e_id='$e_id'";
			$exec3 = mysqli_query($conn, $sqlst) or die ("Error in Query3".mysql_error());
			$onerow = mysqli_fetch_array($exec3);
		
				$name = $onerow['name'];	
				//$id = $onerow['id'];	
			
				?>
				<tr bgcolor="#fff" align="center">
                <td><?php echo $e_id; ?></td>
                 <td align="left"><?php echo $name; ?></td>
					<td><?php echo $inTime; ?></td>
				</tr>
			<?Php	
			}			
		?>
 </table>
   </td></tr>
 </table>