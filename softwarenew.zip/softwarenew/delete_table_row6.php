<?php
session_start();
if(isset($_GET['idvalue'])){	

	$idvalue = $_GET['idvalue'];
	if($idvalue>0){
		require('labdd.php');
		
		$str2 = "DELETE from expense where auto_number = '$idvalue'";
		$userquery = mysqli_query($conn, $str2);
		
		
		 $str3 = "DELETE from dailytransection_lab where section='Expense' AND labinvoice_id = '$idvalue'";
		 //echo $str3;
		 $userquery = mysqli_query($conn, $str3);
		
		 $str4 = "DELETE from dailytransection_lab where section='L PC Paid' AND labinvoice_id = '$idvalue'";
	     $strquery = mysqli_query($conn, $str4);

		
		if($userquery){			
			header("location:index.php?p=statementbyexpense&message=remove-successfully");			
		}
		else{
			header("location:index.php?p=$returnpage&message=couldnotremove");
		}
	}
	else{
		header("location:index.php?p=statementbyexpense&message=incorrect_id");
	}
}
?>
