<script language="JavaScript" type="text/javascript">
	
	var itemdata = <?php echo $itemdata;?>;
	var patientdata = <?php echo $patientdata;?>;
	$(document).ready(function($) {
		document.getElementsByName("salesinvoice_item[]")[0].focus();

		$( ".itemname" ).autocomplete({
			
			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.saleselval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				document.getElementsByName("salesitem_id[]")[indexpos].value = ui.item.salesitem_id;
				document.getElementsByName("salesinvoice_purchase_rate[]")[indexpos].value = ui.item.salesitem_purchase_rate;
				document.getElementsByName("salesinvoice_rate[]")[indexpos].value = ui.item.salesitem_price;				
				document.getElementsByName("salesitem_pack[]")[indexpos].value =1;
				document.getElementsByName("salesinvoice_qty[]")[indexpos].value = 1;					
				document.getElementsByName("salesinvoice_category[]")[indexpos].value = ui.item.salesitem_category;
				document.getElementsByName("salesinvoice_stock[]")[indexpos].value = ui.item.salesitem_stock;
				
				calculateCurrentRowTotal(indexpos);
				
				return false;
			}
		});
		
		
		$( "#salesinvoice_patient" ).autocomplete({
			
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.saleselval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 	document.getElementById('salesinvoice_patientid').value = ui.item.labelval;
				 	document.getElementById('salesinvoice_previousdue').value = ui.item.opregistration_due;
					document.getElementById('salesinvoice_mobile').value = ui.item.opregistration_mobile;
				 	document.getElementById('salesinvoice_address').value = ui.item.opregistration_address;
				
				return false;
			}
		});
		
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
		$( ".sirow input.ccrt" ).keyup(function() {
			var index = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
			calculateCurrentRowTotal(index);
		});
	});
	
	function calculateCurrentRowTotal(index){
		var salesinvoice_purchase_rate = parseFloat(document.getElementsByName("salesinvoice_purchase_rate[]")[index].value);
		if(salesinvoice_purchase_rate=='' || isNaN(salesinvoice_purchase_rate)){salesinvoice_purchase_rate = 0.00;}
		
		//purchase 
		
		var salesinvoice_rate = parseFloat(document.getElementsByName("salesinvoice_rate[]")[index].value);
		if(salesinvoice_rate=='' || isNaN(salesinvoice_rate)){salesinvoice_rate = 0.00;}
		
		
		var salesitem_pack = parseFloat(document.getElementsByName("salesitem_pack[]")[index].value);
		if(salesitem_pack=='' || isNaN(salesitem_pack)){salesitem_pack = 0.00;}
		
		var salesreturn_qty = parseFloat(document.getElementsByName("salesreturn_qty[]")[index].value);
		if(salesreturn_qty=='' || isNaN(salesreturn_qty)){salesreturn_qty = 0.00;}
		
		if(salesitem_pack==0 || salesreturn_qty==0){
			var salesinvoice_qty = parseFloat(document.getElementsByName("salesinvoice_qty[]")[index].value);
			if(salesinvoice_qty=='' || isNaN(salesinvoice_qty)){salesinvoice_qty = 0.00;}
		}
		else{
			var salesinvoice_qty = parseFloat(salesitem_pack-salesreturn_qty);
			if(salesinvoice_qty=='' || isNaN(salesinvoice_qty)){salesinvoice_qty = 0.00;}
			document.getElementsByName("salesinvoice_qty[]")[index].value = salesinvoice_qty.toFixed(2);
		}
		
		var qtyPrice = parseFloat(salesinvoice_rate*salesinvoice_qty);
		// purchase calculate
		var qtypurchasePrice = parseFloat(salesinvoice_purchase_rate*salesinvoice_qty);
		//return process
		var qtyreturnPrice = parseFloat(salesinvoice_rate*salesreturn_qty);
		
		var salesinvoice_discountp = parseFloat(document.getElementsByName("salesinvoice_discountp[]")[index].value);
		if(salesinvoice_discountp=='' || isNaN(salesinvoice_discountp)){salesinvoice_discountp = 0.00;}
		if(salesinvoice_discountp==0){
			var salesinvoice_disc = parseFloat(document.getElementsByName("salesinvoice_disc[]")[index].value);
			if(salesinvoice_disc=='' || isNaN(salesinvoice_disc)){salesinvoice_disc = 0.00;}
		}
		else{
			var salesinvoice_disc = parseFloat(qtyPrice*salesinvoice_discountp*0.01);	
			document.getElementsByName("salesinvoice_disc[]")[index].value = salesinvoice_disc.toFixed(2);
		}
		
		document.getElementsByName("salesinvoice_total[]")[index].value = parseFloat(qtyPrice-salesinvoice_disc).toFixed(2);
		//purchase
		document.getElementsByName("purchaseinvoice_total[]")[index].value = parseFloat(qtypurchasePrice).toFixed(2);
		
		document.getElementsByName("salesreturn_price[]")[index].value = parseFloat(qtyreturnPrice).toFixed(2);
		
		//return process
		
		/*var salesinvoice_qty = parseFloat(salesinvoice_qty-salesreturn_qty);
		document.getElementById('salesinvoice_qty').value=salesinvoice_qty.toFixed(2);		
		*/
		
		calculateGrandTotal();
	}
	
	function calculateGrandTotal(){
		var salesinvoice_totalarray = document.getElementsByName("salesinvoice_total[]");
		var salesinvoice_subtotal = 0.00;
		for(var r=0; r<salesinvoice_totalarray.length; r++){
			var salesinvoice_total = parseFloat(salesinvoice_totalarray[r].value);
			if(salesinvoice_total=='' || isNaN(salesinvoice_total)){salesinvoice_total = 0.00;}
			salesinvoice_subtotal = parseFloat(salesinvoice_subtotal+salesinvoice_total);
		}
		document.getElementById("salesinvoice_subtotal").value = salesinvoice_subtotal.toFixed(2);
		
		// return process
		var salesreturn_pricearray = document.getElementsByName("salesreturn_price[]");
		var salesreturn_subtotal = 0.00;
		for(var k=0; k<salesreturn_pricearray.length; k++){
			var salesreturn_price = parseFloat(salesreturn_pricearray[k].value);
			if(salesreturn_price=='' || isNaN(salesreturn_price)){salesreturn_price = 0.00;}
			salesreturn_subtotal = parseFloat(salesreturn_subtotal+salesreturn_price);
		}
		
		document.getElementById("salesreturn_subtotal").value = salesreturn_subtotal.toFixed(2);
		
		
		var purchaseinvoice_totalarray = document.getElementsByName("purchaseinvoice_total[]");
		var salesinvoice_purchasesubtotal = 0.00;
		for(var m=0; m<purchaseinvoice_totalarray.length; m++){
			var purchaseinvoice_total = parseFloat(purchaseinvoice_totalarray[m].value);
			if(purchaseinvoice_total=='' || isNaN(purchaseinvoice_total)){purchaseinvoice_total = 0.00;}
			salesinvoice_purchasesubtotal = parseFloat(salesinvoice_purchasesubtotal+purchaseinvoice_total);
		}
		
		document.getElementById("salesinvoice_purchasesubtotal").value = salesinvoice_purchasesubtotal.toFixed(2);
		
		
		var salesinvoice_totaldiscp = parseFloat(document.getElementById("salesinvoice_totaldiscp").value);
		if(salesinvoice_totaldiscp=='' || isNaN(salesinvoice_totaldiscp)){salesinvoice_totaldiscp = 0;}
		if(salesinvoice_totaldiscp==0){
			var salesinvoice_totaldisc = parseFloat(document.getElementById("salesinvoice_totaldisc").value);
			if(salesinvoice_totaldisc=='' || isNaN(salesinvoice_totaldisc)){salesinvoice_totaldisc = 0;}
		}
		else{
			var salesinvoice_totaldisc = parseFloat(salesinvoice_subtotal*salesinvoice_totaldiscp*0.01);
			document.getElementById('salesinvoice_totaldisc').value= salesinvoice_totaldisc.toFixed(2);
		}
		
		// prevoius due
		var salesinvoice_previousdue = parseFloat(document.getElementById("salesinvoice_previousdue").value);
		if(salesinvoice_previousdue=='' || isNaN(salesinvoice_previousdue)){salesinvoice_previousdue = 0;}
		
		
		var salesinvoice_subtotalafterdisc = parseFloat(salesinvoice_previousdue+salesinvoice_subtotal-salesinvoice_totaldisc);
		document.getElementById('salesinvoice_subtotalafterdisc').value= salesinvoice_subtotalafterdisc.toFixed(2);
			
		
			
		var salesinvoice_receiveamount = parseFloat(document.getElementById("salesinvoice_receiveamount").value);
		if(salesinvoice_receiveamount=='' || isNaN(salesinvoice_receiveamount)){salesinvoice_receiveamount = 0;}
		
		var salesinvoice_due = parseFloat( salesinvoice_subtotalafterdisc-salesinvoice_receiveamount);
		document.getElementById('salesinvoice_due').value=salesinvoice_due.toFixed(2);		
		
		
			
		
		
	}
	
	/*function check_blankrow(){
		var salesinvoice_itemArray = document.getElementsByName('salesinvoice_item[]');
		var salesinvoice_totalArray = document.getElementsByName('salesinvoice_total[]');
			
		var error_messageid = document.getElementById('errmsg_particular_id');
		error_messageid.innerHTML = '';
		
		for(r = 0; r < salesinvoice_itemArray.length; r++) {
												
			if(salesinvoice_itemArray[r].value==''){
				error_messageid.innerHTML = 'Missing item name '+parseInt(r+1);
				salesinvoice_itemArray[r].focus();
				return false;
			}
			
			if(salesinvoice_totalArray[r].value=='' || salesinvoice_totalArray[r].value==0){
				error_messageid.innerHTML = 'Missing item total '+parseInt(r+1);
				salesinvoice_totalArray[r].focus();
				return false;
			}
		}
		
		return true;
	}
*/
	/*function addnew_particularrow(animate) {
		if(check_blankrow()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php //echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" align=\"center\" width=\"918\" cellpadding=\"1\">"+
							'<tbody><tr></tr><tr>'+
								'<td align="center" width=\"130\"> <input type="text" name="salesinvoice_item[]" value="" class="tdclass itemname"/>'+
								'<input type="hidden" name="salesitem_id[]" id="salesitem_id[]" value="" class="tdclass itemname"/>'+
								'<input type="hidden" name="salesinvoice_category[]" value="" class="tdclass"  /></td>'+
								'<td align="center" width=\"95\"> <input type="text" name="salesinvoice_stock[]" value=\"\" class="tdclasssale itemname"/></td>'+
								"<input type=\"hidden\" name=\"salesinvoice_purchase_rate[]\" class=\"tdclasssale\"/>"+											 
								"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"salesinvoice_rate[]\" value=\"\" class=\"tdclasssale numeric ccrt\"/></td>"+											 
								"<input type=\"hidden\" title=\"class\" name=\"salesitem_pack[]\" class=\"tdclasssale numeric ccrt\" >"+
								"<input type=\"hidden\" name=\"salesinvoice_pqty[]\" value=\"\" class=\"tdclasssale numeric ccrt\" />"+
								"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"salesinvoice_qty[]\" class=\"tdclasssale numeric ccrt\"/></td>"+
								'<td align="center" width=\"95\"><input type="text" name="salesinvoice_discountp[]" class="tdclasssale numeric ccrt"/></td>'+
								"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"salesinvoice_disc[]\"  class=\"tdclasssale numeric  ccrt\" /></td>"+
								'<td align="center" width=\"95\"><input type="text" readonly name="salesinvoice_total[]" class="tdclasssale numeric ccrt"  /></td>'+												
								'<input type="hidden" readonly name="purchaseinvoice_total[]" class="tdclasssale numeric ccrt"  />'+												
								
							  '</tr></tbody>'+
						"</table>";
						
			var $newparticularlist = $("<li class=\"sirow\"></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(300); 
			else 
			   $newparticularlist.show();   
			document.getElementsByName("salesinvoice_item[]")[parseInt(particular_rowcount-1)].focus();
			
			$( ".itemname" ).autocomplete({			
				minLength: 1,
				source: itemdata,
				focus: function( event, ui ) {
					//$( "#search_item_number" ).val( ui.item.saleselval );
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				document.getElementsByName("salesitem_id[]")[indexpos].value = ui.item.salesitem_id;
				document.getElementsByName("salesinvoice_purchase_rate[]")[indexpos].value = ui.item.salesitem_purchase_rate;
				document.getElementsByName("salesinvoice_rate[]")[indexpos].value = ui.item.salesitem_price;				
				document.getElementsByName("salesitem_pack[]")[indexpos].value =ui.item.salesitem_pack;
				document.getElementsByName("salesinvoice_qty[]")[indexpos].value = 1;					
				document.getElementsByName("salesinvoice_category[]")[indexpos].value = ui.item.salesitem_category;
				document.getElementsByName("salesinvoice_stock[]")[indexpos].value = ui.item.salesitem_stock;
				
					calculateCurrentRowTotal(indexpos);
					
					return false;
				}
			});	
				
								
		
			$( ".sirow input.ccrt" ).keyup(function() {
				var index = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
			calculateCurrentRowTotal(index);
			});
			
			$( ".sirow input.deletethislistrow" ).click(function() {
				$(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').slideUp(500, function() {
					$(this).remove();
					calculateGrandTotal();
				});
			});
			
			$( ".numeric" ).keyup(function() {
				var price = $(this).val();
				var ValidChars = "-.0123456789";
				var IsNumber=true;
				var Char;
				var validint = '';
				for (var i = 0; i < price.length && IsNumber == true; i++){ 
					Char = price.charAt(i);
					if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
					else{
						validint = validint+Char;
					}
				}
				$(this).val(validint);
			});
		}
	}*/
</script>