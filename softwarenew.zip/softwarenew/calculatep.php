<script language="JavaScript" type="text/javascript">
	
	var empdata = <?php echo $empdata;?>;
	var patientdata = <?php echo $patientdata;?>;
 	
	$(document).ready(function($) {
	document.getElementsByName("itembar[]")[0].focus();


var itemCache = {};
var ajaxRequest = null;

$(document).on("focus",".itemname",function(){

    console.log("Focused:", this.name);
	
	   if($(this).hasClass("ac_loaded")){
    return;
	}
 	$(this).addClass("ac_loaded");


    $(this).autocomplete({

        minLength:1,

        delay:150,

        source:function(request,response){

            var term=$.trim(request.term);

            if(term.length<1){
                response([]);
                return;
            }

            if(itemCache[term]){
                response(itemCache[term]);
                return;
            }

            if(ajaxRequest){
                ajaxRequest.abort();
            }

            ajaxRequest=$.ajax({

                url:"ajax_item_search.php",

                type:"GET",

                dataType:"json",

                cache:true,

                data:{
                    term:term
                },

                success:function(data){

                    itemCache[term]=data;

                    response(data);

                }

            });

        },

        focus:function(){

            return false;

        },

        select:function(event,ui){

            var indexpos=$(this)
            .closest("li")
            .index();

             document.getElementsByName("salesitem_id[]")[indexpos].value=ui.item.sii;
             document.getElementsByName("itembar[]")[indexpos].value=ui.item.bar;
			 document.getElementsByName("salesinvoice_item[]")[indexpos].value=ui.item.salesitem_name;
             document.getElementsByName("salesinvoice_purchase_rate[]")[indexpos].value=ui.item.sipr;
             document.getElementsByName("salesinvoice_rate[]")[indexpos].value=ui.item.sisp;
             document.getElementsByName("salesitem_pack[]")[indexpos].value=ui.item.sip;
             document.getElementsByName("salesinvoice_qty[]")[indexpos].value='';
             document.getElementsByName("salesinvoice_category[]")[indexpos].value=ui.item.sic;
             document.getElementsByName("salesinvoice_group[]")[indexpos].value=ui.item.sig;
             document.getElementsByName("salesinvoice_stock[]")[indexpos].value=ui.item.sis;
             document.getElementsByName("salesitem_location[]")[indexpos].value=ui.item.sisl;
             calculateCurrentRowTotal(indexpos);

            addnew_particularrow(true);

            return false;

        }

    });

});




		
		
		$( "#employenameentry_name" ).autocomplete({
 			minLength: 1,
			source: empdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
 				 document.getElementById('employenameentry_name').value = ui.item.labelval;
 				 document.getElementById('employenameentry_id').value = ui.item.employenameentry_id;
 				return false;
			}
		});
		
		
		
 		$( "#salesinvoice_patientid" ).autocomplete({
 			minLength: 1,
			source: patientdata,
			focus: function( event, ui ){
 				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 	document.getElementById('salesinvoice_patient').value = ui.item.labelval;
				 	document.getElementById('salesinvoice_patientid').value = ui.item.opregistration_id;
					document.getElementById('salesinvoice_patientcode').value = ui.item.opregistration_code;
					document.getElementById('bar').value = ui.item.bar;
					document.getElementById('salesinvoice_previousdue').value = ui.item.pharmacy_due;
					document.getElementById('salesinvoice_mobile').value = ui.item.opregistration_mobile;
				 	document.getElementById('salesinvoice_address').value = ui.item.opregistration_address;
					document.getElementById('ward').value = ui.item.ward;
				
				return false;
			}
		});
		
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = ".0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
		
		$(document).on("keypress",".salesinvoice_item",function(e){

				if(e.which!=13)
			
					return;
			
				e.preventDefault();
			
				$(this).autocomplete("search");
			
			});
		
		
 
			 $(document).on("keyup",".sirow input.ccrt",function(){
			
					var index=$(this)
				
					.closest("li")
				
					.index();
				
					calculateCurrentRowTotal(index);
				
				});
		
		
	});
	
	function calculateCurrentRowTotal(indexpos){
		//purchase 
		
		var salesinvoice_purchase_rate = parseFloat(document.getElementsByName("salesinvoice_purchase_rate[]")[indexpos].value);
		if(salesinvoice_purchase_rate=='' || isNaN(salesinvoice_purchase_rate)){salesinvoice_purchase_rate = 0.00;}
		
		var salesinvoice_rate = parseFloat(document.getElementsByName("salesinvoice_rate[]")[indexpos].value);
		if(salesinvoice_rate=='' || isNaN(salesinvoice_rate)){salesinvoice_rate = 0.00;}
		
		var salesitem_pack = parseFloat(document.getElementsByName("salesitem_pack[]")[indexpos].value);
		if(salesitem_pack=='' || isNaN(salesitem_pack)){salesitem_pack = 0.00;}
		
		var salesinvoice_pqty = parseFloat(document.getElementsByName("salesinvoice_pqty[]")[indexpos].value);
		if(salesinvoice_pqty=='' || isNaN(salesinvoice_pqty)){salesinvoice_pqty = 0.00;}
		
		if(salesitem_pack==0 || salesinvoice_pqty==0){
			var salesinvoice_qty = parseFloat(document.getElementsByName("salesinvoice_qty[]")[indexpos].value);
			if(salesinvoice_qty=='' || isNaN(salesinvoice_qty)){salesinvoice_qty = 0.00;}
		}
		else{
			var salesinvoice_qty = parseFloat(salesitem_pack*salesinvoice_pqty);
			if(salesinvoice_qty=='' || isNaN(salesinvoice_qty)){salesinvoice_qty = 0.00;}
			document.getElementsByName("salesinvoice_qty[]")[indexpos].value = salesinvoice_qty.toFixed(2);
		}
		
		var qtyPrice = parseFloat(salesinvoice_rate*salesinvoice_qty);
		// purchase calculate
		var qtypurchasePrice = parseFloat(salesinvoice_purchase_rate*salesinvoice_qty);
		
		var salesinvoice_discountp = parseFloat(document.getElementsByName("salesinvoice_discountp[]")[indexpos].value);
		if(salesinvoice_discountp=='' || isNaN(salesinvoice_discountp)){salesinvoice_discountp = 0.00;}
		if(salesinvoice_discountp==0){
			var salesinvoice_disc = parseFloat(document.getElementsByName("salesinvoice_disc[]")[indexpos].value);
			if(salesinvoice_disc=='' || isNaN(salesinvoice_disc)){salesinvoice_disc = 0.00;}
		}
		else{
			var salesinvoice_disc = parseFloat(qtyPrice*salesinvoice_discountp*0.01);	
			document.getElementsByName("salesinvoice_disc[]")[indexpos].value = salesinvoice_disc.toFixed(2);
		}
		
		document.getElementsByName("salesinvoice_total[]")[indexpos].value = parseFloat(qtyPrice-salesinvoice_disc).toFixed(2);
		//purchase
		document.getElementsByName("purchaseinvoice_total[]")[indexpos].value = parseFloat(qtypurchasePrice).toFixed(2);
		
		
		calculateGrandTotal();
	}
	
	function calculateGrandTotal(){
		var salesinvoice_totalarray = document.getElementsByName("salesinvoice_total[]");
		var salesinvoice_subtotal = 0.00;
		for(var r=0; r<salesinvoice_totalarray.length; r++){
			var salesinvoice_total = parseFloat(salesinvoice_totalarray[r].value);
			if(salesinvoice_total=='' || isNaN(salesinvoice_total)){salesinvoice_total = 0.00;}
			salesinvoice_subtotal = parseFloat(salesinvoice_subtotal+salesinvoice_total);
		}
		document.getElementById("salesinvoice_subtotal").value = salesinvoice_subtotal.toFixed(2);
		
		
		var purchaseinvoice_totalarray = document.getElementsByName("purchaseinvoice_total[]");
		var salesinvoice_purchasesubtotal = 0.00;
		for(var m=0; m<purchaseinvoice_totalarray.length; m++){
			var purchaseinvoice_total = parseFloat(purchaseinvoice_totalarray[m].value);
			if(purchaseinvoice_total=='' || isNaN(purchaseinvoice_total)){purchaseinvoice_total = 0.00;}
			salesinvoice_purchasesubtotal = parseFloat(salesinvoice_purchasesubtotal+purchaseinvoice_total);
		}
		document.getElementById("salesinvoice_purchasesubtotal").value = salesinvoice_purchasesubtotal.toFixed(2);
		
		
 			// General shop er jonno on korte hobe
				
				var salesinvoice_totaldiscp = parseFloat(document.getElementById("salesinvoice_totaldiscp").value);
				if(salesinvoice_totaldiscp=='' || isNaN(salesinvoice_totaldiscp)){salesinvoice_totaldiscp = 0;}
				if(salesinvoice_totaldiscp==0){
					var salesinvoice_totaldisc = parseFloat(document.getElementById("salesinvoice_totaldisc").value);
					if(salesinvoice_totaldisc=='' || isNaN(salesinvoice_totaldisc)){salesinvoice_totaldisc = 0;}
				}
				else{
					var salesinvoice_totaldisc = parseFloat(salesinvoice_subtotal*salesinvoice_totaldiscp*0.01);
					document.getElementById('salesinvoice_totaldisc').value= salesinvoice_totaldisc.toFixed(2);
				}
			// General shop er jonno on korte hobe
		
		
		// when sale price above 100 tk  then less 5% ....for general it should be off.
			
			/*var salesinvoice_totaldisc = parseFloat(salesinvoice_totaldisc);
			if(salesinvoice_totaldisc=='' || isNaN(salesinvoice_totaldisc)){salesinvoice_totaldisc = 0;}
			
			if(salesinvoice_subtotal>=100){
				var salesinvoice_totaldisc = parseFloat(salesinvoice_subtotal*5*0.01);
				//document.getElementById('salesinvoice_totaldisc').value= salesinvoice_totaldisc.toFixed(2);
			}
			document.getElementById('salesinvoice_totaldisc').value= salesinvoice_totaldisc.toFixed(2);*/
		
		// when sale price above 100 tk  then less 5%
		
		
		// prevoius due
		var salesinvoice_previousdue = parseFloat(document.getElementById("salesinvoice_previousdue").value);
		if(salesinvoice_previousdue=='' || isNaN(salesinvoice_previousdue)){salesinvoice_previousdue = 0;}
		
		
		var salesinvoice_subtotalafterdisc = parseFloat(salesinvoice_subtotal-salesinvoice_totaldisc);
		document.getElementById('salesinvoice_subtotalafterdisc').value= salesinvoice_subtotalafterdisc.toFixed(2);
			
		
		// for all 
		var salesinvoice_receiveamount = parseFloat(document.getElementById("salesinvoice_receiveamount").value);
		if(salesinvoice_receiveamount=='' || isNaN(salesinvoice_receiveamount)){salesinvoice_receiveamount = 0;}
		
		// for Feni Diabetes temporary/ auto receive amount 
		//var salesinvoice_receiveamount = parseFloat( salesinvoice_subtotalafterdisc);
		//document.getElementById('salesinvoice_receiveamount').value=salesinvoice_receiveamount.toFixed(2);		
		
		
		var salesinvoice_due = parseFloat( salesinvoice_subtotalafterdisc-salesinvoice_receiveamount);
		document.getElementById('salesinvoice_due').value=salesinvoice_due.toFixed(2);		
		
		
		//var salesinvoice_due = parseFloat( salesinvoice_subtotalafterdisc+salesinvoice_previousdue-salesinvoice_receiveamount);
		//document.getElementById('salesinvoice_due').value=salesinvoice_due.toFixed(2);		
		
		
 		var cashreceive = parseFloat(document.getElementById("cashreceive").value);
		if(cashreceive=='' || isNaN(cashreceive)){cashreceive = 0;}
		var cashreturn = parseFloat(cashreceive-salesinvoice_receiveamount);
		document.getElementById('cashreturn').value=cashreturn.toFixed(2);		
 	
	}
	
	function check_blankrow(){
		
		return true;
	}

	function addnew_particularrow(animate) {
		if(check_blankrow()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" align=\"center\" width=\"960\" cellpadding=\"1\">"+
					'<tbody><tr></tr><tr>'+
					"<td align=\"center\" width=\"130\"><input type=\"text\" name=\"itembar[]\" class=\"tdclass salesinvoice_item itemname\"/></td>"+
					'<td align="center" width="130"><input type="text" name="salesinvoice_item[]" class="tdclass ccrt itemname salesinvoice_item"/>'+
					'<input type="hidden" name="salesitem_id[]" class="tdclass"/>'+
					'<input type="hidden" name="salesinvoice_category[]" class="salesinvoice_category" />'+
					'<input type="hidden" name="salesinvoice_group[]" class="salesinvoice_group" />'+
					"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"salesitem_location[]\" class=\"tdclasssale numeric ccrt\"/></td>"+
					"<td align=\"center\" width=\"95\"><input type=\"text\" required name=\"salesinvoice_qty[]\" autocomplete=\"off\" class=\"tdclasssale numeric ccrt\"/></td>"+
					'<td align="center" width="95"><input type="text" name="salesinvoice_stock[]" class="tdclasssale"/></td>'+
					"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"salesinvoice_purchase_rate[]\" class=\"tdclasssale\"/>"+											 
					"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"salesinvoice_rate[]\" class=\"tdclasssale numeric ccrt\"/></td>"+											 
					"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"salesitem_pack[]\" class=\"tdclasssale numeric ccrt\" ></td>"+
					"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"salesinvoice_pqty[]\" class=\"tdclasssale numeric ccrt\" /></td>"+
					
					'<td align="center" width="95"><input type="text" name="salesinvoice_discountp[]" class="tdclasssale numeric ccrt"/></td>'+
					"<td align=\"center\" width=\"95\"><input type=\"text\" name=\"salesinvoice_disc[]\" class=\"tdclasssale numeric ccrt\" /></td>"+
					'<td align="center" width="95"><input type="text" readonly name="salesinvoice_total[]" class="tdclasssale numeric ccrt"  /></td>'+												
					'<input type="hidden" required readonly name="purchaseinvoice_total[]" class="tdclasssale numeric ccrt" />'+												
					'<td>'+
					 "<input type=\"button\" value=\"Del\" class=\"tdclasssales deletethislistrow\"  />"+
					'</td>'+
				  '</tr></tbody>'+
			"</table>";
						
			var $newparticularlist = $("<li class=\"sirow\"></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(300); 
			else 
			   $newparticularlist.show();   
			   document.getElementsByName("salesinvoice_item[]")[parseInt(particular_rowcount-1)].focus();
			
			

			
		
			$(document).on("keyup",".sirow input.ccrt",function(){

				var index=$(this)
			
				.closest("li")
			
				.index();
			
				calculateCurrentRowTotal(index);
			
			});
			

			
			
			$(document).on("click",".deletethislistrow",function(){

				$(this)
			
				.closest("li")
			
				.slideUp(200,function(){
			
					$(this).remove();
			
					calculateGrandTotal();
			
				});
			
			});
			





			$(document).on("keyup",".numeric",function(){

				var price=$(this).val();
			
				var ValidChars="-.0123456789";
			
				var valid='';
			
				for(var i=0;i<price.length;i++){
			
					if(ValidChars.indexOf(price.charAt(i))!=-1){
			
						valid+=price.charAt(i);
			
					}
			
				}
			
				$(this).val(valid);
			
			});
			
			
			$(document).on("focus",".numeric",function(){

				if($(this).val()==0){
			
					$(this).val('');
			
				}
			
			});
			
			$(document).on("blur",".numeric",function(){

				if($(this).val()=='')
			
					$(this).val(0);
			
			});
			
			
			

			
			
			$(document).on("keypress",".salesinvoice_item",function(e){

				if(e.which!=13)
			
					return;
			
				e.preventDefault();


			
				$(this).autocomplete("search");
			
			});
			
			
			
			
		}
	}
	


/*function funcSaveBill1()
{
 	var varUserChoice; 
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet); 
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		//document.frmsales.submit();
		//return true;
	}
}*/		
</script>