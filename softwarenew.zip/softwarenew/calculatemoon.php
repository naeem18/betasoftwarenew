<script language="JavaScript" type="text/javascript">
	var itemdataarray = <?php echo $itemdataarray;?>;
	var itemdata = <?php echo $itemdata;?>;
	var apdata = <?php echo $apdata;?>;
	var iddata = <?php echo $iddata;?>;
	var empdata = <?php echo $empdata;?>;
	var patientdata = <?php echo $patientdata;?>;
	var patientdatainvoice = <?php echo $patientdatainvoice;?>;
	var pcdata = <?php echo $pcdata;?>;
	var drdata = <?php echo $drdata;?>;
	var itemarraydata = itemdataarray;
	$(document).ready(function($){
		document.getElementsByName("labinvoice_patient")[0].focus();

		$( ".itemname" ).autocomplete({
			
			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
 				return false;
			},
			select: function( event, ui ) {
				
 				//Start Duplicate Item Entry Check//
				var itemIdArray = document.getElementsByName("labitem_id[]");
				var itemQtyArray = document.getElementsByName("labinvoice_qty[]");
					//==============================Check Duplicate Id=============================//
					if(itemIdArray.length>0){
						for(var l=0; l<itemIdArray.length; l++){
							var olditem_id = itemIdArray[l].value;
							if(olditem_id !=''){
								if( ui.item.labitem_id == olditem_id){
									/*var qtyVal = parseInt(itemQtyArray[l].value);
									if(qtyVal=='' || isNaN(qtyVal)){qtyVal = 0;}
									qtyVal++;
									itemQtyArray[l].value = qtyVal;
									calculateCurrentRowTotal(l);*/
									$(this).val('');
									$(this).focus();
									alert("Duplicate item found.");
									return false;
								}
							}
						}
					}
					
				//End Duplicate Item Entry Check//
  				
 				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				var labitem_idarray = document.getElementsByName("labitem_id[]");
				labitem_idarray[indexpos].value = ui.item.labitem_id;
				
					var labinvoice_itemarray = document.getElementsByName("labinvoice_item[]");
					labinvoice_itemarray[indexpos].value = ui.item.labitem_name;

				var labinvoice_ratearray = document.getElementsByName("labinvoice_rate[]");
				labinvoice_ratearray[indexpos].value = ui.item.labitem_price;

				var labinvoice_qtyarray = document.getElementsByName("labinvoice_qty[]");
				labinvoice_qtyarray[indexpos].value = 1;
				
				var labinvoice_gpccomissionarray = document.getElementsByName("labinvoice_gpccomission[]");
				labinvoice_gpccomissionarray[indexpos].value = ui.item.labitem_pccommission;


				//var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
				//labinvoice_pccomissionarray[indexpos].value = ui.item.labitem_pccommission;

				var labinvoice_drcomissionarray = document.getElementsByName("labinvoice_drcomission[]");
				labinvoice_drcomissionarray[indexpos].value = ui.item.labitem_drcommission;

				var labinvoice_grouparray = document.getElementsByName("labinvoice_group[]");
				labinvoice_grouparray[indexpos].value = ui.item.labitem_group;
				
				var labinvoice_categoryarray = document.getElementsByName("labinvoice_category[]");
				labinvoice_categoryarray[indexpos].value = ui.item.labitem_category;
				
				var reportnamearray = document.getElementsByName("reportname[]");
				reportnamearray[indexpos].value = ui.item.reportname;

				var labinvoice_samplearray = document.getElementsByName("labinvoice_sample[]");
				labinvoice_samplearray[indexpos].value = ui.item.labitem_sample;
				
				var categoryarray = document.getElementsByName("category[]");
				categoryarray[indexpos].value = ui.item.category;
				
				var notearray = document.getElementsByName("note[]");
				notearray[indexpos].value = ui.item.note;
				
				var orderbyarray = document.getElementsByName("orderby[]");
				orderbyarray[indexpos].value = ui.item.orderby;
				
				var machine_namearray = document.getElementsByName("machine_name[]");
				machine_namearray[indexpos].value = ui.item.machine_name;

				var labinvoice_unitarray = document.getElementsByName("labinvoice_unit[]");
				labinvoice_unitarray[indexpos].value = ui.item.labitem_unit;

				var labinvoice_refvaluearray = document.getElementsByName("labinvoice_refvalue[]");
				labinvoice_refvaluearray[indexpos].value = ui.item.labitem_refvalue;

				var labitem_reagentarray = document.getElementsByName("labitem_reagent[]");
				labitem_reagentarray[indexpos].value = ui.item.labitem_reagent;
				
				var labitem_reagentidarray = document.getElementsByName("labitem_reagentid[]");
				labitem_reagentidarray[indexpos].value = ui.item.labitem_reagentid;
				
 				var reagentqtyarray = document.getElementsByName("reagentqty[]");
				reagentqtyarray[indexpos].value = ui.item.reagentqty;

 
				calculaterowtotal(indexpos);
				//calculate_pctotal();
				//calculate_drtotal();
				addnew_particularrow(true);
				return false;
			}
		});

		$( "#searchpatientid" ).autocomplete({
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
 				 document.getElementById('labinvoice_patient').value = ui.item.labelval;
				 document.getElementById('searchpatientid').value = 'Success';
				 document.getElementById('labinvoice_patientid').value = ui.item.opregistration_id;
				 document.getElementById('labinvoice_patientcode').value = ui.item.opregistration_code;
				 document.getElementById('labinvoice_age').value = ui.item.opregistration_age;
				 document.getElementById('age').value = ui.item.age;
				 document.getElementById('labinvoice_gender').value = ui.item.opregistration_gender;
				 document.getElementById('labinvoice_mobile').value = ui.item.opregistration_mobile;
				 document.getElementById('labinvoice_address').value = ui.item.opregistration_address;
				 document.getElementById('labinvoice_pc').value = ui.item.pcname;
				 document.getElementById('labinvoice_mpo').value = ui.item.mpo;
				 document.getElementById('bar').value = ui.item.bar;
				 document.getElementById('labinvoice_description').value = ui.item.remark;
				 document.getElementById('labinvoice_ward').value = ui.item.ward;
				 document.getElementById('labinvoice_previousdue').value = ui.item.lab_due;
				 document.getElementById('previous_labinvoice_totalpccomission').value = ui.item.labinvoice_totalpccomission;
 				return false;
			}
		});

		//From ID Holder
		$( "#labinvoice_mobile" ).autocomplete({
 			minLength: 1,
			source: iddata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				 document.getElementById('labinvoice_patient').value = ui.item.labelval;
				 document.getElementById('labinvoice_age').value = ui.item.opregistration_age;
				 document.getElementById('bar').value = ui.item.bar;
				 document.getElementById('uhid').value = ui.item.uhidcode;
				 document.getElementById('labinvoice_gender').value = ui.item.opregistration_gender;
				 document.getElementById('labinvoice_mobile').value = ui.item.opregistration_mobile;
				 document.getElementById('labinvoice_totaldiscp').value = ui.item.discp;
				 document.getElementById('labinvoice_address').value = ui.item.opregistration_address;
 				return false;
			}
		});

		//From Appointment// scanner user korle ei part off/ disable rakhte hobe
		$( "#labinvoice_patient" ).autocomplete({
 			minLength: 1,
			source: apdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				 document.getElementById('labinvoice_patient').value = ui.item.labelval;
				 document.getElementById('labinvoice_age').value = ui.item.appointmententry_age;
				 document.getElementById('age').value = ui.item.age;
				 document.getElementById('bar').value = ui.item.bar;
				 document.getElementById('labinvoice_gender').value = ui.item.appointmententry_gender;
				 document.getElementById('labinvoice_mobile').value = ui.item.appointmententry_mobile;
				 document.getElementById('labinvoice_address').value = ui.item.appointmententry_address;
				 document.getElementById('labinvoice_doctor').value = ui.item.appointmententry_doctor;
				 document.getElementById('labinvoice_pc').value = ui.item.appointmententry_pc;
				 document.getElementById('labinvoice_mpo').value = ui.item.appointmententry_mpo;
				return false;
			}
		});
		
		//invoice patient data
		$( "#labinvoice_address" ).autocomplete({
			minLength: 1,
			source: patientdatainvoice,
			focus: function( event, ui ) {
			  return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );

				 document.getElementById('labinvoice_patient').value = ui.item.labelval;
 				 document.getElementById('labinvoice_age').value = ui.item.labinvoice_age;
				 document.getElementById('age').value = ui.item.age;
				 document.getElementById('labinvoice_gender').value = ui.item.labinvoice_gender;
				 document.getElementById('labinvoice_mobile').value = ui.item.labinvoice_mobile;
				 document.getElementById('labinvoice_address').value = ui.item.labinvoice_address;
 				return false;
			}
		});

		// pc search
		$( "#labinvoice_pc" ).autocomplete({
			
			minLength: 1,
			source: pcdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
 				 document.getElementById('labinvoice_pc').value = ui.item.labelval;
				 document.getElementById('labinvoice_mpo').value = ui.item.mpo;
				 document.getElementById('doctor_id').value = ui.item.doctor_id;
				 document.getElementById('previous_pc_comission').value = ui.item.pc_comission;
				 document.getElementById('doctor_mobile').value = ui.item.doctor_mobile;
 				return false;
			}
		});
		
		// dr search
		$( "#labinvoice_doctor" ).autocomplete({
			
			minLength: 1,
			source: drdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
 				 document.getElementById('labinvoice_doctor').value = ui.item.labelval;
				 document.getElementById('labinvoice_doctor').value = ui.item.doctor_name;
 				 return false;
			}
		});
		
		//dues holder
		$( "#labinvoice_duesholder" ).autocomplete({
 			minLength: 1,
			source: empdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
 				 document.getElementById('labinvoice_duesholder').value = ui.item.labelval;
 				 document.getElementById('employenameentry_id').value = ui.item.employenameentry_id;
 				return false;
			}
		});

		
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
		$( ".labinvoice_item" ).keypress(function(keyname) {
			if(keyname.which==13){
				var imei = $(this).val();
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				$.each(itemarraydata, function(key, value){
					var valuearray = value.split('||');
					if(key==imei){
						document.getElementsByName("labitem_id[]")[indexpos].value = valuearray[0];
						//document.getElementsByName("salesinvoice_item[]")[indexpos].value = valuearray[1];
						document.getElementsByName("labinvoice_category[]")[indexpos].value = valuearray[1];
						document.getElementsByName("labinvoice_unit[]")[indexpos].value = valuearray[2];
						document.getElementsByName("labinvoice_refvalue[]")[indexpos].value = valuearray[3];
						document.getElementsByName("labinvoice_rate[]")[indexpos].value = valuearray[4];
						document.getElementsByName("labinvoice_reagent[]")[indexpos].value = valuearray[5];
						document.getElementsByName("labinvoice_pccomission[]")[indexpos].value = valuearray[6];
						document.getElementsByName("labinvoice_drcomission[]")[indexpos].value = valuearray[7];
						document.getElementsByName("labinvoice_qty[]")[indexpos].value = 1;
						calculaterowtotal(indexpos);
						addnew_particularrow(true);
					}
				});
				return false;
			}
		});
	});
	
	function calculate_discountp(){
		
		var labinvoice_discountparray = document.getElementsByName("labinvoice_discountp[]");
		var labinvoice_discarray = document.getElementsByName("labinvoice_disc[]");
		var labinvoice_ratearray = document.getElementsByName("labinvoice_rate[]");
		var labinvoice_qtyarray = document.getElementsByName("labinvoice_qty[]");
		var labinvoice_gpccomissionarray = document.getElementsByName("labinvoice_gpccomission[]");
			
		if(labinvoice_discountparray.length>0){
			for(var p=0; p<labinvoice_discountparray.length; p++){
				var labinvoice_discountp = parseFloat(labinvoice_discountparray[p].value);
				if(labinvoice_discountp=='' || isNaN(labinvoice_discountp)){labinvoice_discountp = 0;}
				
				var labinvoice_disc = parseFloat(labinvoice_discarray[p].value);
				if(labinvoice_disc=='' || isNaN(labinvoice_disc)){labinvoice_disc = 0;}
				if(labinvoice_discountp>0){
					var labinvoice_rate = parseFloat(labinvoice_ratearray[p].value);
					if(labinvoice_rate=='' || isNaN(labinvoice_rate)){labinvoice_rate = 0;}
					
					var labinvoice_gpccomission = parseFloat(labinvoice_gpccomissionarray[p].value);
					if(labinvoice_gpccomission=='' || isNaN(labinvoice_gpccomission)){labinvoice_gpccomission = 0;}
					
					
					var labinvoice_qty = labinvoice_qtyarray[p].value;
					if(labinvoice_qty=='' || isNaN(labinvoice_qty)){labinvoice_qty = 0;}
					
					var pctotal = parseFloat(labinvoice_gpccomission*labinvoice_qty);			
 					var total = parseFloat(labinvoice_rate*labinvoice_qty);
								
					//var labinvoice_pccomission = parseFloat(pctotal*total*labinvoice_discountp*0.01);
					var labinvoice_disc = parseFloat(total*labinvoice_discountp*0.01);
					
					labinvoice_discarray[p].value = labinvoice_disc.toFixed(2);
				}
				
				calculaterowtotal(p);
			}
		}
	}
	
	function calculaterowtotal(indexpos){
		if(indexpos=='all'){
			var labinvoice_ratearray = document.getElementsByName("labinvoice_rate[]");
			var labinvoice_qtyarray = document.getElementsByName("labinvoice_qty[]");
			var labinvoice_discarray = document.getElementsByName("labinvoice_disc[]");
			var labinvoice_totalarray = document.getElementsByName("labinvoice_total[]");
			
			var labinvoice_gpccomissionarray = document.getElementsByName("labinvoice_gpccomission[]");
			var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
			
			if(labinvoice_ratearray.length>0){
				for(var p=0; p<labinvoice_ratearray.length; p++){
					var labinvoice_rate = parseFloat(labinvoice_ratearray[p].value);
					if(labinvoice_rate=='' || isNaN(labinvoice_rate)){labinvoice_rate = 0;}
					
					var labinvoice_gpccomission = parseFloat(labinvoice_gpccomissionarray[p].value);
					if(labinvoice_gpccomission=='' || isNaN(labinvoice_gpccomission)){labinvoice_gpccomission = 0;}
					
					var labinvoice_qty = parseFloat(labinvoice_qtyarray[p].value);
					if(labinvoice_qty=='' || isNaN(labinvoice_qty)){labinvoice_qty = 0;}
										
					var pctotal = parseFloat(labinvoice_gpccomission*labinvoice_qty);
 					var total = parseFloat(labinvoice_rate*labinvoice_qty);
					
					var labinvoice_disc = parseFloat(labinvoice_discarray[p].value);
					if(labinvoice_disc=='' || isNaN(labinvoice_disc)){labinvoice_disc = 0;}
					
					var pctotal = parseFloat(pctotal-labinvoice_disc);
					var total = parseFloat(total-labinvoice_disc);
					
					labinvoice_pccomissionarray[p].value = pctotal.toFixed(2);
 					labinvoice_totalarray[p].value = total.toFixed(2);
					
					
					//var labinvoice_pccomission = parseFloat(labinvoice_pccomission-labinvoice_gpccomission);
					//labinvoice_gpccomissionarray[p].value = labinvoice_pccomission.toFixed(2);

					}
				//calculate_discountp(p);
			}
		}
		else{
			var labinvoice_ratearray = document.getElementsByName("labinvoice_rate[]");
			var labinvoice_rate = parseFloat(labinvoice_ratearray[indexpos].value);
			if(labinvoice_rate=='' || isNaN(labinvoice_rate)){labinvoice_rate = 0;}
			
			var labinvoice_gpccomissionarray = document.getElementsByName("labinvoice_gpccomission[]");
			var labinvoice_gpccomission = parseFloat(labinvoice_gpccomissionarray[indexpos].value);
			if(labinvoice_gpccomission=='' || isNaN(labinvoice_gpccomission)){labinvoice_gpccomission = 0;}
			
			var labinvoice_qtyarray = document.getElementsByName("labinvoice_qty[]");
			var labinvoice_qty = parseFloat(labinvoice_qtyarray[indexpos].value);
			if(labinvoice_qty=='' || isNaN(labinvoice_qty)){labinvoice_qty = 0;}
			
			var pctotal = parseFloat(labinvoice_gpccomission*labinvoice_qty);
			var total = parseFloat(labinvoice_rate*labinvoice_qty);
			
			var labinvoice_discarray = document.getElementsByName("labinvoice_disc[]");
			var labinvoice_disc = parseFloat(labinvoice_discarray[indexpos].value);
			if(labinvoice_disc=='' || isNaN(labinvoice_disc)){labinvoice_disc = 0;}
			
			var pctotal = parseFloat(pctotal-labinvoice_disc);
			var total = parseFloat(total-labinvoice_disc);
			
			var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
			labinvoice_pccomissionarray[indexpos].value = pctotal.toFixed(2);
			
			var labinvoice_totalarray = document.getElementsByName("labinvoice_total[]");
			labinvoice_totalarray[indexpos].value = total.toFixed(2);
			
		}
		
		calculate_total();
	}
	
	function calculate_total(){
		var labinvoice_subtotal = 0;
		var labinvoice_totalarray = document.getElementsByName("labinvoice_total[]");
		if(labinvoice_totalarray.length>0){
			for(var p=0; p<labinvoice_totalarray.length; p++){
				var labinvoice_total = parseFloat(labinvoice_totalarray[p].value);
				if(labinvoice_total=='' || isNaN(labinvoice_total)){labinvoice_total = 0;}
				labinvoice_subtotal = parseFloat(labinvoice_subtotal+labinvoice_total);
			}
		}
		//subtotal calculation
		document.getElementById("labinvoice_subtotal").value = labinvoice_subtotal.toFixed(2);
		
		
		// emergency added
		var emergencyp = parseFloat(document.getElementById("emergencyp").value);
		if(emergencyp=='' || isNaN(emergencyp)){emergencyp = 0;}
		
		var emergency = parseFloat(document.getElementById("emergency").value);
		if(emergency=='' || isNaN(emergency)){emergency = 0;}
		
		if(emergencyp>0){
			var emergency = parseFloat(labinvoice_subtotal*emergencyp*0.01);
			document.getElementById('emergency').value= emergency;
		}
		//Emergency end
		
		
		var labinvoice_totaldiscp = parseFloat(document.getElementById("labinvoice_totaldiscp").value);
		if(labinvoice_totaldiscp=='' || isNaN(labinvoice_totaldiscp)){labinvoice_totaldiscp = 0;}
		
		var labinvoice_totaldisc = parseFloat(document.getElementById("labinvoice_totaldisc").value);
		if(labinvoice_totaldisc=='' || isNaN(labinvoice_totaldisc)){labinvoice_totaldisc = 0;}
		
		var labinvoice_totaldisc2 = parseFloat(document.getElementById("labinvoice_totaldisc2").value);
		if(labinvoice_totaldisc2=='' || isNaN(labinvoice_totaldisc2)){labinvoice_totaldisc2 = 0;}
		
		if(labinvoice_totaldiscp>0){
			var labinvoice_totaldisc = parseFloat(labinvoice_subtotal*labinvoice_totaldiscp*0.01);
			document.getElementById('labinvoice_totaldisc').value= labinvoice_totaldisc+labinvoice_totaldisc2;
		}
		// discount % count start
		if(labinvoice_totaldisc>0){
			var labinvoice_totaldiscp2 = parseFloat(labinvoice_totaldisc/labinvoice_subtotal*100);
			document.getElementById('labinvoice_totaldiscp2').value= labinvoice_totaldiscp2;
		}
		// discount % count end
		
		var labinvoice_subtotalafterdisc = parseFloat(labinvoice_subtotal-labinvoice_totaldisc-labinvoice_totaldisc2+emergency);
		document.getElementById('labinvoice_subtotalafterdisc').value=	labinvoice_subtotalafterdisc.toFixed(2);
			
		var labinvoice_receiveamount = parseFloat(document.getElementById("labinvoice_receiveamount").value);
		if(labinvoice_receiveamount=='' || isNaN(labinvoice_receiveamount)){labinvoice_receiveamount = 0;}
		
		var labinvoice_due = parseFloat(labinvoice_subtotalafterdisc-labinvoice_receiveamount);
		document.getElementById('labinvoice_due').value=labinvoice_due.toFixed(2);		
		
		// net total er 20% pc pabe
		var labinvoice_totalpccomission = parseFloat(labinvoice_subtotalafterdisc*0.2);
		document.getElementById('labinvoice_totalpccomission').value= labinvoice_totalpccomission;
		
		
		var varTDShowTotalAmount1 = document.getElementById("labinvoice_subtotalafterdisc").value;
		document.getElementById("tdShowTotalAmount1").innerHTML = varTDShowTotalAmount1;
		
		//var varTDShowTotalAmount2 = document.getElementById("labinvoice_totaldiscp2").value;
		//document.getElementById("tdShowTotalAmount2").innerHTML = varTDShowTotalAmount2;

		
		//pc comission  percentage...
		
		var labinvoice_totalpccomission = document.getElementById("labinvoice_totalpccomission").value;
		if(labinvoice_totalpccomission=='' || isNaN(labinvoice_totalpccomission)){labinvoice_totalpccomission = 0;}
		
		labinvoice_totalpccomission_percent = ((labinvoice_totalpccomission*100)/labinvoice_subtotal);
		document.getElementById('labinvoice_totalpccomission_percent').value=labinvoice_totalpccomission_percent;
		//pc comission percentage...
 		var labinvoice_totalpccomission = 0;
		var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
		if(labinvoice_pccomissionarray.length>0){
			for(var p=0; p<labinvoice_pccomissionarray.length; p++){
				var labinvoice_pccomission = parseFloat(labinvoice_pccomissionarray[p].value);
				if(labinvoice_pccomission=='' || isNaN(labinvoice_pccomission)){labinvoice_pccomission = 0;}
				labinvoice_totalpccomission = parseFloat((labinvoice_totalpccomission+labinvoice_pccomission));
 			}
		}
		
		//disc amount not less from pc
		//document.getElementById("labinvoice_totalpccomission").value = labinvoice_totalpccomission;
		
		//disc 50% less from pc
 		//document.getElementById("labinvoice_totalpccomission").value = labinvoice_totalpccomission-labinvoice_totaldisc/2;
 		
		//disc 100% less from pc
 		//document.getElementById("labinvoice_totalpccomission").value = labinvoice_totalpccomission-labinvoice_totaldisc;
 		
		 
		// Discount (dr, pc: 100%)
		var labinvoice_totalpccomission = 0;
		var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
		if(labinvoice_pccomissionarray.length>0){
			for(var p=0; p<labinvoice_pccomissionarray.length; p++){
				var labinvoice_pccomission = parseFloat(labinvoice_pccomissionarray[p].value);
				if(labinvoice_pccomission=='' || isNaN(labinvoice_pccomission)){labinvoice_pccomission = 0;}
				labinvoice_totalpccomission = parseFloat((labinvoice_totalpccomission+labinvoice_pccomission));
			if(labinvoice_totaldiscp>0){
			//document.getElementById("labinvoice_totalpccomission").value = labinvoice_totalpccomission-labinvoice_totaldisc;
				}
			}
		}
		// end 21-08-16
		
		// dr comission
		// new 21-08-16
		var labinvoice_totaldrcomission = 0;
		var labinvoice_drcomissionarray = document.getElementsByName("labinvoice_drcomission[]");
		if(labinvoice_drcomissionarray.length>0){
			for(var m=0; m<labinvoice_drcomissionarray.length; m++){
				var labinvoice_drcomission = parseFloat(labinvoice_drcomissionarray[m].value);
				if(labinvoice_drcomission=='' || isNaN(labinvoice_drcomission)){labinvoice_drcomission = 0;}
				
			labinvoice_totaldrcomission = parseFloat((labinvoice_totaldrcomission+labinvoice_drcomission));
			//labinvoice_totalpccomission = parseFloat(labinvoice_totalpccomission);
			if(labinvoice_totaldiscp>0){
			var labinvoice_totaldisc = parseFloat(labinvoice_totaldrcomission*labinvoice_totaldiscp*0.01);
			//document.getElementById('labinvoice_totaldisc').value= labinvoice_totaldisc;
				}
			}
		}
		document.getElementById("labinvoice_totaldrcomission").value = labinvoice_totaldrcomission;
		// end 21-08-16
		
 	}
	

	function calculate_pctotal(){
		var labinvoice_totalpccomission = 0;
		var labinvoice_pccomissionarray = document.getElementsByName("labinvoice_pccomission[]");
		if(labinvoice_pccomissionarray.length>0){
			for(var p=0; p<labinvoice_pccomissionarray.length; p++){
				var labinvoice_pccomission = parseFloat(labinvoice_pccomissionarray[p].value);
				if(labinvoice_pccomission=='' || isNaN(labinvoice_pccomission)){labinvoice_pccomission = 0;}
				labinvoice_totalpccomission = parseFloat(labinvoice_totalpccomission+labinvoice_pccomission);
				}
			}
		document.getElementById("labinvoice_totalpccomission").value = labinvoice_totalpccomission;
		calculate_total();
						
		}
	
	function calculate_drtotal(){
		var labinvoice_totaldrcomission = 0;
		var labinvoice_drcomissionarray = document.getElementsByName("labinvoice_drcomission[]");
		if(labinvoice_drcomissionarray.length>0){
			for(var m=0; m<labinvoice_drcomissionarray.length; m++){
				var labinvoice_drcomission = parseFloat(labinvoice_drcomissionarray[m].value);
				if(labinvoice_drcomission=='' || isNaN(labinvoice_drcomission)){labinvoice_drcomission = 0;}
				labinvoice_totaldrcomission = parseFloat(labinvoice_totaldrcomission+labinvoice_drcomission);
			}
		}
		
		document.getElementById("labinvoice_totaldrcomission").value = labinvoice_totaldrcomission;
		
	}
	
	
	
	function check_particular(){
		
		return true;
	}
	function addnew_particularrow(animate) {
		if(check_particular()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" style=\"BORDER-COLLAPSE: collapse; border:2px solid #FFF\" bgcolor=\"#c0d2ff\" align=\"left\" width=\"<?php echo $printdata_address3;?>\" border=\"0\" cellspacing=\"1\" cellpadding=\"4\">"+
							'<tr>'+
								'<td align="right">Test Name</td>'+
								'<td><input type="text" name="labinvoice_itemT[]" class="tdclasss itemname labinvoice_item" autocomplete="off" /></td>'+
								'<input type="hidden" readonly name="labinvoice_item[]" class="tdclasss"/>'+
								'<input type="hidden" name="labitem_id[]" id="labitem_id" class="tdclass itemname" />'+
								'<input type="hidden" name="labinvoice_group[]" class="tdclass" />'+
								'<input type="hidden" name="labinvoice_category[]" class="tdclass" />'+
								'<input type="hidden" name="category[]" class="tdclass" />'+
								'<input type="hidden" name="note[]" class="tdclass" />'+
								'<input type="hidden" name="orderby[]" class="tdclass" />'+
								'<input type="hidden" name="reportname[]" class="tdclass" />'+
								'<input type="hidden" name="labinvoice_sample[]" class="tdclass" />'+
								'<input type="hidden" name="machine_name[]" class="tdclass" />'+
								'<input type="hidden" name="labinvoice_unit[]" class="tdclass" />'+
								'<input type="hidden" name="labinvoice_refvalue[]" class="tdclass" />'+
 								'<input type="hidden" name="labitem_reagent[]" class="tdclass" />'+
								'<input type="hidden" name="labitem_reagentid[]" class="tdclass" />'+
								'<input type="hidden" name="reagentqty[]" class="tdclass" />'+
								 											 
								'<td align="right">Rate</td>'+
								"<td><textarea type=\"text\" style=\"height:16px; width:60px;\" name=\"labinvoice_rate[]\" id=\"labinvoice_rate\" class=\"tdclasssale numeric\" onKeyUp=\"calculaterowtotal('all');\"/></textarea></td>"+											 
								'<!--<td align="right">Qty</td>-->'+
								"<input type=\"hidden\" name=\"labinvoice_qty[]\" id=\"labinvoice_qty\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\"/>"+
								
								'<td align="right">RfCG</td>'+
								'<td><textarea type="text" readonly style="height:16px; width:60px;" name="labinvoice_gpccomission[]" class="tdclasssale" onKeyUp="calculate_pctotal();" /></textarea></td>'+
								
								'<td align="right">Disc%</td>'+
								'<td><textarea type="text" style="height:16px; width:60px;" name="labinvoice_discountp[]" class="tdclasssale" onKeyUp="calculate_discountp();"/></textarea></td>'+
								'<td align="right">Disc</td>'+
								"<td><textarea type=\"text\" style=\"height:16px; width:60px;\" name=\"labinvoice_disc[]\" class=\"tdclasssale\" onKeyUp=\"calculaterowtotal('all');\" /></textarea></td>"+
								'<td align="right">RfC</td>'+
								'<td><textarea readonly type="text" style="height:16px; width:60px;" name="labinvoice_pccomission[]" class="tdclasssale" onKeyUp="calculate_pctotal();" /></textarea></td>'+
								'<!--<td align="right">Dr.</td>-->'+
								'<td><input type="hidden" name="labinvoice_drcomission[]" class="tdclasssale" onKeyUp="calculate_pctotal();" /></td>'+
								'<td align="right">Total</td>'+
								'<td><input type="text" readonly name="labinvoice_total[]" id="labinvoice_total" class="tdclasssale" /></td>'+												
								"<td align=\"right\">R.Date<input type=\"text\" size=\"6\" name=\"labinvoice_reportdate[]\" id=\"labinvoice_reportdate2\" value=\"<?php echo date('Y-m-d');?>\" /><img src=\"images/cal.gif\" onClick=\"javascript:NewCssCal('labinvoice_reportdate2');\" style=\"cursor:pointer\"/></td>"+	
																		
								'<td><input type="text" size="5" name="labinvoice_reporttime[]" id="labinvoice_reporttime" value="<?php echo date('h:i:s', $endTime);?>" /></td>'+												
								'<td>'+
								 "<input type=\"button\" value=\"Del\" onClick=\"deletethislistrow('particularlistrowno"+particular_rowcount+"');\" class=\"tdclasssale\" />"+
								'</td>'+
							  '</tr>'+
						"</table>";
						
			var $newparticularlist = $("<li></li>").html(newrow);
										
			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(200); 
			else 
			   $newparticularlist.show();   
			 document.getElementsByName("labinvoice_itemT[]")[parseInt(particular_rowcount-1)].focus();
			
			$( ".itemname" ).autocomplete({
				minLength: 1,
				source: itemdata,
				focus: function( event, ui ) {
 					return false;
				},
				select: function( event, ui ) {
				
				//Start duplicate Item Entry Check//	
			    var itemIdArray = document.getElementsByName("labitem_id[]");
				var itemQtyArray = document.getElementsByName("labinvoice_qty[]");
					//==============================Check Duplicate Id=============================//
					if(itemIdArray.length>0){
						for(var l=0; l<itemIdArray.length; l++){
							var olditem_id = itemIdArray[l].value;
							if(olditem_id !=''){
								if( ui.item.labitem_id == olditem_id){
									/*var qtyVal = parseInt(itemQtyArray[l].value);
									if(qtyVal=='' || isNaN(qtyVal)){qtyVal = 0;}
									qtyVal++;
									itemQtyArray[l].value = qtyVal;
									calculateCurrentRowTotal(l);*/
									$(this).val('');
									$(this).focus();
									alert("Duplicate item found.");
									return false;
								}
							}
						}
					}
					
					//End duplicate Item Entry Check//
					
 					
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				var labitem_idarray = document.getElementsByName("labitem_id[]");
				labitem_idarray[indexpos].value = ui.item.labitem_id;
				
					var labinvoice_itemarray = document.getElementsByName("labinvoice_item[]");
					labinvoice_itemarray[indexpos].value = ui.item.labitem_name;
					
				var labinvoice_ratearray = document.getElementsByName("labinvoice_rate[]");
				labinvoice_ratearray[indexpos].value = ui.item.labitem_price;

				var labinvoice_qtyarray = document.getElementsByName("labinvoice_qty[]");
				labinvoice_qtyarray[indexpos].value = 1;

				var labinvoice_gpccomissionarray = document.getElementsByName("labinvoice_gpccomission[]");
				labinvoice_gpccomissionarray[indexpos].value = ui.item.labitem_pccommission;

				var labinvoice_drcomissionarray = document.getElementsByName("labinvoice_drcomission[]");
				labinvoice_drcomissionarray[indexpos].value = ui.item.labitem_drcommission;

				var labinvoice_grouparray = document.getElementsByName("labinvoice_group[]");
				labinvoice_grouparray[indexpos].value = ui.item.labitem_group;
				
				var labinvoice_categoryarray = document.getElementsByName("labinvoice_category[]");
				labinvoice_categoryarray[indexpos].value = ui.item.labitem_category;
				
				var reportnamearray = document.getElementsByName("reportname[]");
				reportnamearray[indexpos].value = ui.item.reportname;

				var labinvoice_samplearray = document.getElementsByName("labinvoice_sample[]");
				labinvoice_samplearray[indexpos].value = ui.item.labitem_sample;
				
				var categoryarray = document.getElementsByName("category[]");
				categoryarray[indexpos].value = ui.item.category;
				
				var notearray = document.getElementsByName("note[]");
				notearray[indexpos].value = ui.item.note;
				
				var orderbyarray = document.getElementsByName("orderby[]");
				orderbyarray[indexpos].value = ui.item.orderby;
				
				var machine_namearray = document.getElementsByName("machine_name[]");
				machine_namearray[indexpos].value = ui.item.machine_name;

				var labinvoice_unitarray = document.getElementsByName("labinvoice_unit[]");
				labinvoice_unitarray[indexpos].value = ui.item.labitem_unit;

				var labinvoice_refvaluearray = document.getElementsByName("labinvoice_refvalue[]");
				labinvoice_refvaluearray[indexpos].value = ui.item.labitem_refvalue;
				// reagent......
				var labitem_reagentarray = document.getElementsByName("labitem_reagent[]");
				labitem_reagentarray[indexpos].value = ui.item.labitem_reagent;
				
				var labitem_reagentidarray = document.getElementsByName("labitem_reagentid[]");
				labitem_reagentidarray[indexpos].value = ui.item.labitem_reagentid;
				
 				var reagentqtyarray = document.getElementsByName("reagentqty[]");
				reagentqtyarray[indexpos].value = ui.item.reagentqty;
	
					calculaterowtotal(indexpos);
					calculate_pctotal();
					calculate_drtotal();
					addnew_particularrow(true);   //automatic add next row
					return false;
				}
			});	

			$( ".labinvoice_item" ).keypress(function(keyname) {
			if(keyname.which==13){
				var imei = $(this).val();
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();

				$.each(itemarraydata, function(key, value){
					var valuearray = value.split('||');
					if(key==imei){
						document.getElementsByName("labitem_id[]")[indexpos].value = valuearray[0];
						//document.getElementsByName("salesinvoice_item[]")[indexpos].value = valuearray[1];
						document.getElementsByName("labinvoice_category[]")[indexpos].value = valuearray[1];
						document.getElementsByName("labinvoice_unit[]")[indexpos].value = valuearray[2];
						document.getElementsByName("labinvoice_refvalue[]")[indexpos].value = valuearray[3];
						document.getElementsByName("labinvoice_rate[]")[indexpos].value = valuearray[4];
						document.getElementsByName("labinvoice_reagent[]")[indexpos].value = valuearray[5];
						document.getElementsByName("labinvoice_pccomission[]")[indexpos].value = valuearray[6];
						document.getElementsByName("labinvoice_drcomission[]")[indexpos].value = valuearray[7];
						document.getElementsByName("labinvoice_qty[]")[indexpos].value = 1;

						calculaterowtotal(indexpos);
						addnew_particularrow(true);
					}
				});
				return false;
			}
		});				
		}
	}

	function deletethislistrow(tableidname){
		$("#"+tableidname).parent("li").slideUp(200, function() {
			$(this).remove();
			calculaterowtotal('all');
		});
	}
	
// prevent multi times save


function checkcontactform(){
		var labinvoice_mobile = document.getElementById("labinvoice_mobile");
		var error_labinvoice_mobile = document.getElementById("error_labinvoice_mobile");
		error_labinvoice_mobile.innerHTML = '';
		if(labinvoice_mobile.value==''){
			error_labinvoice_mobile.innerHTML = "Number is missing.";
			labinvoice_mobile.focus();
			return false;
		}
		else if(labinvoice_mobile.value.length<10){
			error_labinvoice_mobile.innerHTML = "Number should be 11 Digit.";
			labinvoice_mobile.focus();
			return false;
		}
		
		
		var labinvoice_totaldiscp = document.getElementById("labinvoice_totaldiscp");
		var error_labinvoice_totaldiscp = document.getElementById("error_labinvoice_totaldiscp");
		error_labinvoice_totaldiscp.innerHTML = '';
		if(labinvoice_totaldiscp.value==''){
			error_labinvoice_totaldiscp.innerHTML = "Disc is missing.";
			labinvoice_totaldiscp.focus();
			return false;
		}
		else if(labinvoice_totaldiscp.value>50){
			error_labinvoice_totaldiscp.innerHTML = "Disc should be less than 10%";
			labinvoice_totaldiscp.focus();
			return false;
		}
		
		
		var labinvoice_totaldisc = document.getElementById("labinvoice_totaldisc");
		var error_labinvoice_totaldisc = document.getElementById("error_labinvoice_totaldisc");
		error_labinvoice_totaldisc.innerHTML = '';
		if(labinvoice_totaldisc.value==''){
			error_labinvoice_totaldisc.innerHTML = "Disc is missing.";
			labinvoice_totaldisc.focus();
			return false;
		}
		else if(labinvoice_totaldisc.value>3000){
			error_labinvoice_totaldisc.innerHTML = "Disc should be greater than 1000";
			labinvoice_totaldisc.focus();
			return false;
		}
		
		//pc Discount 
		var labinvoice_totalpccomission = document.getElementById("labinvoice_totalpccomission");
		var error_labinvoice_totalpccomission = document.getElementById("error_labinvoice_totalpccomission");
		error_labinvoice_totalpccomission.innerHTML = '';
		if(labinvoice_totalpccomission.value==''){
			error_labinvoice_totalpccomission.innerHTML = "PC comission is missing.";
			labinvoice_totalpccomission.focus();
			return false;
		}
		else if(labinvoice_totalpccomission.value<1){
			error_labinvoice_totalpccomission.innerHTML = "Disc amount should not be bigger than PC amount";
			labinvoice_totalpccomission.focus();
			return false;
		}
		
		return true;

	}
	
	
	function checkcontactform2(){
	
 	//var error_labinvoice_totaldisc = document.getElementById("error_labinvoice_totaldisc");
	var error_labinvoice_totalpccomission = document.getElementById("error_labinvoice_totalpccomission");
 	error_labinvoice_totalpccomission.innerHTML = '';
		if(labinvoice_totalpccomission.value==''){
			error_labinvoice_totalpccomission.innerHTML = "0";
			labinvoice_totalpccomission.focus();
			return false;
		}
 	else if (labinvoice_totalpccomission.value<0 )
		{
		error_labinvoice_totalpccomission.innerHTML = "Disc amount should not be bigger than PC amount"
		labinvoice_totalpccomission.focus();
		return false;
		}
	
	
	/*var labinvoice_subtotalafterdisc = document.getElementById("labinvoice_subtotalafterdisc").value;
		if(labinvoice_subtotalafterdisc=='' || isNaN(labinvoice_subtotalafterdisc)){labinvoice_subtotalafterdisc = 0;}
		
	var error_labinvoice_totaldisc = document.getElementById("error_labinvoice_totaldisc");
	var error_labinvoice_subtotalafterdisc = document.getElementById("error_labinvoice_subtotalafterdisc");
		error_labinvoice_totaldisc.innerHTML = '';
		if(labinvoice_totaldisc.value==''){
			error_labinvoice_totaldisc.innerHTML = "0";
			labinvoice_totaldisc.focus();
			return false;
		}
		else if(labinvoice_totaldisc.value> labinvoice_subtotalafterdisc.innerHTML ){
			error_labinvoice_totaldisc.innerHTML = "Disc should be greater than 1000";
			labinvoice_totaldisc.focus();
			return false;
		}*/
		
		
		
		
 	return true;
 	}
	
		
/*function funcSaveBill1()
	{
	
	var varUserChoice; 
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet); 
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		//document.frmcontact1.submit();
		//return true;
	}
}*/
</script>