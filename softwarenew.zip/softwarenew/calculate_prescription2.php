﻿<script language="JavaScript" type="text/javascript">
	
	var labitemdataarray = <?php echo $labitemdataarray;?>;
	var labitemdata = <?php echo $labitemdata;?>;
	var itemdata = <?php echo $itemdata;?>;
	var complainitemdata = <?php echo $complainitemdata;?>;
	var diagnosisitemdata = <?php echo $diagnosisitemdata;?>;
	var patientdata = <?php echo $patientdata;?>;
	
	var labitemarraydata = labitemdataarray;
	
	$(document).ready(function($) {
		document.getElementsByName("medicine_name[]")[0].focus();
		document.getElementsByName("lab_item[]")[0].focus();
		document.getElementsByName("complain_name[]")[0].focus();
		document.getElementsByName("diagnosis_name[]")[0].focus();

		$( ".itemname" ).autocomplete({
			
			minLength: 1,
			source: itemdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				document.getElementsByName("salesitem_stock[]")[indexpos].value = ui.item.salesitem_stock;
				document.getElementsByName("medicine_id[]")[indexpos].value = ui.item.salesitem_id;
				
				return false;
			}
		});
		
	
		$( ".labitemname" ).autocomplete({
			
			minLength: 1,
			source: labitemdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				return false;
			}
		});
		
		$( ".diagnosisitemname" ).autocomplete({
			
			minLength: 1,
			source: diagnosisitemdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				return false;
			}
		});
		
		
		$( ".complainitemname" ).autocomplete({
			
			minLength: 1,
			source: complainitemdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.labelval );
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				return false;
			}
		});
		
		
		$( "#patient_code" ).autocomplete({
			
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				//$( "#search_item_number" ).val( ui.item.labelval );
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('patient_id').value = ui.item.opregistration_id;
				 document.getElementById('patient_name').value = ui.item.labelval;
				 document.getElementById('patient_age').value = ui.item.opregistration_age;
				 document.getElementById('patient_gender').value = ui.item.opregistration_gender;
				 document.getElementById('patient_mobile').value = ui.item.opregistration_mobile;
				 document.getElementById('patient_address').value = ui.item.opregistration_address;
				
				return false;
			}
		});
		
		
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
		
		
		$( ".medicine_name" ).keypress(function(keyname) {
			if(keyname.which==13){
				var imei = $(this).val();
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				$.each(itemarraydata, function(key, value){
					var valuearray = value.split('||');
					if(key==imei){
						document.getElementsByName("salesitem_id[]")[indexpos].value = valuearray[0];
						//document.getElementsByName("medicine_id[]")[indexpos].value = ui.item.medicine_id;
						addnew_particularrow(true);
					}
				});
				return false;
			}
		});
		
		$( ".complain_name" ).keypress(function(keyname) {
			if(keyname.which==13){
				var imei = $(this).val();
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				$.each(complainitemarraydata, function(key, value){
					var valuearray = value.split('||');
					if(key==imei){
						document.getElementsByName("autonumber[]")[indexpos].value = valuearray[0];
						addnew_particularrow1(true);
					}
				});
				return false;
			}
		});
		
		
		$( ".diagnosis_name" ).keypress(function(keyname) {
			if(keyname.which==13){
				var imei = $(this).val();
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				$.each(diagnosisitemarraydata, function(key, value){
					var valuearray = value.split('||');
					if(key==imei){
						document.getElementsByName("autonumber[]")[indexpos].value = valuearray[0];
						addnew_particularrow11(true);
					}
				});
				return false;
			}
		});
		
		
		$( ".lab_item" ).keypress(function(keyname) {
			if(keyname.which==13){
				var imei = $(this).val();
				var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
				
				$.each(labitemarraydata, function(key, value){
					var valuearray = value.split('||');
					if(key==imei){
						document.getElementsByName("labitem_id[]")[indexpos].value = valuearray[0];
						
						//calculaterowtotal(indexpos);
						addnew_particularrow2(true);
					}
				});
				return false;
			}
		});
	});
	
	
	
	function check_particular(){
		return true;
	}
	
	function addnew_particularrow(animate) {
		if(check_particular()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno"+particular_rowcount+"\" style=\"BORDER-COLLAPSE: collapse; border:2px solid #FFF\" bgcolor=\"#77F7AA\" align=\"left\" width=\"60%\" border=\"0\" cellspacing=\"1\" cellpadding=\"2\">"+
							'<tr>'+
								'<td align="right">Medicine</td>'+
								'<td><input type="text" name="medicine_name[]" id="medicine_name" class="tdclass itemname"/></td>'+
								'<td><input type="text" name="medicine_id[]" id="medicine_id" class="tdclass itemname"/></td>'+
								'<td><input type="text" name="salesitem_stock[]" id="salesitem_stock" size="5"/></td>'+
	
							'<td width="220"><label>Qty</label></td>'+
								 '<td>'+
								   '<select id="morning_qty" name="morning_qty[]" >'+
										'<option>1 vial IV slowly stat & daily</option>'+
										'<option>1 vial IV slowly stat & 12 hourly</option>'+
										'<option>1 amp IM stat & 12 hourly</option>'+
										'<option>1 amp IM stat & 8 hourly</option>'+
										'<option>1 amp IV very slowly stat & daily</option>'+
										'<option>1 amp IV slowly stat & SOS</option>'+
										'<option>1 amp IV slowly stat & 8 hourly</option>'+
										'<option>IV @ 30 drops/minute</option>'+
										'<option>১+০+১(ভরা পেটে খাবেন)</option>'+
										'<option>১+১+১(ভরা পেটে জ্বর থাকলে খাবেন)</option>'+
									   '<option>২+২+২(ভরা পেটে জ্বর থাকলে খাবেন)</option>'+
									   '<option>১+০+১(খাবার আধা ঘন্টা আগে খাবেন)</option>'+
									   '<option>১+০+০(খাবার এক ঘন্টা আগে খাবেন)</option>'+
									   '<option>০+০+১(খাবার এক ঘন্টা আগে খাবেন)</option>'+
									   '<option>১+১+১+১(খাবার দুই ঘন্টা আগে খাবেন)</option>'+
									   '<option>১+১+১(ভরা পেটে ব্যথা থাকলে খাবেন)</option>'+
									   '<option>১+০+১(খাবার মাঝ খানে খাবেন)</option>'+
									   '<option>এক চা চামুচ করে দিনে এক বার খাওয়াবেন</option>'+
									   '<option>দেড় চা চামুচ করে দিনে এক বার খাওয়াবেন</option>'+
										'<option>দুই চা চামুচ করে দিনে এক বার খাওয়াবেন</option>'+
										'<option>আড়াই চা চামুচ করে দিনে এক বার খাওয়াবেন</option>'+
										'<option>এক চা চামুচ করে দিনে তিন বার জ্বর থাকলে খাওয়াবেন</option>'+
										'<option>দেড় চা চামুচ করে দিনে তিন বার জ্বর থাকলে খাওয়াবেন</option>'+
										'<option>দুই চা চামুচ করে দিনে তিন বার জ্বর থাকলে খাওয়াবেন </option>'+
										'<option>আড়াই চা চামুচ করে দিনে তিন বার জ্বর থাকলে খাওয়াবেন</option>'+
										'<option>তিন চা চামুচ করে দিনে তিন বার জ্বর থাকলে খাওয়াবেন</option>'+
										'<option>এক চা চামুচ করে দিনে দুই বার খাওয়াবেন</option>'+
										'<option> দেড় চা চামুচ করে দিনে দুই বার খাওয়াবেন </option>'+
										'<option> দুই চা চামুচ করে দিনে দুই বার খাওয়াবেন</option>'+
										'<option>দুই চা চামুচ করে দিনে তিন বার খাওয়াবেন</option>'+
										'<option>........+.......+........(       ) চামড়ার নিচে খাবারের আধ ঘন্টা পূর্বে </option>'+
									'</select>'+
								'</td>'+
			
								'<!--<td align="right">Mor</td>-->'+
								'<!--<td align="right">Noon</td>-->'+
								'<td><input type="hidden" name="noon_qty[]" id="noon_qty" value="1" class="tdclasssale"/></td>'+
								'<!--<td align="right">Night</td>-->'+
								'<td><input type="hidden" name="evening_qty[]" id="evening_qty" value="1" class="tdclasssale"/></td>'+		
								'<td align="right">Note</td>'+
								"<td><input type=\"text\" name=\"note[]\" id=\"note\" class=\"tdclasssale5\"/></td>"+
								
							'<td width="220"><label>Duration</label></td>'+
							 '<td>'+
								'<select id="day" name="day[]" >'+
									'<option> </option>'+
									'<option>১ দিন </option>'+
                    '<option>৩ দিন</option>'+
                    '<option>৭ দিন</option>'+
                    '<option>১০ দিন</option>'+
                    '<option>১৪ দিন</option>'+
                    '<option>১৫ দিন </option>'+
                    '<option>১ মাস</option>'+
		     '<option>২ মাস</option>'+
		     '<option>৩ মাস</option>'+
			'<option>চলবে</option>'+
			'<option> দিন</option>'+
		     '<option> মাস</option>'+				'</select>'+
							'</td>'+
			
								'<td>'+
								 "<input type=\"button\" value=\"Cancel\" onClick=\"deletethislistrow('particularlistrowno"+particular_rowcount+"');\" class=\"tdclasssale\"/>"+
								'</td>'+
							  '</tr>'+
						"</table>";

			var $newparticularlist = $("<li></li>").html(newrow);

			$("#particularlist").append($newparticularlist.hide());
			if(animate) 
				$newparticularlist.slideDown(200); 
			else 
			   $newparticularlist.show();   
			document.getElementsByName("medicine_name[]")[parseInt(particular_rowcount-1)].focus();
			
			$( ".itemname" ).autocomplete({			
				minLength: 1,
				source: itemdata,
				focus: function( event, ui ) {
					//$( "#search_item_number" ).val( ui.item.labelval );
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					document.getElementsByName("salesitem_stock[]")[indexpos].value = ui.item.salesitem_stock;
					document.getElementsByName("medicine_id[]")[indexpos].value = ui.item.salesitem_id;
				
					return false;
				}
			});						
		}
	}
	function deletethislistrow(tableidname){
		$("#"+tableidname).parent("li").slideUp(200, function() {
			$(this).remove();
			calculaterowtotal('all');
		});
	}
	
	
	
	
	
	
	function check_particular1(){
		return true;
	}
	function addnew_particularrow1(animate) {
		if(check_particular1()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno1"+particular_rowcount+"\" style=\"BORDER-COLLAPSE: collapse; border:2px solid #FFF\" bgcolor=\"#B9B9FF\" align=\"left\" width=\"100%\" cellpadding=\"2\">"+
							'<tr>'+
								'<td align="right">Complain</td>'+
								'<td><input type="text" name="complain_name[]" id="complain_name" class="tdclass complainitemname complain_name"/></td>'+
															
								'<td>'+
								 "<input type=\"button\" value=\"Cancel\" onClick=\"deletethislistrow1('particularlistrowno1"+particular_rowcount+"');\" class=\"tdclasssale\"  />"+
								'</td>'+
							  '</tr>'+
						"</table>";
						
			var $newparticularlist1 = $("<li></li>").html(newrow);
										
			$("#particularlist1").append($newparticularlist1.hide());
			if(animate) 
				$newparticularlist1.slideDown(200); 
			else 
			   $newparticularlist1.show();   
			document.getElementsByName("complain_name[]")[parseInt(particular_rowcount-1)].focus();
			
			$( ".complainitemname" ).autocomplete({		
				minLength: 1,
				source: complainitemdata,
				focus: function( event, ui ) {
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					
					return false;
				}
			});						
		}
	}
	
	
	function deletethislistrow1(tableidname){
		$("#"+tableidname).parent("li").slideUp(200, function() {
			$(this).remove();
			calculaterowtotal('all');
		});
	}
	
	
	
	function check_particular11(){
		return true;
	}
	function addnew_particularrow11(animate) {
		if(check_particular11()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno11"+particular_rowcount+"\" style=\"BORDER-COLLAPSE: collapse; border:2px solid #FFF\" bgcolor=\"#B9B9FF\" align=\"left\" width=\"100%\" cellpadding=\"2\">"+
							'<tr>'+
								'<td align="right">Clinical Diagnosis</td>'+
								'<td><input type="text" name="diagnosis_name[]" id="diagnosis_name" class="tdclass diagnosisitemname diagnosis_name"/></td>'+
															
								'<td>'+
								 "<input type=\"button\" value=\"Cancel\" onClick=\"deletethislistrow11('particularlistrowno11"+particular_rowcount+"');\" class=\"tdclasssale\"  />"+
								'</td>'+
							  '</tr>'+
						"</table>";
						
			var $newparticularlist11 = $("<li></li>").html(newrow);
										
			$("#particularlist11").append($newparticularlist11.hide());
			if(animate) 
				$newparticularlist11.slideDown(200); 
			else 
			   $newparticularlist11.show();   
			document.getElementsByName("diagnosis_name[]")[parseInt(particular_rowcount-1)].focus();
			
			$( ".diagnosisitemname" ).autocomplete({		
				minLength: 1,
				source: diagnosisitemdata,
				focus: function( event, ui ) {
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					
					return false;
				}
			});						
		}
	}
	
	
	function deletethislistrow11(tableidname){
		$("#"+tableidname).parent("li").slideUp(200, function() {
			$(this).remove();
			calculaterowtotal('all');
		});
	}
	
	
	
	
	function check_particular2(){
		return true;
	}
	function addnew_particularrow2(animate) {
		if(check_particular2()==false){return false;}
		else{
			$("#errmsg_particular_id").html('');
			var particular_rowcount = $("ul#particularlist").children().length+1;
			var select_particular_list = '<?php echo $selectname_list;?>';
			var newrow = "<table id=\"particularlistrowno2"+particular_rowcount+"\" style=\"BORDER-COLLAPSE: collapse; border:2px solid #FFF\" bgcolor=\"#B9B9FF\" align=\"left\" width=\"100%\" border=\"0\" cellspacing=\"1\" cellpadding=\"2\">"+
							'<tr>'+
								'<td align="right">Test Name</td>'+
								'<td><input type="text" name="lab_item[]" id="lab_item" class="tdclass labitemname lab_item"/></td>'+
															
								'<td>'+
								 "<input type=\"button\" value=\"Cancel\" onClick=\"deletethislistrow2('particularlistrowno2"+particular_rowcount+"');\" class=\"tdclasssale\"  />"+
								'</td>'+
							  '</tr>'+
						"</table>";
						
			var $newparticularlist2 = $("<li></li>").html(newrow);
										
			$("#particularlist2").append($newparticularlist2.hide());
			if(animate) 
				$newparticularlist2.slideDown(200); 
			else 
			   $newparticularlist2.show();   
			document.getElementsByName("lab_item[]")[parseInt(particular_rowcount-1)].focus();
			
			$( ".labitemname" ).autocomplete({			
				minLength: 1,
				source: labitemdata,
				focus: function( event, ui ) {
					return false;
				},
				select: function( event, ui ) {
					$(this).val( ui.item.labelval );
					var indexpos = $(this).parent('td').parent('tr').parent('tbody').parent('table').parent('li').index();
					
					return false;
				}
			});	
			
		}
	}
	
	
	
	function deletethislistrow2(tableidname){
		$("#"+tableidname).parent("li").slideUp(200, function() {
			$(this).remove();
			calculaterowtotal('all');
		});
	}
</script>