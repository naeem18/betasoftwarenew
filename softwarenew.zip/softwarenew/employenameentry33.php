 <table align="center" width="100%" border="1" style="BORDER-COLLAPSE: collapse;" cellspacing="1" cellpadding="3">
  <tr>
    <td colspan="10" bgcolor="#0033FF" align="center" style="color:#fff; border:1px solid #03F;">
        <strong><?php echo $hospitaldata_name;?></strong><br>
        <strong>Attendance Import Information</strong>
    </td>
  </tr>
  <tr bgcolor="#ccc" align="center">
    <td>ID</td>
    <td>Name</td>
    <td>IN Time</td>
    <td>Out Time</td>
   </tr>

<?php
$mdObj = mysqli_query($conn, "SELECT * FROM machine_data, employee WHERE employee.e_id = machine_data.e_id AND machine_data.in_out>0");
$mdCount = mysqli_num_rows($mdObj);
if($mdCount>0){
	$attendanceData = $employeeDate = array();
	while($mdOneRow=mysqli_fetch_array($mdObj)){
		$employeeDate[$mdOneRow['e_id']][$mdOneRow['entry_date']] = $mdOneRow['name'];
		$attendanceData[$mdOneRow['entry_date']][] = array($mdOneRow['entry_date'], $mdOneRow['entry_time'], $mdOneRow['in_out']);
	}
	ksort($employeeDate);
	if(!empty($employeeDate)){
		foreach($employeeDate as $e_id=>$dateInfo){			
			foreach($dateInfo as $date=>$name){
				
				$inTime = $outTime = '';
				
				$empAttInfo = array();
				if(array_key_exists($date, $attendanceData)){$empAttInfo = $attendanceData[$date];}
				if(!empty($empAttInfo)){
					foreach($empAttInfo as $attOneRow){
						$entry_date = $attOneRow[0];
						$entry_time = $attOneRow[1];
						$in_out = $attOneRow[2];
						if($in_out==1){
							$inTime = "$entry_date $entry_time";
						}
						elseif($in_out==2){
							$outTime = "$entry_date $entry_time";
						}
					}
				}
				?>
				<tr bgcolor="#f2f2f2" align="left">
					<td><?php echo $e_id; ?></td>
					<td><?php echo $name; ?></td>
					<td><?php echo $inTime; ?></td>
					<td><?php echo $outTime; ?></td>
				</tr>
				<!--echo "<p>ID: $e_id, Name: $name, In-Time: $inTime, Out-Time: $outTime</p>";-->
				
			<?Php	
			}			
		}
	}
}

?>
 </table>