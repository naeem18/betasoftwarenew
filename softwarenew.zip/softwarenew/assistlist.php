<?php
//include ("labdd.php");
//date_default_timezone_set('Asia/Dhaka'); 
$searchstr='';
if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
{
	$transactiondatefrom = $_REQUEST['ADate1'];
	$transactiondateto = $_REQUEST['ADate2'];
	
	$doctor_name = $_REQUEST['doctor_name'];
	if($doctor_name !=''){
		$searchstr .= " and doctor_name like '%$doctor_name%'";
	}
}
else
{
	$transactiondatefrom = date('Y-m-d', strtotime('-1 year'));
	$transactiondateto = date('Y-m-d');
}
?>


<script language="javascript">
function cbcustomername1()
{
	document.cbform1.submit();
}
</script>

<script type="text/javascript">
window.onload = function ()
{
	var oTextbox = new AutoSuggestControl(document.getElementById("searchcustomername"), new StateSuggestions());        
}
</script>

<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td valign="top" align="center">
    	<form name="cbform1" method="post" action="index.php?p=assistlist">
            <table width="100%" border="0" align="center" cellpadding="4" cellspacing="0" bordercolor="#666666" id="AutoNumber3" style="border-collapse: collapse">
              <tbody>
                <tr bgcolor="#011E6A">
                  <td colspan="10" bgcolor="#CCCCCC" class="bodytext3"><strong>Search Date / Assist Nmae wise</strong></td>
                </tr>           
                <tr>
                    <td class="bodytext31" width="10%" valign="center"  align="right" bgcolor="#FFFFFF"> Date From&nbsp;:&nbsp;</td>
                    <td width="16%" align="left" valign="center"  bgcolor="#FFFFFF" class="bodytext30">
                        <input name="ADate1" id="ADate1" style="border: 1px solid #001E6A" value="<?php echo $transactiondatefrom; ?>"  size="10"  readonly="readonly" onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
                    </td>
                    <td width="10%" align="right" valign="center"  bgcolor="#FFFFFF" class="bodytext30"> Date To&nbsp;:&nbsp;</td>
                    <td width="16%" align="left" valign="center"  bgcolor="#FFFFFF">
                        <span class="bodytext31">
                            <input name="ADate2" id="ADate2" style="border: 1px solid #001E6A" value="<?php echo $transactiondateto; ?>"  size="10"  readonly="readonly" onKeyDown="return disableEnterKey()" />
                            <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate2')" style="cursor:pointer"/>
                        </span>
                    </td>
                    <td width="10%" align="right" valign="center"  bgcolor="#FFFFFF" class="bodytext30">By Name</td>
            	    <td width="10%" align="left" valign="center"  bgcolor="#FFFFFF"> <input type="text" name="doctor_name" id="doctor_name" value=""   /></td>
                    <td align="left" valign="top"  bgcolor="#FFFFFF">
                        <input type="hidden" name="cbfrmflag1" value="cbfrmflag1">
                        <input  style="border: 1px solid #001E6A" type="submit" value="Search" name="Submit" />
                        <input name="resetbutton" type="reset" id="resetbutton"  style="border: 1px solid #001E6A" value="Reset" />
                    </td>
                    <td width="10%" align="right" valign="top"  bgcolor="#FFFFFF">
                       <input name="print" type="button" id="print"  style="border: 1px solid #001E6A" value="Print" onClick="PrintDiv();" />
                    </td>
                </tr>
              </tbody>
            </table>
		</form>
       
   	</td>
</tr>

	<td>
    
		<?php 
		
		$datetime1 = new DateTime($transactiondatefrom);
		$datetime2 = new DateTime($transactiondateto);
		$interval = $datetime1->diff($datetime2);
		$totaldays = $interval->format('%a');
		if($datetime1<$datetime2){
			$fromdate = $transactiondatefrom;
			$todate = $transactiondateto;
		}
		else{
			$fromdate = $transactiondateto;
			$todate = $transactiondatefrom;
		}
		?>
        
        <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1" cellspacing="0" cellpadding="2">
        <tbody>
         <tr>
            <td colspan="19" bgcolor="#f2f2f2" align="center" style="color:#03F; border:1px solid #03F; padding-left:15px;">
            	<strong><?php echo $hospitaldata_name;?></strong><br>
                <samp>assist List :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></samp>
            </td>
          </tr>
            <tr>
            
               	<td width="10%" align="left" valign="center" bgcolor="#ffffff" class="bodytext31">
               		<strong>SL No.</strong>
           		</td>
                <td width="10%" align="left" valign="center" bgcolor="#ffffff" class="bodytext31">
               		<strong>ID No.</strong>
           		</td>
              	<td width="10%" align="left" valign="center" bgcolor="#ffffff" class="bodytext31">
                	<strong>Assist Name</strong>
              	</td>              
              	<td width="10%" align="left" valign="center" bgcolor="#ffffff" class="bodytext31">
                	<strong>Mobile</strong>
              	</td>
                <td width="10%" align="left" valign="center" bgcolor="#ffffff" class="bodytext31">
                	<strong>Address</strong>
              	</td>
                 <td width="10%" align="left" valign="center" bgcolor="#ffffff" class="bodytext31">
                	<strong>Edit/Delete</strong>
              	</td>         
              </tr>
		<?php
		$s='';
			
		for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
			$sqlst = "select * from doctorentry where doctor_category= 'assist' and  doctor_date between '$newfromdate' and '$newtodate' $searchstr order by doctor_id desc";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery &&  mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery)) {
					$doctor_id = $strow['doctor_id'];
                    $doctor_name = $strow['doctor_name'];
                    $doctor_mobile = $strow['doctor_mobile'];
                    $doctor_address = $strow['doctor_address'];
                    $doctor_date = $strow['doctor_date'];
					$action = "<a href=\"index.php?p=doctorentry&doctor_id=$doctor_id\">Edit</a> | 
				<a href=\"javascript:void(0)\" onclick=\"removetablerow('doctorentry', $doctor_id, 'pclist')\">Remove</a>";
			
					?>
				
                <tr>
                    <td bgcolor="#FFFFFF" class="bodytext31" valign="center"  align="left">
                        <samp><?php echo $s=$s+1; ?></samp>
                    </td>
                    <td bgcolor="#FFFFFF"  class="bodytext31" valign="center"  align="left">
                        <samp><?php echo $doctor_id; ?></samp>
                    </td>
                    <td bgcolor="#FFFFFF"  class="bodytext31" valign="center"  align="left">
                        <samp><?php echo $doctor_name; ?></samp>
                    </td>
                   <td bgcolor="#FFFFFF" class="bodytext31" valign="center"  align="left">
                       <samp> <?php echo $doctor_mobile; ?></samp>
                    </td>
                     <td bgcolor="#FFFFFF" class="bodytext31" valign="center"  align="left">
                       <samp> <?php echo $doctor_address; ?></samp>
                    </td>
                     <td bgcolor="#FFFFFF" class="bodytext31" valign="center"  align="left">
                       <samp> <?php echo $action; ?></samp>
                    </td>
              	</tr>
                <?php
                	}
				}
			}
		?>
        	
           <tbody>
        </table>
        </td>
      
<td align="center" id="divToPrint" style="display:none">
        
        <table align="center" style="BORDER-COLLAPSE: collapse" width="450" border="1" cellspacing="0" cellpadding="2">
        <tbody>
         <tr>
            <td colspan="19" bgcolor="#FFF" align="center" style="color:#000; border:1px solid #000; padding-left:15px;">
            	<strong><?php echo $hospitaldata_name;?></strong><br>
                <samp>Assist List :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></samp>
            </td>
          </tr>
             <tr>
               	<td width="10%" align="left" valign="center" bgcolor="#ffffff" class="bodytext31">
               		<strong>SL No.</strong>
           		</td>
                <td width="10%" align="left" valign="center" bgcolor="#ffffff" class="bodytext31">
               		<strong>ID No.</strong>
           		</td>
              	<td width="10%" align="left" valign="center" bgcolor="#ffffff" class="bodytext31">
                	<strong>Assist Name</strong>
              	</td>              
              	<td width="10%" align="left" valign="center" bgcolor="#ffffff" class="bodytext31">
                	<strong>Mobile</strong>
              	</td>
                <td width="10%" align="left" valign="center" bgcolor="#ffffff" class="bodytext31">
                	<strong>Address</strong>
              	</td> 
              </tr>
		<?php
			$s='';	
			$sqlst = "select * from doctorentry where doctor_category= 'assist' and  doctor_date between '$newfromdate' and '$newtodate' $searchstr order by doctor_id desc";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery &&  mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery)) {
					 $doctor_id = $strow['doctor_id'];
                    $doctor_name = $strow['doctor_name'];
                    $doctor_mobile = $strow['doctor_mobile'];
                    $doctor_address = $strow['doctor_address'];
                    $doctor_date = $strow['doctor_date'];
					?>
				
                <tr>
                    <td bgcolor="#FFFFFF" class="bodytext31" valign="center"  align="left">
                        <samp><?php echo $s=$s+1;?></samp>
                    </td>
                    <td bgcolor="#FFFFFF"  class="bodytext31" valign="center"  align="left">
                        <samp><?php echo $doctor_id; ?></samp>
                    </td>
                    
                    <td bgcolor="#FFFFFF"  class="bodytext31" valign="center"  align="left">
                        <samp><?php echo $doctor_name; ?></samp>
                    </td>
                    <td bgcolor="#FFFFFF" class="bodytext31" valign="center"  align="left">
                       <samp> <?php echo $doctor_mobile; ?></samp>
                    </td>
                     <td bgcolor="#FFFFFF" class="bodytext31" valign="center"  align="left">
                       <samp> <?php echo $doctor_address; ?></samp>
                    </td>
              	</tr>
                <?php
                	
				}
			}
		?>
        
             <tbody>
          </table>
        </td>
</table>