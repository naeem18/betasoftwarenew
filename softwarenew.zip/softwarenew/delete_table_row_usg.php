<?php
session_start();
if(isset($_GET['idvalue'])){	
	$idvalue = $_GET['idvalue'];
	if($idvalue>0){
		require('labdd.php');
 		// $str2 = "update labinvoicedetails set usgpaid = '2'
						// where usgpaid_id = '$idvalue'";
		 //$userquery = mysqli_query($conn, $str2);
		
		 $str = "update labinvoicedetails set usgpaid = '2'
							   where auto_number = '$idvalue'";
		 $userquery = mysqli_query($conn, $str);
		
		  
		if($userquery){			
			header("location:index.php?p=statementbylabtestusg&message=Update-successfully");			
		}
		else{
			header("location:index.php?p=$statementbylabtestusg&message=couldnotremove");
		}
	}
	else{
		header("location:index.php?p=statementbylabtestusg&message=incorrect_id");
	}
}
?>