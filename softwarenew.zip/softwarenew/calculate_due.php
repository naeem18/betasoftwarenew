<script language="JavaScript" type="text/javascript">
	
	var patientdata = <?php echo $patientdata;?>;
	$(document).ready(function($) {
		
		
		$( "#companyinvoice_name" ).autocomplete({
			
			minLength: 1,
			source: patientdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				
				 document.getElementById('companyid').value = ui.item.labelval;
				 document.getElementById('companyinvoice_number').value = ui.item.company_mobile;
				 document.getElementById('company_due').value = ui.item.company_due;
				 document.getElementById('companyinvoice_address').value = ui.item.company_address;
				
				return false;
			}
		});
		
			
		$( ".numeric" ).focus(function() {
			var price = $(this).val();
			if(price==0){
				$(this).val('');
			}
		});
		
		$( ".numeric" ).blur(function() {
			var price = $(this).val();
			if(price==''){
				$(this).val(0);
			}
		});
		
		$( ".numeric" ).keyup(function() {
			var price = $(this).val();
			var ValidChars = "-.0123456789";
			var IsNumber=true;
			var Char;
			var validint = '';
			for (var i = 0; i < price.length && IsNumber == true; i++){ 
				Char = price.charAt(i);
				if ((i==0 && Char==0) || ValidChars.indexOf(Char) == -1){}
				else{
					validint = validint+Char;
				}
			}
			$(this).val(validint);
		});
		
		
	});
	
		
	function calculate_total(){
		
		var company_due = parseFloat(document.getElementById("company_due").value);
		if(company_due=='' || isNaN(company_due)){company_due = 0;}
		
		var disc_amount = parseFloat(document.getElementById("disc_amount").value);
		if(disc_amount=='' || isNaN(disc_amount)){disc_amount = 0;}
			
		var paid_amount = parseFloat(document.getElementById("paid_amount").value);
		if(paid_amount=='' || isNaN(paid_amount)){paid_amount = 0;}
		
		var total_balance = parseFloat(company_due - disc_amount-paid_amount);
		document.getElementById('total_balance').value=	total_balance.toFixed(2);
		
		}
	
	function funcSaveBill1()
{
	
	var varUserChoice; 
	varUserChoice = confirm('Are You Sure Want To Save This Entry?'); 
	//alert(fRet); 
	if (varUserChoice == false)
	{
		alert ("Entry Not Saved.");
		return false;
	}
	else
	{
		alert ("Entry Saved.");
		document.frmsales.submit();
		//return true;
	}
}
</script>