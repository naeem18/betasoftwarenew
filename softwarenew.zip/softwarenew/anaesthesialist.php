<?php
 $searchstr='';
if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
{
	$transactiondatefrom = $_REQUEST['ADate1'];
	$transactiondateto = $_REQUEST['ADate2'];
	
	$doctor_name = $_REQUEST['doctor_name'];
	if($doctor_name !=''){
		$searchstr .= " and doctor_name like '%$doctor_name%'";
	}
}
else
{
	$transactiondatefrom = date('Y-m-d', strtotime('-1 year'));
	$transactiondateto = date('Y-m-d');
}
?>

<table width="100%" border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td valign="top" align="center">
    	<form name="cbform1" method="post" action="index.php?p=anaesthesialist">
            <table width="100%" border="0" align="center" cellpadding="4" cellspacing="0" bordercolor="#666666" style="border-collapse: collapse">
              <tbody>
                <tr bgcolor="#011E6A">
                  <td colspan="10" bgcolor="#CCCCCC"><strong>Search Date / Anaesthesia wise</strong></td>
                </tr>           
                <tr>
                    <td>Date From:</td>
                    <td>
                        <input name="ADate1" id="ADate1" style="border: 1px solid #001E6A" value="<?php echo $transactiondatefrom; ?>" size="10" readonly="readonly" onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
                    </td>
                    <td>Date To:</td>
                    <td>
                         <input name="ADate2" id="ADate2" style="border: 1px solid #001E6A" value="<?php echo $transactiondateto; ?>" size="10" readonly="readonly" onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate2')" style="cursor:pointer"/>
                     </td>
                    <td>By Name</td>
            	    <td><input type="text" name="doctor_name" id="doctor_name"/></td>
                    <td>
                        <input  style="border: 1px solid #001E6A" type="submit" value="Search" name="Submit" />
                     </td>
                    <td><input name="print" type="button" id="print" style="border: 1px solid #001E6A" value="Print" onClick="PrintDiv();" />
                    </td>
                </tr>
              </tbody>
            </table>
		</form>
    	</td>
</tr>

	<td>
 		<?php 
		$datetime1 = new DateTime($transactiondatefrom);
		$datetime2 = new DateTime($transactiondateto);
		$interval = $datetime1->diff($datetime2);
		$totaldays = $interval->format('%a');
		if($datetime1<$datetime2){
			$fromdate = $transactiondatefrom;
			$todate = $transactiondateto;
		}
		else{
			$fromdate = $transactiondateto;
			$todate = $transactiondatefrom;
		}
		?>
        
        <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1" cellspacing="0" cellpadding="2">
        <tbody>
         <tr>
            <td colspan="19" bgcolor="#f2f2f2" align="center" style="color:#03F; border:1px solid #03F;">
            	<strong><?php echo $hospitaldata_name;?></strong><br>
                <strong>Anaesthesia List :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></strong>
            </td>
          </tr>
            <tr>
                <td><strong>SL No.</strong></td>
               	<td>
                	<strong>Anaesthesia Name</strong>
              	</td>              
              	<td>
                	<strong>Mobile</strong>
              	</td>
                <td>
                	<strong>Address</strong>
              	</td>
                 <td>
                	<strong>Edit/Delete</strong>
              	</td>         
              </tr>
		<?php
		$s='';
			
		for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
			$sqlst = "select * from doctorentry where doctor_category= 'anaesthetist' and  doctor_date between '$newfromdate' and '$newtodate' $searchstr order by doctor_id desc";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery &&  mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery)) {
					$doctor_id = $strow['doctor_id'];
                    $doctor_name = $strow['doctor_name'];
                    $doctor_mobile = $strow['doctor_mobile'];
                    $doctor_address = $strow['doctor_address'];
                    $doctor_date = $strow['doctor_date'];
					$action = "<a href=\"index.php?p=doctorentry&doctor_id=$doctor_id\">Edit</a> | 
				<a href=\"javascript:void(0)\" onclick=\"removetablerow('doctorentry', $doctor_id, 'pclist')\">Remove</a>";
			
					?>
				
                <tr>
                    <td>
                        <?php echo $s=$s+1; ?>
                    </td>
                     <td>
                        <?php echo $doctor_name; ?>
                    </td>
                   <td>
                        <?php echo $doctor_mobile; ?>
                    </td>
                     <td>
                        <?php echo $doctor_address; ?>
                    </td>
                     <td>
                        <?php echo $action; ?>
                    </td>
              	</tr>
                <?php
                	}
				}
			}
		?>
        	
           <tbody>
        </table>
        </td>
      
<td align="center" id="divToPrint" style="display:none">
        <table align="center" style="BORDER-COLLAPSE: collapse" width="450" border="1" cellspacing="0" cellpadding="2">
        <tbody>
         <tr>
            <td colspan="19" bgcolor="#FFF" align="center" style="color:#000; border:1px solid #000;">
            	<strong><?php echo $hospitaldata_name;?></strong><br>
                Anaesthetist List :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?>
            </td>
          </tr>
             <tr>
               
               	<td>
               		<strong>SL No.</strong>
           		</td>
               	<td>
                	<strong>Anaesthesia Name</strong>
              	</td>              
              	<td>
                	<strong>Mobile</strong>
              	</td>
                <td>
                	<strong>Address</strong>
              	</td> 
                            
              </tr>
		<?php
			$s='';	
			$sqlst = "select * from doctorentry where doctor_category= 'anaesthetist' and  doctor_date between '$newfromdate' and '$newtodate' $searchstr order by doctor_id desc";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery &&  mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery)) {
					 $doctor_id = $strow['doctor_id'];
                    $doctor_name = $strow['doctor_name'];
                    $doctor_mobile = $strow['doctor_mobile'];
                    $doctor_address = $strow['doctor_address'];
                    $doctor_date = $strow['doctor_date'];
 					?>
				
                <tr>
                    <td><?php echo $s=$s+1;?></td>
                    <td><?php echo $doctor_name; ?></td>
                    <td><?php echo $doctor_mobile;?></td>
                    <td><?php echo $doctor_address; ?></td>
              	</tr>
                <?php
 				}
			}
		   ?>
          <tbody>
        </table>
      </td>
</table>