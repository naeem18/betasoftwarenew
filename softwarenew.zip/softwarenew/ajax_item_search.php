<?php

error_reporting(E_ALL);
ini_set('display_errors', 0);

include("labdd.php");

header('Content-Type: application/json; charset=utf-8');

$term = '';

if(isset($_GET['term'])){
    $term = trim($_GET['term']);
}

if($term == ''){
    echo json_encode(array());
    exit;
}

$term = mysqli_real_escape_string($conn, $term);


$sql = "

SELECT
    salesitem_id,
    bar,
    salesitem_name,
    salesitem_group,
    salesitem_category,
    salesitem_pack,
    salesitem_purchase_rate,
    salesitem_location,
    salesitem_price,
    salesitem_stock

FROM salesitem

WHERE salesitem_stock >= 0

AND
(
    bar LIKE '$term%'
    OR
    salesitem_name LIKE '$term%'
    OR
    salesitem_group LIKE '$term%'
)

ORDER BY

CASE

    WHEN bar='$term' THEN 1

    WHEN salesitem_name='$term' THEN 2

    WHEN bar LIKE '$term%' THEN 3

    WHEN salesitem_name LIKE '$term%' THEN 4

    WHEN salesitem_group LIKE '$term%' THEN 5

    ELSE 6

END,

salesitem_name ASC

LIMIT 20

";


$query = mysqli_query($conn, $sql);


if(!$query){

    echo json_encode(array());

    exit;
}


$data = array();


while($row = mysqli_fetch_assoc($query)){

    $data[] = array(

        /* Autocomplete dropdown text */

        "label" =>
            $row['salesitem_name']
            ." | "
            .$row['salesitem_group']
            ." | Stock : "
            .$row['salesitem_stock'],


        /* Select করার পর input-এ বসবে */

        "value" => $row['salesitem_name'],

        "labelval" => $row['salesitem_name'],


        "sii" => $row['salesitem_id'],

        "bar" => $row['bar'],

        "salesitem_name" => $row['salesitem_name'],

        "sig" => $row['salesitem_group'],

        "sic" => $row['salesitem_category'],

        "sip" => $row['salesitem_pack'],

        "sipr" => $row['salesitem_purchase_rate'],

        "sisl" => $row['salesitem_location'],

        "sisp" => $row['salesitem_price'],

        "sis" => $row['salesitem_stock']

    );

}


echo json_encode($data);

exit;

?>