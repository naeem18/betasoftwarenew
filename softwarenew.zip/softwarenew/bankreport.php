<?php
$searchstr='';
if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
{
	$transactiondatefrom = $_REQUEST['ADate1'];
	$transactiondateto = $_REQUEST['ADate2'];
	
	$user = $_REQUEST['user'];
	$bankinvoice_name = $_REQUEST['bankinvoice_name'];
	if($bankinvoice_name !=''){
		$searchstr .= " and bankinvoice_name like '%$bankinvoice_name%'";
	}
	
	elseif($user !=''){
		$searchstr .= " and user like '%$user%'";
	}
}
else
{
	$transactiondatefrom = date('Y-m-d', strtotime('-0 day'));
	$transactiondateto = date('Y-m-d');
}
?>

<table width="100%" border="0" cellspacing="0" cellpadding="2">
 
  <tr>
    <td valign="top" align="center">
    	<form name="cbform1" method="post" action="index.php?p=bankreport">
            <table width="100%" border="1" align="center" cellpadding="4" bgcolor="#FFFFFF" cellspacing="0" bordercolor="#666666" id="AutoNumber3" style="border-collapse: collapse">
              <tbody>
                <tr bgcolor="#011E6A">
                  <td colspan="100%" bgcolor="#CCCCCC" align="center"><strong>Search Date wise</strong></td>
                </tr>           
                <tr>
                    <td>Date From:
                    	<input size="7" name="ADate1" id="ADate1" style="border: 1px solid #001E6A" value="<?php echo $transactiondatefrom; ?>"  readonly="readonly" onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
                    </td>
                    <td>Date To: 
                    		<input size="7" name="ADate2" id="ADate2" style="border: 1px solid #001E6A" value="<?php echo $transactiondateto; ?>" readonly onKeyDown="return disableEnterKey()" />
                            <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate2')" style="cursor:pointer"/>
                    </td>
                   
                    <td>By Bank Name: <input type="text" size="12" name="bankinvoice_name" id="bankinvoice_name" /></td>
            		
                    <td>By User: <input size="10" type="text" placeholder="user" name="user" id="user"/></td>
            
                    <td><input style="border: 1px solid #001E6A" type="submit" value="Search" name="Submit" /> </td>
                    <td> <input name="print" type="button" id="print"  style="border: 1px solid #001E6A" value="Print" onClick="PrintDiv();" />
                   </td>
                </tr>
              </tbody>
            </table>
		</form>
   	</td>
</tr>

    <tr>
        <td>
		<?php 
		$datetime1 = new DateTime($transactiondatefrom);
		$datetime2 = new DateTime($transactiondateto);
		$interval = $datetime1->diff($datetime2);
		$totaldays = $interval->format('%a');
		if($datetime1<$datetime2){
			$fromdate = $transactiondatefrom;
			$todate = $transactiondateto;
		}
		else{
			$fromdate = $transactiondateto;
			$todate = $transactiondatefrom;
		}
		?>
        <table align="center" bgcolor="#FFFFFF" style="border-collapse:collapse" width="100%" border="1" cellspacing="1" cellpadding="5">
          <tr>
            <td colspan="19" bgcolor="#f2f2f2" align="center" style="color:#03F; border:1px solid #03F;">
            	<strong><?php echo $hospitaldata_name;?></strong><br>
                <strong>Bank Statement :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></strong>
            </td>
          </tr>
           
           <tr bgcolor="#CCCCCC">
               <td>SL No.</td>
               <td>Date </td>
               <td>Bank Name</td>
               <td>A/C Number</td>
               <td>Type</td>
               <td>Previous Balance</td>
               <td>Deposit Amount</td>
               <td>Withdrawal Amount</td>
               <td>Adjustment Amount</td>
               <td>Current Balance</td>
               <td>Note</td>
               <td>User</td>
          </tr>
  
		 <?php
         $s='';
         $total_deposite_amount=0;
         $total_withdrawal_amount=0;
          for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
	$sqlst = "select * from bankinvoice where bankinvoice_date between '$newfromdate' and '$newtodate' $searchstr order by bankinvoice_id asc";
	  	$stquery = mysqli_query($conn, $sqlst);
			if($stquery && mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery))
			 	{
                    $bankinvoice_id = $strow['bankinvoice_id'];
					$bankaccounts_id = $strow['bankaccounts_id'];
					$user = $strow['user'];
                   $note = $strow['note'];
                    $bankinvoice_name = $strow['bankinvoice_name'];
                    $bankinvoice_number = $strow['bankinvoice_number'];
                    $bankinvoice_address = $strow['bankinvoice_address'];
					$deposite_amount = $strow['deposite_amount'];
					$withdrawal_amount = $strow['withdrawal_amount'];
					$current_balance = $strow['current_balance'];
					$adjustment = $strow['adjustment'];
					$total_balance = $strow['total_balance'];
					$bankinvoice_date=	$strow['bankinvoice_date'];
				
					$total_deposite_amount=$total_deposite_amount+$deposite_amount;
					$total_withdrawal_amount=$total_withdrawal_amount+$withdrawal_amount;
					
				$sqlst = "select current_balance from bankaccounts where bankaccounts_id='$bankaccounts_id'";
				$exec3 = mysqli_query($conn, $sqlst) or die ("Error in Query3".mysql_error());
				$onerow = mysqli_fetch_array($exec3);
				echo	$ccurrent_balance = $onerow['current_balance'];
				?>
                  <tr>
                    <td><?php echo $s=$s+1;?></td>
                    <td><?php echo $bankinvoice_date;?></td>
                    <td><?php echo $bankinvoice_name;?></td>
                    <td><?php echo $bankinvoice_number;?></td>
                    <td><?php if($deposite_amount>0){echo 'Deposit';} else{echo 'Withdraw';};?></td>
                    <td><?php echo $current_balance;?></td>
                    <td><strong><?php echo $deposite_amount;?></strong></td>
                    <td><strong><?php echo $withdrawal_amount;?></strong></td>
                    <td><?php echo $adjustment;?></td>
                    <td><?php echo $total_balance;?></td>
                    <td><?php echo $note;?></td>
                    <td><?php echo $user;?></td>
                   </tr>
                <?php
					}
				}
		  }
		  ?>
      
        <tr bgcolor="#CCCCCC">
            <td align="right" colspan="6"><strong>Total:</strong></td>
            <td> Deposit: <strong><?php echo $total_deposite_amount;?></strong></td>
            <td>Withdrawal: <strong><?php echo $total_withdrawal_amount;?></strong></td>
            <td colspan="2">Current Balance: <?php echo $ccurrent_balance;?></td>
        </tr>
    </table>
</td>
    
    <td align="center" id="divToPrint" style="display:none">
 	 
     	<?php 
		$datetime1 = new DateTime($transactiondatefrom);
		$datetime2 = new DateTime($transactiondateto);
		$interval = $datetime1->diff($datetime2);
		$totaldays = $interval->format('%a');
		if($datetime1<$datetime2){
			$fromdate = $transactiondatefrom;
			$todate = $transactiondateto;
		}
		else{
			$fromdate = $transactiondateto;
			$todate = $transactiondatefrom;
		}
		?>
        <table align="center" bgcolor="#FFFFFF" style="border-collapse:collapse" width="100%" border="1" cellspacing="1" cellpadding="5">
          <tr>
            <td colspan="19" bgcolor="#f2f2f2" align="center" style="color:#03F; border:1px solid #03F;">
            	<strong><?php echo $hospitaldata_name;?></strong><br>
                <strong>Bank Statement :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></strong>
            </td>
          </tr>
           
           <tr bgcolor="#CCCCCC">
               <td>SL No.</td>
               <td>Date </td>
               <td>Bank Name</td>
               <td>A/C Number</td>
               <td>Type</td>
               <td>Previous Balance</td>
               <td>Deposit Amount</td>
               <td>Withdrawal Amount</td>
               <td>Adjustment Amount</td>
               <td>Current Balance</td>
               <td>User</td>
          </tr>
  
		 <?php
         $s='';
         $total_deposite_amount=0;
         $total_withdrawal_amount=0;
          for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
	$sqlst = "select * from bankinvoice where bankinvoice_date between '$newfromdate' and '$newtodate' $searchstr order by bankinvoice_id asc";
	  	$stquery = mysqli_query($conn, $sqlst);
			if($stquery && mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery))
			 	{
                    $bankinvoice_id = $strow['bankinvoice_id'];
					$bankaccounts_id = $strow['bankaccounts_id'];
					$user = $strow['user'];
                    $bankinvoice_name = $strow['bankinvoice_name'];
                    $bankinvoice_number = $strow['bankinvoice_number'];
                    $bankinvoice_address = $strow['bankinvoice_address'];
					$deposite_amount = $strow['deposite_amount'];
					$withdrawal_amount = $strow['withdrawal_amount'];
					$current_balance = $strow['current_balance'];
					$adjustment = $strow['adjustment'];
					$total_balance = $strow['total_balance'];
					$bankinvoice_date=	$strow['bankinvoice_date'];
				
					$total_deposite_amount=$total_deposite_amount+$deposite_amount;
					$total_withdrawal_amount=$total_withdrawal_amount+$withdrawal_amount;
					
				$sqlst = "select current_balance from bankaccounts where bankaccounts_id='$bankaccounts_id'";
				$exec3 = mysqli_query($conn, $sqlst) or die ("Error in Query3".mysql_error());
				$onerow = mysqli_fetch_array($exec3);
				echo	$ccurrent_balance = $onerow['current_balance'];
				?>
                  <tr>
                    <td><?php echo $s=$s+1;?></td>
                    <td><?php echo $bankinvoice_date;?></td>
                    <td><?php echo $bankinvoice_name;?></td>
                    <td><?php echo $bankinvoice_number;?></td>
                    <td><?php if($deposite_amount>0){echo 'Deposit';} else{echo 'Withdraw';};?></td>
                    <td><?php echo $current_balance;?></td>
                    <td><strong><?php echo $deposite_amount;?></strong></td>
                    <td><strong><?php echo $withdrawal_amount;?></strong></td>
                    <td><?php echo $adjustment;?></td>
                    <td><?php echo $total_balance;?></td>
                     <td><?php echo $user;?></td>
                   </tr>
                <?php
					}
				}
		  }
		  ?>
      
        <tr bgcolor="#CCCCCC">
            <td align="right" colspan="6"><strong>Total:</strong></td>
            <td> Deposit: <strong><?php echo $total_deposite_amount;?></strong></td>
            <td>Withdrawal: <strong><?php echo $total_withdrawal_amount;?></strong></td>
            <td colspan="2">Current Balance: <?php echo $ccurrent_balance;?></td>
        </tr>
    </table>

    </td>
</tr>
</table>