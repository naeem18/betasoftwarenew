<?php
header('Content-Type: application/json');

// Get and validate input data
$input = json_decode(file_get_contents('php://input'), true);

if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON data']);
    exit;
}

// Authentication check
if (!isset($input['username']) || !isset($input['password'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Username and password required']);
    exit;
}

if ($input['username'] !== 'rubel' || $input['password'] !== 'rubel') {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Validate required field
if (!isset($input['InvNo'])) {
    http_response_code(400);
    echo json_encode(['error' => 'InvNo is required']);
    exit;
}
include('labdd.php');

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed: ' . $conn->connect_error]);
    exit;
}

// Extract data
$InvNo          = $input['InvNo'];
$patientName    = isset($input['patientName']) ? $input['patientName'] : null;
$Age            = isset($input['Age']) ? $input['Age'] : null;
$Parameter      = isset($input['Parameter']) ? $input['Parameter'] : null;
$Result         = isset($input['Result']) ? $input['Result'] : null;
$Unit           = isset($input['Unit']) ? $input['Unit'] : null;
$NormalValue    = isset($input['NormalValue']) ? $input['NormalValue'] : null;
$ReportingGroup = isset($input['ReportingGroup']) ? $input['ReportingGroup'] : null;
$AliasName      = isset($input['AliasName']) ? $input['AliasName'] : null;

try {
    // Check if record exists (InvNo + Parameter)
    $checkStmt = $conn->prepare("SELECT InvNo FROM labdata WHERE InvNo = ? AND Parameter = ?");
    if (!$checkStmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    $checkStmt->bind_param("ss", $InvNo, $Parameter);
    $checkStmt->execute();
    $checkStmt->store_result();
    $recordExists = $checkStmt->num_rows > 0;
    $checkStmt->close();
    
    if ($recordExists) {
        // Update existing record -> only update Result
        $stmt = $conn->prepare("UPDATE labdata SET Result = ? WHERE InvNo = ? AND Parameter = ?");
        
        if (!$stmt) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
        
        $stmt->bind_param("sss", $Result, $InvNo, $Parameter);
        
        if ($stmt->execute()) {
            echo json_encode([
                'status' => 'success',
                'message' => 'Result updated successfully',
                'action' => 'update',
                'received' => $input
            ]);
        } else {
            throw new Exception("Database update failed: " . $stmt->error);
        }
    } else {
        // Insert new record
        $stmt = $conn->prepare("INSERT INTO labdata 
            (InvNo, patientName, Age, Parameter, Result, Unit, NormalValue, ReportingGroup, AliasName) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

        if (!$stmt) {
            throw new Exception("Prepare failed: " . $conn->error);
        }

        $stmt->bind_param("sssssssss", 
            $InvNo,
            $patientName,
            $Age,
            $Parameter,
            $Result,
            $Unit,
            $NormalValue,
            $ReportingGroup,
            $AliasName
        );

        if ($stmt->execute()) {
            $insertId = $stmt->insert_id;
            echo json_encode([
                'status' => 'success',
                'message' => 'Data inserted successfully',
                'inserted_id' => $insertId,
                'action' => 'insert',
                'received' => $input
            ]);
        } else {
            throw new Exception("Database insert failed: " . $stmt->error);
        }
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Operation failed',
        'message' => $e->getMessage()
    ]);
}

$conn->close();
?>
