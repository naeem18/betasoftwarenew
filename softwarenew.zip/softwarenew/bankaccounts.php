		<article class="bottomcontent">
 			<h3> Add New Bank Accounts</h3>
 			<content>
		<?php
        if(isset($_GET['message']) && $_GET['message']=='field-missing1'){
        echo "<h2 class=\"red12bold\">You have missing Something</h2>";
        }
        elseif(isset($_GET['message']) && $_GET['message']=='duplicatename'){
        echo "<h2 class=\"red12bold\">This Item  already exists. Please try with different item .</h2>";   
        }
        elseif(isset($_GET['message']) && $_GET['message']=='error-insert'){
        echo "<h2 class=\"red12bold\">Error occured! Could not insert.</h2>";   
        }
        elseif(isset($_GET['message']) && $_GET['message']=='insert-successfully'){
        echo "<h2 class=\"red12bold\">Item insert successfully</h2>";   
        }

         $bankaccounts_id = 0;
         $bankaccounts_name = '';
         $bankaccounts_number = '';
         $bankaccounts_address = '';
         $current_balance='';
        
        if(isset($_GET['bankaccounts_id'])){
            $bankaccounts_id = $_GET['bankaccounts_id'];
            $sqlbankitem = "select * from bankaccounts where bankaccounts_id = $bankaccounts_id";
            $bankitemquery = mysqli_query($conn, $sqlbankitem);
            if($bankitemquery){
                while($bankitemrow = mysqli_fetch_array($bankitemquery)){
                    $bankaccounts_id = $bankitemrow['bankaccounts_id'];
                    $bankaccounts_name = $bankitemrow['bankaccounts_name'];
                    $bankaccounts_number = $bankitemrow['bankaccounts_number'];
                    $bankaccounts_address = $bankitemrow['bankaccounts_address'];
                     $current_balance = $bankitemrow['current_balance'];
                 }
            }
        }
        ?>        
                             
<form action="save_bankinfo.php" name="frmcontact" onsubmit="return checkcontactform();" method="post" enctype="multipart/form-data">
       
            <table width="100%" border="0" cellspacing="0" bgcolor="f2f2f2" cellpadding="2" class=" ">
                 <tr>
                    <td width="220"><lebel>Section*</lebel></td>
                     <td>
                         <select required id="section" style="width:170px" name="section" >
                            <option value=""></option>
                            <option value="Hospital">Hospital</option>
                            <option value="Lab">Lab</option>
                            <option value="Pharmacy">Pharmacy</option>
                         </select>
                    </td>
                </tr>
                
                <tr>
                    <td width="220"><lebel>Bank Name *</lebel></td>
                     <td>
                      <?php /*?><select required id="bankaccounts_name" style="width:170px" title="class" name="bankaccounts_name" >
                            <option value="<?php echo $bankaccounts_name; ?>"><?php echo $bankaccounts_name; ?></option>
                             <?php
                          
                            $query5 = "select * from category where section='bank' order by category";
                            $exec5 = mysqli_query($conn, $query5) or die ("Error in Query5".mysql_error());
                            while ($res5 = mysqli_fetch_array($exec5))
                            {
                                $res5doctorname = trim($res5["category"]);
                                $res5doctorcode = $res5["auto_number"];
                                if($res5doctorname !=''){						
                                    ?>
                                    <option value="<?php echo $res5doctorname; ?>"><?php echo $res5doctorname; ?></option>
                                    <?php
                                }
                            }
                            ?>
                        </select><?php */?>
                        <input type="text" required name="bankaccounts_name" id="bankaccounts_name" value="<?php echo $bankaccounts_name;?>" class="textfieldcssmem"  />
                    </td>
                </tr>
                <tr>
                    <td width="220"><lebel>A/C No. *</lebel></td>
                    <td width="310">
                        <input type="text" required name="bankaccounts_number" id="bankaccounts_number" value="<?php echo $bankaccounts_number;?>" class="textfieldcssmem"  />
                    </td>
                    <td><span class="red12bold"></span></td>
                </tr>
                 
                 
                 <tr>
                    <td width="120"><lebel>Current Balance</lebel></td>
                    <td width="310">
                        <input type="text" readonly name="current_balance" id="current_balance" value="<?php echo $current_balance;?>" class="textfieldcssmem"  />
                    </td>
                    <td><span class="red12bold"></span></td>
                </tr>
                <tr>
                    <td width="220"><lebel>Address</lebel></td>
                    <td width="310">
                        <input type="text" required name="bankaccounts_address" id="bankaccounts_address" value="<?php echo $bankaccounts_address;?>" class="textfieldcssmem"  />
                    </td>
                    <td><span class="red12bold"></span></td>
                </tr>
               
                 
                <tr>
                    <td>&nbsp;</td>
                    <td>
                        <input type="hidden" name="bankaccounts_id" id="bankaccounts_id" value="<?php echo $bankaccounts_id;?>">
                        <input type="submit" value=" Save " name="submit_bankaccounts" id="submit_bankaccounts" class="submitbuttoncss" />
                    </td>
                    <td></td>
                </tr>
          </table>
      </form>
<td><strong>Bank List</strong></td>
<table width="100%" border="1" style="border-collapse:collapse">
      <tr>
        <td>SL No.</td>
        <td>Section</td>
        <td>Bank Name</td>
        <td>A/C No.</td>
        <td>Address</td>
        <td>Current Balance</td>
        <td>Edit</td>
      </tr>
	  	<?php
       		$i='';
	   		$total_current_balance='';
			$sqlbankitem = "select * from bankaccounts order by bankaccounts_id desc";
			$bankitemquery = mysqli_query($conn, $sqlbankitem);
			if($bankitemquery && mysqli_num_rows($bankitemquery)>0){
				while ($bankitemrow = mysqli_fetch_array($bankitemquery))
			 	{
				$bankaccounts_id = $bankitemrow['bankaccounts_id'];
				$section = $bankitemrow['section'];
				$bankaccounts_name = $bankitemrow['bankaccounts_name'];
				$bankaccounts_number = $bankitemrow['bankaccounts_number'];
				$current_balance = $bankitemrow['current_balance'];
                $bankaccounts_address = $bankitemrow['bankaccounts_address'];
			$action = "<a href=\"index.php?p=bankaccounts&bankaccounts_id=$bankaccounts_id\">Edit</a>";
			
			$action2 = "<a href=\"javascript:void(0)\" onclick=\"removetablerow('bankaccounts', $bankaccounts_id, 'bankaccounts')\">Remove</a>";
			$total_current_balance=$total_current_balance+$current_balance;
			?>
                <tr bgcolor="#FFFFFF">
                <td><?php echo $i=$i+1;?></td>
                <td><?php echo $section;?></td>
                <td><?php echo $bankaccounts_name;?></td>
                <td><?php echo $bankaccounts_number;?></td>
                 <td><?php echo $bankaccounts_address;?></td>
                <td><?php echo $current_balance;?></td>
                 <td><?php if($_SESSION['employeename']=='SUPERADMINISTRATOR'){ echo $action; }?> |
               <?php if($_SESSION['employeename']=='SUPERADMINISTRATOR'){ echo $action2; }?>
               </td>
             
              </tr>
                <?php
                }
            }
        ?>
   <tr>
    <td colspan="3"></td>
    <td><strong>Total:</strong></td>
     <td colspan="2"><strong><?php echo $total_current_balance;?></strong></td>
  </tr>
</table>
 </content>
</article>