<?php
date_default_timezone_set('Asia/Dhaka');
$pcdata = array();
$sqlpc = "select doctor_name, mpo from doctorentry where doctor_category='pc' order by doctor_name asc";
$stqry1 = mysqli_query($conn, $sqlpc);
if($stqry1 && mysqli_num_rows($stqry1)>0){

	while ($strow = mysqli_fetch_array($stqry1)){
		$doctor_name = $strow['doctor_name'];
		$mpo = $strow['mpo'];
		$pcdata[] =array( 'labelval' => $doctor_name,
							'label' => $doctor_name,
							'doctor_name'=>$doctor_name,
							'mpo'=>$mpo
							);
		}
	}
$pcdata = json_encode($pcdata);

$drdata = array();
$sqldr = "select doctor_id, doctor_name, roomno, charge, day_serial from doctorentry where 
doctor_category='doctor' order by doctor_name asc";
$stqry2 = mysqli_query($conn, $sqldr);
if($stqry2 && mysqli_num_rows($stqry2)>0){
 	while ($strow = mysqli_fetch_array($stqry2)){
		$doctor_id = $strow['doctor_id'];
		$roomno = $strow['roomno'];
		$charge = $strow['charge'];
		$day_serial = $strow['day_serial'];
		$doctor_name = $strow['doctor_name'];
		$drdata[] =array( 'labelval' =>$doctor_name,
							'label' =>$doctor_name,
							'doctor_id' =>$doctor_id,
							'roomno' =>$roomno,
							'charge' =>$charge,
							'day_serial' =>$day_serial,
							'doctor_name'=>$doctor_name
							);
		}
	}
$drdata = json_encode($drdata);

$apdata = '';
$sqlar = "select * from appointmententry order by appointmententry_name DESC LIMIT 400";
$stquery3 = mysqli_query($conn, $sqlar);
if($stquery3 && mysqli_num_rows($stquery3)>0){

	while ($strow = mysqli_fetch_array($stquery3)){
		$appointmententry_id = $strow['appointmententry_id'];
		$appointmententry_name = $strow['appointmententry_name'];
		$appointmententry_age = $strow['appointmententry_age'];
		$age = $strow['age'];
		$bar = $strow['bar'];
		$appointmententry_gender = $strow['appointmententry_gender'];
		$appointmententry_mobile = $strow['appointmententry_mobile'];
		$appointmententry_doctor = $strow['appointmententry_doctor'];
		$district = $strow['district'];
		$appointmententry_address = $strow['appointmententry_address'];
		$apdata[] =array( 'labelval' => $appointmententry_name,
							'label' => $appointmententry_name.'#'.$appointmententry_mobile,
							'appointmententry_name'=>$appointmententry_name,
							'appointmententry_age'=>$appointmententry_age,
							'district'=>$district,
							'age'=>$age,
							'bar'=>$bar,
							'appointmententry_gender'=>$appointmententry_gender,
							'appointmententry_doctor'=>$appointmententry_doctor,
							'appointmententry_mobile'=>$appointmententry_mobile,
							'appointmententry_address'=>$appointmententry_address
 							);
		}
	}
$apdata = json_encode($apdata);


$apidata = array();
$sqlar = "select * from idholder order by opregistration_id asc";
$stqry3 = mysqli_query($conn, $sqlar);
if($stqry3 && mysqli_num_rows($stqry3)>0){

	while ($strow = mysqli_fetch_array($stqry3)){
		$opregistration_id = $strow['opregistration_id'];
		$opregistration_name = $strow['opregistration_name'];
		$opregistration_age = $strow['opregistration_age'];
		$opregistration_gender = $strow['opregistration_gender'];
		$opregistration_mobile = $strow['opregistration_mobile'];
		$bar = $strow['bar'];
		$opregistration_address = $strow['opregistration_address'];
		$apidata[] =array( 'labelval' => $opregistration_name,
							'label' => $opregistration_name.'#'.$opregistration_mobile.'#'.$bar,
							'opregistration_name'=>$opregistration_name,
							'bar'=>$bar,
							'opregistration_age'=>$opregistration_age,
							'opregistration_id'=>$opregistration_id,
							'opregistration_gender'=>$opregistration_gender,
 							'opregistration_mobile'=>$opregistration_mobile,
							'opregistration_address'=>$opregistration_address
 							);
		}
	}
$apidata = json_encode($apidata);
?>

<link rel="stylesheet" href="autocomplete/jquery-ui.css">
<script src="autocomplete/jquery-ui.min.js"></script>
 <script language="JavaScript" type="text/javascript">
 	var pcdata = <?php echo $pcdata;?>;
	var drdata = <?php echo $drdata;?>;
 	var apdata = <?php echo $apdata;?>;
 	var apidata = <?php echo $apidata;?>;
 	$(document).ready(function($) {
 	$( "#appointmententry_pc" ).autocomplete({
 			minLength: 1,
			source: pcdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
 				 document.getElementById('appointmententry_pc').value = ui.item.labelval;
				 document.getElementById('appointmententry_mpo').value = ui.item.mpo;
 				return false;
			}
		});
 		
	$( "#appointmententry_doctor" ).autocomplete({
 			minLength: 1,
			source: drdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				 document.getElementById('appointmententry_doctor').value = ui.item.labelval;
				 document.getElementById('doctor_id').value = ui.item.doctor_id;
				 document.getElementById('appointmententry_doctor').value = ui.item.doctor_name;
				 document.getElementById('roomno').value = ui.item.roomno;
				 document.getElementById('appointmententry_amount').value = ui.item.charge;
				 document.getElementById('appointmententry_number').value = ui.item.day_serial;
				return false;
			}
		});
	
	$( "#appointmententry_name" ).autocomplete({
 			minLength: 1,
			source: apdata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				 document.getElementById('appointmententry_name').value = ui.item.labelval;
				 document.getElementById('appointmententry_age').value = ui.item.appointmententry_age;
				 document.getElementById('age').value = ui.item.age;
				 document.getElementById('appointmententry_gender').value = ui.item.appointmententry_gender;
				 document.getElementById('appointmententry_mobile').value = ui.item.appointmententry_mobile;
				 document.getElementById('district').value = ui.item.district;
				 document.getElementById('bar').value = ui.item.bar;
				 document.getElementById('appointmententry_address').value = ui.item.appointmententry_address;
 				return false;
			}
		});
		
	$( "#sbar" ).autocomplete({
 			minLength: 1,
			source: apidata,
			focus: function( event, ui ) {
				return false;
			},
			select: function( event, ui ) {
				$(this).val( ui.item.label );
				 document.getElementById('appointmententry_name').value = ui.item.labelval;
				 document.getElementById('appointmententry_age').value = ui.item.opregistration_age;
				 document.getElementById('age').value = ui.item.age;
				 document.getElementById('bar').value = ui.item.bar;
				 document.getElementById('sbar').value = ui.item.bar;
				 document.getElementById('uhid').value = ui.item.opregistration_id;
				 document.getElementById('appointmententry_gender').value = ui.item.opregistration_gender;
				 document.getElementById('appointmententry_mobile').value = ui.item.opregistration_mobile;
				 document.getElementById('appointmententry_address').value = ui.item.opregistration_address;
 				return false;
			}
		});
	});
</script>

<style type="text/css">
.ui-autocomplete { height:auto !important; max-height:300px; overflow:auto; background:#FFF; border:1px solid #CCC;	width:250px;}
.search_row{text-align:left;}
.ui-autocomplete li{ min-height:30px; border-bottom:1px dotted #CCC; padding:10px; text-align:left;}
</style>

<content>
 <?php
    if(isset($_GET['message']) && $_GET['message']=='save-successfully'){
        echo "<p class=\"red12bold\">Information insert successfully.
        Click Print Button To Print or View Previous Bill <td align=\"center\" >
        <a onclick=\"PrintDiv();\"><input type=\"button\" value=\"PRINT\" class=\"tdclass\" /></a></td></p>";   
    }
 ?>

<head>
      <style>
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
         
        
        h1 {
            font-size: 18px;
            margin: 0;
        }
        
        .offline-notice {
            background: #e67e22;
            color: white;
            text-align: center;
            padding: 5px;
            font-weight: bold;
        }
        
        form {
            padding: 5px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            background: #f8f8f8;
        }
        
        td {
            padding: 1px;
            border: 1px solid #ddd;
            vertical-align: top;
        }
        
        tr:nth-child(even) {
            background: #f0f0f0;
        }
        
        td:first-child {
            width: 160px;
            text-align: right;
            font-weight: bold;
            background: #e8e8e8;
        }
        
        input, select, textarea {
            width: 100%;
            padding: 2px;
            border: 1px solid #ccc;
            border-radius: 3px;
            font-size: 13px;
        }
        
        input:focus, select:focus, textarea:focus {
            outline: 2px solid #3498db;
        }
        
        .required::after {
            content: " *";
            color: #e74c3c;
        }
        
        .input-group {
            display: flex;
            gap: 5px;
        }
        
        .input-group input {
            flex: 1;
        }
        
        .input-group select {
            width: 100px;
        }
        
        .info-text {
            font-size: 13px;
            color: #666;
            margin-top: 3px;
        }
        
        .form-actions {
            text-align: center;
            margin-top: 10px;
            padding-top: 5px;
            border-top: 1px solid #ddd;
        }
        
        button {
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            margin: 0 5px;
        }
        
        .btn-save {
            background: #2ecc71;
            color: white;
        }
        
        .btn-reset {
            background: #e74c3c;
            color: white;
        }
        
        .storage-info {
            background: #e8f4fc;
            border: 1px solid #b8daff;
            border-radius: 4px;
            padding: 8px;
            margin-top: 10px;
            font-size: 13px;
        }
        
        @media (max-width: 600px) {
            td:first-child {
                width: 120px;
            }
            
            .input-group {
                flex-direction: column;
            }
            
            .input-group select {
                width: 100%;
            }
        }
    </style>
</head>

  <div class="container">
     <h2 style="padding:2px" align="center">⏰ Appointment Booking System</h2>
     <div class="offline-notice"><!--Book your medical appointment quickly and easily--></div>
    <form action="save_appointmententry.php" name="frmcontact" onsubmit="return checkcontactform();" method="post" enctype="multipart/form-data">
	<table width="800" align="center" border="1" style="BORDER-COLLAPSE: collapse;" bgcolor="#f8f8f8" cellpadding="2">
      <tr><td colspan="2" align="justify">Appointment Details</td></tr>
       <input type="hidden" name="user" id="user" value="<?php echo $_SESSION['fullname'];?>" class="tdclass" />
         <input type="hidden" name="uniqid" id="uniqid" value="<?php echo $_SESSION['auto_number'];?><?php echo str_pad(mt_rand(0, 99999999), 8, '0', STR_PAD_LEFT);?>">
    <tr>
        <td align="right">Appointment Date </td>
        <td><div class="input-group"><input type="text" name="ADate1" id="ADate1" value="<?php echo date('Y-m-d');?>" class="tdclass" />
        	<img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
        	Appointment Time:<!--<input type="text" name="appointmententry_time" id="appointmententry_time" value="<?php //echo date('H:i');?>" size="30" />-->
        	<input type="time" name="appointmententry_time" id="appointmententry_time" value="<?php echo date('h:i:s');?>" ></td>
        </div>
     </tr>
     <tr>
        <td align="right">Consultant/Doctor</td>
        <td><input type="text" required name="appointmententry_doctor" id="appointmententry_doctor" size="30" placeholder="search by doctor" autofocus/></td>
     </tr>
     <tr><td colspan="2" align="justify">Patient Details</td></tr>
     <tr>
    	 <input type="hidden" name="sbar" id="sbar" size="30" placeholder="search by barcode, name or mobile from ID Holder"/>
         <input type="hidden" required value="<?php echo date('Ymdhis')?>" name="bar" id="bar" size="30"/>
     </tr>
     <tr>
    	<td align="right">Patient Name* </td>
    	<td><input type="text" required name="appointmententry_name" id="appointmententry_name" size="30" placeholder="search by barcode, name or mobile from old data" />
        </td>
     </tr>
     <tr>
     	 <input type="hidden" readonly name="uhid" id="uhid" size="30" />
         <input type="hidden" readonly name="roomno" id="roomno" size="30" />
     </tr>
        
     <tr>
    	<td align="right">Age*</td>
    	<td><div class="input-group">
        	<input type="text" required name="appointmententry_age" id="appointmententry_age" style="width:110px" />
        	<select style="width:115px" required id="age" name="age" >
		   <?php
            $doyouknowarray = array('', 'Days', 'Months', 'Years', 'Day', 'Month', 'Year');
            foreach($doyouknowarray as $singleoption){
                $selected = '';
                if($section=="$singleoption"){$selected = ' selected="selected"';}
                echo "<option value=\"$singleoption\"$selected>$singleoption</option>";
                }
            ?>
        </select>
        Gender*: <select required style="width:125px" id="appointmententry_gender" name="appointmententry_gender" >
               <option value=""></option>
                <?php
                $patientarray = array('Other', 'Female', 'Male');
                foreach($patientarray as $singleoption){
                    $selected = '';
                    if($singleoption=="$singleoption"){$selected = ' selected="selected"';}
                    echo "<option value=\"$singleoption\"$selected>$singleoption</option>";
                }
                ?>
            </select>
        </div>
        </td>
     </tr>
  
     <tr>
        <td align="right">Mobile*</td>
        <td><input type="text" required name="appointmententry_mobile" id="appointmententry_mobile" size="30" /></td>
     </tr>
    
     <tr>
    	<td align="right">Address</td>
    	<td><textarea type="text" name="appointmententry_address" id="appointmententry_address" rows="2"></textarea></td>
     </tr>
    
    	<tr>
         <td width="235" align="right">District</td>
         <td>
            <select id="district" name="district" >
                <option></option>
                <?php
                $doyouknowarray = array(
									'Cumilla ( কুমিল্লা )',
                                    /*'Barguna ( বরগুনা )', 
                                    'Barishal ( বরিশাল )',
                                    'Bhola ( ভোলা )',
                                    'Jhalokati ( ঝালকাঠি )',
                                    'Patuakhali ( পটুয়াখালি )',
                                    'Pirojpur ( পিরোজপুর )',
                                    'Bandarban ( বান্দরবান )',
                                    'Brahmanbaria ( ব্রাহ্মণবাড়িয়া )',
                                    'Chandpur ( চাঁদপুর )',
                                    'Chattogram ( চট্টগ্রাম )',
                                    'Cox Bazar ( কক্সবাজার )',
                                    'Cumilla ( কুমিল্লা )',
                                    'Feni ( ফেনী )',
                                    'Khagrachhari ( খাগড়াছড়ি )',
                                    'Lakshmipur ( লক্ষ্মীপুর )',
                                    'Noakhali ( নোয়াখালি )',
                                    'Rangamati ( রাঙ্গামাটি )',
                                    'Dhaka ( ঢাকা )',
                                    'Faridpur ( ফরিদপুর )',
                                    'Gazipur ( গাজীপুর )',
                                    'Gopalganj ( গোপালগঞ্জ )',
                                    'Kishoreganj ( কিশোরগঞ্জ )',
                                    'Madaripur ( মাদারিপুর )',
                                    'Manikganj ( মানিকগঞ্জ )',
                                    'Munshiganj ( মুন্সিগঞ্জ )',
                                    'Narayanganj ( নারায়ণগঞ্জ )',
                                    'Narsingdi ( নরসিংদি )',
                                    'Rajbari ( রাজবাড়ি )',
                                    'Shariatpur ( শরিয়তপুর )',
                                    'Tangail ( টাঙ্গাইল )',
                                    'Bagerhat ( বাগেরহাট )',
                                    'Chuadanga ( চুয়াডাঙ্গা )',
                                    'Jashore ( যশোর )',
                                    'Jhenaidah ( ঝিনাইদহ )',
                                    'Khulna ( খুলনা )',
                                    'Kushtia ( কুষ্টিয়া )',
                                    'Magura ( মাগুরা )',
                                    'Meherpur ( মেহেরপুর )',
                                    'Narail ( নড়াইল )',
                                    'Satkhira ( সাতক্ষীরা )',
                                    'Jamalpur ( জামালপুর )',
                                    'Mymensingh ( ময়মনসিংহ )',
                                    'Netrokona ( নেত্রকোনা )',
                                    'Sherpur ( শেরপুর )',
                                    'Bogura ( বগুড়া )',
                                    'Chapainawabganj ( চাঁপাইনবাবগঞ্জ )',
                                    'Joypurhat ( জয়পুরহাট )',
                                    'Naogaon ( নওগাঁ )',
                                    'Natore ( নাটোর )',
                                    'Pabna ( পাবনা )',
                                    'Rajshahi ( রাজশাহী )',
                                    'Sirajganj ( সিরাজগঞ্জ )',
                                    'Dinajpur ( দিনাজপুর )',
                                    'Gaibandha ( গাইবান্ধা )',
                                    'Kurigram ( কুড়িগ্রাম )',
                                    'Lalmonirhat ( লালমনিরহাট )',
                                    'Nilphamari ( নীলফামারি )',
                                    'Panchagarh ( পঞ্চগড় )',
                                    'Rangpur ( রংপুর )',
                                    'Thakurgaon ( ঠাকুরগাঁও	)',
                                    'Habiganj ( হবিগঞ্জ )',
                                    'Moulvibazar ( মৌলভীবাজার )',
                                    'Sunamganj ( সুনামগঞ্জ )',*/
                                    'Sylhet ( সিলেট )');
                foreach($doyouknowarray as $singleoption){
                    $selected = '';
                    if($section=="$singleoption"){$selected = ' selected="selected"';}
                    echo "<option value=\"$singleoption\"$selected>$singleoption</option>";
                }
                ?>
            </select>
        </td>
    </tr>
       	<tr><td colspan="2" align="justify">Medical Details</td></tr>
    <tr>
        <td align="right">Patient Category*</td>
         <td>
            <select required style="width:235px" id="appointmententry_pcategory" name="appointmententry_pcategory" >
                <option value=""></option>
                <option value="New">New</option>
                <option value="Old">Old</option>
                <option value="Report">Report</option>
             </select>
        </td>
    </tr>
         
    <tr>
        <td align="right">Appointment Number</td>
        <td><div class="input-group">
        <input type="hidden" name="doctor_id" id="doctor_id" value="<?php //echo $appointmententry_number + 1;?>" size="30" />
        <input type="text" name="appointmententry_number" id="appointmententry_number" value="<?php //echo $appointmententry_number + 1;?>" size="30" />
        Auto Serial<input type="text" name="appointmententry_code" id="appointmententry_code" value="<?php //echo $appointmententry_code;?>" size="30" />
        </div>
        </td>
    </tr>
    
          
    <tr>
    	<td align="right">Consultant Fee</td>
    	<td><input type="text" name="appointmententry_amount" id="appointmententry_amount" value="<?php echo $charge;?>" size="30" /></td>
    </tr>

	<tr>
        <td align="right">RF/PC Comission</td>
        <td><input type="text" name="apccomission" id="apccomission" size="30" />
        </td>
    </tr>
    
	<tr>
    	<td align="right">Ref.</td>
    	<td><div class="input-group">
        	PC: <input type="text" name="appointmententry_pc" id="appointmententry_pc" size="30"/>
            MPO: <input type="text" name="appointmententry_mpo" id="appointmententry_mpo" size="30" />
        </div>
        </td>
    </tr>
 </table>
<div class="form-actions">
    <button type="submit" name="submit_invoice" id="submit_invoice" class="btn-save">SAVE</button>
    <button type="reset" class="btn-reset">Cancel</button>
    <input type="hidden" name="appointmententry_id" id="appointmententry_id" value="0" >
</div>
</form>
        

	<?php /*?><script>
    document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("frmcontact");
    const submitBtn = document.getElementById("submit_invoice");
    
    let submitted = false; // একবার submit হয়েছে কিনা track করার জন্য
    form.addEventListener("submit", function(e) {
    if (!submitted) {
    submitted = true;      
    submitBtn.disabled = true;
    submitBtn.value = "Refresh...";
    // প্রথমবার submit হলে page reload হবে, তারপর script আবার active হবে
    }
    // কোনো preventDefault নেই, form normally submit হবে
    });
    
    // Enter key থেকে repeated submit block
    form.addEventListener("keydown", function(e) {
    if (e.key === "Enter" && submitBtn.disabled) {
    e.preventDefault(); 
    return false;
    }
    });
    });
    </script>          
<?php */?>    </div>   
 
</content>
 
	<div id="divToPrint" style="display:none;">
 		<article>
		  <?php
		   if(isset($_GET['appointmententry_id'])){
          	$appointmententry_id = $_GET['appointmententry_id'];
            $asql = "select * from appointmententry where appointmententry_id = $appointmententry_id";
            $aqry = mysqli_query($conn, $asql);
            if($aqry && mysqli_num_rows($aqry)>0){
                while($prow = mysqli_fetch_array($aqry)){
                   $appointmententry_id = $prow['appointmententry_id'];
                   $appointmententry_code = $prow['appointmententry_code'];
                    $appointmententry_name = $prow['appointmententry_name'];
                    $appointmententry_mobile = $prow['appointmententry_mobile'];
					$bar = $prow['bar'];
                    $uhid = $prow['uhid'];
                    $user = $prow['user'];
                    $day_serial = $prow['day_serial'];
                    $appointmententry_doctor = $prow['appointmententry_doctor'];
                    $appointmententry_time = $prow['appointmententry_time'];
                    $appointmententry_number = $prow['appointmententry_number'];
                    $appointmententry_date = $prow['appointmententry_date'];
				 	$appointmententry_amount = $prow['appointmententry_amount'];
					$appointmententry_pcategory = $prow['appointmententry_pcategory'];
 					$appointmententry_age = $prow['appointmententry_age'];
				 	$appointmententry_gender = $prow['appointmententry_gender'];
  		 	 ?>        
              <table align="center" width="100%" style="border:1px solid #999; padding:0 5px; font-size:12px;" bgcolor="#FFF" cellpadding="0">
                <tr>
                <?php
                  if($hospitaldata_logo!=''){
					?>
                    <td width="65">
                    <div align="left" style="font-size:15px;">
                    <img alt="barcode" width="60" height="60" src="logo_images/<?php echo $hospitaldata_logo; ?>" /></div>
                   </td>
                <?php }?>
                <td width="320">
                    <div align="left" style="font-size:18px;"><strong><?php echo $hospitaldata_name;?></strong></div>
                    <div align="left"><?php echo $hospitaldata_address1;?></div>
                    <div align="left" style="font-size:14px;">Contact:<?php echo $hospitaldata_mobile;?></div>
                </td>
                </tr>
             </table>
            
            <table align="center" width="100%" style="border:1px solid #999; height:60px;padding:0 5px; font-size:13px;" bgcolor="#FFF" cellpadding="0">
              <tr align="right">
                <td align="left"><strong>Serial Number : <?php  echo $appointmententry_number;?></strong></td>
                <td align="right">
                <?php 
                $barCode = $bar;
                require("barcodePrint.php");
            	?>
                </td>
               </tr>
            </table>
                       
            <table align="center" width="100%" style="border:1px solid #999;font-size:12px; border-bottom:none; padding:2px 8px 0 8px; margin-top:6px" bgcolor="#FFF" cellpadding="0">
                <tr>
                    <td width="300">
                        <div align="left"><strong>Patient: <?php echo $appointmententry_name;?></strong></div>
                        <div align="left">Mobile: <?php echo $appointmententry_mobile;?></div>
                        <div align="left">Gender: <?php echo $appointmententry_gender;?></div>
                        <div align="left">Age: <?php echo $appointmententry_age;?> Years</div>
                        <div align="left"><strong>Category: <?php echo $appointmententry_pcategory;?></strong></div>
                    </td>
                    <td width="150">
                        <div align="right" style="font-size:15px"><strong>Appointment Slip</strong></div>
                        <div align="right">Ref. No.: <?php echo $appointmententry_id;?></div>
                        <div align="right">UHID: <?php  echo $uhid;?></div>
                        <div align="right">A.Date: <?php  echo $appointmententry_date;?></div>
                      	<div align="right">Time: <?php  echo $appointmententry_time;?></div>
                   </td>
                 </tr>
             </table>
                 
            <table align="center" width="100%" style="border:1px solid #999;font-size:12px; padding:0 8px 5px 8px;" bgcolor="#FFF" cellpadding="0">
                <tr><td width="450"><strong>Ref Dr.: <?php echo $appointmententry_doctor;?></strong></td></tr>
            </table>
             <table align="center" width="100%" bgcolor="#FFF" style=" padding:0 0 40px;font-size:12px; border:1px #999 solid; border-top:none;" cellspacing="0" cellpadding="0">
                 <tr height="20">
                    <td style="border:1px solid #999;text-align:center;border-top:none;"><strong>Particular</strong></td>
                    <td style="border:1px solid #999; text-align:center;border-top:none;"><strong>Paid Amount</strong></td>
                </tr>
                
                <tr>
                    <td style=" text-align:center; padding-left:3px" width="250">Consultant Fee</td>
                    <td style="text-align:center;"><?php echo $appointmententry_amount;?></td>
                </tr>
             </table>
                <?php
              		}
			  	}
			 }
            ?>
              
         <table width="100%" align="center" style="font-size:12px;">
        	<tr>
            	<td><?php include ("convert_currency_to_words.php");
 					echo 'InWord:';	echo covert_currency_to_words($appointmententry_amount); ?>
            	</td>
            </tr>
         </table>
        
         <table align="center" width="100%" style=" font-size:12px; padding:5px 2px" bgcolor="#FFF" cellpadding="0">
              <tr>
                <td width="200">
                	<div>Prepared By: <?php echo $user; ?></div>
                </td>
                <td width="200">
                	<div style="padding-bottom:10px" align="right"></div>
                	<div align="right">Authorised Sign</div>
                </td>
             </tr>
         </table>
     </article>
</div>