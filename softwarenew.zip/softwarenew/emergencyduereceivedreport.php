<script type="text/javascript" language="javascript">
	function removetablerow8(idvalue){
		var conf = confirm("Do you sure want to delete this ID="+idvalue+" from this Table ");
		if(conf)
			window.location='delete_table_row8.php?idvalue='+idvalue;
		}
</script>
<?php
$searchstr='';
if (isset($_REQUEST['ADate1']) != '' && isset($_REQUEST['ADate2']) != '')
{
	$transactiondatefrom = $_REQUEST['ADate1'];
	$transactiondateto = $_REQUEST['ADate2'];
	
	$emergencyinvoice_patient = $_REQUEST['emergencyinvoice_patient'];
	$emergencyinvoice_id = $_REQUEST['emergencyinvoice_id'];
 	$user = $_REQUEST['user'];
 	if($emergencyinvoice_patient !=''){
		$searchstr .= " and emergencyinvoice_patient like '%$emergencyinvoice_patient%'";
	}
	elseif($emergencyinvoice_id !=''){
		$searchstr .= " and emergencyinvoice_id like '%$emergencyinvoice_id%'";
	}
	elseif($user !=''){
		$searchstr .= " and user like '%$user%'";
	}
}
	else
	{
		$transactiondatefrom = date('Y-m-d', strtotime('-0 day'));
		$transactiondateto = date('Y-m-d');
	}
 
	$datetime1 = new DateTime($transactiondatefrom);
	$datetime2 = new DateTime($transactiondateto);
	$interval = $datetime1->diff($datetime2);
	$totaldays = $interval->format('%a');
	if($datetime1<$datetime2){
		$fromdate = $transactiondatefrom;
		$todate = $transactiondateto;
	}
	else{
		$fromdate = $transactiondateto;
		$todate = $transactiondatefrom;
	}
?>

<table width="100%" cellpadding="2">
  <tr>
    <td valign="top" align="center">
    	<form name="cbform1" method="post" action="index.php?p=emergencyduereceivedreport">
            <table width="1050" align="left" cellpadding="3" bordercolor="#666666">
              <tbody>
                <tr bgcolor="#011E6A">
                  <td colspan="18" bgcolor="#CCCCCC"><strong>Search By..</strong></td>
                </tr>           
                <tr bgcolor="#FFFFFF">
                
               		<?php /*?> <?php if($_SESSION['employeename']=='SUPERADMINISTRATOR'){?><?php */?>
                     <td align="right">Date From:</td>
                    <td>
                        <input name="ADate1" id="ADate1" style="border: 1px solid #001E6A; " value="<?php echo $transactiondatefrom; ?>" size="7" readonly onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate1')" style="cursor:pointer"/>
                    </td>
                    <td>To:</td>
                    <td>
                        <input name="ADate2" id="ADate2" style="border: 1px solid #001E6A;" value="<?php echo $transactiondateto; ?>" size="7" readonly onKeyDown="return disableEnterKey()" />
                        <img src="images/cal.gif" onClick="javascript:NewCssCal('ADate2')" style="cursor:pointer"/>
                    </td>
                    
                   <?php /*?> <?php } ?><?php */?>
                   
                    <td>Inv</td>
            	    <td><input type="text" style="width:40px"  name="emergencyinvoice_id" id="emergencyinvoice_id"/></td>
             		
                 	<td>Name</td>
            	    <td><input type="text" style="width:90px" placeholder="Patient Name" name="emergencyinvoice_patient" id="emergencyinvoice_patient" /></td>
             		
                  	<td>user</td>
            	    <td><input type="text" size="6" placeholder="user" name="user" id="user" /></td>
                 
                 	<td><input style="border: 1px solid #001E6A" type="submit" value="Search" name="Submit" /></td>
                    <td><input name="print" type="button" id="print"  style="border: 1px solid #001E6A" value="Print" onClick="PrintDiv();" />
                    </td>
              	</tr>
              </tbody>
            </table>
		</form>
   	</td>
</tr>

	<td align="center">
      <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1" cellspacing="0" cellpadding="2">
        <tr>
            <td colspan="26" bgcolor="#ccc" align="center" style="color:#03F; border:1px solid #03F;">
                <strong><?php echo $hospitaldata_name;?></strong><br>
                <strong>Statement By Emergency Due Received :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></strong>
            </td>
        </tr>
      
        <tr bgcolor="#096B7F" style="color:#FFF">
            <td>SL</td>
            <td>Bill No.</td>
            <td>Bill Date</td>
            <td>Patient</td>
            <td><strong>Received</strong></td>
            <td >Disc %</td>
            <td><strong>Disc Amount</strong></td>
            <td><strong>Dues</strong></td>
            <td>User</td>
           </tr>
		<?php
		$s='';
		$totalsumemergencyinvoice_subtotal='0.00';
		$totalsumemergencyinvoice_subtotalafterdisc='0.00';
		$totalsumemergencyinvoice_totaldisc='0.00';
		$totalsumemergencyinvoice_receiveamount='0.00';
		$totalsumemergencyinvoice_due='0.00';
		$totalsumemergencyinvoice_subtotalafterdisc='0.00';
		$totalsumemergencyinvoice_pccommission='0.00';
		$totalsumcollection_amount='0.00';
	
		for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
			$sqlst = "select * from emergencycollection where emergencyinvoice_date between '$newfromdate' and '$newtodate'
			 $searchstr order by emergencycollection_id asc";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery &&  mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery)) {
					$emergencycollection_id = $strow['emergencycollection_id'];
                    $emergencyinvoice_id = $strow['emergencyinvoice_id'];
                    $user = $strow['user'];
					$emergencyinvoice_name = $strow['emergencyinvoice_name'];
					$emergencyinvoice_number = $strow['emergencyinvoice_number'];
					$collection_amount=	$strow['collection_amount'];
					$discount_amountp  =	$strow['discount_amountp'];
					$discount_amount  =	$strow['discount_amount'];
					$due  =	$strow['due'];
					$emergencyinvoice_date=	$strow['emergencyinvoice_date'];
				
				$totalsumemergencyinvoice_due  = $totalsumemergencyinvoice_due + $collection_amount;
				?>
                <tr bgcolor="#fff" >
                    <td><?php echo $s=$s+1;?></td>
                    <td><?php echo $emergencyinvoice_id;?></td>
                    <td><?php echo $emergencyinvoice_date;?></td>
                    <td><?php echo $emergencyinvoice_name;?></td>
                    <td><?php echo $collection_amount;?></td>
                    <td><?php echo $discount_amountp;?></td>
                    <td><?php echo $discount_amount;?></td>
                    <td style="color: #00C"><?php echo $due;?></td>
                    <td><?php echo $user;?></td>
                   	</tr>
                <?php
					}
				}
			}
		?>
        	<tr bgcolor="#F2EBEB">
                <td colspan="3">&nbsp;</td>
                <td><strong>Total:</strong></td>
                 <td><strong>Received: <?php echo number_format($totalsumemergencyinvoice_due); ?></strong></td>
                <td colspan="3">&nbsp;</td>
            </tr>
          </table>
     </td>
      
      <tr>
		<td align="center" id="divToPrint" style="display:none">
    		<?php 
            $datetime1 = new DateTime($transactiondatefrom);
            $datetime2 = new DateTime($transactiondateto);
            $interval = $datetime1->diff($datetime2);
            $totaldays = $interval->format('%a');
            if($datetime1<$datetime2){
                $fromdate = $transactiondatefrom;
                $todate = $transactiondateto;
            }
            else{
                $fromdate = $transactiondateto;
                $todate = $transactiondatefrom;
            }
            ?>
            
      
           <table align="center" style="BORDER-COLLAPSE: collapse" width="100%" border="1" cellspacing="0" cellpadding="2">
        <tr>
            <td colspan="26" bgcolor="#ccc" align="center" style="color:#03F; border:1px solid #03F;">
                <strong><?php echo $hospitaldata_name;?></strong><br>
                <strong>Statement By Emergency Due Received :: Date: <?php echo date('d.m.y',strtotime($fromdate)).' to '.date('d.m.y',strtotime($todate));?></strong>
            </td>
        </tr>
      
        <tr bgcolor="#096B7F" style="color:#FFF">
            <td>SL</td>
            <td>INV No.</td>
            <td>INV Date</td>
            <td>Patient</td>
            <td><strong>Received</strong></td>
            <td >Disc</td>
            <td><strong>Dues</strong></td>
            <td>User</td>
           </tr>
		<?php
		$s='';
		$totalsumemergencyinvoice_subtotal='0.00';
		$totalsumemergencyinvoice_subtotalafterdisc='0.00';
		$totalsumemergencyinvoice_totaldisc='0.00';
		$totalsumemergencyinvoice_receiveamount='0.00';
		$totalsumemergencyinvoice_due='0.00';
		$totalsumemergencyinvoice_subtotalafterdisc='0.00';
		$totalsumemergencyinvoice_pccommission='0.00';
		$totalsumcollection_amount='0.00';
	
		for($i=0; $i<=$totaldays; $i++){
			$newfromdate = date('Y-m-d 0:0:0', strtotime($fromdate)+floor($i*86400));
			$newtodate = date('Y-m-d 23:59:59', strtotime($fromdate)+floor($i*86400));
			
			$sqlst = "select * from emergencycollection where  emergencyinvoice_date between '$newfromdate' and '$newtodate' $searchstr order by emergencycollection_id asc";
	  		$stquery = mysqli_query($conn, $sqlst);
			if($stquery &&  mysqli_num_rows($stquery)>0){
			while ($strow = mysqli_fetch_array($stquery)) {
					$emergencycollection_id = $strow['emergencycollection_id'];
                    $emergencyinvoice_id = $strow['emergencyinvoice_id'];
                    $user = $strow['user'];
					$emergencyinvoice_name = $strow['emergencyinvoice_name'];
					$emergencyinvoice_number = $strow['emergencyinvoice_number'];
					$collection_amount=	$strow['collection_amount'];
					$discount_amount  =	$strow['discount_amount'];
					$due  =	$strow['due'];
					$emergencyinvoice_date=	$strow['emergencyinvoice_date'];
				
				$totalsumemergencyinvoice_due  = $totalsumemergencyinvoice_due + $collection_amount;
				?>
                <tr bgcolor="#f5f5f5" >
                    <td><?php echo $s=$s+1;?></td>
                    <td><?php echo $emergencyinvoice_id;?></td>
                    <td><?php echo $emergencyinvoice_date;?></td>
                    <td><?php echo $emergencyinvoice_name;?></td>
                    <td><?php echo $collection_amount;?></td>
                    <td><?php echo $discount_amount;?></td>
                    <td style="color: #00C"><?php echo $due;?></td>
                    <td><?php echo $user;?></td>
                   	</tr>
                <?php
					}
				}
			}
		?>
        	<tr bgcolor="#F2EBEB">
                <td colspan="3">&nbsp;</td>
                <td><strong>Total:</strong></td>
                 <td><strong>Received: <?php echo number_format($totalsumemergencyinvoice_due); ?></strong></td>
                <td colspan="3">&nbsp;</td>
            </tr>
          </table>
        </td>
    </tr>
</table>